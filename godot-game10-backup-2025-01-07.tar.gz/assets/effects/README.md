# Telegraph Effect Placeholders

The TelegraphSystem.gd references these image files:
- telegraph_circle.png - Circle indicator for melee attacks
- telegraph_reticle.png - Targeting reticle for ranged attacks
- telegraph_area.png - Area indicator for AoE attacks
- warning_icon.png - Warning symbol

For now, use icon.svg as placeholder for all of these in the TelegraphSystem.gd