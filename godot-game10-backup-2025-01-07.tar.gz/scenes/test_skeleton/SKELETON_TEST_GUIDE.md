# Skeleton Test Scene Guide

## Overview
This is a test scene for experimenting with Godot's Skeleton2D system, rigging, and animation. Now includes automatic animation generation!

## Scene Structure
- **TestSkeleton.tscn**: Basic skeleton scene with manual controls
- **EnhancedTestSkeleton.tscn**: Enhanced scene with multiple animations
- **TestSkeletonController.gd**: Basic controller script
- **EnhancedSkeletonController.gd**: Enhanced controller with animation system
- **AnimationGenerator.gd**: Procedural animation generator

## Bone Hierarchy
```
Root
├── Spine
│   ├── Chest
│   │   ├── Head
│   │   ├── ArmLeft
│   │   │   ├── ForearmLeft
│   │   │   └── HandLeft
│   │   └── ArmRight
│   │       ├── ForearmRight
│   │       └── HandRight
└── Pelvis
    ├── ThighLeft
    │   ├── ShinLeft
    │   └── FootLeft
    └── ThighRight
        ├── ShinRight
        └── FootRight
```

## Controls
- **Arrow Keys (Left/Right)**: Rotate selected bone
- **Arrow Keys (Up/Down)**: Scale selected bone
- **Tab**: Cycle through bones
- **Space**: Play/Stop idle animation
- **R**: Reset all bones to rest pose

## Features
1. **Complete Humanoid Rig**: 17 bones for full body animation
2. **Interactive Bone Manipulation**: Test rotations and scales in real-time
3. **Idle Animation**: Pre-built breathing animation with subtle movements
4. **Visual Feedback**: Selected bone highlighted in yellow
5. **Polygon Visualization**: Blue polygon shows the "body" shape

## How to Use
1. Open the scene: `scenes/test_skeleton/TestSkeleton.tscn`
2. Run the scene (F6)
3. Use Tab to select different bones
4. Use arrow keys to manipulate selected bone
5. Press Space to see the idle animation
6. Press R to reset the pose

## Animation System
The scene includes an AnimationPlayer with a basic idle animation that features:
- Chest breathing (scale animation)
- Head tilting (rotation animation)
- Arm swaying (rotation animation)

## Extending the System
To add more animations:
1. Select the AnimationPlayer node
2. Create new animation
3. Add tracks for bone properties (position, rotation, scale)
4. Use the bone paths shown in the script

## Enhanced Features

### Automatic Animation System
The enhanced version includes 11 pre-built animations:
1. **Idle** - Breathing and subtle movements
2. **Walk** - Full walking cycle with arm swing
3. **Jump** - Crouch and leap animation
4. **Dance** - Hip sway and arm waves
5. **Wave** - Wave motion through skeleton
6. **Random Mild** - Gentle random movements
7. **Random Medium** - Moderate random movements
8. **Random Wild** - Extreme random movements
9-11. **Custom Slots** - Regeneratable random animations

### Animation Generator Features
- **Procedural Generation**: Creates animations automatically
- **Bone Constraints**: Respects anatomical limits
- **Intensity Control**: Adjustable animation strength
- **Wave Propagation**: Creates flowing movements
- **Random Variation**: Generates unique animations each time

### How to Use Enhanced Version
1. Open `scenes/test_skeleton/EnhancedTestSkeleton.tscn`
2. Run the scene (F6)
3. Press number keys 1-9 to play different animations
4. Press 0 to regenerate all random animations
5. Use Tab to select bones for manual control

## Next Steps
- Add sprite/texture binding to bones
- Implement IK (Inverse Kinematics) chains
- Create animation blending system
- Add physics-based secondary motion
- Export animations for use in game characters
- Create animation state machine