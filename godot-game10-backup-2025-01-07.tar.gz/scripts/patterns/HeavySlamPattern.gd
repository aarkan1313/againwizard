# HeavySlamPattern.gd
# Heavy pattern - slow approach, long telegraph, devastating AoE attack
extends EnemyAttackPattern
class_name HeavySlamPattern

# Heavy-specific properties
var slam_radius: float = 120.0
var shockwave_speed: float = 200.0
var ground_shake_intensity: float = 10.0
var windup_movement_penalty: float = 0.3  # Movement speed during telegraph
var is_slam_charging: bool = false

func _ready():
	super._ready()
	
	# Heavy configuration - everything is slower but more powerful
	attack_range = 80.0
	telegraph_duration = 1.2  # Long windup
	attack_duration = 0.4    # Impact duration
	recovery_duration = 0.8  # Long recovery - vulnerable window
	reposition_duration = 0.6
	
	# Tank behavior
	preferred_distance = 60.0
	comfort_zone = 120.0  # Needs more space
	pursuit_speed_multiplier = 0.7  # Slow approach
	retreat_speed_multiplier = 0.5  # Very slow retreat

func handle_idle_state(delta):
	super.handle_idle_state(delta)
	
	# Heavy units are less aggressive but persistent
	if can_see_target() and is_target_in_aggro_range():
		# Announce presence with a roar/stomp
		announce_aggro()
		transition_to_state(PatternState.PURSUING)

func handle_pursuing_state(delta):
	var distance = enemy.global_position.distance_to(target.global_position)
	
	# Steady, intimidating approach
	if distance <= attack_range * 1.5:  # Start preparing early
		# Check if we have room for slam
		if has_room_for_slam():
			transition_to_state(PatternState.POSITIONING)
		else:
			# Push through other enemies
			move_toward_target_pushing(pursuit_speed_multiplier)
	else:
		# Menacing march
		move_toward_target(pursuit_speed_multiplier)
		
		# Periodic stomps while approaching
		if int(Time.get_ticks_msec() / 1000.0) % 2 == 0:
			create_march_effect()

func handle_positioning_state(delta):
	# Heavy units need good positioning for their big attacks
	var distance = enemy.global_position.distance_to(target.global_position)
	
	if distance <= attack_range and has_room_for_slam():
		# Perfect! Begin the slam
		transition_to_state(PatternState.TELEGRAPHING)
	elif distance > attack_range:
		# Get closer
		move_toward_target_pushing(pursuit_speed_multiplier)
	else:
		# Need more room - push allies away
		clear_slam_area()

func handle_telegraphing_state(delta):
	# Epic windup for heavy slam
	is_slam_charging = true
	attack_committed = true
	
	# Slow movement during windup
	if target:
		var to_target = (target.global_position - enemy.global_position).normalized()
		enemy.velocity = to_target * enemy.speed * windup_movement_penalty
		enemy.move_and_slide()
	
	# Visual buildup
	var charge_progress = 1.0 - (state_timer / telegraph_duration)
	
	# Raise weapon/fist
	enemy.scale = Vector2(1.0 + charge_progress * 0.3, 1.0 + charge_progress * 0.3)
	enemy.modulate = lerp(Color.WHITE, Color(1.5, 0.5, 0.5), charge_progress)
	
	# Ground effects
	if charge_progress > 0.3:
		create_charge_ground_cracks(charge_progress)
	
	# Screen shake buildup
	if charge_progress > 0.7:
		if GameEvents:
			GameEvents.emit_signal("screen_shake_requested", charge_progress * 5.0, 0.1)
	
	if state_timer <= 0:
		transition_to_state(PatternState.EXECUTING)

func handle_executing_state(delta):
	if state_timer == attack_duration:  # First frame
		execute_slam()
		is_slam_charging = false
	
	# Stuck in place during slam
	enemy.velocity = Vector2.ZERO
	enemy.move_and_slide()
	
	# Continue ground effects
	create_slam_shockwave_visual(1.0 - state_timer / attack_duration)
	
	if state_timer <= 0:
		transition_to_state(PatternState.RECOVERING)

func handle_recovering_state(delta):
	# Completely vulnerable during recovery
	enemy.modulate = Color(0.7, 0.7, 0.7)  # Darkened to show vulnerability
	enemy.scale = Vector2(0.9, 0.9)  # Slightly smaller - exhausted
	
	# Can't move during recovery
	enemy.velocity = Vector2.ZERO
	enemy.move_and_slide()
	
	if state_timer <= 0:
		# Return to normal
		enemy.modulate = Color.WHITE
		enemy.scale = Vector2(1.0, 1.0)
		transition_to_state(PatternState.REPOSITIONING)

func handle_repositioning_state(delta):
	# After heavy attack, slowly reposition
	match pattern_variation:
		0:  # Stand ground
			enemy.velocity = Vector2.ZERO
		1:  # Slow retreat
			move_away_from_target(retreat_speed_multiplier * 0.5)
		2:  # Turn to face target
			aim_at_target_slowly()
	
	if state_timer <= 0:
		transition_to_state(PatternState.IDLE)

# Heavy-specific functions
func has_room_for_slam() -> bool:
	# Check if there's enough space for the slam AoE
	var nearby_allies = get_all_nearby_enemies(slam_radius * 0.8)
	return nearby_allies.size() < 2  # Don't slam if too many allies nearby

func move_toward_target_pushing(speed_mult: float):
	# Heavy units push lighter enemies aside
	move_toward_target(speed_mult)
	
	# Push nearby enemies
	for other in get_all_nearby_enemies(comfort_zone):
		if "mass" in other and other.mass < enemy.mass:
			var push_direction = (other.global_position - enemy.global_position).normalized()
			var push_force = (comfort_zone - enemy.global_position.distance_to(other.global_position)) * 2.0
			
			if other.has_method("apply_push"):
				other.apply_push(push_direction * push_force)

func clear_slam_area():
	# Push allies out of slam radius
	for other in get_all_nearby_enemies(slam_radius):
		var push_direction = (other.global_position - enemy.global_position).normalized()
		var push_force = 150.0
		
		if other.has_method("apply_push"):
			other.apply_push(push_direction * push_force)

func execute_slam():
	# Devastating area attack
	create_slam_impact_effect()
	
	# Screen shake
	if GameEvents:
		GameEvents.emit_signal("screen_shake_requested", ground_shake_intensity, 0.5)
	
	# Damage in radius
	var bodies_in_radius = get_bodies_in_radius(enemy.global_position, slam_radius)
	for body in bodies_in_radius:
		if body.has_method("take_damage"):
			var distance = enemy.global_position.distance_to(body.global_position)
			var damage_falloff = 1.0 - (distance / slam_radius) * 0.3  # 70% damage at edge
			var final_damage = calculate_damage() * damage_falloff
			
			body.take_damage(final_damage, enemy, "heavy_slam")
			
			# Knockback
			if body.has_method("apply_knockback"):
				var knockback_direction = (body.global_position - enemy.global_position).normalized()
				var knockback_force = (1.0 - distance / slam_radius) * 300.0
				body.apply_knockback(knockback_direction * knockback_force)
	
	# Create shockwave
	create_expanding_shockwave()

func get_bodies_in_radius(center: Vector2, radius: float) -> Array:
	var bodies = []
	# Check all potential targets
	for target in get_tree().get_nodes_in_group("player"):
		if center.distance_to(target.global_position) <= radius:
			bodies.append(target)
	return bodies

func announce_aggro():
	# Heavy enemy announcement effect
	enemy.scale = Vector2(1.2, 1.2)
	var tween = get_tree().create_tween()
	tween.tween_property(enemy, "scale", Vector2(1.0, 1.0), 0.3).set_ease(Tween.EASE_OUT)
	
	# Roar/stomp effect
	create_stomp_effect(enemy.global_position)

func aim_at_target_slowly():
	if not target:
		return
	
	# Slowly turn to face target
	var to_target = target.global_position - enemy.global_position
	var target_angle = to_target.angle()
	enemy.rotation = lerp_angle(enemy.rotation, target_angle, 0.05)

func create_march_effect():
	# Footstep/march effect
	var effect = preload("res://scenes/effects/HeavyFootstep.tscn").instantiate()
	get_tree().current_scene.add_child(effect)
	effect.global_position = enemy.global_position
	
	var tween = get_tree().create_tween()
	tween.tween_property(effect, "modulate:a", 0, 0.5)
	tween.tween_callback(effect.queue_free)

func create_charge_ground_cracks(progress: float):
	# Ground cracking during charge
	if randf() < progress * 0.3:  # More cracks as charge progresses
		var crack = preload("res://scenes/effects/GroundCrack.tscn").instantiate()
		get_tree().current_scene.add_child(crack)
		
		var offset = Vector2(randf_range(-50, 50), randf_range(-50, 50))
		crack.global_position = enemy.global_position + offset
		crack.modulate = Color(1, 1, 1, progress)
		
		# Fade out
		var tween = get_tree().create_tween()
		tween.tween_property(crack, "modulate:a", 0, 2.0)
		tween.tween_callback(crack.queue_free)

func create_slam_impact_effect():
	# Major impact effect
	var impact = preload("res://scenes/effects/HeavySlamImpact.tscn").instantiate()
	get_tree().current_scene.add_child(impact)
	impact.global_position = enemy.global_position
	impact.scale = Vector2(slam_radius / 100.0, slam_radius / 100.0)
	
	# Dust clouds
	for i in range(8):
		var angle = i * PI / 4
		create_dust_burst(enemy.global_position, Vector2(cos(angle), sin(angle)))

func create_expanding_shockwave():
	# Visual shockwave ring
	var shockwave = preload("res://scenes/effects/Shockwave.tscn").instantiate()
	get_tree().current_scene.add_child(shockwave)
	shockwave.global_position = enemy.global_position
	
	# Expand outward
	var tween = get_tree().create_tween()
	tween.tween_property(shockwave, "scale", Vector2(slam_radius / 50.0, slam_radius / 50.0), 0.5)
	tween.parallel().tween_property(shockwave, "modulate:a", 0, 0.5)
	tween.tween_callback(shockwave.queue_free)

func create_dust_burst(pos: Vector2, direction: Vector2):
	var dust = preload("res://scenes/effects/DustBurst.tscn").instantiate()
	get_tree().current_scene.add_child(dust)
	dust.global_position = pos
	
	var tween = get_tree().create_tween()
	tween.tween_property(dust, "global_position", pos + direction * 100, 0.8)
	tween.parallel().tween_property(dust, "modulate:a", 0, 0.8)
	tween.tween_callback(dust.queue_free)

func create_slam_shockwave_visual(progress: float):
	# Continuing ground effects during slam
	if randf() < 0.3:
		var debris = preload("res://scenes/effects/GroundDebris.tscn").instantiate()
		get_tree().current_scene.add_child(debris)
		
		var random_offset = Vector2(randf_range(-slam_radius, slam_radius), randf_range(-slam_radius, slam_radius)) * progress
		debris.global_position = enemy.global_position + random_offset
		
		# Launch debris
		var tween = get_tree().create_tween()
		tween.tween_property(debris, "position:y", debris.position.y - 50, 0.3)
		tween.tween_property(debris, "position:y", debris.position.y, 0.3)
		tween.parallel().tween_property(debris, "modulate:a", 0, 0.6)
		tween.tween_callback(debris.queue_free)

func create_stomp_effect(pos: Vector2):
	# Intimidation effect
	create_dust_burst(pos, Vector2.UP)
	
	# Small screen shake
	if GameEvents:
		GameEvents.emit_signal("screen_shake_requested", 3.0, 0.2)

func create_telegraph_effect():
	# Heavy attack telegraph - ground target area
	var area_indicator = preload("res://scenes/effects/SlamAreaIndicator.tscn").instantiate()
	get_tree().current_scene.add_child(area_indicator)
	area_indicator.global_position = enemy.global_position
	area_indicator.scale = Vector2(slam_radius / 100.0, slam_radius / 100.0)
	
	# Pulse and intensify
	var tween = get_tree().create_tween()
	tween.set_loops()
	tween.tween_property(area_indicator, "modulate", Color(1.5, 0.5, 0.5, 0.8), 0.3)
	tween.tween_property(area_indicator, "modulate", Color(1.0, 0.3, 0.3, 0.6), 0.3)
	
	# Cleanup after telegraph
	get_tree().create_timer(telegraph_duration).timeout.connect(func():
		tween.kill()
		area_indicator.queue_free()
	)

func get_attack_cooldown() -> float:
	# Heavy attacks have long cooldowns
	match enemy.enemy_type:
		"golem":
			return 4.0
		"orc":
			return 3.0
		_:
			return 3.5

func calculate_damage() -> float:
	var base_damage = super.calculate_damage()
	
	# Heavy attacks do massive damage
	match enemy.enemy_type:
		"golem":
			return base_damage * 2.5
		"orc":
			return base_damage * 1.8
		_:
			return base_damage * 2.0

func get_attack_type() -> String:
	return "heavy_slam"
