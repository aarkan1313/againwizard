# RangedKitePattern.gd
# Ranged pattern - maintains distance, fires projectiles, repositions
extends EnemyAttackPattern
class_name RangedKitePattern

# Ranged-specific properties
var ideal_range: float = 120.0
var minimum_range: float = 80.0
var projectile_speed: float = 300.0
var aim_prediction: bool = true
var shots_before_reposition: int = 2
var shots_fired: int = 0

func _ready():
    super._ready()
    
    # Ranged configuration
    attack_range = 150.0
    telegraph_duration = 0.6
    attack_duration = 0.1
    recovery_duration = 0.4
    reposition_duration = 0.8
    
    # Kiting behavior
    preferred_distance = ideal_range
    comfort_zone = 100.0  # Keep distance from allies
    pursuit_speed_multiplier = 0.9  # Cautious approach
    retreat_speed_multiplier = 1.1  # Quick retreat

func handle_idle_state(delta):
    super.handle_idle_state(delta)
    
    # Ranged enemies are more aware
    if can_see_target() and is_target_in_aggro_range():
        # Check current distance before engaging
        var distance = enemy.global_position.distance_to(target.global_position)
        if distance < minimum_range:
            transition_to_state(PatternState.REPOSITIONING)
        else:
            transition_to_state(PatternState.POSITIONING)

func handle_pursuing_state(delta):
    # Ranged units don't pursue - they position
    transition_to_state(PatternState.POSITIONING)

func handle_positioning_state(delta):
    var distance = enemy.global_position.distance_to(target.global_position)
    
    # Maintain ideal distance
    if distance < minimum_range:
        # Too close! Back up
        move_away_from_target(retreat_speed_multiplier)
    elif distance > attack_range:
        # Too far, carefully approach
        move_toward_target(pursuit_speed_multiplier * 0.7)
    elif abs(distance - ideal_range) < 20 and can_see_target():
        # Good position, prepare to fire
        transition_to_state(PatternState.TELEGRAPHING)
    else:
        # Adjust position
        find_firing_position()

func handle_telegraphing_state(delta):
    super.handle_telegraphing_state(delta)
    
    # Aim at target with prediction
    aim_at_target()
    
    # Visual: charging effect
    var charge_progress = 1.0 - (state_timer / telegraph_duration)
    enemy.modulate = Color(1.0, 1.0 - charge_progress * 0.5, 1.0 - charge_progress * 0.5)
    
    # Create aiming line
    if charge_progress > 0.5:
        show_aim_line()

func handle_executing_state(delta):
    if state_timer == attack_duration:  # First frame
        fire_projectile()
        shots_fired += 1
    
    # No movement during firing
    enemy.velocity = Vector2.ZERO
    enemy.move_and_slide()
    
    if state_timer <= 0:
        transition_to_state(PatternState.RECOVERING)

func handle_recovering_state(delta):
    super.handle_recovering_state(delta)
    
    # Slight backward movement while recovering
    move_away_from_target(retreat_speed_multiplier * 0.3)
    
    # Turn to keep facing target
    aim_at_target()

func handle_repositioning_state(delta):
    # After firing, reposition based on pattern
    match pattern_variation:
        0:  # Lateral movement
            strafe_to_new_position()
        1:  # Fall back
            move_away_from_target(retreat_speed_multiplier)
        2:  # Find cover (if available)
            move_to_cover()
    
    if state_timer <= 0:
        # Check if we should fire again or reposition more
        if shots_fired >= shots_before_reposition:
            shots_fired = 0
            transition_to_state(PatternState.IDLE)
        elif is_in_good_firing_position():
            transition_to_state(PatternState.TELEGRAPHING)
        else:
            transition_to_state(PatternState.POSITIONING)

# Ranged-specific functions
func find_firing_position():
    # Look for a good spot to shoot from
    var current_distance = enemy.global_position.distance_to(target.global_position)
    
    # Check multiple angles for clear shot
    var best_position = null
    var best_score = -1.0
    
    for angle in range(0, 360, 45):
        var test_offset = Vector2(cos(deg_to_rad(angle)), sin(deg_to_rad(angle))) * 50
        var test_pos = enemy.global_position + test_offset
        var score = evaluate_firing_position(test_pos)
        
        if score > best_score:
            best_score = score
            best_position = test_pos
    
    if best_position:
        var move_direction = (best_position - enemy.global_position).normalized()
        enemy.velocity = move_direction * enemy.speed * pursuit_speed_multiplier * 0.8
        enemy.move_and_slide()
    else:
        # Can't find good position, strafe
        strafe_around_target()

func evaluate_firing_position(pos: Vector2) -> float:
    var score = 0.0
    
    # Check line of sight from position
    if has_clear_shot_from(pos):
        score += 50.0
    
    # Check distance to target
    var distance = pos.distance_to(target.global_position)
    if abs(distance - ideal_range) < 20:
        score += 30.0
    elif distance >= minimum_range and distance <= attack_range:
        score += 10.0
    
    # Check crowding
    var crowd_penalty = 0.0
    for other in get_all_nearby_enemies(comfort_zone):
        var other_distance = pos.distance_to(other.global_position)
        if other_distance < comfort_zone:
            crowd_penalty += (comfort_zone - other_distance) / comfort_zone * 20.0
    score -= crowd_penalty
    
    return score

func has_clear_shot_from(pos: Vector2) -> bool:
    var space_state = enemy.get_world_2d().direct_space_state
    var query = PhysicsRayQueryParameters2D.create(
        pos,
        target.global_position,
        4  # Environment layer
    )
    var result = space_state.intersect_ray(query)
    return result.is_empty()

func is_in_good_firing_position() -> bool:
    var distance = enemy.global_position.distance_to(target.global_position)
    return distance >= minimum_range and distance <= attack_range and can_see_target() and !is_position_crowded()

func aim_at_target():
    if not target:
        return
    
    # Face target
    var to_target = target.global_position - enemy.global_position
    enemy.rotation = to_target.angle()  # Assuming enemy can rotate

func show_aim_line():
    # Visual indicator of where shot will go
    # This would create a line renderer or sprite in actual implementation
    pass

func fire_projectile():
    if not target:
        return
    
    # Calculate aim direction with prediction
    var aim_direction = calculate_aim_direction()
    
    # Spawn projectile
    var projectile = preload("res://scenes/projectiles/EnemyProjectile.tscn").instantiate()
    get_tree().current_scene.add_child(projectile)
    projectile.global_position = enemy.global_position
    
    # Initialize projectile
    if projectile.has_method("initialize"):
        projectile.initialize(aim_direction, projectile_speed, calculate_damage(), enemy)
    else:
        # Fallback for basic projectile
        projectile.velocity = aim_direction * projectile_speed
        projectile.damage = calculate_damage()
    
    # Visual/audio feedback
    create_muzzle_flash()
    # AudioManager.play_sfx("enemy_shoot")

func calculate_aim_direction() -> Vector2:
    if not target:
        return Vector2.RIGHT
    
    var to_target = target.global_position - enemy.global_position
    
    if aim_prediction and "velocity" in target:
        # Predict where target will be
        var time_to_impact = to_target.length() / projectile_speed
        var predicted_pos = target.global_position + target.velocity * time_to_impact * 0.8  # 80% prediction
        to_target = predicted_pos - enemy.global_position
    
    return to_target.normalized()

func strafe_to_new_position():
    # Move laterally while maintaining distance
    var to_target = (target.global_position - enemy.global_position).normalized()
    var strafe_direction = to_target.rotated(PI/2 * (1 if shots_fired % 2 == 0 else -1))
    
    enemy.velocity = strafe_direction * enemy.speed * retreat_speed_multiplier
    enemy.move_and_slide()

func move_to_cover():
    # Look for environmental cover (simplified version)
    # In full implementation, would check for cover points
    strafe_to_new_position()  # Fallback to strafing

func create_telegraph_effect():
    # Ranged telegraph - aiming indicator
    var effect = preload("res://scenes/effects/RangedTelegraph.tscn").instantiate()
    get_tree().current_scene.add_child(effect)
    effect.global_position = enemy.global_position
    effect.rotation = (target.global_position - enemy.global_position).angle()
    
    # Pulse effect
    var tween = get_tree().create_tween()
    tween.set_loops(int(telegraph_duration / 0.3))
    tween.tween_property(effect, "modulate", Color(1, 0.5, 0.5), 0.15)
    tween.tween_property(effect, "modulate", Color(1, 1, 0), 0.15)
    
    # Cleanup
    get_tree().create_timer(telegraph_duration).timeout.connect(effect.queue_free)

func create_attack_effect():
    create_muzzle_flash()

func create_muzzle_flash():
    # Muzzle flash effect
    var effect = preload("res://scenes/effects/MuzzleFlash.tscn").instantiate()
    get_tree().current_scene.add_child(effect)
    effect.global_position = enemy.global_position
    effect.rotation = enemy.rotation
    
    # Quick flash
    var tween = get_tree().create_tween()
    tween.tween_property(effect, "scale", Vector2(1.5, 1.5), 0.05)
    tween.tween_property(effect, "modulate:a", 0, 0.1)
    tween.tween_callback(effect.queue_free)

func get_attack_cooldown() -> float:
    # Varies by enemy type
    match enemy.enemy_type:
        "skeleton":
            return 1.8
        "wizard":
            return 2.5
        _:
            return 2.0

func calculate_damage() -> float:
    var base_damage = super.calculate_damage()
    
    # Ranged attacks often do less damage but are harder to avoid
    match enemy.enemy_type:
        "skeleton":
            return base_damage * 0.7
        "wizard":
            return base_damage * 1.2
        _:
            return base_damage * 0.9

func get_attack_type() -> String:
    return "ranged_projectile"