# MeleeRushPattern.gd
# Aggressive melee pattern - rushes in, attacks, brief retreat
extends EnemyAttackPattern
class_name MeleeRushPattern

# Melee-specific configuration
func _ready():
    super._ready()
    
    # Fast, aggressive pattern
    attack_range = 45.0
    telegraph_duration = 0.3
    attack_duration = 0.15
    recovery_duration = 0.2
    reposition_duration = 0.4
    
    # Aggressive behavior
    preferred_distance = 40.0
    comfort_zone = 60.0  # Comfortable getting close
    pursuit_speed_multiplier = 1.3  # Rushes in fast
    retreat_speed_multiplier = 0.6  # Slower retreat

# Override: Aggressive pursuit
func handle_pursuing_state(delta):
    var distance = enemy.global_position.distance_to(target.global_position)
    
    # Rush in fast when far away
    if distance > attack_range * 2:
        move_toward_target(pursuit_speed_multiplier * 1.2)  # Extra fast approach
    elif distance <= attack_range:
        # In range! Check if we can attack
        if can_attack_from_position():
            transition_to_state(PatternState.TELEGRAPHING)
        else:
            transition_to_state(PatternState.POSITIONING)
    else:
        # Normal approach
        move_toward_target(pursuit_speed_multiplier)
    
    # Add slight zigzag movement for variety
    if pattern_variation == 1:
        add_zigzag_movement()

func handle_positioning_state(delta):
    # Quick positioning - melee enemies don't need perfect spots
    if state_timer <= 0:
        state_timer = 0.2  # Quick position check
    
    # Try to flank if crowded
    if is_position_crowded():
        flank_target()
    elif is_in_attack_position():
        transition_to_state(PatternState.TELEGRAPHING)
    else:
        # Get closer
        move_toward_target(pursuit_speed_multiplier * 0.8)

func handle_telegraphing_state(delta):
    super.handle_telegraphing_state(delta)
    
    # Melee telegraph: lean back before strike
    var lean_amount = state_timer / telegraph_duration
    var lean_offset = (enemy.global_position - target.global_position).normalized() * 10 * lean_amount
    
    # Visual lean back (would need sprite offset in actual implementation)
    enemy.modulate = Color(1.0, 1.0 - lean_amount * 0.3, 1.0 - lean_amount * 0.3)

func handle_executing_state(delta):
    # Lunge forward during attack!
    if state_timer == attack_duration:  # First frame of attack
        execute_lunge_attack()
    
    # Continue moving forward during attack
    var lunge_direction = (target.global_position - enemy.global_position).normalized()
    enemy.velocity = lunge_direction * enemy.speed * 2.0  # Double speed lunge
    enemy.move_and_slide()
    
    if state_timer <= 0:
        transition_to_state(PatternState.RECOVERING)

func handle_recovering_state(delta):
    super.handle_recovering_state(delta)
    
    # Slight backward movement during recovery
    move_away_from_target(retreat_speed_multiplier * 0.5)

func handle_repositioning_state(delta):
    # After attack, circle strafe or retreat based on pattern
    match pattern_variation:
        0:  # Circle strafe
            strafe_around_target()
        1:  # Quick retreat
            move_away_from_target(retreat_speed_multiplier)
        2:  # Stand ground briefly
            enemy.velocity = Vector2.ZERO
            enemy.move_and_slide()
    
    if state_timer <= 0:
        # 30% chance to immediately attack again if still in range
        if randf() < 0.3 and is_in_attack_position() and !is_attack_on_cooldown():
            transition_to_state(PatternState.TELEGRAPHING)
        else:
            transition_to_state(PatternState.IDLE)

# Melee-specific functions
func can_attack_from_position() -> bool:
    if not target:
        return false
    
    var distance = enemy.global_position.distance_to(target.global_position)
    var has_clear_path = !is_path_blocked()
    
    return distance <= attack_range and has_clear_path and !is_attack_on_cooldown()

func is_path_blocked() -> bool:
    # Check if another enemy is directly between us and target
    var to_target = target.global_position - enemy.global_position
    var distance = to_target.length()
    to_target = to_target.normalized()
    
    for other in get_all_nearby_enemies(distance):
        var to_other = other.global_position - enemy.global_position
        var dot = to_target.dot(to_other.normalized())
        
        if dot > 0.9 and to_other.length() < distance:  # Other enemy in the way
            return true
    
    return false

func flank_target():
    # Try to attack from the side
    var to_target = (target.global_position - enemy.global_position).normalized()
    var flank_direction = to_target.rotated(PI/3 * (1 if randf() > 0.5 else -1))
    
    enemy.velocity = flank_direction * enemy.speed * pursuit_speed_multiplier
    enemy.move_and_slide()

func add_zigzag_movement():
    # Add slight side-to-side movement while approaching
    var zigzag = sin(Time.get_ticks_msec() / 200.0) * 30.0
    var perpendicular = enemy.velocity.normalized().rotated(PI/2)
    enemy.velocity += perpendicular * zigzag

func execute_lunge_attack():
    # Deal damage in a small arc in front
    if not target:
        return
    
    var attack_center = enemy.global_position + (target.global_position - enemy.global_position).normalized() * 30
    var enemies_hit = []
    
    # Check all potential targets in arc
    for potential_target in get_tree().get_nodes_in_group("player"):  # Could hit player
        var to_target = potential_target.global_position - attack_center
        if to_target.length() <= attack_range:
            if potential_target.has_method("take_damage"):
                var damage = calculate_damage()
                potential_target.take_damage(damage, enemy, "melee_lunge")
                enemies_hit.append(potential_target)
    
    # Visual feedback
    create_slash_effect(attack_center)
    
    # Audio would go here
    # AudioManager.play_sfx("melee_slash")

func create_telegraph_effect():
    # Create warning effect for melee attack
    var effect = preload("res://scenes/effects/MeleeTelegraph.tscn").instantiate()
    get_tree().current_scene.add_child(effect)
    effect.global_position = enemy.global_position
    effect.scale = Vector2(attack_range / 50.0, attack_range / 50.0)
    
    # Auto cleanup
    effect.modulate = Color(1, 1, 0, 0.5)
    var tween = get_tree().create_tween()
    tween.tween_property(effect, "modulate:a", 0.8, telegraph_duration)
    tween.tween_callback(effect.queue_free)

func create_attack_effect():
    create_slash_effect(enemy.global_position)

func create_slash_effect(position: Vector2):
    # Create slash visual effect
    var effect = preload("res://scenes/effects/MeleeSlash.tscn").instantiate()
    get_tree().current_scene.add_child(effect)
    effect.global_position = position
    effect.rotation = (target.global_position - enemy.global_position).angle()
    
    # Animate and cleanup
    var tween = get_tree().create_tween()
    tween.tween_property(effect, "scale", Vector2(2, 2), 0.2)
    tween.parallel().tween_property(effect, "modulate:a", 0, 0.2)
    tween.tween_callback(effect.queue_free)

func get_attack_cooldown() -> float:
    # Varies by enemy type
    match enemy.enemy_type:
        "goblin":
            return 1.0
        "orc":
            return 2.2
        _:
            return 1.5

func calculate_damage() -> float:
    var base_damage = super.calculate_damage()
    
    # Melee attacks do consistent damage
    match enemy.enemy_type:
        "goblin":
            return base_damage * 0.8  # Quick but weaker
        "orc":
            return base_damage * 1.5  # Slow but powerful
        _:
            return base_damage

func get_attack_type() -> String:
    return "melee_rush"