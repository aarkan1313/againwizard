# XPOrb.gd
# Experience orb dropped by enemies
extends Area2D

@export var xp_value: int = 10
@export var magnet_range: float = 150.0
@export var magnet_speed: float = 400.0

@onready var pickup_timer: Timer = $PickupTimer
@onready var sprite: Sprite2D = $Sprite2D

var can_pickup: bool = false
var target_player: Node2D = null

func _ready():
	body_entered.connect(_on_body_entered)
	pickup_timer.timeout.connect(_on_pickup_timer_timeout)
	
	# Set initial properties
	scale = Vector2(0.5, 0.5)
	
	# Spawn animation
	var tween = create_tween()
	tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.3).set_ease(Tween.EASE_OUT)
	
	# Floating animation
	var float_tween = create_tween()
	float_tween.set_loops()
	float_tween.tween_property(sprite, "position:y", -5, 1.0)
	float_tween.tween_property(sprite, "position:y", 5, 1.0)

func _on_pickup_timer_timeout():
	can_pickup = true

func _physics_process(delta):
	if not can_pickup:
		return
	
	# Check for nearby player
	var player = get_player_in_range()
	if player:
		# Magnet effect - move toward player
		var direction = (player.global_position - global_position).normalized()
		global_position += direction * magnet_speed * delta
		
		# Speed up as we get closer
		var distance = global_position.distance_to(player.global_position)
		if distance < 50:
			magnet_speed = 600.0

func get_player_in_range() -> Node2D:
	var players = get_tree().get_nodes_in_group("player")
	for player in players:
		if global_position.distance_to(player.global_position) < magnet_range:
			return player
	return null

func _on_body_entered(body):
	if not can_pickup:
		return
	
	if body.is_in_group("player"):
		collect(body)

func collect(player: Node2D):
	# Award XP
	if GameEvents:
		GameEvents.emit_signal("xp_collected", xp_value)
	
	# Visual effect
	var tween = create_tween()
	tween.parallel().tween_property(self, "scale", Vector2(1.5, 1.5), 0.1)
	tween.parallel().tween_property(self, "modulate:a", 0, 0.1)
	tween.tween_callback(queue_free)
	
	# Disable collision
	set_deferred("monitoring", false)
