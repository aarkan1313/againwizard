extends Node
# StatAllocationManager_UIFixed.gd - Enhanced with proper UI update triggers
# Purpose: Singleton manager for stat allocation UI integration with fixed UI consistency
# Godot Version: 4.4.1 (verified via official docs)
# FIXED: Proper HealthComponent and UI updates after stat allocation

# === SIGNAL DEFINITIONS ===
signal allocation_panel_opened()
signal allocation_panel_closed()
signal stats_allocated(allocations: Dictionary)

# === REFERENCES ===
var stat_allocation_ui: Control = null
var player_stat_sheet: PlayerStatSheet = null
var is_panel_open: bool = false

# Scene path for the stat allocation UI
const STAT_ALLOCATION_UI_SCENE = "res://scenes/ui/stats/StatAllocationUI.tscn"

func _ready() -> void:
	print("📊 StatAllocationManager singleton initialized")
	
	# Set process mode to always run (important for pause handling)
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	# Enable input processing
	set_process_unhandled_input(true)
	
	# Connect to player stat sheet for level up notifications
	# Will connect when player is found
	print("🔗 StatAllocationManager ready - will connect to player when available")
	print("📊 Press TAB to open stat allocation panel")

# === INPUT HANDLING ===
func _unhandled_input(event: InputEvent) -> void:
	# Handle TAB key press
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_TAB:
			_handle_character_sheet_input()
			get_viewport().set_input_as_handled()

# Manual input check function for external use
func check_character_sheet_input() -> void:
	if InputHandler and InputHandler.is_character_sheet_pressed():
		_handle_character_sheet_input()

func _handle_character_sheet_input() -> void:
	if is_panel_open:
		close_stat_allocation_panel()
	else:
		open_stat_allocation_panel()

# === PUBLIC INTERFACE ===

# Open the stat allocation panel
func open_stat_allocation_panel() -> void:
	if is_panel_open:
		print("⚠️ Stat allocation panel already open")
		return
	
	# Find the player stat sheet
	if not _find_player_stat_sheet():
		push_error("StatAllocationManager: Cannot find PlayerStatSheet")
		return
	
	# Check if player has available stat points
	if player_stat_sheet.available_stat_points <= 0:
		print("⚠️ No stat points available for allocation")
		_show_no_points_message()
		return
	
	# Load and setup the UI
	if not _setup_stat_allocation_ui():
		push_error("StatAllocationManager: Failed to setup stat allocation UI")
		return
	
	# Open the panel
	stat_allocation_ui.open_allocation_panel(player_stat_sheet)
	is_panel_open = true
	
	# Emit signal
	allocation_panel_opened.emit()
	
	print("📊 Stat allocation panel opened")

# Close the stat allocation panel
func close_stat_allocation_panel() -> void:
	if not is_panel_open:
		return
	
	if stat_allocation_ui:
		stat_allocation_ui.close_allocation_panel()
	
	is_panel_open = false
	
	# Emit signal
	allocation_panel_closed.emit()
	
	print("📊 Stat allocation panel closed")

# === PRIVATE METHODS ===

# Find the player's stat sheet
func _find_player_stat_sheet() -> bool:
	# Try to find the player entity
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("⚠️ StatAllocationManager: Player not found")
		return false
	
	# Try to get the stat sheet from the player
	var stat_sheet = null
	
	# Check if player has a direct stat_sheet property
	if player.has_method("get_stat_sheet"):
		stat_sheet = player.get_stat_sheet()
	elif "stat_sheet" in player:
		stat_sheet = player.stat_sheet
	
	# If not found, try looking for StatSheet component
	if not stat_sheet:
		stat_sheet = player.get_node_or_null("StatSheet")
	
	# If still not found, try PlayerStatSheet component
	if not stat_sheet:
		stat_sheet = player.get_node_or_null("PlayerStatSheet")
	
	if not stat_sheet:
		print("⚠️ StatAllocationManager: PlayerStatSheet not found on player")
		return false
	
	player_stat_sheet = stat_sheet
	print("✅ Found PlayerStatSheet:", player_stat_sheet)
	return true

# Setup the stat allocation UI
func _setup_stat_allocation_ui() -> bool:
	if stat_allocation_ui:
		return true  # Already setup
	
	# Load the stat allocation UI scene
	var ui_scene = load(STAT_ALLOCATION_UI_SCENE)
	if not ui_scene:
		push_error("StatAllocationManager: Failed to load stat allocation UI scene")
		return false
	
	# Instance the scene
	stat_allocation_ui = ui_scene.instantiate()
	if not stat_allocation_ui:
		push_error("StatAllocationManager: Failed to instantiate stat allocation UI")
		return false
	
	# Find the UI CanvasLayer to add to
	var ui_layer = _find_ui_layer()
	if not ui_layer:
		push_error("StatAllocationManager: No UI layer found")
		return false
	
	ui_layer.add_child(stat_allocation_ui)
	
	# Connect signals (check if not already connected to prevent duplicates)
	if stat_allocation_ui.has_signal("allocation_completed"):
		if not stat_allocation_ui.allocation_completed.is_connected(_on_allocation_completed):
			stat_allocation_ui.allocation_completed.connect(_on_allocation_completed)
	
	if stat_allocation_ui.has_signal("allocation_cancelled"):
		if not stat_allocation_ui.allocation_cancelled.is_connected(_on_allocation_cancelled):
			stat_allocation_ui.allocation_cancelled.connect(_on_allocation_cancelled)
	
	print("✅ Stat allocation UI setup complete")
	return true

# Find the UI CanvasLayer in the scene
func _find_ui_layer() -> CanvasLayer:
	var current_scene = get_tree().current_scene
	if not current_scene:
		return null
	
	# Look for a CanvasLayer named "UI"
	var ui_layer = current_scene.find_child("UI", true, false)
	if ui_layer and ui_layer is CanvasLayer:
		return ui_layer
	
	# Look for any CanvasLayer
	for child in current_scene.get_children():
		if child is CanvasLayer:
			return child
	
	# Look recursively for CanvasLayer
	var found_layer = _find_canvas_layer_recursive(current_scene)
	return found_layer

func _find_canvas_layer_recursive(node: Node) -> CanvasLayer:
	if node is CanvasLayer:
		return node
	
	for child in node.get_children():
		var result = _find_canvas_layer_recursive(child)
		if result:
			return result
	
	return null

# Show message when no stat points are available
func _show_no_points_message() -> void:
	print("💡 Level up to gain stat points for allocation!")
	
	# Create a visual notification
	var notification = _create_notification_panel("No Stat Points Available", 
		"Level up to gain points for allocation!", 
		Color(1.0, 0.5, 0.0, 0.9), # Orange color
		2.5) # Display for 2.5 seconds
	
	if notification:
		# Add to UI layer
		var ui_layer = _find_ui_layer()
		if ui_layer:
			ui_layer.add_child(notification)
		else:
			# Fallback: add to root
			get_tree().root.add_child(notification)

# Create a simple notification panel
func _create_notification_panel(title: String, message: String, color: Color, duration: float) -> Control:
	# Create container
	var panel = PanelContainer.new()
	# Set anchors to center like the wave display
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.anchor_top = 0.0
	panel.anchor_bottom = 0.0
	
	# Center the panel by offsetting half its width
	# We'll set this after adding content
	panel.position.y = 130  # Position below wave counter (moved down 20px total)
	
	# Style
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	style.content_margin_left = 20
	style.content_margin_right = 20
	style.content_margin_top = 15
	style.content_margin_bottom = 15
	panel.add_theme_stylebox_override("panel", style)
	
	# Content
	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 5)
	panel.add_child(vbox)
	
	# Title
	var title_label = Label.new()
	title_label.text = title
	title_label.add_theme_font_size_override("font_size", 20)
	title_label.add_theme_color_override("font_color", Color.WHITE)
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title_label)
	
	# Message
	var message_label = Label.new()
	message_label.text = message
	message_label.add_theme_font_size_override("font_size", 16)
	message_label.add_theme_color_override("font_color", Color.WHITE)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(message_label)
	
	# Auto-remove after duration
	var timer = Timer.new()
	timer.wait_time = duration
	timer.one_shot = true
	timer.autostart = true  # Auto-start when added to tree
	timer.timeout.connect(panel.queue_free)
	panel.add_child(timer)
	
	# Ensure minimum width for proper centering
	panel.custom_minimum_size.x = 300
	
	# Center the panel by adjusting position
	# The notification will be approximately 300px wide
	panel.position.x = -163  # Half width + 13px left adjustment
	
	# Fade in effect
	panel.modulate.a = 0
	var tween = panel.create_tween()
	tween.tween_property(panel, "modulate:a", 1.0, 0.3)
	tween.tween_interval(duration - 0.5)
	tween.tween_property(panel, "modulate:a", 0.0, 0.5)
	
	return panel

# === SIGNAL HANDLERS ===

# Handle player level up
func _on_player_leveled_up(new_level: int, stat_points_gained: int) -> void:
	print("🎉 Player leveled up! New level: ", new_level, ", stat points gained: ", stat_points_gained)
	
	# Show level up notification
	if stat_points_gained > 0:
		var notification = _create_notification_panel("LEVEL UP!", 
			"Level %d reached! +%d stat points available" % [new_level, stat_points_gained], 
			Color(0.0, 1.0, 0.0, 0.9), # Green color
			3.0) # Display for 3 seconds
		
		if notification:
			var ui_layer = _find_ui_layer()
			if ui_layer:
				ui_layer.add_child(notification)
			else:
				get_tree().root.add_child(notification)
		
		# Add a small delay to ensure all level up processing is complete
		await get_tree().create_timer(1.0).timeout
		
		# Show hint about TAB key
		var hint = _create_notification_panel("Stat Points Available", 
			"Press TAB to allocate your points!", 
			Color(0.0, 0.8, 1.0, 0.9), # Blue color
			2.5)
		
		if hint:
			hint.position.y = 180 # Position below first notification
			var ui_layer = _find_ui_layer()
			if ui_layer:
				ui_layer.add_child(hint)
			else:
				get_tree().root.add_child(hint)

# Handle allocation completed
func _on_allocation_completed(allocations: Dictionary) -> void:
	print("✅ Stat allocation completed: ", allocations)
	
	# Panel already closed itself - just update our state
	is_panel_open = false
	
	# Emit panel closed signal
	allocation_panel_closed.emit()
	
	# Emit signal for other systems
	stats_allocated.emit(allocations)
	
	# FIXED: Comprehensive UI updates after stat allocation
	_refresh_all_systems_after_allocation()

# Handle allocation cancelled
func _on_allocation_cancelled() -> void:
	print("❌ Stat allocation cancelled")
	
	# Panel is already closing itself - just update our state
	# DO NOT call close_stat_allocation_panel() here to prevent infinite recursion!
	is_panel_open = false
	
	# Emit panel closed signal
	allocation_panel_closed.emit()

# === ENHANCED UI INTEGRATION ===

# FIXED: Comprehensive system refresh after stat allocation
func _refresh_all_systems_after_allocation() -> void:
	print("🔄 Refreshing all systems after stat allocation...")
	
	# 1. Find the player
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("⚠️ Player not found for system refresh")
		return
	
	# 2. Force HealthComponent to update from stats
	var health_component = player.get_node_or_null("HealthComponent")
	if health_component and health_component.has_method("force_update_from_stats"):
		health_component.force_update_from_stats()
		print("🔄 HealthComponent updated from stats")
	elif health_component:
		# Fallback: manually trigger GameEvents with new max values
		if player_stat_sheet:
			var vital_stats = player_stat_sheet.get_vital_stats()
			var current_health = health_component.current_health
			var current_mana = health_component.current_mana
			
			# Update HealthComponent max values
			health_component.max_health = vital_stats.max_health
			health_component.max_mana = vital_stats.max_mana
			
			# Trigger GameEvents for UI updates
			if GameEvents:
				GameEvents.emit_player_health_changed(current_health, vital_stats.max_health)
				GameEvents.emit_player_mana_changed(current_mana, vital_stats.max_mana)
				print("🔄 GameEvents updated manually: Health ", current_health, "/", vital_stats.max_health, " Mana ", current_mana, "/", vital_stats.max_mana)
	else:
		print("⚠️ HealthComponent not found")
	
	# 3. Force PlayerUI refresh
	var player_ui = get_tree().get_first_node_in_group("player_ui")
	if not player_ui:
		# Try finding it by name
		player_ui = get_tree().current_scene.find_child("PlayerUI", true, false)
	
	if player_ui and player_ui.has_method("force_refresh"):
		player_ui.force_refresh()
		print("🔄 PlayerUI refreshed after stat allocation")
	else:
		print("⚠️ PlayerUI not found or doesn't have force_refresh method")
	
	# 4. Update any other stat displays
	var stat_displays = get_tree().get_nodes_in_group("stat_displays")
	for display in stat_displays:
		if display.has_method("force_refresh") or display.has_method("update_display"):
			if display.has_method("force_refresh"):
				display.force_refresh()
			else:
				display.update_display()
			print("🔄 Stat display refreshed: ", display.name)
	
	# 5. Wait a frame then emit additional GameEvents to ensure UI synchronization
	await get_tree().process_frame
	
	if GameEvents and health_component and player_stat_sheet:
		var vital_stats = player_stat_sheet.get_vital_stats()
		GameEvents.emit_player_health_changed(health_component.current_health, vital_stats.max_health)
		GameEvents.emit_player_mana_changed(health_component.current_mana, vital_stats.max_mana)
		print("🔄 Final GameEvents sync completed")
	
	print("✅ All systems refreshed after stat allocation")

# === DEBUG AND UTILITY ===

func get_manager_status() -> String:
	return """
StatAllocationManager Status:
- Panel Open: %s
- UI Instance: %s
- Player StatSheet: %s
- Available Points: %s
""" % [
	str(is_panel_open),
	str(stat_allocation_ui != null),
	str(player_stat_sheet != null),
	str(player_stat_sheet.available_stat_points) if player_stat_sheet else "N/A"
]

# Force refresh the manager state
func refresh_manager() -> void:
	if is_panel_open:
		close_stat_allocation_panel()
	
	player_stat_sheet = null
	_find_player_stat_sheet()
	
	print("🔄 StatAllocationManager refreshed")
