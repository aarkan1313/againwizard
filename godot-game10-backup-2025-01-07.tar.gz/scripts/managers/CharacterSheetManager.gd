# CharacterSheetManager.gd
# Purpose: Singleton manager for the draggable character sheet
# Handles opening/closing and ensures only one instance exists

extends Node

# The character sheet window instance (untyped to avoid parser errors)
var character_sheet_window = null

# Scene path
const CHARACTER_SHEET_SCENE = "res://scenes/ui/DraggableCharacterSheet.tscn"

func _ready():
	print("📊 CharacterSheetManager singleton initialized")
	# Set process mode to handle input during pause
	process_mode = Node.PROCESS_MODE_ALWAYS

func _input(event):
	# Handle character sheet toggle
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_C and not event.shift_pressed:
			toggle_character_sheet()
			get_viewport().set_input_as_handled()

func toggle_character_sheet():
	if character_sheet_window:
		if character_sheet_window.is_open:
			character_sheet_window.hide_character_sheet()
		else:
			character_sheet_window.show_character_sheet()
	else:
		_create_character_sheet()

func _create_character_sheet():
	# Load the character sheet scene
	var sheet_scene = load(CHARACTER_SHEET_SCENE)
	if not sheet_scene:
		push_error("Failed to load character sheet scene: " + CHARACTER_SHEET_SCENE)
		return
	
	# Instance the window
	character_sheet_window = sheet_scene.instantiate()
	get_tree().root.add_child(character_sheet_window)
	
	# Show it immediately
	character_sheet_window.show_character_sheet()
	
	print("✅ Character sheet window created and shown")

func open_character_sheet():
	if not character_sheet_window:
		_create_character_sheet()
	else:
		character_sheet_window.show_character_sheet()

func close_character_sheet():
	if character_sheet_window:
		character_sheet_window.hide_character_sheet()

# Clean up on exit
func _exit_tree():
	if character_sheet_window:
		character_sheet_window.queue_free()
