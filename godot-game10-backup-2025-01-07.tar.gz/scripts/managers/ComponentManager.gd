# ComponentManager.gd - Centralized component lifecycle management
# Purpose: Manage all enemy components with consistent patterns
# Godot Version: 4.4.1
# Benefits: Centralized management, error handling, debugging support

extends Node
class_name ComponentManager

signal component_added(component_name: String)
signal component_removed(component_name: String)
signal component_error(component_name: String, error_message: String)
signal all_components_ready()

var components: Dictionary = {}
var parent_entity: Node
var is_initialized: bool = false
var initialization_errors: Array[String] = []

func initialize(entity: Node) -> bool:
    # Initialize component manager with parent entity
    if not is_instance_valid(entity):
        push_error("ComponentManager: Invalid entity provided")
        return false
    
    parent_entity = entity
    is_initialized = true
    print("🔧 ComponentManager initialized for: ", entity.name)
    return true

# Component Management

func add_component(component: IEnemyComponent) -> bool:
    # Add component with validation and lifecycle management
    if not is_initialized:
        push_error("ComponentManager: Cannot add component - manager not initialized")
        return false
    
    if not component:
        push_error("ComponentManager: Cannot add null component")
        return false
    
    var component_name = component.get_component_name()
    
    # Check for duplicates
    if component_name in components:
        push_warning("ComponentManager: Component already exists: " + component_name)
        return false
    
    # Initialize component
    if component.initialize(parent_entity):
        components[component_name] = component
        
        # Connect component signals
        component.component_ready.connect(_on_component_ready.bind(component_name))
        component.component_error.connect(_on_component_error.bind(component_name))
        component.component_state_changed.connect(_on_component_state_changed.bind(component_name))
        
        # Add to scene tree if needed
        if not component.get_parent():
            parent_entity.add_child(component)
        
        component_added.emit(component_name)
        print("✅ Component added: ", component_name)
        
        # Check if all components are ready
        _check_all_components_ready()
        
        return true
    else:
        var error_msg = "Failed to initialize component: " + component_name
        initialization_errors.append(error_msg)
        push_error("ComponentManager: " + error_msg)
        return false

func remove_component(component_name: String) -> bool:
    # Remove component with proper cleanup
    if not component_name in components:
        return false
    
    var component = components[component_name]
    
    # Disconnect signals
    if component.component_ready.is_connected(_on_component_ready):
        component.component_ready.disconnect(_on_component_ready)
    if component.component_error.is_connected(_on_component_error):
        component.component_error.disconnect(_on_component_error)
    if component.component_state_changed.is_connected(_on_component_state_changed):
        component.component_state_changed.disconnect(_on_component_state_changed)
    
    # Cleanup component
    component.cleanup()
    
    # Remove from scene tree
    if component.get_parent():
        component.get_parent().remove_child(component)
    
    components.erase(component_name)
    component_removed.emit(component_name)
    print("🗑️ Component removed: ", component_name)
    
    return true

func get_component(component_name: String) -> IEnemyComponent:
    # Get component by name with validation
    var component = components.get(component_name, null)
    if component and component.validate():
        return component
    return null

func has_component(component_name: String) -> bool:
    # Check if component exists and is valid
    if not component_name in components:
        return false
    return components[component_name].validate()

func get_component_by_type(component_type) -> IEnemyComponent:
    # Get first component of specified type
    for component in components.values():
        if component is component_type:
            return component
    return null

func get_all_components_of_type(component_type) -> Array[IEnemyComponent]:
    # Get all components of specified type
    var result: Array[IEnemyComponent] = []
    for component in components.values():
        if component is component_type:
            result.append(component)
    return result

# Component State Management

func activate_component(component_name: String) -> bool:
    # Activate specific component
    var component = get_component(component_name)
    if component:
        component.activate()
        return true
    return false

func deactivate_component(component_name: String) -> bool:
    # Deactivate specific component
    var component = get_component(component_name)
    if component:
        component.deactivate()
        return true
    return false

func activate_all_components():
    # Activate all components
    for component in components.values():
        if component.validate():
            component.activate()

func deactivate_all_components():
    # Deactivate all components
    for component in components.values():
        if component.validate():
            component.deactivate()

# Cleanup and Validation

func cleanup_all():
    # Clean up all components
    var component_names = components.keys()
    for component_name in component_names:
        remove_component(component_name)
    
    components.clear()
    is_initialized = false
    initialization_errors.clear()
    print("🧹 ComponentManager: All components cleaned up")

func validate_all_components() -> bool:
    # Validate all components
    var all_valid = true
    for component_name in components:
        var component = components[component_name]
        if not component.validate():
            push_warning("ComponentManager: Invalid component: " + component_name)
            all_valid = false
    
    return all_valid

func get_component_count() -> int:
    # Get total number of components
    return components.size()

func get_active_component_count() -> int:
    # Get number of active components
    var active_count = 0
    for component in components.values():
        if component.is_component_ready():
            active_count += 1
    return active_count

# Debug and Information

func get_component_info() -> Dictionary:
    # Get detailed component information for debugging
    var info = {
        "total_components": components.size(),
        "active_components": get_active_component_count(),
        "initialization_errors": initialization_errors.size(),
        "components": {}
    }
    
    for component_name in components:
        var component = components[component_name]
        info.components[component_name] = {
            "state": component.get_component_state(),
            "is_ready": component.is_component_ready(),
            "is_valid": component.validate()
        }
    
    return info

func print_component_status():
    # Print component status for debugging
    print("=== ComponentManager Status ===")
    print("Entity: ", parent_entity.name if parent_entity else "None")
    print("Total Components: ", components.size())
    print("Active Components: ", get_active_component_count())
    
    for component_name in components:
        var component = components[component_name]
        print("  ", component_name, ": ", component.get_component_state())
    
    if initialization_errors.size() > 0:
        print("Initialization Errors:")
        for error in initialization_errors:
            print("  ❌ ", error)

func get_component_names() -> Array[String]:
    # Get list of all component names
    var names: Array[String] = []
    names.assign(components.keys())
    return names

# Signal Handlers

func _on_component_ready(component_name: String):
    # Handle component ready signal
    if GameConfig and GameConfig.should_log_event():
        print("✅ Component ready: ", component_name)
    _check_all_components_ready()

func _on_component_error(component_name: String, error_message: String):
    # Handle component error signal
    var full_error = "Component [" + component_name + "] error: " + error_message
    push_error(full_error)
    component_error.emit(component_name, error_message)

func _on_component_state_changed(component_name: String, new_state: String):
    # Handle component state change
    if GameConfig and GameConfig.should_log_event():
        print("🔄 Component state changed: ", component_name, " -> ", new_state)

func _check_all_components_ready():
    # Check if all components are ready and emit signal
    var all_ready = true
    for component in components.values():
        if not component.is_component_ready():
            all_ready = false
            break
    
    if all_ready and components.size() > 0:
        all_components_ready.emit()

# Utility Methods

func call_method_on_all(method_name: String, args: Array = []) -> Array:
    # Call method on all components that have it
    var results = []
    for component in components.values():
        if component.has_method(method_name):
            var result = component.callv(method_name, args)
            results.append(result)
    return results

func get_components_with_method(method_name: String) -> Array[IEnemyComponent]:
    # Get all components that have specified method
    var result: Array[IEnemyComponent] = []
    for component in components.values():
        if component.has_method(method_name):
            result.append(component)
    return result