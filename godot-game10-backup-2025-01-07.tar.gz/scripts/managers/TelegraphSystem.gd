# TelegraphSystem_Animated.gd  
# Enhanced telegraph system with animated warnings and visual effects
extends Node

# Telegraph types
enum TelegraphType {
	MELEE_CIRCLE,
	RANGED_LINE,
	AREA_CIRCLE,
	CONE_AREA,
	BEAM_LINE
}

# Active telegraphs
var active_telegraphs: Dictionary = {}  # Enemy -> Telegraph node

# Telegraph scene cache
var telegraph_scenes: Dictionary = {}

# Colors by threat level
const THREAT_COLORS = {
	"low": Color(1.0, 1.0, 0.0, 0.5),      # Yellow
	"medium": Color(1.0, 0.65, 0.0, 0.6),   # Orange  
	"high": Color(1.0, 0.0, 0.0, 0.7),      # Red
	"extreme": Color(0.5, 0.0, 0.0, 0.8)    # Dark red
}

func _ready():
	add_to_group("telegraph_system")
	set_process(true)

func _process(delta):
	# Update all active telegraphs
	for enemy in active_telegraphs:
		if is_instance_valid(enemy) and is_instance_valid(active_telegraphs[enemy]):
			update_telegraph_position(enemy, active_telegraphs[enemy])
		else:
			# Clean up invalid references
			if enemy in active_telegraphs:
				active_telegraphs.erase(enemy)

# Main telegraph functions
func show_melee_telegraph(enemy: Node2D, range: float, threat_level: String = "medium"):
	hide_telegraph(enemy)  # Clear any existing
	
	var telegraph = create_animated_circle_telegraph(range, threat_level)
	add_telegraph_to_scene(telegraph, enemy.global_position)
	active_telegraphs[enemy] = telegraph
	
	# Animate the telegraph
	animate_melee_telegraph(telegraph, threat_level)

func show_ranged_telegraph(enemy: Node2D, target: Node2D, threat_level: String = "medium"):
	if not target:
		return
		
	hide_telegraph(enemy)
	
	var telegraph = create_animated_line_telegraph(enemy, target, threat_level)
	add_telegraph_to_scene(telegraph, enemy.global_position)
	active_telegraphs[enemy] = telegraph
	
	# Animate the telegraph
	animate_ranged_telegraph(telegraph, threat_level)

func show_area_telegraph(enemy: Node2D, radius: float, threat_level: String = "high"):
	hide_telegraph(enemy)
	
	var telegraph = create_animated_area_telegraph(radius, threat_level)
	add_telegraph_to_scene(telegraph, enemy.global_position)
	active_telegraphs[enemy] = telegraph
	
	# Animate the area telegraph
	animate_area_telegraph(telegraph, threat_level)

func show_cone_telegraph(enemy: Node2D, direction: Vector2, angle: float, range: float, threat_level: String = "medium"):
	hide_telegraph(enemy)
	
	var telegraph = create_animated_cone_telegraph(direction, angle, range, threat_level)
	add_telegraph_to_scene(telegraph, enemy.global_position)
	active_telegraphs[enemy] = telegraph
	
	# Animate the cone telegraph
	animate_cone_telegraph(telegraph, threat_level)

func hide_telegraph(enemy: Node2D):
	if enemy in active_telegraphs:
		var telegraph = active_telegraphs[enemy]
		if is_instance_valid(telegraph):
			# Simply remove the telegraph immediately to avoid tween conflicts
			telegraph.queue_free()
		active_telegraphs.erase(enemy)

# Telegraph creation functions
func create_animated_circle_telegraph(radius: float, threat_level: String) -> Node2D:
	var telegraph = Node2D.new()
	telegraph.z_index = -1
	
	# Create multiple rings for animated effect
	var outer_ring = create_ring_sprite(radius, threat_level, 1.0)
	var middle_ring = create_ring_sprite(radius * 0.8, threat_level, 0.7)
	var inner_ring = create_ring_sprite(radius * 0.6, threat_level, 0.5)
	
	telegraph.add_child(outer_ring)
	telegraph.add_child(middle_ring) 
	telegraph.add_child(inner_ring)
	
	# Add danger symbol in center
	var danger_symbol = create_danger_symbol(threat_level)
	telegraph.add_child(danger_symbol)
	
	return telegraph

func create_ring_sprite(radius: float, threat_level: String, alpha_mult: float) -> Node2D:
	var ring = Node2D.new()
	ring.set_script(preload("res://scripts/effects/TelegraphRingDrawer.gd"))
	ring.set("radius", radius)
	ring.set("thickness", 3.0)
	var color = THREAT_COLORS[threat_level]
	color.a *= alpha_mult
	ring.set("color", color)
	return ring

func create_danger_symbol(threat_level: String) -> Node2D:
	var symbol = Sprite2D.new()
	
	# Create exclamation mark texture
	var image = Image.create(32, 64, false, Image.FORMAT_RGBA8)
	
	# Draw exclamation mark
	for x in range(32):
		for y in range(64):
			var in_mark = false
			# Top part of exclamation
			if y < 40 and x >= 12 and x < 20:
				in_mark = true
			# Dot at bottom
			elif y >= 48 and y < 56 and x >= 12 and x < 20:
				in_mark = true
				
			if in_mark:
				image.set_pixel(x, y, THREAT_COLORS[threat_level])
	
	var texture = ImageTexture.create_from_image(image)
	symbol.texture = texture
	symbol.scale = Vector2(0.5, 0.5)
	
	return symbol

func create_animated_line_telegraph(enemy: Node2D, target: Node2D, threat_level: String) -> Node2D:
	var telegraph = Node2D.new()
	telegraph.z_index = -1
	
	# Main line
	var line = Line2D.new()
	line.width = 20.0
	line.default_color = THREAT_COLORS[threat_level]
	line.add_point(Vector2.ZERO)
	line.add_point(target.global_position - enemy.global_position)
	telegraph.add_child(line)
	
	# Animated dots along the line
	var num_dots = 5
	for i in range(num_dots):
		var dot = create_line_dot(threat_level)
		dot.position = line.get_point_position(0).lerp(line.get_point_position(1), i / float(num_dots - 1))
		telegraph.add_child(dot)
	
	# Target reticle
	var reticle = create_target_reticle(threat_level)
	reticle.position = line.get_point_position(1)
	telegraph.add_child(reticle)
	
	return telegraph

func create_line_dot(threat_level: String) -> Sprite2D:
	var dot = Sprite2D.new()
	
	# Create glowing dot texture
	var image = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for x in range(16):
		for y in range(16):
			var dist = Vector2(x - 8, y - 8).length()
			if dist < 8:
				var alpha = 1.0 - (dist / 8.0)
				var color = THREAT_COLORS[threat_level]
				color.a *= alpha
				image.set_pixel(x, y, color)
	
	var texture = ImageTexture.create_from_image(image)
	dot.texture = texture
	return dot

func create_target_reticle(threat_level: String) -> Node2D:
	var reticle = Node2D.new()
	reticle.set_script(preload("res://scripts/effects/TargetReticleDrawer.gd"))
	reticle.set("color", THREAT_COLORS[threat_level])
	reticle.set("size", 30.0)
	return reticle

func create_animated_area_telegraph(radius: float, threat_level: String) -> Node2D:
	var telegraph = Node2D.new()
	telegraph.z_index = -1
	
	# Multiple expanding rings
	for i in range(3):
		var ring = create_ring_sprite(radius * (0.6 + i * 0.2), threat_level, 0.5 - i * 0.15)
		telegraph.add_child(ring)
	
	# Danger zone fill
	var fill = Node2D.new()
	fill.set_script(preload("res://scripts/effects/CircleFillDrawer.gd"))
	fill.set("radius", radius)
	var fill_color = THREAT_COLORS[threat_level]
	fill_color.a *= 0.2
	fill.set("color", fill_color)
	telegraph.add_child(fill)
	
	# Ground cracks preview
	for i in range(8):
		var crack = create_ground_crack_preview(radius, i * PI/4, threat_level)
		telegraph.add_child(crack)
	
	return telegraph

func create_ground_crack_preview(radius: float, angle: float, threat_level: String) -> Line2D:
	var crack = Line2D.new()
	crack.add_point(Vector2.ZERO)
	crack.add_point(Vector2(cos(angle), sin(angle)) * radius * 0.8)
	crack.width = 2.0
	var color = THREAT_COLORS[threat_level]
	color.a *= 0.5
	crack.default_color = color
	return crack

func create_animated_cone_telegraph(direction: Vector2, angle: float, range: float, threat_level: String) -> Node2D:
	var telegraph = Node2D.new()
	telegraph.z_index = -1
	telegraph.rotation = direction.angle()
	
	# Cone outline
	var cone = Node2D.new()
	cone.set_script(preload("res://scripts/effects/ConeDrawer.gd"))
	cone.set("angle", angle)
	cone.set("range", range)
	cone.set("color", THREAT_COLORS[threat_level])
	telegraph.add_child(cone)
	
	# Sweeping line effect
	var sweep_line = Line2D.new()
	sweep_line.add_point(Vector2.ZERO)
	sweep_line.add_point(Vector2(range, 0))
	sweep_line.width = 3.0
	sweep_line.default_color = THREAT_COLORS[threat_level]
	telegraph.add_child(sweep_line)
	
	return telegraph

# Animation functions
func animate_melee_telegraph(telegraph: Node2D, threat_level: String):
	var rings = []
	for child in telegraph.get_children():
		if child.has_method("_draw"):
			rings.append(child)
	
	# Pulsing rings
	for i in range(rings.size()):
		var ring = rings[i]
		var tween = ring.create_tween()  # Create on the ring itself
		tween.set_loops()  # Infinite loops are OK when bound to the node
		
		# Offset timing for wave effect
		if i > 0:
			tween.tween_interval(i * 0.1)
		
		# Pulse
		tween.tween_property(ring, "scale", Vector2(1.1, 1.1), 0.3)
		tween.tween_property(ring, "scale", Vector2(0.9, 0.9), 0.3)
	
	# Danger symbol bounce
	var symbol = telegraph.get_child(telegraph.get_child_count() - 1)
	if symbol is Sprite2D:
		var symbol_tween = symbol.create_tween()  # Create on the symbol itself
		symbol_tween.set_loops()
		symbol_tween.tween_property(symbol, "position:y", -10, 0.5).set_ease(Tween.EASE_OUT)
		symbol_tween.tween_property(symbol, "position:y", 0, 0.5).set_ease(Tween.EASE_IN)

func animate_ranged_telegraph(telegraph: Node2D, threat_level: String):
	# Animate dots flowing along line
	var dots = []
	for child in telegraph.get_children():
		if child is Sprite2D and child.texture:
			dots.append(child)
	
	# Remove reticle from dots
	if dots.size() > 0:
		dots.pop_back()
	
	# Flow animation
	for i in range(dots.size()):
		var dot = dots[i]
		var tween = dot.create_tween()  # Create on the dot itself
		tween.set_loops()
		
		# Stagger start times
		tween.tween_interval(i * 0.2)
		
		# Pulse and move
		tween.tween_property(dot, "scale", Vector2(1.5, 1.5), 0.3)
		tween.parallel().tween_property(dot, "modulate:a", 1.0, 0.3)
		tween.tween_property(dot, "scale", Vector2(0.5, 0.5), 0.3)
		tween.parallel().tween_property(dot, "modulate:a", 0.3, 0.3)
	
	# Reticle rotation
	var reticle = telegraph.get_child(telegraph.get_child_count() - 1)
	var reticle_tween = reticle.create_tween()  # Create on the reticle itself
	reticle_tween.set_loops()
	reticle_tween.tween_property(reticle, "rotation", TAU, 2.0)

func animate_area_telegraph(telegraph: Node2D, threat_level: String):
	# Expanding rings
	var rings = []
	for child in telegraph.get_children():
		if child.has_method("_draw") and child.get("radius"):
			rings.append(child)
	
	# Ripple effect
	for ring in rings:
		var original_radius = ring.get("radius")
		var tween = ring.create_tween()  # Create on the ring itself
		tween.set_loops()
		
		# Expand and fade
		tween.tween_property(ring, "radius", original_radius * 1.2, 1.0)
		tween.parallel().tween_property(ring, "modulate:a", 0.0, 1.0)
		tween.tween_property(ring, "radius", original_radius, 0.0)
		tween.tween_property(ring, "modulate:a", THREAT_COLORS[threat_level].a, 0.0)
	
	# Ground shake preview
	var shake_tween = telegraph.create_tween()  # Create on the telegraph itself
	shake_tween.set_loops()
	shake_tween.tween_property(telegraph, "position:x", 2, 0.05)
	shake_tween.tween_property(telegraph, "position:x", -2, 0.05)
	shake_tween.tween_property(telegraph, "position:x", 0, 0.05)
	shake_tween.tween_interval(0.5)

func animate_cone_telegraph(telegraph: Node2D, threat_level: String):
	# Sweeping line
	var sweep_line = null
	for child in telegraph.get_children():
		if child is Line2D:
			sweep_line = child
			break
	
	if sweep_line:
		var angle = telegraph.get_child(0).get("angle")
		var sweep_tween = sweep_line.create_tween()  # Create on the sweep line itself
		sweep_tween.set_loops()
		
		# Sweep back and forth
		sweep_tween.tween_property(sweep_line, "rotation", -angle/2, 0.5)
		sweep_tween.tween_property(sweep_line, "rotation", angle/2, 1.0)
		sweep_tween.tween_property(sweep_line, "rotation", 0, 0.5)

# Helper functions
func add_telegraph_to_scene(telegraph: Node2D, position: Vector2):
	get_tree().current_scene.add_child(telegraph)
	telegraph.global_position = position

func update_telegraph_position(enemy: Node2D, telegraph: Node2D):
	if telegraph and is_instance_valid(telegraph):
		telegraph.global_position = enemy.global_position

# Cleanup
func clear_all_telegraphs():
	for enemy in active_telegraphs:
		hide_telegraph(enemy)
