# EnemyAbilities.gd - REBUILT - Simplified charge system and improved reliability
# Executes abilities for enemies based on AbilityData resources - SIMPLIFIED & CRASH PROOF
extends Node2D
class_name EnemyAbilities

signal ability_executed(ability_data: AbilityData)
signal projectile_spawned(projectile: Node2D)
signal damage_dealt(amount: int, position: Vector2)

@export var projectile_scene: PackedScene
@export var effect_scene: PackedScene

var enemy: Enemy
var available_abilities: Array[AbilityData] = []  # Store actual abilities
var current_cooldowns: Dictionary = {}  # ability_id -> time_remaining
var global_ability_cooldown: float = 0.0  # Prevent ability spam
var min_ability_interval: float = 0.5  # Will be loaded from GameConfig

# Visual effect colors for different damage types
const DAMAGE_TYPE_COLORS = {
	"physical": Color.WHITE,
	"fire": Color.ORANGE_RED,
	"ice": Color.LIGHT_BLUE,
	"poison": Color.GREEN,
	"arcane": Color.PURPLE
}

func _ready() -> void:
	enemy = get_parent()
	set_process(true)
	
	# Create default projectile scene if not set
	if not projectile_scene:
		projectile_scene = preload("res://scenes/projectiles/EnemyProjectile.tscn")

func initialize(abilities: Array, parent_enemy: Enemy) -> void:
	# Initialize the abilities component with enemy data
	if is_instance_valid(parent_enemy):
		enemy = parent_enemy
		
		# Clear and populate available abilities and cooldowns
		available_abilities.clear()
		current_cooldowns.clear()
		for ability in abilities:
			if ability is AbilityData:
				available_abilities.append(ability)
				current_cooldowns[ability.ability_name] = 0.0
		
		# Load configurable values from GameConfig
		if GameConfig:
			min_ability_interval = GameConfig.get_ability_spam_prevention()
		
		# Reduced logging for better performance - only log first few spawns
		if randf() < 0.3:  # Only log 30% of enemy ability initializations
			print("⚡ EnemyAbilities initialized for ", parent_enemy.enemy_data.enemy_name if parent_enemy.enemy_data else "Unknown", " with ", abilities.size(), " abilities")
			# Skip detailed ability listing to reduce spam

func _process(delta: float) -> void:
	# Update cooldowns
	if global_ability_cooldown > 0:
		global_ability_cooldown -= delta
	
	for ability_id in current_cooldowns.keys():
		current_cooldowns[ability_id] -= delta
		if current_cooldowns[ability_id] <= 0:
			current_cooldowns.erase(ability_id)

func can_execute_ability(ability: AbilityData) -> bool:
	if not ability:
		return false
	
	if not is_instance_valid(enemy):
		return false
	
	# Check global cooldown to prevent spam
	if global_ability_cooldown > 0:
		return false
		
	# Check individual ability cooldown
	if ability.ability_name in current_cooldowns:
		return false
		
	# Check if we have a valid target for targeted abilities
	if ability.requires_line_of_sight and not (PlayerTracker.is_player_valid() if PlayerTracker else GameManager.get_player()):
		return false
		
	return true

func try_use_ability(target: Node2D) -> bool:
	# Try to use any available ability on the target
	if not is_instance_valid(target) or not is_instance_valid(enemy):
		return false
	
	# Check each available ability
	for ability in available_abilities:
		if can_execute_ability(ability):
			var target_pos = target.global_position
			execute_ability(ability, target_pos)
			return true
	
	return false

func execute_ability(ability: AbilityData, target_position: Vector2) -> void:
	if not can_execute_ability(ability):
		return
	
	if not is_instance_valid(enemy):
		return
	
	# Minimal logging - only log critical errors
	if randf() < 0.01:  # Only log 1% of ability executions
		print("🔥 EXECUTING ABILITY: ", ability.ability_name, " for ", enemy.enemy_type if "enemy_type" in enemy else "unknown")
		
	# Put ability on cooldown
	current_cooldowns[ability.ability_name] = ability.cooldown_time
	global_ability_cooldown = min_ability_interval
	
	# Execute based on ability type - SIMPLIFIED
	match ability.ability_type:
		"ranged":
			_execute_projectile(ability, target_position)
		"aoe":
			_execute_aoe(ability, enemy.global_position)  # Center on enemy, not target
		"melee_aoe":
			_execute_melee_aoe(ability, target_position)
		"speed_boost":
			_execute_buff(ability)
		"buff":
			_execute_buff(ability)
		"heal":
			_execute_heal(ability)
		_:
			# Reduced warning spam
			if randf() < 0.1:
				push_warning("Unknown ability type: " + ability.ability_type)
	
	# Emit signal for UI/effects
	ability_executed.emit(ability)

func _execute_projectile(ability: AbilityData, target_position: Vector2) -> void:
	if not projectile_scene:
		return
		
	if not is_instance_valid(enemy):
		return
		
	var projectile = projectile_scene.instantiate()
	if not projectile:
		return
		
	get_tree().current_scene.add_child(projectile)
	projectile.global_position = enemy.global_position
	
	# Calculate direction to target
	var direction = (target_position - enemy.global_position).normalized()
	
	# Configure projectile
	if projectile.has_method("setup"):
		var damage_multiplier = 1.0
		if "damage_multiplier" in enemy:
			damage_multiplier = enemy.damage_multiplier
		
		projectile.setup(
			direction,
			ability.damage * damage_multiplier,
			ability.projectile_speed,
			ability.range,
			ability.damage_type,
			2 if ability.projectile_piercing else 0
		)
	
	# Apply visual effects based on damage type
	if projectile.has_node("Sprite2D"):
		var sprite = projectile.get_node("Sprite2D")
		sprite.modulate = DAMAGE_TYPE_COLORS.get(ability.damage_type, Color.WHITE)
	
	projectile_spawned.emit(projectile)

func _execute_aoe(ability: AbilityData, target_position: Vector2) -> void:
	# Execute area of effect damage with visual warning
	if not is_instance_valid(enemy):
		return
	
	# Show visual warning indicator first
	if ability.warning_duration > 0:
		_show_aoe_warning(target_position, ability.charge_damage_radius, ability.warning_color, ability.warning_duration)
		await get_tree().create_timer(ability.warning_duration).timeout
		
		if not is_instance_valid(enemy):
			return
	
	# FIXED: Create Area2D with proper physics timing
	_execute_aoe_with_fixed_detection(ability, target_position)

func _execute_aoe_with_fixed_detection(ability: AbilityData, target_position: Vector2) -> void:
	# Execute AOE damage with fixed Area2D detection timing
	# Create and fully configure Area2D before adding to scene
	var damage_area = Area2D.new()
	var collision_shape = CollisionShape2D.new()
	var circle_shape = CircleShape2D.new()
	
	# Configure shape
	circle_shape.radius = ability.charge_damage_radius
	collision_shape.shape = circle_shape
	
	# Configure Area2D BEFORE adding to scene
	damage_area.collision_layer = 0  # Don't collide with anything
	damage_area.collision_mask = 1   # Detect player on layer 1
	damage_area.monitoring = true
	damage_area.position = target_position
	
	# Add collision shape to Area2D
	damage_area.add_child(collision_shape)
	
	# Add to scene tree
	get_tree().current_scene.add_child(damage_area)
	
	# Golem stomp area created (logging disabled for performance)
	
	# FIXED: Wait for multiple physics frames to ensure proper detection
	await get_tree().physics_frame  # Wait for physics frame specifically
	await get_tree().physics_frame  # Wait for second physics frame to be sure
	
	# Now check for overlapping bodies
	var overlapping_bodies = damage_area.get_overlapping_bodies()
	# Check overlapping bodies (logging disabled for performance)
	
	var hit_applied = false
	
	for body in overlapping_bodies:
		# Check body groups (logging disabled for performance)
		if body.is_in_group("player") and body.has_method("take_damage"):
			var damage_multiplier = 1.0
			if "damage_multiplier" in enemy:
				damage_multiplier = enemy.damage_multiplier
			
			var final_damage = ability.damage * damage_multiplier
			body.take_damage(final_damage)
			damage_dealt.emit(final_damage, body.global_position)
			# Golem stomp hit (logging disabled for performance)
			hit_applied = true
		else:
			# Body not player (logging disabled for performance)
			pass
	
	# Fallback distance check only if Area2D didn't detect the player
	if not hit_applied:
		var player = GameManager.get_player()
		if is_instance_valid(player):
			var distance = target_position.distance_to(player.global_position)
			# Check player distance (logging disabled for performance)
			if distance <= ability.charge_damage_radius:
				# Using fallback distance check (logging disabled for performance)
				var damage_multiplier = 1.0
				if "damage_multiplier" in enemy:
					damage_multiplier = enemy.damage_multiplier
				
				var final_damage = ability.damage * damage_multiplier
				player.take_damage(final_damage)
				damage_dealt.emit(final_damage, player.global_position)
				# Golem stomp hit via fallback (logging disabled for performance)
	
	# Clean up the damage area using a proper cleanup function (no lambda)
	_cleanup_damage_area(damage_area, 0.1)

func _on_aoe_body_entered(body: Node2D, ability: AbilityData) -> void:
	# Handle AOE damage to targets
	if body.is_in_group("player") and body.has_method("take_damage"):
		var damage_multiplier = 1.0
		if "damage_multiplier" in enemy:
			damage_multiplier = enemy.damage_multiplier
		
		var final_damage = ability.damage * damage_multiplier
		body.take_damage(final_damage)
		damage_dealt.emit(final_damage, body.global_position)

func _execute_melee_aoe(ability: AbilityData, target_position: Vector2) -> void:
	# Execute melee AOE attack around the enemy
	if not is_instance_valid(enemy):
		return
	
	# Delay the actual damage (no visual warning)
	await get_tree().create_timer(ability.cast_time).timeout
	
	if not is_instance_valid(enemy):
		return
	
	# Use enemy position for melee AOE (centered on golem)
	_execute_aoe(ability, enemy.global_position)

func _execute_buff(ability: AbilityData) -> void:
	# Execute buff abilities like speed boost
	if not is_instance_valid(enemy):
		return
		
	match ability.ability_type:
		"speed_boost":
			_apply_speed_buff(enemy, ability.speed_multiplier, ability.effect_duration)

func _execute_heal(ability: AbilityData) -> void:
	# Execute heal ability
	if not is_instance_valid(enemy):
		return
	
	# Heal the enemy
	if enemy.has_method("heal") or "current_health" in enemy:
		var heal_amount = ability.damage  # Heal abilities use damage as heal amount
		if "current_health" in enemy and "max_health" in enemy:
			enemy.current_health = min(enemy.current_health + heal_amount, enemy.max_health)
		elif enemy.has_method("heal"):
			enemy.heal(heal_amount)


# SIMPLIFIED: Buff application helpers
func _apply_speed_buff(target: Node2D, modifier: float, duration: float) -> void:
	if not is_instance_valid(target):
		return
		
	if "movement_speed_multiplier" in target:
		var original_multiplier = target.movement_speed_multiplier
		target.movement_speed_multiplier *= modifier
		
		# Add green flash effect for goblin speed boost
		_add_speed_visual_effect(target, duration)
		
		# Minimal logging for better performance
		if randf() < 0.01:  # Only log 1% of speed buffs
			print("💨 Applied speed buff: ", modifier, "x for ", duration, "s to ", target.name)
		
		# Revert after duration
		await get_tree().create_timer(duration).timeout
		if is_instance_valid(target) and "movement_speed_multiplier" in target:
			target.movement_speed_multiplier = original_multiplier

# UTILITY: Predictive aiming for projectiles
func calculate_predictive_direction(from: Vector2, to: Vector2, projectile_speed: float, target: Node2D) -> Vector2:
	# Calculate direction with basic prediction
	if not is_instance_valid(target) or projectile_speed <= 0:
		return (to - from).normalized()
	
	# Simple predictive aiming
	var target_velocity = Vector2.ZERO
	if "velocity" in target:
		target_velocity = target.velocity
	
	var distance = from.distance_to(to)
	var time_to_target = distance / projectile_speed
	var predicted_position = to + target_velocity * time_to_target
	
	return (predicted_position - from).normalized()

func _add_speed_visual_effect(target: Node2D, duration: float) -> void:
	# Add green flash effect to enemy during speed boost
	if not is_instance_valid(target):
		return
	
	# Find the sprite node
	var sprite = null
	for child in target.get_children():
		if child is Sprite2D:
			sprite = child
			break
	
	if not sprite:
		return
	
	# Store original modulate
	var original_modulate = sprite.modulate
	
	# Create green flash effect
	var tween = create_tween()
	tween.tween_property(sprite, "modulate", Color.GREEN * 1.5, 0.2)
	tween.tween_property(sprite, "modulate", original_modulate, 0.3)
	tween.tween_property(sprite, "modulate", Color.GREEN * 1.2, 0.2)
	tween.tween_property(sprite, "modulate", original_modulate, 0.3)
	
	# Restore original color when duration ends
	_cleanup_speed_effect(sprite, tween, original_modulate, duration)

func _show_aoe_warning(position: Vector2, radius: float, color: Color, duration: float) -> void:
	# Show visual warning circle for AOE attacks
	var warning_circle = Node2D.new()
	warning_circle.name = "AOEWarning"
	
	get_tree().current_scene.add_child(warning_circle)
	warning_circle.global_position = position
	
	# Create a circle using Line2D points
	var line = Line2D.new()
	line.width = 3.0
	line.default_color = color
	warning_circle.add_child(line)
	
	# Generate circle points
	var points = PackedVector2Array()
	var segments = 32
	for i in range(segments + 1):
		var angle = (i * PI * 2.0) / segments
		var point = Vector2(cos(angle), sin(angle)) * radius
		points.append(point)
	
	line.points = points
	
	# Pulsing effect with proper cleanup
	var tween = create_tween()
	if is_instance_valid(warning_circle):
		tween.set_loops(int(duration / 0.6))  # Limited loops based on duration
		tween.tween_property(warning_circle, "modulate:a", 0.3, 0.3)
		tween.tween_property(warning_circle, "modulate:a", 0.8, 0.3)
	
	# Auto cleanup without lambda
	_cleanup_warning_circle(warning_circle, tween, duration)

func _cleanup_warning_circle(circle: Node2D, circle_tween: Tween, delay: float) -> void:
	# Clean up warning circle after delay
	await get_tree().create_timer(delay).timeout
	if is_instance_valid(circle_tween):
		circle_tween.kill()
	if is_instance_valid(circle):
		circle.queue_free()

func _cleanup_speed_effect(sprite: Node, sprite_tween: Tween, original_color: Color, delay: float) -> void:
	# Clean up speed effect after delay
	await get_tree().create_timer(delay).timeout
	if is_instance_valid(sprite_tween):
		sprite_tween.kill()
	if is_instance_valid(sprite):
		sprite.modulate = original_color

func _cleanup_damage_area(damage_area: Area2D, delay: float) -> void:
	# Clean up damage area after delay - no lambda to avoid capture errors
	await get_tree().create_timer(delay).timeout
	if is_instance_valid(damage_area):
		damage_area.queue_free()
