# EnemyProjectile.gd - FIXED for proper collision layers
# Enemy projectile with FIXED collision and damage system
extends Area2D
class_name EnemyProjectile

@export var base_speed: float = 360.0  # Increased by 1.2x (300 * 1.2)
@export var base_damage: int = 10
@export var lifetime: float = 5.0

var direction: Vector2 = Vector2.RIGHT
var speed: float = 360.0  # Increased by 1.2x (300 * 1.2)
var damage: int = 10
var max_range: float = 1000.0
var damage_type: String = "physical"
var pierce_count: int = 0

var traveled_distance: float = 0.0
var pierced_targets: Array[Node2D] = []
var is_active: bool = true

# Visual components
@onready var sprite: Sprite2D = $Sprite2D
@onready var collision_shape: CollisionShape2D = $CollisionShape2D
@onready var particles: CPUParticles2D = $CPUParticles2D
@onready var lifetime_timer: Timer = $LifetimeTimer

func _ready() -> void:
	# Connect signals
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)
	
	# Setup lifetime timer
	if lifetime_timer:
		lifetime_timer.wait_time = lifetime
		lifetime_timer.timeout.connect(_on_lifetime_timeout)
		lifetime_timer.start()
	
	# FIXED: Set collision layers for proper player detection
	# Layer 4 (value 8) for enemy projectiles
	collision_layer = 8  # Enemy projectile layer (layer 4)
	collision_mask = 1   # Only detect player layer
	
	# Ensure we're in the projectiles group for player detection
	add_to_group("enemy_projectiles")
	
	# Enemy projectile spawned

func _physics_process(delta: float) -> void:
	if not is_active:
		return
		
	# Move projectile
	var movement = direction * speed * delta
	position += movement
	traveled_distance += movement.length()
	
	# Check max range
	if traveled_distance >= max_range:
		_destroy()
	
	# Rotate sprite to face direction
	if sprite:
		sprite.rotation = direction.angle()

func setup(new_direction: Vector2, new_damage: int, new_speed: float, new_range: float, new_damage_type: String, new_pierce_count: int) -> void:
	direction = new_direction.normalized()
	damage = new_damage
	speed = new_speed
	max_range = new_range
	damage_type = new_damage_type
	pierce_count = new_pierce_count
	
	# Update visual based on damage type
	_update_visual_for_damage_type()
	
	# Set initial rotation
	if sprite:
		sprite.rotation = direction.angle()
	
	# Projectile setup complete

func _update_visual_for_damage_type() -> void:
	var color_map = {
		"physical": Color.WHITE,
		"fire": Color.ORANGE_RED,
		"ice": Color.LIGHT_BLUE,
		"poison": Color.GREEN,
		"arcane": Color.PURPLE
	}
	
	var projectile_color = color_map.get(damage_type, Color.WHITE)
	
	if sprite:
		sprite.modulate = projectile_color
	
	# Particle system completely disabled
	if particles:
		particles.emitting = false

func _on_body_entered(body: Node2D) -> void:
	if not is_active:
		return
	
	# FIXED: Check if it's the player using proper group check
	if body.is_in_group("player") and body.has_method("take_damage"):
		# Check if we already hit this target (for piercing)
		if body in pierced_targets:
			return
		
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL, 
			"Projectile hit player: %.0f damage" % damage, "EnemyProjectile")
		
		# Deal damage to player
		var damage_dealt = body.take_damage(damage)
		if damage_dealt:
			pierced_targets.append(body)
			# Damage applied successfully to player
		else:
			# Failed to apply damage to player
			pass
		
		# Emit hit effect
		_create_hit_effect(body.global_position)
		
		# Always destroy projectile when hitting player
		# (Enemy projectiles should not pierce through the player)
		# Projectile destroyed on impact
		_destroy()

func _on_area_entered(area: Area2D) -> void:
	# Handle Area2D collisions (like player's DamageReceiver)
	if not is_active:
		return
	
	var area_owner = area.get_parent()
	if area_owner and area_owner.is_in_group("player"):
		# Hit player damage area
		# Trigger the body collision logic
		_on_body_entered(area_owner)

func _create_hit_effect(hit_position: Vector2) -> void:
	# Hit effects disabled - no particles
	pass

func _on_lifetime_timeout() -> void:
	# Projectile timed out
	_destroy()

func _destroy() -> void:
	if not is_active:
		return
		
	is_active = false
	# Projectile destroyed
	
	# Stop particle emission and clean up
	if particles:
		particles.emitting = false
		# Clear any remaining particles immediately
		particles.restart()
	
	# Disable collision
	if collision_shape:
		collision_shape.set_deferred("disabled", true)
	
	# FIXED: Immediate cleanup without fade animation to prevent trail persistence
	queue_free()
