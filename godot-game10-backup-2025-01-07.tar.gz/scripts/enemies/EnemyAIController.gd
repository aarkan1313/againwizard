# EnemyAIController.gd - CRASH PROOF - Safe node handling and memory management
# Godot 4.4.1 Compatible - Enhanced AI with multiple behaviors - CRASH PROOF
extends Node
class_name EnemyAIController

var enemy: Node  # Reference to parent enemy
var enemy_data: EnemyData
var current_target: Node
var state: String = "chasing"  # idle, chasing, attacking, retreating, casting - Start chasing immediately
var state_timer: float = 0.0
var min_state_duration: float = 0.0  # Prevents state thrashing
var last_state_change_time: float = 0.0

# State duration constants
const MIN_ATTACKING_DURATION: float = 0.5
const MIN_CASTING_DURATION: float = 0.2
const MIN_STATE_CHANGE_INTERVAL: float = 0.3

# AI Behavior parameters - FIXED property access
var preferred_distance: float = 50.0
var cached_player_reference: Node = null
var player_cache_timer: float = 0.0
const PLAYER_CACHE_INTERVAL: float = 1.0  # Cache player for 1 second
var retreat_threshold: float = 0.25  # Retreat when health < 25%

# Pathfinding and movement
var desired_position: Vector2
var movement_timer: float = 0.0
var position_update_interval: float = 0.2  # Update desired position every 200ms

# ABILITY USAGE - FIXED AND SAFE
var ability_cooldown_timer: float = 0.0
var min_ability_cooldown: float = 0.8  # Reduced for more frequent ranged attacks
var last_ability_time: float = 0.0

# SAFETY: Track validity to prevent freed instance errors
var is_initialized: bool = false
var cleanup_requested: bool = false
var separation_enabled: bool = true  # For disabling during charges

signal ai_state_changed(new_state: String)
signal ability_cast_requested(ability: AbilityData, target_position: Vector2)

func setup(parent_enemy: Node, data: EnemyData):
	# Initialize AI controller with SAFE property access and validation
	# SAFETY: Validate inputs
	if not is_instance_valid(parent_enemy) or not data:
		push_error("EnemyAIController: Invalid setup parameters")
		return
		
	enemy = parent_enemy
	enemy_data = data
	is_initialized = true
	
	# CONFIGURATION UPGRADE: Load configurable values from GameConfig
	if GameConfig:
		min_ability_cooldown = GameConfig.get_ability_spam_prevention()
	
	# FIXED: Get attack_range from EnemyData (this property exists)
	var attack_range = enemy_data.attack_range if enemy_data else 50.0
	
	# Set preferred distance based on AI behavior
	match enemy_data.ai_behavior:
		"melee_aggressive":
			preferred_distance = attack_range * 0.8
		"ranged_kiting":
			preferred_distance = attack_range * 0.5  # Closer for more frequent attacks
		"support_healing":
			preferred_distance = attack_range * 0.9
	
	# AI Controller setup complete
	
	# Initialize desired position to current position
	if is_instance_valid(enemy):
		desired_position = enemy.global_position

func _ready():
	set_physics_process(true)
	set_process(false)

func _physics_process(delta):
	# SAFETY: Check if we should continue processing
	if cleanup_requested or not is_initialized:
		return
		
	# SAFETY: Validate enemy reference
	if not is_instance_valid(enemy) or not enemy_data:
		_request_cleanup()
		return
	
	state_timer += delta
	movement_timer += delta
	ability_cooldown_timer -= delta
	
	# Update AI state
	update_ai_state(delta)
	
	# Execute current behavior
	execute_current_behavior(delta)
	
	# FIXED: Try to use abilities with safety checks
	attempt_ability_usage(delta)

func update_ai_state(delta: float):
	# Update AI state based on conditions - SAFE property access
	var player = get_cached_player_reference(delta)
	if not is_instance_valid(player):
		change_state("idle")
		return
	
	# SAFETY: Validate enemy still exists
	if not is_instance_valid(enemy):
		return
	
	# Prevent state thrashing
	if Time.get_ticks_msec() * 0.001 - last_state_change_time < MIN_STATE_CHANGE_INTERVAL:
		return
	
	# PERFORMANCE UPGRADE: Use PlayerTracker for faster distance calculation
	var distance_to_player = INF
	if PlayerTracker and PlayerTracker.is_player_valid():
		distance_to_player = PlayerTracker.get_distance_to_player(enemy.global_position)
	else:
		distance_to_player = enemy.global_position.distance_to(player.global_position)
	
	# FIXED: Safe health access from enemy object
	var health_percentage = 1.0
	if enemy.has_method("get_health_percentage"):
		health_percentage = enemy.get_health_percentage()
	elif "current_health" in enemy and "max_health" in enemy and enemy.max_health > 0:
		health_percentage = enemy.current_health / enemy.max_health
	
	# FIXED: Use attack_range from enemy_data (this property exists)
	var attack_range = enemy_data.attack_range if enemy_data else 50.0
	
	# State transition logic with stabilization
	match state:
		"idle":
			# Always chase in horde survival mode
			change_state("chasing")
		
		"chasing":
			# Never stop chasing in horde survival mode
			if distance_to_player <= attack_range:
				if should_retreat(health_percentage):
					change_state("retreating")
				else:
					change_state("attacking")
		
		"attacking":
			# Require minimum duration in attacking state
			if state_timer >= MIN_ATTACKING_DURATION:
				if distance_to_player > attack_range * 1.5:
					change_state("chasing")
				elif should_retreat(health_percentage):
					change_state("retreating")
		
		"retreating":
			# Retreat until healthy or too far
			if distance_to_player > attack_range * 2.0:
				change_state("chasing")
			elif health_percentage > retreat_threshold + 0.1:  # Hysteresis
				change_state("chasing")
		
		"casting":
			# Require minimum casting duration
			if state_timer >= MIN_CASTING_DURATION:
				change_state("chasing")

func execute_current_behavior(delta: float):
	# Execute behavior based on current state - SAFE
	var player = get_cached_player_reference(delta)
	if not is_instance_valid(player) or not is_instance_valid(enemy):
		return
	
	match state:
		"chasing":
			execute_chase_behavior(player, delta)
		"attacking":
			execute_attack_behavior(player, delta)
		"retreating":
			execute_retreat_behavior(player, delta)
		"casting":
			execute_casting_behavior(player, delta)
		"idle":
			# Do nothing in idle state
			pass

func execute_chase_behavior(player: Node, delta: float):
	# Chase the player aggressively - SAFE speed access
	if not is_instance_valid(player) or not is_instance_valid(enemy):
		return
		
	# Update desired position periodically
	if movement_timer >= position_update_interval:
		desired_position = player.global_position
		movement_timer = 0.0
	
	# Move toward player with AI-specific behavior
	var direction = (desired_position - enemy.global_position).normalized()
	
	# FIXED: Get movement speed from enemy object (final calculated speed)
	var move_speed = get_enemy_movement_speed()
	
	match enemy_data.ai_behavior:
		"melee_aggressive":
			# Direct charge
			move_enemy_towards(desired_position, move_speed)
		
		"ranged_kiting":
			# Maintain preferred distance with more aggressive positioning
			var distance = enemy.global_position.distance_to(player.global_position)
			if distance < preferred_distance * 0.8:
				# Too close, back away slightly but stay in attack range
				direction = -direction
				move_enemy_towards(enemy.global_position + direction * 40, move_speed * 0.6)
			elif distance > preferred_distance * 1.3:
				# Too far, move closer for better attack positioning
				move_enemy_towards(desired_position, move_speed * 0.8)
			else:
				# Good distance, slight repositioning but mostly stay to attack
				var slight_offset = Vector2(randf_range(-20, 20), randf_range(-20, 20))
				move_enemy_towards(enemy.global_position + slight_offset, move_speed * 0.3)
		
		"support_healing":
			# Stay at medium range
			var distance = enemy.global_position.distance_to(player.global_position)
			if distance > preferred_distance * 1.5:
				move_enemy_towards(desired_position, move_speed * 0.7)

func execute_attack_behavior(player: Node, delta: float):
	# Execute attack behavior - SAFE speed access
	if not is_instance_valid(player) or not is_instance_valid(enemy):
		return
		
	# Basic contact damage is handled by Enemy.gd collision system
	# AI just needs to position for attack
	
	var move_speed = get_enemy_movement_speed()
	
	match enemy_data.ai_behavior:
		"melee_aggressive":
			# Get close for contact damage
			move_enemy_towards(player.global_position, move_speed)
		
		"ranged_kiting":
			# Stay mostly stationary while attacking for better accuracy
			var distance = enemy.global_position.distance_to(player.global_position)
			if distance < preferred_distance * 0.7:
				# Back away slightly if too close
				var direction = (enemy.global_position - player.global_position).normalized()
				move_enemy_towards(enemy.global_position + direction * 25, move_speed * 0.4)
			# Otherwise stay put for better attack accuracy
		
		"support_healing":
			# Stay at safe distance
			var distance = enemy.global_position.distance_to(player.global_position)
			if distance < preferred_distance:
				var direction = (enemy.global_position - player.global_position).normalized()
				move_enemy_towards(enemy.global_position + direction * 30, move_speed * 0.6)

func execute_retreat_behavior(player: Node, delta: float):
	# Retreat from the player - SAFE speed access
	if not is_instance_valid(player) or not is_instance_valid(enemy):
		return
		
	var retreat_direction = (enemy.global_position - player.global_position).normalized()
	var retreat_target = enemy.global_position + retreat_direction * 150
	var move_speed = get_enemy_movement_speed()
	move_enemy_towards(retreat_target, move_speed * 1.2)

func execute_casting_behavior(player: Node, delta: float):
	# Execute casting behavior (stay still while casting)
	# Don't move while casting
	pass

# FIXED: Get movement speed from the right source - SAFE
func get_enemy_movement_speed() -> float:
	# Get enemy movement speed from the correct property with multiplier support - SAFE
	if not is_instance_valid(enemy):
		return 120.0  # Safe fallback
		
	var base_speed = 120.0
	
	# Get base movement speed
	if "movement_speed" in enemy:
		base_speed = enemy.movement_speed
	elif "base_speed" in enemy:
		base_speed = enemy.base_speed
	elif enemy_data and "base_speed" in enemy_data:
		base_speed = enemy_data.base_speed
	
	# Apply movement speed multiplier for buffs (like goblin rush)
	var speed_multiplier = 1.0
	if "movement_speed_multiplier" in enemy:
		speed_multiplier = enemy.movement_speed_multiplier
	
	return base_speed * speed_multiplier

# FIXED: SAFE ability usage - no more crashes
func attempt_ability_usage(delta: float):
	# Try to use abilities based on AI behavior and conditions - CRASH PROOF
	# SAFETY: Validate everything first
	if not is_instance_valid(enemy) or not enemy_data:
		return
		
	var player = get_cached_player_reference(delta)
	if not is_instance_valid(player):
		return
		
	if not enemy_data.abilities or enemy_data.abilities.is_empty():
		return
	
	# Check cooldown
	if ability_cooldown_timer > 0:
		return
	
	# AGGRESSIVE ABILITY USAGE: Try to use abilities whenever possible, cooldowns control frequency
	var distance_to_player = enemy.global_position.distance_to(player.global_position)
	
	# FIXED: Use attack_range from enemy_data
	var attack_range = enemy_data.attack_range if enemy_data else 50.0
	
	# Always attempt to use abilities when in combat states - cooldowns will prevent spam
	var should_use_ability = false
	
	match enemy_data.ai_behavior:
		"ranged_kiting":
			# Ranged enemies: more aggressive ability usage within attack range
			should_use_ability = (distance_to_player <= attack_range and state != "retreating")
		
		"melee_aggressive":
			# Melee enemies: use abilities when chasing or attacking
			should_use_ability = (state in ["chasing", "attacking"])
		
		"support_healing":
			# Support enemies: use abilities when hurt or when player is close
			var health_percentage = 1.0
			if enemy.has_method("get_health_percentage"):
				health_percentage = enemy.get_health_percentage()
			elif "current_health" in enemy and "max_health" in enemy and enemy.max_health > 0:
				health_percentage = enemy.current_health / enemy.max_health
			should_use_ability = (health_percentage < 0.8 or distance_to_player <= attack_range)
	
	if should_use_ability:
		use_best_ability(player)

func use_best_ability(player: Node):
	# Use the best available ability - CRASH PROOF
	# SAFETY: Triple validation
	if not is_instance_valid(enemy) or not is_instance_valid(player) or not enemy_data:
		return
		
	# SAFETY: Check if enemy has EnemyAbilities component and it's valid
	var abilities_component = enemy.get_node_or_null("EnemyAbilities")
	if not is_instance_valid(abilities_component):
		return
	
	# FIXED: Get abilities from the abilities component, not enemy_data
	if not abilities_component.available_abilities or abilities_component.available_abilities.is_empty():
		return
	
	# Try to use the first available ability from the component
	for ability_data in abilities_component.available_abilities:
		if not ability_data:  # SAFETY: Skip null abilities
			continue
			
		# SAFETY: Check component still valid before calling methods
		if not is_instance_valid(abilities_component):
			return
			
		if abilities_component.has_method("can_execute_ability") and abilities_component.can_execute_ability(ability_data):
			# Use the ability
			change_state("casting")
			ability_cooldown_timer = min_ability_cooldown
			
			# FIXED: Only use signal-based execution, not direct call
			# This prevents duplicate execution conflicts
			if ability_cast_requested.get_connections().size() > 0:
				ability_cast_requested.emit(ability_data, player.global_position)
				# Minimal logging - only log critical errors
				if randf() < 0.01:  # Only log 1% of ability requests
					print("🔥 %s ability requested: %s" % [enemy_data.enemy_name, ability_data.ability_name])
			else:
				# Fallback to direct execution if no signal connections
				if is_instance_valid(abilities_component) and is_instance_valid(player):
					abilities_component.execute_ability(ability_data, player.global_position)
					# Direct ability execution (logging disabled for performance)
			return

func move_enemy_towards(target_position: Vector2, speed: float):
	# Move enemy towards target position - SAFE
	if not is_instance_valid(enemy):
		return
		
	if not enemy.has_method("move_and_slide"):
		return
	
	# FIXED: Don't override velocity during charges
	if "is_charging" in enemy and enemy.is_charging:
		# During charge, just apply move_and_slide to use existing velocity
		enemy.move_and_slide()
		return
	
	var direction = (target_position - enemy.global_position).normalized()
	enemy.velocity = direction * speed
	
	# Apply separation force to avoid clustering
	apply_separation_force()
	
	# Move the enemy
	enemy.move_and_slide()

func apply_separation_force():
	# Apply separation force to prevent enemy clustering - SAFE
	if not is_instance_valid(enemy) or not separation_enabled:
		return
		
	# CONFIGURATION UPGRADE: Use GameConfig for tunable separation distance
	var separation_distance = GameConfig.get_separation_distance() if GameConfig else 40.0
	var separation_force = Vector2.ZERO
	var nearby_count = 0
	
	# SAFETY: Get valid enemies only
	var enemies = get_tree().get_nodes_in_group("enemies")
	for other_enemy in enemies:
		if other_enemy == enemy or not is_instance_valid(other_enemy):
			continue
		
		var distance = enemy.global_position.distance_to(other_enemy.global_position)
		if distance < separation_distance and distance > 0:
			var away_direction = (enemy.global_position - other_enemy.global_position).normalized()
			var force_strength = (separation_distance - distance) / separation_distance
			separation_force += away_direction * force_strength * 20.0  # REDUCED: Lower force
			nearby_count += 1
	
	# Apply the separation force
	if nearby_count > 0 and is_instance_valid(enemy):
		enemy.velocity += separation_force

func set_separation_enabled(enabled: bool):
	# Enable or disable separation force (useful during charges)
	separation_enabled = enabled

func change_state(new_state: String):
	# Change AI state with validation - SAFE
	if new_state == state:
		return
	
	# State change logging disabled for performance
	
	state = new_state
	state_timer = 0.0
	last_state_change_time = Time.get_ticks_msec() * 0.001
	
	# SAFETY: Check signal connections before emitting
	if ai_state_changed.get_connections().size() > 0:
		ai_state_changed.emit(new_state)

func get_cached_player_reference(delta: float) -> Node:
	# Get cached player reference - PERFORMANCE UPGRADED with PlayerTracker
	# PERFORMANCE UPGRADE: Use PlayerTracker for instant cached access
	if PlayerTracker and PlayerTracker.is_player_valid():
		return PlayerTracker.get_player()
	
	# Fallback to original caching system if PlayerTracker unavailable
	player_cache_timer += delta
	
	if player_cache_timer >= PLAYER_CACHE_INTERVAL or not is_instance_valid(cached_player_reference):
		var new_player = GameManager.get_player()
		if is_instance_valid(new_player):
			cached_player_reference = new_player
		player_cache_timer = 0.0
	
	return cached_player_reference

func should_retreat(health_percentage: float) -> bool:
	# Determine if enemy should retreat based on behavior
	if not enemy_data:
		return false
		
	match enemy_data.ai_behavior:
		"melee_aggressive":
			return health_percentage < 0.15  # Very low retreat threshold
		"ranged_kiting":
			return health_percentage < 0.3   # Medium retreat threshold
		"support_healing":
			return health_percentage < 0.5   # High retreat threshold
		_:
			return health_percentage < retreat_threshold

# SAFETY: Cleanup functions
func _request_cleanup():
	# Request cleanup when enemy is invalid
	cleanup_requested = true
	set_physics_process(false)

func cleanup():
	# Clean up AI controller safely
	is_initialized = false
	cleanup_requested = true
	set_physics_process(false)
	
	# Clear references
	enemy = null
	enemy_data = null
	current_target = null
	cached_player_reference = null

# Debug and utility functions
func get_current_state() -> String:
	return state

func get_distance_to_player() -> float:
	var player = get_cached_player_reference(0.0)
	if is_instance_valid(player) and is_instance_valid(enemy):
		return enemy.global_position.distance_to(player.global_position)
	return -1.0

func is_ability_ready() -> bool:
	return ability_cooldown_timer <= 0.0

# SAFETY: Validation functions
func is_valid() -> bool:
	# Check if AI controller is in valid state
	return is_initialized and not cleanup_requested and is_instance_valid(enemy) and enemy_data != null

func validate_setup() -> bool:
	# Validate AI controller setup
	var is_valid = true
	
	if not is_instance_valid(enemy):
		push_error("EnemyAIController: No enemy reference")
		is_valid = false
	
	if not enemy_data:
		push_error("EnemyAIController: No enemy_data reference")
		is_valid = false
	
	if enemy_data and not enemy_data.ai_behavior:
		push_warning("EnemyAIController: No ai_behavior set, using default")
	
	return is_valid
