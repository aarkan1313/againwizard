# TestKillWavePersistence.gd
# Purpose: Test script to verify kill and wave save/load functionality
# Run this from a scene with GameManager and WaveManager autoloads active

extends Node

func _ready():
	print("\n🧪 === KILL & WAVE PERSISTENCE TEST ===")
	print("Press F1 to simulate kills and progress")
	print("Press F2 to save current state")
	print("Press F3 to load and verify state")
	print("Press F4 to run automated test sequence")

func _input(event):
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_F1:
				simulate_gameplay()
			KEY_F2:
				test_save()
			KEY_F3:
				test_load()
			KEY_F4:
				run_automated_test()

func simulate_gameplay():
	print("\n📊 Simulating gameplay...")
	
	# Add some kills to progress waves
	if WaveManager:
		print("Current state before simulation:")
		print_current_state()
		
		# Simulate 30 kills (should advance to wave 2)
		print("\n🎮 Simulating 30 enemy kills...")
		for i in range(30):
			# Simulate enemy death
			GameEvents.emit_enemy_died("goblin", 10)
		
		print("\nState after simulation:")
		print_current_state()
	else:
		print("❌ WaveManager not found!")

func test_save():
	print("\n💾 Testing save functionality...")
	
	if not SaveManager:
		print("❌ SaveManager not found!")
		return
	
	# Ensure we have a save
	if not SaveManager.current_save:
		SaveManager.create_new_save("TestWizard")
	
	# Save current state
	var success = SaveManager.save_current_game()
	
	if success:
		print("✅ Game saved successfully!")
		print("Saved data:")
		var save_data = SaveManager.current_save.run_data
		print("- Current Wave: ", save_data.current_wave)
		print("- Total Kills: ", save_data.total_kills)
		print("- Kills This Wave: ", save_data.kills_this_wave)
		print("- Waves Completed: ", save_data.waves_completed)
		print("- Highest Wave: ", save_data.highest_wave_reached)
	else:
		print("❌ Save failed!")

func test_load():
	print("\n📥 Testing load functionality...")
	
	if not SaveManager:
		print("❌ SaveManager not found!")
		return
	
	# Store current values for comparison
	var pre_load_wave = WaveManager.current_wave if WaveManager else 0
	var pre_load_kills = WaveManager.total_kills if WaveManager else 0
	
	print("Pre-load state:")
	print_current_state()
	
	# Load the save
	var success = SaveManager.load_saved_game()
	
	if success:
		print("\n✅ Game loaded successfully!")
		print("Post-load state:")
		print_current_state()
		
		# Verify WaveManager was updated
		if WaveManager:
			print("\n🔍 Verification:")
			print("- Wave restored correctly: ", WaveManager.current_wave == SaveManager.current_save.run_data.current_wave)
			print("- Total kills match: ", WaveManager.total_kills == SaveManager.current_save.run_data.total_kills)
			print("- Kills this wave match: ", WaveManager.kills_in_current_wave == SaveManager.current_save.run_data.kills_this_wave)
	else:
		print("❌ Load failed!")

func run_automated_test():
	print("\n🤖 === AUTOMATED KILL/WAVE PERSISTENCE TEST ===")
	
	# Step 1: Reset to known state
	print("\n1️⃣ Creating fresh save...")
	SaveManager.create_new_save("AutoTestWizard")
	
	# Step 2: Simulate specific gameplay
	print("\n2️⃣ Simulating specific kill counts...")
	
	# Kill 10 enemies (stay in wave 1)
	for i in range(10):
		GameEvents.emit_enemy_died("skeleton", 15)
	
	print("After 10 kills:")
	print_current_state()
	
	# Save this state
	print("\n3️⃣ Saving state at 10 kills...")
	SaveManager.save_current_game()
	
	# Continue playing - kill 20 more (advance to wave 2)
	print("\n4️⃣ Killing 20 more enemies...")
	for i in range(20):
		GameEvents.emit_enemy_died("orc", 20)
	
	print("After 30 total kills (should be wave 2):")
	print_current_state()
	
	# Load the earlier save
	print("\n5️⃣ Loading earlier save (10 kills)...")
	SaveManager.load_saved_game()
	
	print("After loading:")
	print_current_state()
	
	# Verify the load worked
	print("\n6️⃣ Verification Results:")
	var passed = true
	
	if WaveManager.current_wave != 1:
		print("❌ Wave not restored correctly (expected 1, got ", WaveManager.current_wave, ")")
		passed = false
	else:
		print("✅ Wave restored correctly")
	
	if WaveManager.total_kills != 10:
		print("❌ Total kills not restored (expected 10, got ", WaveManager.total_kills, ")")
		passed = false
	else:
		print("✅ Total kills restored correctly")
	
	if WaveManager.kills_in_current_wave != 10:
		print("❌ Kills this wave not restored (expected 10, got ", WaveManager.kills_in_current_wave, ")")
		passed = false
	else:
		print("✅ Kills this wave restored correctly")
	
	# Test progression after load
	print("\n7️⃣ Testing progression after load...")
	for i in range(20):
		GameEvents.emit_enemy_died("goblin", 12)
	
	print("After 20 more kills (30 total):")
	print_current_state()
	
	if WaveManager.current_wave == 2 and WaveManager.total_kills == 30:
		print("✅ Progression works correctly after load!")
	else:
		print("❌ Progression broken after load")
		passed = false
	
	print("\n" + ("✅ ALL TESTS PASSED!" if passed else "❌ SOME TESTS FAILED"))

func print_current_state():
	if WaveManager:
		print("📊 Current Wave State:")
		print("  - Wave: ", WaveManager.current_wave)
		print("  - Total Kills: ", WaveManager.total_kills)
		print("  - Kills This Wave: ", WaveManager.kills_in_current_wave)
		print("  - Kills to Next Wave: ", WaveManager.get_kills_to_next_wave())
		print("  - Progress: ", WaveManager.get_wave_progress_percentage(), "%")
	
	if GameManager:
		print("  - GM Wave: ", GameManager.current_wave if "current_wave" in GameManager else "N/A")
		print("  - GM Total Kills: ", GameManager.total_enemies_killed if "total_enemies_killed" in GameManager else "N/A")
		print("  - GM Kills This Wave: ", GameManager.enemies_killed_this_wave if "enemies_killed_this_wave" in GameManager else "N/A")