# GameplayController.gd
# Purpose: Main gameplay loop controller for Phase 3 integrated experience
# Godot Version: 4.4.1 compatible
# Dependencies: WaveManager, EnemySpawner, Player, UI components

extends Node
class_name GameplayController

# UI References  
@onready var wave_label: Label = $"../../UI/GameplayHUD/WaveInfo/WaveLabel"
@onready var kills_label: Label = $"../../UI/GameplayHUD/WaveInfo/KillsLabel"
@onready var enemies_label: Label = $"../../UI/GameplayHUD/WaveInfo/EnemiesLabel"
@onready var enemy_spawner = $"../EnemySpawner"

# State tracking
var gameplay_started: bool = false
var ui_needs_update: bool = true  # Event-driven UI updates instead of polling

func _ready():
	name = "GameplayController"
	
	# Wait for all systems to initialize
	await get_tree().process_frame
	
	# Connect to game events
	if GameEvents:
		GameEvents.enemy_died.connect(_on_enemy_died)
		GameEvents.spell_cast.connect(_on_spell_cast)
		GameEvents.wave_completed.connect(_on_wave_completed)
		print("✅ GameplayController connected to GameEvents")
	
	# Connect to wave manager events
	if WaveManager:
		WaveManager.wave_started.connect(_on_wave_started)
		WaveManager.kill_milestone_reached.connect(_on_milestone_reached)
		print("✅ GameplayController connected to WaveManager")
	
	# Start gameplay after short delay
	await get_tree().create_timer(1.0).timeout
	start_gameplay()

func start_gameplay():
	if gameplay_started:
		return
	
	print("🎮 Starting Phase 3 Gameplay Experience...")
	
	# Validate required systems
	if not _validate_systems():
		push_error("Cannot start gameplay - system validation failed")
		return
	
	# Start enemy spawning
	if enemy_spawner:
		enemy_spawner.start_spawning()
	
	# Initialize UI
	_update_ui()
	
	gameplay_started = true
	print("✅ Gameplay started successfully!")
	
	# Give player some XP to test stat system
	_give_initial_bonuses()

func _give_initial_bonuses():
	var player = get_tree().get_first_node_in_group("players")
	if player and player.has_method("gain_xp"):
		# Give 50 XP to demonstrate stat progression
		player.gain_xp(50.0)
		print("🎁 Player given 50 XP to demonstrate stat system")

func _process(_delta):
	if not gameplay_started:
		return
	
	# Update UI only when needed (event-driven)
	if ui_needs_update:
		_update_ui()
		ui_needs_update = false

func _update_ui():
	if not WaveManager:
		return
	
	var wave_info = WaveManager.get_wave_info()
	
	# Update wave info
	if wave_label:
		wave_label.text = "Wave: " + str(wave_info.current_wave)
	
	if kills_label:
		var kills_to_next = wave_info.kills_to_next
		var current_kills = wave_info.total_kills
		if kills_to_next > 0:
			kills_label.text = "Kills: " + str(current_kills) + "/" + str(current_kills + kills_to_next)
		else:
			kills_label.text = "Kills: " + str(current_kills) + " (Max Wave)"
	
	# Update enemy count
	if enemies_label and enemy_spawner:
		var enemy_count = enemy_spawner.get_active_enemy_count()
		enemies_label.text = "Enemies: " + str(enemy_count)

func _validate_systems() -> bool:
	var systems = {
		"WaveManager": WaveManager,
		"GameEvents": GameEvents,
		"GameManager": GameManager,
		"Enemy Spawner": enemy_spawner
	}
	
	var all_valid = true
	for system_name in systems.keys():
		var system = systems[system_name]
		if system:
			print("  ✅ " + system_name + " - Available")
		else:
			print("  ❌ " + system_name + " - Missing")
			all_valid = false
	
	var player = get_tree().get_first_node_in_group("players")
	if player:
		print("  ✅ Player - Available")
		
		# Check player stat sheet
		if player.has_method("get_stat_sheet"):
			var stat_sheet = player.get_stat_sheet()
			if stat_sheet:
				print("  ✅ Player Stat Sheet - Available")
			else:
				print("  ⚠️ Player Stat Sheet - Null")
		else:
			print("  ❌ Player Stat Sheet - Method missing")
			all_valid = false
	else:
		print("  ❌ Player - Missing")
		all_valid = false
	
	return all_valid

# Event handlers
func _on_enemy_died(enemy_name: String, xp_awarded: int):
	print("💀 Enemy died: ", enemy_name, " (", xp_awarded, " XP)")
	
	# Award XP to player
	var player = get_tree().get_first_node_in_group("players")
	if player and player.has_method("gain_xp"):
		player.gain_xp(float(xp_awarded))
	
	# Trigger UI update
	ui_needs_update = true

func _on_spell_cast(_spell_name: String, _damage: float):
	# Optional: Add visual feedback for spell casting
	pass

func _on_wave_started(new_wave: int, _enemy_multipliers: Dictionary):
	print("🌊 Wave Started! Wave ", new_wave)
	
	# Wave notification removed - UI display is sufficient
	
	# Increase enemy spawner difficulty
	if enemy_spawner:
		enemy_spawner.set_max_enemies(min(20 + new_wave * 4, 80))  # Scale max enemies (doubled scaling)
	
	# Trigger UI update
	ui_needs_update = true

func _on_milestone_reached(kills: int, milestone_name: String):
	print("🏆 Milestone Reached! ", kills, " kills - ", milestone_name)
	
	# Show achievement notification
	if has_node("/root/AchievementNotificationManager"):
		AchievementNotificationManager.show_kill_milestone(kills, milestone_name)
	else:
		# Fallback to existing wave notification - but positioned properly
		_show_wave_notification("Milestone: " + str(kills) + " kills!\n" + milestone_name)

func _on_wave_completed(wave_number: int):
	print("🏆 Wave ", wave_number, " completed!")
	# Wave completion notification removed - UI display is sufficient

func _show_wave_notification(text: String):
	# Create temporary notification label
	var notification = Label.new()
	notification.text = text
	notification.add_theme_font_size_override("font_size", 32)
	notification.add_theme_color_override("font_color", Color.YELLOW)
	notification.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	notification.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	
	# Position above wave UI (wave UI is at y=40-120, so we position at y=130)
	notification.set_anchors_preset(Control.PRESET_TOP_WIDE)
	notification.anchor_left = 0.5
	notification.anchor_right = 0.5
	notification.offset_left = -200
	notification.offset_right = 200
	notification.offset_top = 130
	notification.offset_bottom = 180
	
	# Add to UI with proper fallback handling
	var ui_layer = get_tree().get_first_node_in_group("ui") 
	if not ui_layer:
		# Try multiple possible UI paths
		var ui_paths = ["../UI", "../../UI", "../../../UI"]
		for path in ui_paths:
			ui_layer = get_node_or_null(path)
			if ui_layer:
				break
	
	if ui_layer:
		ui_layer.add_child(notification)
		
		# Animate and remove
		var tween = create_tween()
		tween.tween_property(notification, "modulate:a", 0.0, 2.0)
		tween.tween_callback(notification.queue_free)
	else:
		# Fallback: add to current scene root
		print("⚠️ UI layer not found, adding notification to scene root")
		get_tree().current_scene.add_child(notification)
		
		# Animate and remove
		var tween = create_tween()
		tween.tween_property(notification, "modulate:a", 0.0, 2.0)
		tween.tween_callback(notification.queue_free)

# Debug functions
func _input(event):
	if not event is InputEventKey or not event.pressed:
		return
	
	# Debug controls (F keys)
	match event.keycode:
		KEY_F6:
			_debug_add_kills()
		KEY_F7:
			_debug_add_xp()
		KEY_F8:
			_debug_print_stats()
		KEY_F9:
			_debug_clear_enemies()

func _debug_add_kills():
	if WaveManager:
		WaveManager.debug_add_kills(10)
		print("🐛 DEBUG: Added 10 kills")

func _debug_add_xp():
	var player = get_tree().get_first_node_in_group("players")
	if player and player.has_method("gain_xp"):
		player.gain_xp(100.0)
		print("🐛 DEBUG: Added 100 XP")

func _debug_print_stats():
	var player = get_tree().get_first_node_in_group("players")
	if player and player.has_method("get_stat_sheet"):
		var stat_sheet = player.get_stat_sheet()
		if stat_sheet:
			print("🐛 DEBUG Stats:")
			print("  Intelligence: ", stat_sheet.get_stat_value("intelligence"))
			print("  Spell Damage Multiplier: ", stat_sheet.get_stat_value("spell_damage_multiplier"))
			print("  Critical Chance: ", stat_sheet.get_stat_value("critical_chance"), "%")
			print("  Level: ", stat_sheet.get_stat_value("level"))

func _debug_clear_enemies():
	if enemy_spawner:
		enemy_spawner.clear_all_enemies()
		print("🐛 DEBUG: All enemies cleared")

func stop_gameplay():
	gameplay_started = false
	if enemy_spawner:
		enemy_spawner.stop_spawning()
	print("⏹️ Gameplay stopped")

func get_debug_info() -> String:
	var info = "GameplayController Debug Info:\n"
	info += "- Gameplay Started: " + str(gameplay_started) + "\n"
	info += "- Systems Valid: " + str(_validate_systems()) + "\n"
	
	if WaveManager:
		var wave_info = WaveManager.get_wave_info()
		info += "- Current Wave: " + str(wave_info.current_wave) + "\n"
		info += "- Total Kills: " + str(wave_info.total_kills) + "\n"
	
	if enemy_spawner:
		info += "- Active Enemies: " + str(enemy_spawner.get_active_enemy_count()) + "\n"
	
	return info
