extends Node2D

@onready var skeleton: Skeleton2D = $Skeleton2D
@onready var animation_player: AnimationPlayer = $AnimationPlayer

var bones: Array[Bone2D] = []
var bone_paths: Dictionary = {}
var selected_bone_index: int = 0
var current_animation_index: int = 0

var bone_names: Array[String] = [
	"Root", "Spine", "Chest", "Head",
	"ArmLeft", "ForearmLeft", "HandLeft",
	"ArmRight", "ForearmRight", "HandRight",
	"Pelvis", "ThighLeft", "ShinLeft", "FootLeft",
	"ThighRight", "ShinRight", "FootRight"
]

var animation_names: Array[String] = [
	"idle", "walk", "jump", "dance", "wave", 
	"random_mild", "random_medium", "random_wild",
	"custom_1", "custom_2", "custom_3"
]

func _ready() -> void:
	_collect_bones()
	_build_bone_paths()
	_create_all_animations()
	_highlight_selected_bone()
	
	print("Enhanced Skeleton Controller Ready!")
	print("Press 1-9 for different animations")
	print("Press 0 to generate new random animations")

func _collect_bones() -> void:
	bones.clear()
	bones.append($Skeleton2D/Bone2D_Root)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Head)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft/Bone2D_ForearmLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft/Bone2D_ForearmLeft/Bone2D_HandLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight/Bone2D_ForearmRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight/Bone2D_ForearmRight/Bone2D_HandRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft/Bone2D_ShinLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft/Bone2D_ShinLeft/Bone2D_FootLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight/Bone2D_ShinRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight/Bone2D_ShinRight/Bone2D_FootRight)

func _build_bone_paths() -> void:
	bone_paths = {
		"Root": "Bone2D_Root",
		"Spine": "Bone2D_Root/Bone2D_Spine",
		"Chest": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest",
		"Head": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Head",
		"ArmLeft": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft",
		"ForearmLeft": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft/Bone2D_ForearmLeft",
		"HandLeft": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft/Bone2D_ForearmLeft/Bone2D_HandLeft",
		"ArmRight": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight",
		"ForearmRight": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight/Bone2D_ForearmRight",
		"HandRight": "Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight/Bone2D_ForearmRight/Bone2D_HandRight",
		"Pelvis": "Bone2D_Root/Bone2D_Pelvis",
		"ThighLeft": "Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft",
		"ShinLeft": "Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft/Bone2D_ShinLeft",
		"FootLeft": "Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft/Bone2D_ShinLeft/Bone2D_FootLeft",
		"ThighRight": "Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight",
		"ShinRight": "Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight/Bone2D_ShinRight",
		"FootRight": "Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight/Bone2D_ShinRight/Bone2D_FootRight",
	}

func _create_all_animations() -> void:
	var anim_library = AnimationLibrary.new()
	
	# Create idle animation manually
	anim_library.add_animation("idle", _create_idle_animation())
	
	# Create predefined animations using generator
	anim_library.add_animation("walk", AnimationGenerator.create_walk_animation("Skeleton2D"))
	anim_library.add_animation("jump", AnimationGenerator.create_jump_animation("Skeleton2D"))
	anim_library.add_animation("dance", AnimationGenerator.create_dance_animation("Skeleton2D"))
	anim_library.add_animation("wave", AnimationGenerator.create_wave_animation("Skeleton2D", bone_paths))
	
	# Create random animations with different intensities
	anim_library.add_animation("random_mild", AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 0.3))
	anim_library.add_animation("random_medium", AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 0.6))
	anim_library.add_animation("random_wild", AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 1.0))
	
	# Create placeholder slots for custom animations
	for i in range(3):
		anim_library.add_animation("custom_" + str(i + 1), AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 0.5))
	
	animation_player.add_animation_library("default", anim_library)

func _create_idle_animation() -> Animation:
	var idle_anim = Animation.new()
	idle_anim.length = 2.0
	idle_anim.loop_mode = Animation.LOOP_LINEAR
	
	# Breathing animation - chest subtle scale
	var chest_scale_track = idle_anim.add_track(Animation.TYPE_VALUE)
	idle_anim.track_set_path(chest_scale_track, "Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest:scale")
	idle_anim.track_insert_key(chest_scale_track, 0.0, Vector2(1.0, 1.0))
	idle_anim.track_insert_key(chest_scale_track, 1.0, Vector2(1.05, 1.05))
	idle_anim.track_insert_key(chest_scale_track, 2.0, Vector2(1.0, 1.0))
	
	# Head subtle rotation
	var head_rot_track = idle_anim.add_track(Animation.TYPE_VALUE)
	idle_anim.track_set_path(head_rot_track, "Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Head:rotation")
	idle_anim.track_insert_key(head_rot_track, 0.0, 0.0)
	idle_anim.track_insert_key(head_rot_track, 0.5, deg_to_rad(5))
	idle_anim.track_insert_key(head_rot_track, 1.5, deg_to_rad(-5))
	idle_anim.track_insert_key(head_rot_track, 2.0, 0.0)
	
	return idle_anim

func _input(event: InputEvent) -> void:
	# Animation hotkeys
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_1: _play_animation(0)
			KEY_2: _play_animation(1)
			KEY_3: _play_animation(2)
			KEY_4: _play_animation(3)
			KEY_5: _play_animation(4)
			KEY_6: _play_animation(5)
			KEY_7: _play_animation(6)
			KEY_8: _play_animation(7)
			KEY_9: _play_animation(8)
			KEY_0: _regenerate_random_animations()
	
	# Original controls
	if event.is_action_pressed("ui_left"):
		_rotate_selected_bone(-deg_to_rad(5))
	elif event.is_action_pressed("ui_right"):
		_rotate_selected_bone(deg_to_rad(5))
	elif event.is_action_pressed("ui_up"):
		_scale_selected_bone(Vector2(1.1, 1.1))
	elif event.is_action_pressed("ui_down"):
		_scale_selected_bone(Vector2(0.9, 0.9))
	elif event.is_action_pressed("ui_focus_next"):
		_cycle_selected_bone()
	elif event.is_action_pressed("ui_select"):
		_toggle_animation()
	elif event.is_action_pressed("ui_text_submit"):
		_reset_pose()

func _play_animation(index: int) -> void:
	if index < animation_names.size():
		current_animation_index = index
		animation_player.play("default/" + animation_names[index])
		print("Playing animation: ", animation_names[index])

func _regenerate_random_animations() -> void:
	print("Regenerating random animations...")
	var lib = animation_player.get_animation_library("default")
	
	# Regenerate all random animations
	lib.add_animation("random_mild", AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 0.3))
	lib.add_animation("random_medium", AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 0.6))
	lib.add_animation("random_wild", AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, 1.0))
	
	# Also regenerate custom slots
	for i in range(3):
		lib.add_animation("custom_" + str(i + 1), AnimationGenerator.create_random_animation("Skeleton2D", bone_paths, randf_range(0.2, 0.8)))
	
	print("Random animations regenerated!")

func _rotate_selected_bone(angle: float) -> void:
	if selected_bone_index < bones.size():
		bones[selected_bone_index].rotation += angle

func _scale_selected_bone(scale_factor: Vector2) -> void:
	if selected_bone_index < bones.size():
		bones[selected_bone_index].scale *= scale_factor

func _cycle_selected_bone() -> void:
	selected_bone_index = (selected_bone_index + 1) % bones.size()
	_highlight_selected_bone()
	print("Selected bone: ", bone_names[selected_bone_index])

func _highlight_selected_bone() -> void:
	queue_redraw()

func _toggle_animation() -> void:
	if animation_player.is_playing():
		animation_player.stop()
	else:
		_play_animation(current_animation_index)

func _reset_pose() -> void:
	animation_player.stop()
	for bone in bones:
		bone.rotation = 0
		bone.scale = Vector2(1, 1)
		bone.position = bone.rest.origin

func _draw() -> void:
	if selected_bone_index < bones.size():
		var bone = bones[selected_bone_index]
		var global_pos = bone.global_position
		draw_circle(global_pos, 5, Color.YELLOW)
		draw_circle(global_pos, 7, Color.YELLOW, false, 2.0)