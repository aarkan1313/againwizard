extends Node

class_name AnimationGenerator

# Animation generation parameters
const ANIMATION_LENGTH := 2.0
const KEYFRAME_COUNT := 4

# Bone constraint definitions
const BONE_CONSTRAINTS = {
	"Head": {"rotation": [-30, 30], "scale": [0.95, 1.05]},
	"Chest": {"rotation": [-10, 10], "scale": [0.95, 1.1]},
	"Spine": {"rotation": [-15, 15], "scale": [0.98, 1.02]},
	"ArmLeft": {"rotation": [-90, 45], "scale": [0.9, 1.1]},
	"ArmRight": {"rotation": [-45, 90], "scale": [0.9, 1.1]},
	"ForearmLeft": {"rotation": [-120, 0], "scale": [0.95, 1.05]},
	"ForearmRight": {"rotation": [0, 120], "scale": [0.95, 1.05]},
	"HandLeft": {"rotation": [-45, 45], "scale": [0.9, 1.1]},
	"HandRight": {"rotation": [-45, 45], "scale": [0.9, 1.1]},
	"Pelvis": {"rotation": [-10, 10], "scale": [0.98, 1.02]},
	"ThighLeft": {"rotation": [-45, 90], "scale": [0.95, 1.05]},
	"ThighRight": {"rotation": [-45, 90], "scale": [0.95, 1.05]},
	"ShinLeft": {"rotation": [-120, 0], "scale": [0.95, 1.05]},
	"ShinRight": {"rotation": [-120, 0], "scale": [0.95, 1.05]},
	"FootLeft": {"rotation": [-30, 30], "scale": [0.95, 1.05]},
	"FootRight": {"rotation": [-30, 30], "scale": [0.95, 1.05]},
}

# Predefined animation templates
static func create_walk_animation(skeleton_path: String) -> Animation:
	var anim = Animation.new()
	anim.length = 1.0
	anim.loop_mode = Animation.LOOP_LINEAR
	
	# Leg movement
	_add_walk_leg_tracks(anim, skeleton_path, "Left", 0.0)
	_add_walk_leg_tracks(anim, skeleton_path, "Right", 0.5)
	
	# Arm swing
	_add_walk_arm_tracks(anim, skeleton_path, "Left", 0.5)
	_add_walk_arm_tracks(anim, skeleton_path, "Right", 0.0)
	
	# Body sway
	var spine_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(spine_track, skeleton_path + "/Bone2D_Root/Bone2D_Spine:rotation")
	anim.track_insert_key(spine_track, 0.0, deg_to_rad(-2))
	anim.track_insert_key(spine_track, 0.5, deg_to_rad(2))
	anim.track_insert_key(spine_track, 1.0, deg_to_rad(-2))
	
	return anim

static func _add_walk_leg_tracks(anim: Animation, skeleton_path: String, side: String, offset: float) -> void:
	# Thigh
	var thigh_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(thigh_track, skeleton_path + "/Bone2D_Root/Bone2D_Pelvis/Bone2D_Thigh" + side + ":rotation")
	anim.track_insert_key(thigh_track, offset, deg_to_rad(-30))
	anim.track_insert_key(thigh_track, offset + 0.25, deg_to_rad(30))
	anim.track_insert_key(thigh_track, offset + 0.5, deg_to_rad(-30))
	
	# Shin
	var shin_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(shin_track, skeleton_path + "/Bone2D_Root/Bone2D_Pelvis/Bone2D_Thigh" + side + "/Bone2D_Shin" + side + ":rotation")
	anim.track_insert_key(shin_track, offset, deg_to_rad(-45))
	anim.track_insert_key(shin_track, offset + 0.25, deg_to_rad(0))
	anim.track_insert_key(shin_track, offset + 0.5, deg_to_rad(-45))

static func _add_walk_arm_tracks(anim: Animation, skeleton_path: String, side: String, offset: float) -> void:
	var arm_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(arm_track, skeleton_path + "/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Arm" + side + ":rotation")
	var base_rot = deg_to_rad(-45 if side == "Left" else 45)
	anim.track_insert_key(arm_track, offset, base_rot + deg_to_rad(-20))
	anim.track_insert_key(arm_track, offset + 0.5, base_rot + deg_to_rad(20))

static func create_jump_animation(skeleton_path: String) -> Animation:
	var anim = Animation.new()
	anim.length = 1.0
	anim.loop_mode = Animation.LOOP_NONE
	
	# Crouch
	var pelvis_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(pelvis_track, skeleton_path + "/Bone2D_Root/Bone2D_Pelvis:position")
	anim.track_insert_key(pelvis_track, 0.0, Vector2(0, 10))
	anim.track_insert_key(pelvis_track, 0.2, Vector2(0, 20))
	anim.track_insert_key(pelvis_track, 0.5, Vector2(0, -20))
	anim.track_insert_key(pelvis_track, 1.0, Vector2(0, 10))
	
	# Arms up
	for side in ["Left", "Right"]:
		var arm_track = anim.add_track(Animation.TYPE_VALUE)
		anim.track_set_path(arm_track, skeleton_path + "/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Arm" + side + ":rotation")
		var base = deg_to_rad(-45 if side == "Left" else 45)
		anim.track_insert_key(arm_track, 0.0, base)
		anim.track_insert_key(arm_track, 0.5, base + deg_to_rad(-90 if side == "Left" else 90))
		anim.track_insert_key(arm_track, 1.0, base)
	
	return anim

static func create_dance_animation(skeleton_path: String) -> Animation:
	var anim = Animation.new()
	anim.length = 2.0
	anim.loop_mode = Animation.LOOP_LINEAR
	
	# Hip sway
	var pelvis_rot_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(pelvis_rot_track, skeleton_path + "/Bone2D_Root/Bone2D_Pelvis:rotation")
	anim.track_insert_key(pelvis_rot_track, 0.0, deg_to_rad(-10))
	anim.track_insert_key(pelvis_rot_track, 0.5, deg_to_rad(10))
	anim.track_insert_key(pelvis_rot_track, 1.0, deg_to_rad(-10))
	anim.track_insert_key(pelvis_rot_track, 1.5, deg_to_rad(10))
	anim.track_insert_key(pelvis_rot_track, 2.0, deg_to_rad(-10))
	
	# Arms wave
	for side in ["Left", "Right"]:
		var arm_track = anim.add_track(Animation.TYPE_VALUE)
		anim.track_set_path(arm_track, skeleton_path + "/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Arm" + side + ":rotation")
		var offset = 0.0 if side == "Left" else 1.0
		anim.track_insert_key(arm_track, offset, deg_to_rad(-90))
		anim.track_insert_key(arm_track, offset + 0.5, deg_to_rad(-45))
		anim.track_insert_key(arm_track, offset + 1.0, deg_to_rad(-90))
		anim.track_insert_key(arm_track, offset + 1.5, deg_to_rad(-45))
	
	# Head bob
	var head_track = anim.add_track(Animation.TYPE_VALUE)
	anim.track_set_path(head_track, skeleton_path + "/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Head:rotation")
	for i in range(8):
		var time = i * 0.25
		anim.track_insert_key(head_track, time, deg_to_rad(sin(time * TAU) * 15))
	
	return anim

static func create_random_animation(skeleton_path: String, bone_paths: Dictionary, intensity: float = 1.0) -> Animation:
	var anim = Animation.new()
	anim.length = ANIMATION_LENGTH
	anim.loop_mode = Animation.LOOP_LINEAR
	
	for bone_name in bone_paths:
		if bone_name == "Root":
			continue
			
		var bone_path = bone_paths[bone_name]
		
		# Rotation track
		if randf() > 0.3:  # 70% chance to animate rotation
			var rot_track = anim.add_track(Animation.TYPE_VALUE)
			anim.track_set_path(rot_track, skeleton_path + "/" + bone_path + ":rotation")
			
			var constraints = BONE_CONSTRAINTS.get(bone_name, {"rotation": [-45, 45]})
			var rot_range = constraints["rotation"]
			
			for i in range(KEYFRAME_COUNT):
				var time = (i / float(KEYFRAME_COUNT - 1)) * ANIMATION_LENGTH
				var value = randf_range(deg_to_rad(rot_range[0]), deg_to_rad(rot_range[1])) * intensity
				anim.track_insert_key(rot_track, time, value)
		
		# Scale track
		if randf() > 0.7:  # 30% chance to animate scale
			var scale_track = anim.add_track(Animation.TYPE_VALUE)
			anim.track_set_path(scale_track, skeleton_path + "/" + bone_path + ":scale")
			
			var constraints = BONE_CONSTRAINTS.get(bone_name, {"scale": [0.9, 1.1]})
			var scale_range = constraints["scale"]
			
			for i in range(KEYFRAME_COUNT):
				var time = (i / float(KEYFRAME_COUNT - 1)) * ANIMATION_LENGTH
				var value = randf_range(scale_range[0], scale_range[1]) * (1.0 + (intensity - 1.0) * 0.5)
				anim.track_insert_key(scale_track, time, Vector2(value, value))
	
	return anim

static func create_wave_animation(skeleton_path: String, bone_paths: Dictionary) -> Animation:
	var anim = Animation.new()
	anim.length = 3.0
	anim.loop_mode = Animation.LOOP_LINEAR
	
	# Create a wave that travels through the skeleton
	var bone_order = ["Pelvis", "Spine", "Chest", "Head", "ArmLeft", "ForearmLeft", "HandLeft"]
	
	for i in range(bone_order.size()):
		var bone_name = bone_order[i]
		if not bone_paths.has(bone_name):
			continue
			
		var bone_path = bone_paths[bone_name]
		var delay = i * 0.2
		
		var rot_track = anim.add_track(Animation.TYPE_VALUE)
		anim.track_set_path(rot_track, skeleton_path + "/" + bone_path + ":rotation")
		
		for j in range(4):
			var time = delay + j * 0.75
			if time > anim.length:
				time -= anim.length
			var angle = sin(j * PI * 0.5) * deg_to_rad(20)
			anim.track_insert_key(rot_track, time, angle)
	
	return anim