extends Node2D

@onready var skeleton: Skeleton2D = $Skeleton2D
@onready var animation_player: AnimationPlayer = $AnimationPlayer

var bones: Array[Bone2D] = []
var selected_bone_index: int = 0
var bone_names: Array[String] = [
	"Root", "Spine", "Chest", "Head",
	"ArmLeft", "ForearmLeft", "HandLeft",
	"ArmRight", "ForearmRight", "HandRight",
	"Pelvis", "ThighLeft", "ShinLeft", "FootLeft",
	"ThighRight", "ShinRight", "FootRight"
]

func _ready() -> void:
	_collect_bones()
	_create_idle_animation()
	_highlight_selected_bone()

func _collect_bones() -> void:
	bones.clear()
	bones.append($Skeleton2D/Bone2D_Root)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Head)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft/Bone2D_ForearmLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft/Bone2D_ForearmLeft/Bone2D_HandLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight/Bone2D_ForearmRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight/Bone2D_ForearmRight/Bone2D_HandRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft/Bone2D_ShinLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighLeft/Bone2D_ShinLeft/Bone2D_FootLeft)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight/Bone2D_ShinRight)
	bones.append($Skeleton2D/Bone2D_Root/Bone2D_Pelvis/Bone2D_ThighRight/Bone2D_ShinRight/Bone2D_FootRight)

func _create_idle_animation() -> void:
	var anim_library = AnimationLibrary.new()
	var idle_anim = Animation.new()
	idle_anim.length = 2.0
	idle_anim.loop_mode = Animation.LOOP_LINEAR
	
	# Breathing animation - chest subtle scale
	var chest_scale_track = idle_anim.add_track(Animation.TYPE_VALUE)
	idle_anim.track_set_path(chest_scale_track, "Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest:scale")
	idle_anim.track_insert_key(chest_scale_track, 0.0, Vector2(1.0, 1.0))
	idle_anim.track_insert_key(chest_scale_track, 1.0, Vector2(1.05, 1.05))
	idle_anim.track_insert_key(chest_scale_track, 2.0, Vector2(1.0, 1.0))
	
	# Head subtle rotation
	var head_rot_track = idle_anim.add_track(Animation.TYPE_VALUE)
	idle_anim.track_set_path(head_rot_track, "Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_Head:rotation")
	idle_anim.track_insert_key(head_rot_track, 0.0, 0.0)
	idle_anim.track_insert_key(head_rot_track, 0.5, deg_to_rad(5))
	idle_anim.track_insert_key(head_rot_track, 1.5, deg_to_rad(-5))
	idle_anim.track_insert_key(head_rot_track, 2.0, 0.0)
	
	# Arms subtle movement
	var arm_left_rot_track = idle_anim.add_track(Animation.TYPE_VALUE)
	idle_anim.track_set_path(arm_left_rot_track, "Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmLeft:rotation")
	idle_anim.track_insert_key(arm_left_rot_track, 0.0, deg_to_rad(-45))
	idle_anim.track_insert_key(arm_left_rot_track, 1.0, deg_to_rad(-40))
	idle_anim.track_insert_key(arm_left_rot_track, 2.0, deg_to_rad(-45))
	
	var arm_right_rot_track = idle_anim.add_track(Animation.TYPE_VALUE)
	idle_anim.track_set_path(arm_right_rot_track, "Skeleton2D/Bone2D_Root/Bone2D_Spine/Bone2D_Chest/Bone2D_ArmRight:rotation")
	idle_anim.track_insert_key(arm_right_rot_track, 0.0, deg_to_rad(45))
	idle_anim.track_insert_key(arm_right_rot_track, 1.0, deg_to_rad(40))
	idle_anim.track_insert_key(arm_right_rot_track, 2.0, deg_to_rad(45))
	
	anim_library.add_animation("idle", idle_anim)
	animation_player.add_animation_library("default", anim_library)

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_left"):
		_rotate_selected_bone(-deg_to_rad(5))
	elif event.is_action_pressed("ui_right"):
		_rotate_selected_bone(deg_to_rad(5))
	elif event.is_action_pressed("ui_up"):
		_scale_selected_bone(Vector2(1.1, 1.1))
	elif event.is_action_pressed("ui_down"):
		_scale_selected_bone(Vector2(0.9, 0.9))
	elif event.is_action_pressed("ui_focus_next"):
		_cycle_selected_bone()
	elif event.is_action_pressed("ui_select"):
		_toggle_animation()
	elif event.is_action_pressed("ui_text_submit"):
		_reset_pose()

func _rotate_selected_bone(angle: float) -> void:
	if selected_bone_index < bones.size():
		bones[selected_bone_index].rotation += angle

func _scale_selected_bone(scale_factor: Vector2) -> void:
	if selected_bone_index < bones.size():
		bones[selected_bone_index].scale *= scale_factor

func _cycle_selected_bone() -> void:
	selected_bone_index = (selected_bone_index + 1) % bones.size()
	_highlight_selected_bone()
	print("Selected bone: ", bone_names[selected_bone_index])

func _highlight_selected_bone() -> void:
	queue_redraw()

func _toggle_animation() -> void:
	if animation_player.is_playing():
		animation_player.stop()
	else:
		animation_player.play("default/idle")

func _reset_pose() -> void:
	animation_player.stop()
	for bone in bones:
		bone.rotation = 0
		bone.scale = Vector2(1, 1)
		bone.position = bone.rest.origin

func _draw() -> void:
	if selected_bone_index < bones.size():
		var bone = bones[selected_bone_index]
		var global_pos = bone.global_position
		draw_circle(global_pos, 5, Color.YELLOW)
		draw_circle(global_pos, 7, Color.YELLOW, false, 2.0)