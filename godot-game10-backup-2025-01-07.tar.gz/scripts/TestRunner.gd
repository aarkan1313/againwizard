extends Node2D
# TestRunner.gd - Phase 0 Infrastructure Testing
# Integrated with Debug Menu F1 -> Testing Tab

var test_results: Array[String] = []
var last_test_results: Array[String] = []
var tests_completed: bool = false

# Debug control flag - set to false to reduce console spam
var enable_spell_input_debug: bool = false

func _ready():
	# Set this node to process even when paused
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	# Set UI to also work when paused
	$UI.process_mode = Node.PROCESS_MODE_ALWAYS
	
	print("🧪 Phase 0 + Phase 1 + Phase 2 Test Runner initialized")
	print("SPACE key now reserved for DODGE functionality")
	print("Use F1 Debug Menu -> Testing Tab -> 'Run All Tests' for testing")

func _input(event):
	# Only handle key events, ignore mouse motion
	if not event is InputEventKey:
		return
		
	# REMOVED SPACE KEY - Now available for dodge functionality
	# Use F1 Debug Menu -> Testing Tab -> "Run All Tests" instead
	if event.pressed and event.keycode == KEY_H:  # H key - damage player
		print("🔑 DEBUG: H key pressed")
		_debug_damage_player()
	elif event.pressed and event.keycode == KEY_M:  # M key - consume mana
		print("🔑 DEBUG: M key pressed")
		_debug_consume_mana()
	elif event.pressed and event.keycode == KEY_R:  # R key - regen status
		print("🔑 DEBUG: R key pressed")
		_debug_regen_status()
	elif event.pressed and event.keycode == KEY_Q:  # Q key - spell test
		print("🔑 DEBUG: Q key pressed")
		_debug_spell_casting()
	elif event.pressed and event.keycode == KEY_I:  # I key - intelligence debug
		print("🔑 DEBUG: I key pressed")
		_debug_intelligence_scaling()
	elif event.pressed and event.keycode == KEY_O:  # O key - all stats debug
		print("🔑 DEBUG: O key pressed")
		_debug_all_stats_caching()
	# Phase 2: Test spell input detection (keys 1-5)
	elif event.is_action_pressed("spell_1"):
		if enable_spell_input_debug:
			print("🔮 SPELL INPUT: Spell 1 detected - attempting cast")
		_test_spell_cast(0)
	elif event.is_action_pressed("spell_2"):
		if enable_spell_input_debug:
			print("🔮 SPELL INPUT: Spell 2 detected - attempting cast")
		_test_spell_cast(1)
	elif event.is_action_pressed("spell_3"):
		if enable_spell_input_debug:
			print("🔮 SPELL INPUT: Spell 3 detected - attempting cast")
		_test_spell_cast(2)
	elif event.is_action_pressed("spell_4"):
		if enable_spell_input_debug:
			print("🔮 SPELL INPUT: Spell 4 detected - attempting cast")
		_test_spell_cast(3)
	elif event.is_action_pressed("spell_5"):
		if enable_spell_input_debug:
			print("🔮 SPELL INPUT: Spell 5 detected - attempting cast")
		_test_spell_cast(4)
	# Note: ESC now handled by GameManager for proper pause/unpause

func run_all_tests():
	print("🧪 Starting Phase 0 + 1 + 2 comprehensive tests...")
	test_results.clear()
	tests_completed = false
	
	# Test 1: Singleton Initialization
	test_singletons_exist()
	
	# Test 2: GameEvents System
	test_game_events()
	
	# Test 3: GameManager System  
	test_game_manager()
	
	# Test 4: Input System
	test_input_system()
	
	# Test 5: Project Configuration
	test_project_configuration()
	
	# Test 6: Performance Baseline
	test_performance()
	
	# Test 7: Player System (Phase 1)
	test_player_system()
	
	# Test 8: Spell System (Phase 2)
	test_spell_system()
	
	# Display Results and store for debug menu
	display_test_results()
	tests_completed = true

func test_singletons_exist() -> bool:
	add_test_result("=== SINGLETON EXISTENCE TESTS ===")
	
	var success = true
	
	# Test GameEvents
	if GameEvents != null:
		add_test_result("✅ GameEvents singleton: FOUND")
	else:
		add_test_result("❌ GameEvents singleton: MISSING")
		success = false
	
	# Test GameManager
	if GameManager != null:
		add_test_result("✅ GameManager singleton: FOUND")
	else:
		add_test_result("❌ GameManager singleton: MISSING")
		success = false
	
	return success

func test_game_events() -> bool:
	add_test_result("\n=== GAMEEVENTS SYSTEM TESTS ===")
	
	var success = true
	
	if GameEvents == null:
		add_test_result("❌ GameEvents not available for testing")
		return false
	
	# Test signal emission
	GameEvents.emit_player_moved(Vector2(100, 200))
	add_test_result("✅ player_moved signal: WORKS")
	
	GameEvents.emit_player_health_changed(80.0, 100.0)
	add_test_result("✅ player_health_changed signal: WORKS")
	
	GameEvents.emit_spell_cast("TestSpell", 25.0)
	add_test_result("✅ spell_cast signal: WORKS")
	
	# Test validation (this should trigger validation error in console)
	GameEvents.emit_player_health_changed(-50.0, 100.0)  # Should fail validation
	add_test_result("✅ Input validation: TEST COMPLETED (check console for error)")

	
	return success

func test_game_manager() -> bool:
	add_test_result("\n=== GAMEMANAGER SYSTEM TESTS ===")
	
	var success = true
	
	if GameManager == null:
		add_test_result("❌ GameManager not available for testing")
		return false
	
	# Test state management
	var _initial_state = GameManager.get_current_state()
	add_test_result("✅ Initial state: " + GameManager.get_state_string())
	
	# Test health system
	var initial_health = GameManager.player_health
	add_test_result("✅ Initial health: " + str(initial_health) + "/" + str(GameManager.player_max_health))
	
	# Test performance tracking
	var perf_info = GameManager.get_performance_info()
	add_test_result("✅ Performance tracking: " + str(perf_info.fps) + " FPS")
	
	return success

func test_pause_system():
	add_test_result("\n=== PAUSE SYSTEM TEST ===")
	
	if GameManager == null:
		add_test_result("❌ GameManager not available")
		return
	
	# Wait a frame for GameManager to process the input
	await get_tree().process_frame
	var current_state = GameManager.get_state_string()
	
	add_test_result("✅ Pause system activated: " + current_state)
	add_test_result("ℹ️ Press ESC again to unpause, or P to toggle manually")
	display_test_results()

func manual_pause_test():
	add_test_result("\n=== MANUAL PAUSE TOGGLE TEST ===")
	
	if GameManager == null:
		add_test_result("❌ GameManager not available")
		return
	
	var before_state = GameManager.get_state_string()
	GameManager.toggle_pause()
	
	await get_tree().process_frame
	var after_state = GameManager.get_state_string()
	
	add_test_result("Manual toggle: " + before_state + " -> " + after_state)
	display_test_results()

func test_input_system() -> bool:
	add_test_result("\n=== INPUT SYSTEM TESTS ===")
	
	var success = true
	
	# Test input map configuration
	var input_actions = [
		"move_left", "move_right", "move_up", "move_down",
		"spell_1", "spell_2", "spell_3", "spell_4", "spell_5",
		"pause_game"
	]
	
	for action in input_actions:
		if InputMap.has_action(action):
			add_test_result("✅ Input action '" + action + "': CONFIGURED")
		else:
			add_test_result("❌ Input action '" + action + "': MISSING")
			success = false
	
	return success

func test_project_configuration() -> bool:
	add_test_result("\n=== PROJECT CONFIGURATION TESTS ===")
	
	var success = true
	
	# Test collision layers
	var layer_names = [
		["player", 1],
		["enemies", 2], 
		["projectiles", 3],
		["environment", 4]
	]
	
	for layer_data in layer_names:
		var layer_name = ProjectSettings.get_setting("layer_names/2d_physics/layer_" + str(layer_data[1]), "")
		if layer_name == layer_data[0]:
			add_test_result("✅ Collision layer " + str(layer_data[1]) + " ('" + layer_data[0] + "'): CONFIGURED")
		else:
			add_test_result("❌ Collision layer " + str(layer_data[1]) + ": EXPECTED '" + layer_data[0] + "' GOT '" + layer_name + "'")
			success = false
	
	return success

func test_performance() -> bool:
	add_test_result("\n=== PERFORMANCE BASELINE TESTS ===")
	
	var fps = Engine.get_frames_per_second()
	add_test_result("✅ Current FPS: " + str(fps))
	
	if fps >= 55:  # Allow some variance
		add_test_result("✅ Performance: ACCEPTABLE (>= 55 FPS)")
		return true
	else:
		add_test_result("⚠️ Performance: LOW (" + str(fps) + " FPS)")
		return false

func test_player_system() -> bool:
	add_test_result("\n=== PLAYER SYSTEM TESTS (Phase 1) ===")
	
	var success = true
	
	# Test InputHandler singleton
	if InputHandler != null:
		add_test_result("✅ InputHandler singleton: FOUND")
	else:
		add_test_result("❌ InputHandler singleton: MISSING")
		success = false
	
	# Test Player node exists
	var player = get_node_or_null("GameWorld/Player")
	if player != null:
		add_test_result("✅ Player node: FOUND")
		
		# Test Player components using safe node access
		var movement_comp = player.get_node_or_null("MovementComponent")
		if movement_comp != null:
			add_test_result("✅ MovementComponent: FOUND")
		else:
			add_test_result("❌ MovementComponent: MISSING")
			success = false
		
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp != null:
			add_test_result("✅ HealthComponent: FOUND")
		else:
			add_test_result("❌ HealthComponent: MISSING")
			success = false
		
		# Test collision setup
		if player.collision_layer == 1:
			add_test_result("✅ Player collision layer: CORRECT (1)")
		else:
			add_test_result("❌ Player collision layer: INCORRECT (" + str(player.collision_layer) + ")")
			success = false
		
		if player.collision_mask == 4:
			add_test_result("✅ Player collision mask: CORRECT (4)")
		else:
			add_test_result("❌ Player collision mask: INCORRECT (" + str(player.collision_mask) + ")")
			success = false
		
		# Test GameManager registration
		if GameManager.player_reference == player:
			add_test_result("✅ GameManager player_reference: REGISTERED")
		else:
			add_test_result("❌ GameManager player_reference: NOT REGISTERED")
			success = false
		
		# Test Player integrity check
		if player.has_method("validate_player_integrity"):
			if player.validate_player_integrity():
				add_test_result("✅ Player integrity validation: PASSED")
			else:
				add_test_result("❌ Player integrity validation: FAILED")
				success = false
		else:
			add_test_result("❌ Player integrity validation: METHOD NOT FOUND")
			success = false
		
	else:
		add_test_result("❌ Player node: NOT FOUND")
		success = false
	
	# Test movement input system
	var movement_vector = InputHandler.get_movement_vector()
	add_test_result("✅ Movement input system: READY (current: " + str(movement_vector) + ")")
	
	return success

func test_spell_system() -> bool:
	add_test_result("\n=== SPELL SYSTEM TESTS (Phase 2) ===")
	
	var success = true
	
	# Test Player node exists (prerequisite)
	var player = get_node_or_null("GameWorld/Player")
	if player == null:
		add_test_result("❌ Player node: NOT FOUND - Cannot test spell system")
		return false
	
	# Test SpellComponent exists
	var spell_comp = player.get_node_or_null("SpellComponent")
	if spell_comp != null:
		add_test_result("✅ SpellComponent: FOUND")
		
		# Test SpellComponent setup validation
		if spell_comp.has_method("validate_setup"):
			if spell_comp.validate_setup():
				add_test_result("✅ SpellComponent validation: PASSED")
			else:
				add_test_result("❌ SpellComponent validation: FAILED")
				success = false
		else:
			add_test_result("❌ SpellComponent validate_setup method: MISSING")
			success = false
		
		# Test equipped spells
		if spell_comp.has_method("get_equipped_spells"):
			var spells = spell_comp.get_equipped_spells()
			if spells.size() > 0:
				add_test_result("✅ Equipped spells: " + str(spells.size()) + " spells loaded")
				
				# Test first spell (fireball)
				if spells[0].spell_name == "Fireball":
					add_test_result("✅ Default Fireball spell: LOADED")
				else:
					add_test_result("❌ Default spell name: EXPECTED 'Fireball' GOT '" + str(spells[0].spell_name) + "'")
					success = false
			else:
				add_test_result("❌ Equipped spells: NO SPELLS LOADED")
				success = false
		else:
			add_test_result("❌ get_equipped_spells method: MISSING")
			success = false
		
		# Test spell readiness check
		if spell_comp.has_method("is_spell_ready"):
			var spell_ready = spell_comp.is_spell_ready(0)
			add_test_result("✅ Spell readiness check: " + ("READY" if spell_ready else "NOT READY"))
		else:
			add_test_result("❌ is_spell_ready method: MISSING")
			success = false
		
	else:
		add_test_result("❌ SpellComponent: NOT FOUND")
		success = false
	
	# Test SpellData class availability 
	var spell_data_test = SpellData.new()
	if spell_data_test != null:
		add_test_result("✅ SpellData class: AVAILABLE")
		# SpellData is a Resource, not a Node - no need to free it
		spell_data_test = null
	else:
		add_test_result("❌ SpellData class: NOT AVAILABLE")
		success = false
	
	# Test SpellProjectile scene
	var projectile_path = "res://scenes/SpellProjectile.tscn"
	if ResourceLoader.exists(projectile_path):
		add_test_result("✅ SpellProjectile scene: EXISTS")
		
		# Test scene loading
		var projectile_scene = load(projectile_path)
		if projectile_scene != null:
			add_test_result("✅ SpellProjectile scene: LOADS SUCCESSFULLY")
		else:
			add_test_result("❌ SpellProjectile scene: FAILED TO LOAD")
			success = false
	else:
		add_test_result("❌ SpellProjectile scene: NOT FOUND")
		success = false
	
	# Test spell input actions
	var spell_actions = ["spell_1", "spell_2", "spell_3", "spell_4", "spell_5"]
	for action in spell_actions:
		if InputMap.has_action(action):
			add_test_result("✅ Input action '" + action + "': CONFIGURED")
		else:
			add_test_result("❌ Input action '" + action + "': MISSING")
			success = false
	
	return success

func add_test_result(text: String):
	test_results.append(text)
	print(text)

# API for Debug Menu to get test results
func get_last_test_results() -> Array[String]:
	return last_test_results.duplicate()

func has_test_results() -> bool:
	return last_test_results.size() > 0

# Infrastructure-only tests (Phase 0)
func run_infrastructure_tests():
	print("🧪 Running Infrastructure Tests Only (Phase 0)...")
	test_results.clear()
	
	test_singletons_exist()
	test_game_events()
	test_game_manager()
	test_input_system()
	test_project_configuration()
	test_performance()
	
	# Store results for debug menu
	last_test_results = test_results.duplicate()
	print("🧪 Infrastructure tests complete!")

# Phase 0 tests specifically
func run_phase_0_tests():
	run_infrastructure_tests()

func display_test_results():
	# Store results for debug menu access
	last_test_results = test_results.duplicate()
	
	var display_text = ""
	for result in test_results:
		display_text += result + "\n"
	
	display_text += "\nTest Summary:\n"
	display_text += "Total tests run: " + str(test_results.size()) + "\n"
	
	if tests_completed:
		display_text += "✅ Phase 0 + Phase 1 + Phase 2 testing complete!\n"
		display_text += "Check console for detailed results\n"
		display_text += "Player movement: Use WASD keys to test\n"
		display_text += "Spell casting: Press '1' key to cast fireball"
	
	print("📋 Test results summary available via Debug Menu F1 -> Testing Tab")

# Debug functions for testing health and mana systems
func _debug_damage_player():
	print("🧪 DEBUG: H key detected - damaging player")
	var player = get_node_or_null("GameWorld/Player")
	if player:
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp and health_comp.has_method("take_damage"):
			print("🧪 DEBUG: Damaging player for 20 health")
			health_comp.take_damage(20.0)
		else:
			print("❌ DEBUG: HealthComponent or take_damage method not found")
	else:
		print("❌ DEBUG: Player not found")

func _debug_consume_mana():
	print("🧪 DEBUG: M key detected - attempting mana consumption")
	var player = get_node_or_null("GameWorld/Player")
	if player:
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp:
			if health_comp.has_method("consume_mana"):
				print("🧪 DEBUG: Before - Mana: " + str(health_comp.current_mana) + "/" + str(health_comp.max_mana))
				var success = health_comp.consume_mana(10.0)
				print("🧪 DEBUG: After - Mana: " + str(health_comp.current_mana) + "/" + str(health_comp.max_mana))
				if not success:
					print("⚠️ DEBUG: Mana consumption failed (insufficient mana?)")
				else:
					print("✅ DEBUG: Mana consumption successful")
			else:
				print("❌ DEBUG: consume_mana method not found")
				print("🔍 DEBUG: Available methods: " + str(health_comp.get_method_list()))
		else:
			print("❌ DEBUG: HealthComponent not found")
	else:
		print("❌ DEBUG: Player not found")

func _debug_regen_status():
	var player = get_node_or_null("GameWorld/Player")
	if player:
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp:
			if health_comp.has_method("get_status"):
				print("📊 DEBUG: " + health_comp.get_status())
			else:
				print("📊 DEBUG: Health: " + str(health_comp.current_health) + "/" + str(health_comp.max_health))
				print("📊 DEBUG: Mana: " + str(health_comp.current_mana) + "/" + str(health_comp.max_mana))
				print("📊 DEBUG: Health Regen: " + str(health_comp.health_regen_rate) + "/sec")
				print("📊 DEBUG: Mana Regen: " + str(health_comp.mana_regen_rate) + "/sec")
		else:
			print("❌ DEBUG: HealthComponent not found")
	else:
		print("❌ DEBUG: Player not found")

# Debug functions for testing spell system
func _debug_spell_casting():
	print("🧪 DEBUG: Q key detected - testing spell system")
	var player = get_node_or_null("GameWorld/Player")
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent") 
		if spell_comp:
			if spell_comp.has_method("get_debug_info"):
				print("🔮 DEBUG: " + spell_comp.get_debug_info())
			else:
				print("🔮 DEBUG: SpellComponent found but no debug info available")
				# Try to get basic info
				if spell_comp.has_method("get_equipped_spells"):
					var spells = spell_comp.get_equipped_spells()
					print("🔮 DEBUG: Equipped spells: " + str(spells.size()))
				if spell_comp.has_method("is_spell_ready"):
					var is_ready = spell_comp.is_spell_ready(0)
					print("🔮 DEBUG: First spell ready: " + str(is_ready))
		else:
			print("❌ DEBUG: SpellComponent not found")
	else:
		print("❌ DEBUG: Player not found")

func _test_spell_cast(spell_index: int):
	if enable_spell_input_debug:
		print("🧪 DEBUG: Testing spell cast for index " + str(spell_index))
	var player = get_node_or_null("GameWorld/Player")
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp:
			if spell_comp.has_method("cast_spell"):
				if enable_spell_input_debug:
					print("🔮 DEBUG: Attempting to cast spell " + str(spell_index))
				var success = spell_comp.cast_spell(spell_index)
				if enable_spell_input_debug:
					if success:
						print("✅ DEBUG: Spell cast successful!")
					else:
						print("❌ DEBUG: Spell cast failed")
			else:
				if enable_spell_input_debug:
					print("❌ DEBUG: cast_spell method not found")
		else:
			if enable_spell_input_debug:
				print("❌ DEBUG: SpellComponent not found")
	else:
		if enable_spell_input_debug:
			print("❌ DEBUG: Player not found")

func _debug_intelligence_scaling():
	print("=== INTELLIGENCE SCALING DEBUG ===")
	
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("❌ No player found")
		return
	
	if not player.has_method("get_stat_sheet"):
		print("❌ Player missing get_stat_sheet() method")
		return
	
	var stat_sheet = player.get_stat_sheet()
	if not stat_sheet:
		print("❌ Player stat_sheet is null")
		return
	
	print("✅ Found stat sheet")
	
	# Get current intelligence and computed multiplier
	var intelligence = stat_sheet.get_stat_value("intelligence")
	var spell_damage_multiplier = stat_sheet.get_stat_value("spell_damage_multiplier")
	
	print("📊 Current Stats:")
	print("  Intelligence: ", intelligence)
	print("  Spell Damage Multiplier: ", spell_damage_multiplier)
	
	# Calculate expected multiplier
	var expected_multiplier = 1.0 + intelligence * 0.02
	print("  Expected Multiplier: ", expected_multiplier)
	print("  Difference: ", spell_damage_multiplier - expected_multiplier)
	
	# Check if it's a computed stat
	var computed_stat = stat_sheet.get_computed_stat("spell_damage_multiplier")
	if computed_stat:
		print("📈 Computed Stat Analysis:")
		print("  Formula: ", computed_stat.formula)
		print("  Dependencies: ", computed_stat.dependencies)
		
		# Force recalculation
		computed_stat.mark_dirty()
		var recalculated = computed_stat.get_final_value()
		print("  After recalculation: ", recalculated)
	else:
		print("❌ spell_damage_multiplier is not a computed stat")
	
	# Test spell casting with current stats
	var spell_comp = player.get_node_or_null("SpellComponent")
	if spell_comp:
		print("🪄 Testing spell damage calculation...")
		var test_base_damage = 25.0
		var calculated_damage = spell_comp._calculate_enhanced_damage(test_base_damage)
		print("  Base damage: ", test_base_damage)
		print("  Calculated enhanced damage: ", calculated_damage)
		print("  Actual multiplier used: ", calculated_damage / test_base_damage)
		
		# Test it again to see if it's consistent now
		print("🔄 Testing again for consistency...")
		var calculated_damage2 = spell_comp._calculate_enhanced_damage(test_base_damage)
		print("  Second calculation: ", calculated_damage2)
		print("  Multiplier second time: ", calculated_damage2 / test_base_damage)
	
	print("=== DEBUG COMPLETE ===")

func _debug_all_stats_caching():
	print("=== ALL STATS CACHING DEBUG ===")
	
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("❌ No player found")
		return
	
	var stat_sheet = player.get_stat_sheet()
	if not stat_sheet:
		print("❌ Player stat_sheet is null")
		return
	
	print("✅ Found player and stat sheet")
	
	# Test all computed stats for caching issues
	var computed_stats = [
		"max_health",
		"health_regen_rate", 
		"max_mana",
		"mana_regen_rate",
		"spell_damage_multiplier",
		"critical_chance",
		"cooldown_reduction",
		"movement_speed",
		"cast_speed_multiplier"
	]
	
	print("\n📊 TESTING ALL COMPUTED STATS FOR CACHING BUGS:")
	for stat_name in computed_stats:
		_test_stat_caching_issue(stat_sheet, stat_name)
	
	print("\n🔧 TESTING COMPONENT INTEGRATIONS:")
	_test_health_mana_integration(player, stat_sheet)
	_test_movement_integration(player, stat_sheet)
	_test_spell_integration(player, stat_sheet)
	
	print("\n=== ALL STATS DEBUG COMPLETE ===")

func _test_stat_caching_issue(stat_sheet: PlayerStatSheet, stat_name: String):
	print("\n🔍 Testing: ", stat_name)
	
	# Get current value
	var current_value = stat_sheet.get_stat_value(stat_name)
	print("  Current value: ", current_value)
	
	# Check if it's a computed stat
	var computed_stat = stat_sheet.get_computed_stat(stat_name)
	if not computed_stat:
		print("  ⚠️ Not a computed stat")
		return
	
	print("  Formula: ", computed_stat.formula)
	print("  Dependencies: ", computed_stat.dependencies)
	
	# Force recalculation
	computed_stat.mark_dirty()
	var recalculated_value = computed_stat.get_final_value()
	print("  After forced recalc: ", recalculated_value)
	
	# Check if values differ (indicating caching issue)
	if abs(current_value - recalculated_value) > 0.001:
		print("  🐛 CACHING BUG: Values differ by ", abs(current_value - recalculated_value))
	else:
		print("  ✅ Values match - no caching issue")

func _test_health_mana_integration(player: Node, stat_sheet: PlayerStatSheet):
	print("\n💖 HEALTH/MANA INTEGRATION TEST:")
	
	var health_comp = player.get_node_or_null("HealthComponent")
	if not health_comp:
		print("❌ HealthComponent not found")
		return
	
	# Get fresh stat values
	var stat_max_health = stat_sheet.get_stat_value("max_health")
	var stat_max_mana = stat_sheet.get_stat_value("max_mana")
	
	print("  Stat Sheet Max Health: ", stat_max_health)
	print("  Stat Sheet Max Mana: ", stat_max_mana)
	
	# Check if HealthComponent has the values
	if health_comp.has_method("get_max_health"):
		var comp_max_health = health_comp.get_max_health()
		print("  HealthComponent Max Health: ", comp_max_health)
		if abs(stat_max_health - comp_max_health) > 0.1:
			print("  🐛 SYNC BUG: Health values don't match!")
		else:
			print("  ✅ Health values synchronized")
	
	if health_comp.has_method("get_max_mana"):
		var comp_max_mana = health_comp.get_max_mana()
		print("  HealthComponent Max Mana: ", comp_max_mana)
		if abs(stat_max_mana - comp_max_mana) > 0.1:
			print("  🐛 SYNC BUG: Mana values don't match!")
		else:
			print("  ✅ Mana values synchronized")

func _test_movement_integration(player: Node, stat_sheet: PlayerStatSheet):
	print("\n🏃 MOVEMENT INTEGRATION TEST:")
	
	var movement_comp = player.get_node_or_null("MovementComponent")
	if not movement_comp:
		print("❌ MovementComponent not found")
		return
	
	var stat_movement_speed = stat_sheet.get_stat_value("movement_speed")
	print("  Stat Sheet Movement Speed: ", stat_movement_speed)
	
	# Check if MovementComponent has the values
	if movement_comp.has_method("get_movement_speed"):
		var comp_movement_speed = movement_comp.get_movement_speed()
		print("  MovementComponent Speed: ", comp_movement_speed)
		if abs(stat_movement_speed - comp_movement_speed) > 0.1:
			print("  🐛 SYNC BUG: Movement speeds don't match!")
		else:
			print("  ✅ Movement speeds synchronized")

func _test_spell_integration(player: Node, stat_sheet: PlayerStatSheet):
	print("\n🪄 SPELL INTEGRATION TEST:")
	
	var spell_comp = player.get_node_or_null("SpellComponent")
	if not spell_comp:
		print("❌ SpellComponent not found")
		return
	
	var intelligence = stat_sheet.get_stat_value("intelligence")
	var stat_spell_multiplier = stat_sheet.get_stat_value("spell_damage_multiplier")
	var stat_crit_chance = stat_sheet.get_stat_value("critical_chance")
	
	print("  Intelligence: ", intelligence)
	print("  Stat Sheet Spell Multiplier: ", stat_spell_multiplier)
	print("  Stat Sheet Critical Chance: ", stat_crit_chance)
	
	# Expected values based on formulas
	var expected_multiplier = 1.0 + intelligence * 0.02
	var expected_crit = 0.05 + intelligence * 0.001
	
	print("  Expected Spell Multiplier: ", expected_multiplier)
	print("  Expected Critical Chance: ", expected_crit)
	
	if abs(stat_spell_multiplier - expected_multiplier) > 0.001:
		print("  🐛 FORMULA BUG: Spell multiplier doesn't match formula!")
	else:
		print("  ✅ Spell multiplier formula correct")
	
	if abs(stat_crit_chance - expected_crit) > 0.001:
		print("  🐛 FORMULA BUG: Critical chance doesn't match formula!")
	else:
		print("  ✅ Critical chance formula correct")
	
	# Test actual spell damage calculation
	if spell_comp.has_method("_calculate_enhanced_damage"):
		var test_damage = spell_comp._calculate_enhanced_damage(25.0)
		var actual_multiplier = test_damage / 25.0
		print("  SpellComponent actual multiplier: ", actual_multiplier)
		
		if abs(actual_multiplier - expected_multiplier) > 0.1:  # Allow for crits
			print("  🐛 COMPONENT BUG: SpellComponent using wrong multiplier!")
		else:
			print("  ✅ SpellComponent using correct multiplier")
