extends Node
# QualityGateDay0.gd - Automated validation script for Phase 0 infrastructure
# Purpose: Ensures all Phase 0 systems are working correctly before Phase 1
# Godot Version: 4.4.1 compatible

# Quality gate status tracking
var gates_passed: int = 0
var total_gates: int = 5
var validation_complete: bool = false
var validation_results: Array = []

# Quality gate thresholds
const MAX_ACCEPTABLE_ERRORS = 5
const MAX_ACCEPTABLE_WARNINGS = 15
const MIN_ACCEPTABLE_FPS = 55
const VALIDATION_TIMEOUT = 30.0  # seconds

func _ready() -> void:
	# Ensure this runs even when game is paused
	process_mode = Node.PROCESS_MODE_ALWAYS
	print("🔒 QualityGateDay0 initialized - Phase 0 validation ready")

# Main validation function
func run_phase0_validation() -> bool:
	print("🔒 Starting Phase 0 Quality Gate Validation...")
	print("📋 Running " + str(total_gates) + " quality gates...")
	
	validation_results.clear()
	gates_passed = 0
	validation_complete = false
	
	var start_time = Time.get_time_dict_from_system()
	
	# Gate 1: Autoload System Health
	var gate1_result = _gate_autoload_health()
	_record_gate_result(1, "Autoload System Health", gate1_result)
	
	# Gate 2: Scene Integrity
	var gate2_result = _gate_scene_integrity()
	_record_gate_result(2, "Scene Integrity", gate2_result)
	
	# Gate 3: Input System Functionality
	var gate3_result = _gate_input_functionality()
	_record_gate_result(3, "Input System Functionality", gate3_result)
	
	# Gate 4: Error Tracking System
	var gate4_result = _gate_error_tracking()
	_record_gate_result(4, "Error Tracking System", gate4_result)
	
	# Gate 5: Performance Baseline
	var gate5_result = _gate_performance_baseline()
	_record_gate_result(5, "Performance Baseline", gate5_result)
	
	validation_complete = true
	var end_time = Time.get_time_dict_from_system()
	
	# Generate final report
	_generate_validation_report()
	
	var all_gates_passed = (gates_passed == total_gates)
	
	if all_gates_passed:
		print("🎉 ALL QUALITY GATES PASSED - Phase 0 validation successful!")
		print("✅ System ready for Phase 1 development")
		if UnifiedDebugSystem:
			UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.TESTING, "Phase 0 validation completed successfully", "QualityGateDay0")
	else:
		print("❌ QUALITY GATE FAILURE - " + str(gates_passed) + "/" + str(total_gates) + " gates passed")
		print("🚫 System NOT ready for Phase 1 development")
		if UnifiedDebugSystem:
			UnifiedDebugSystem.log_error_internal(UnifiedDebugSystem.LogCategory.TESTING, "Phase 0 validation failed: " + str(gates_passed) + "/" + str(total_gates) + " gates passed", "QualityGateDay0")
	
	return all_gates_passed

# Individual Quality Gates
func _gate_autoload_health() -> bool:
	print("🔍 Gate 1: Checking autoload system health...")
	
	var issues = []
	
	# Check GameEvents singleton
	if not GameEvents:
		issues.append("GameEvents singleton not accessible")
	else:
		# Test signal emission (basic check)
		if GameEvents.has_signal("player_health_changed"):
			GameEvents.emit_player_health_changed(100.0, 100.0)
		else:
			issues.append("GameEvents signal emission failed")
	
	# Check GameManager singleton
	if not GameManager:
		issues.append("GameManager singleton not accessible")
	else:
		# Test state management
		var current_state = GameManager.get_current_state()
		if current_state == null:
			issues.append("GameManager state system not working")
	
	# Check InputHandler singleton
	if not InputHandler:
		issues.append("InputHandler singleton not accessible")
	else:
		# Test input vector
		var movement_vector = InputHandler.get_movement_vector()
		if not movement_vector is Vector2:
			issues.append("InputHandler movement vector invalid")
	
	# Check Logger singleton (if available)
	if not Logger:
		issues.append("Logger singleton not accessible")
	else:
		# Test logging functionality
		Logger.test_logger_functionality()
	
	var gate_passed = issues.is_empty()
	
	if gate_passed:
		print("✅ Gate 1 PASSED: All autoloads healthy")
	else:
		print("❌ Gate 1 FAILED: " + str(issues.size()) + " issues found")
		for issue in issues:
			print("  - " + issue)
	
	return gate_passed

func _gate_scene_integrity() -> bool:
	print("🔍 Gate 2: Checking scene integrity...")
	
	var issues = []
	var main_scene = get_tree().current_scene
	
	if not main_scene:
		issues.append("No main scene loaded")
		return false
	
	# Check scene structure exists
	var required_nodes = [
		"GameWorld",
		"UI"
	]
	
	for node_name in required_nodes:
		var node = main_scene.get_node_or_null(node_name)
		if not node:
			issues.append("Required node '" + node_name + "' not found in scene")
	
	# Check for critical scene errors
	var scene_file_path = main_scene.scene_file_path
	if scene_file_path.is_empty():
		issues.append("Main scene has no file path")
	
	# Validate collision layer setup
	if not CollisionValidator.validate_project_collision_layers():
		issues.append("Collision layer configuration invalid")
	
	var gate_passed = issues.is_empty()
	
	if gate_passed:
		print("✅ Gate 2 PASSED: Scene integrity verified")
	else:
		print("❌ Gate 2 FAILED: " + str(issues.size()) + " issues found")
		for issue in issues:
			print("  - " + issue)
	
	return gate_passed

func _gate_input_functionality() -> bool:
	print("🔍 Gate 3: Checking input system functionality...")
	
	var issues = []
	
	# Check input actions exist
	var required_actions = [
		"move_left", "move_right", "move_up", "move_down",
		"spell_1", "spell_2", "spell_3", "spell_4", "spell_5",
		"pause_game"
	]
	
	for action in required_actions:
		if not InputMap.has_action(action):
			issues.append("Input action '" + action + "' not configured")
	
	# Check InputHandler functionality
	if InputHandler:
		var movement_vector = InputHandler.get_movement_vector()
		if movement_vector.length() > 1.1:  # Allow slight tolerance
			issues.append("Movement vector not properly normalized: " + str(movement_vector.length()))
	else:
		issues.append("InputHandler not available for testing")
	
	var gate_passed = issues.is_empty()
	
	if gate_passed:
		print("✅ Gate 3 PASSED: Input system functional")
	else:
		print("❌ Gate 3 FAILED: " + str(issues.size()) + " issues found")
		for issue in issues:
			print("  - " + issue)
	
	return gate_passed

func _gate_error_tracking() -> bool:
	print("🔍 Gate 4: Checking error tracking system...")
	
	var issues = []
	
	# Check Logger availability and functionality
	if not UnifiedDebugSystem:
		issues.append("UnifiedDebugSystem singleton not available")
		return false
	
	# Test error tracking
	var initial_error_count = UnifiedDebugSystem.error_count
	var initial_warning_count = UnifiedDebugSystem.warning_count
	
	# Test logging functionality
	UnifiedDebugSystem.log_error_internal(UnifiedDebugSystem.LogCategory.TESTING, "Quality gate test error", "QualityGateDay0")
	UnifiedDebugSystem.log_warning_internal(UnifiedDebugSystem.LogCategory.TESTING, "Quality gate test warning", "QualityGateDay0")
	
	# Verify counts increased
	if UnifiedDebugSystem.error_count != initial_error_count + 1:
		issues.append("Error counting not working correctly")
	
	if UnifiedDebugSystem.warning_count != initial_warning_count + 1:
		issues.append("Warning counting not working correctly")
	
	# Check error threshold compliance
	if UnifiedDebugSystem.error_count > 10 or UnifiedDebugSystem.warning_count > 50:
		issues.append("System exceeds acceptable error/warning thresholds")
	
	# Check system health
	if not UnifiedDebugSystem.is_system_healthy():
		issues.append("UnifiedDebugSystem reports system as unhealthy")
	
	var gate_passed = issues.is_empty()
	
	if gate_passed:
		print("✅ Gate 4 PASSED: Error tracking system functional")
	else:
		print("❌ Gate 4 FAILED: " + str(issues.size()) + " issues found")
		for issue in issues:
			print("  - " + issue)
	
	return gate_passed

func _gate_performance_baseline() -> bool:
	print("🔍 Gate 5: Checking performance baseline...")
	
	var issues = []
	
	# Check current FPS
	var current_fps = Engine.get_frames_per_second()
	if current_fps < MIN_ACCEPTABLE_FPS:
		issues.append("FPS below acceptable threshold: " + str(current_fps) + " < " + str(MIN_ACCEPTABLE_FPS))
	
	# Check GameManager performance tracking
	if GameManager and GameManager.has_method("get_performance_info"):
		var perf_info = GameManager.get_performance_info()
		if perf_info.has("fps") and perf_info.fps < MIN_ACCEPTABLE_FPS:
			issues.append("GameManager reports low FPS: " + str(perf_info.fps))
	
	# Memory usage check (basic) - Godot 4.4.1 compatible
	var memory_info = OS.get_memory_info()
	if memory_info.is_empty():
		# Basic memory check not available, skip
		pass
	
	var gate_passed = issues.is_empty()
	
	if gate_passed:
		print("✅ Gate 5 PASSED: Performance baseline acceptable (" + str(current_fps) + " FPS)")
	else:
		print("❌ Gate 5 FAILED: " + str(issues.size()) + " issues found")
		for issue in issues:
			print("  - " + issue)
	
	return gate_passed

# Helper functions
func _record_gate_result(gate_number: int, gate_name: String, passed: bool) -> void:
	var result = {
		"gate_number": gate_number,
		"gate_name": gate_name,
		"passed": passed,
		"timestamp": Time.get_datetime_string_from_system()
	}
	
	validation_results.append(result)
	
	if passed:
		gates_passed += 1

func _generate_validation_report() -> void:
	print("\n🔒 ================== PHASE 0 QUALITY GATE REPORT ==================")
	print("📊 Overall Result: " + str(gates_passed) + "/" + str(total_gates) + " gates passed")
	print("⏱️ Validation completed at: " + Time.get_datetime_string_from_system())
	
	print("\n📋 Individual Gate Results:")
	for result in validation_results:
		var status = "✅ PASSED" if result.passed else "❌ FAILED"
		print("  Gate " + str(result.gate_number) + ": " + result.gate_name + " - " + status)
	
	if UnifiedDebugSystem:
		print("\n📝 Error Summary:")
		print(Logger.get_error_summary())
	
	print("\n🎯 Phase 0 Status:")
	if gates_passed == total_gates:
		print("  ✅ READY FOR PHASE 1 DEVELOPMENT")
		print("  🎉 All infrastructure systems validated")
	else:
		print("  ❌ NOT READY FOR PHASE 1")
		print("  🔧 Fix failing gates before proceeding")
	
	print("🔒 ================================================================\n")

# Public interface for external testing
func get_validation_status() -> Dictionary:
	return {
		"validation_complete": validation_complete,
		"gates_passed": gates_passed,
		"total_gates": total_gates,
		"all_gates_passed": (gates_passed == total_gates),
		"results": validation_results
	}

func is_phase0_ready() -> bool:
	if not validation_complete:
		return false
	return gates_passed == total_gates

# Testing function
func quick_validation_check() -> bool:
	print("🔍 Running quick Phase 0 validation check...")
	
	var quick_checks = []
	
	# Quick autoload check
	quick_checks.append(GameEvents != null)
	quick_checks.append(GameManager != null)
	quick_checks.append(InputHandler != null)
	quick_checks.append(Logger != null)
	
	# Quick performance check
	quick_checks.append(Engine.get_frames_per_second() >= MIN_ACCEPTABLE_FPS)
	
	var passed_checks = 0
	for check in quick_checks:
		if check:
			passed_checks += 1
	
	var all_passed = (passed_checks == quick_checks.size())
	
	if all_passed:
		print("✅ Quick validation: All systems appear healthy")
	else:
		print("⚠️ Quick validation: " + str(passed_checks) + "/" + str(quick_checks.size()) + " checks passed")
	
	return all_passed
