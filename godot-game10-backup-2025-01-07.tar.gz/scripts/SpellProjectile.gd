# SpellProjectile.gd
# Purpose: Projectile behavior for spell casting system with SAFE animation handling
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: SpellData, CollisionValidator, Logger
# API References: Area2D collision detection, Timer
# FIX: Eliminates ERR_INVALID_PARAMETER errors from animation libraries

extends Area2D
class_name SpellProjectile

var spell_data: SpellData
var damage: float = 0.0
var travel_distance: float = 0.0
var max_range: float = 600.0
var start_position: Vector2
var direction: Vector2 = Vector2.RIGHT
var speed: float = 300.0

# Damage number optimization - prevent duplicate creation
var damage_number_created: bool = false

func _ready():
	# Set collision layer (Layer 3 = Projectiles, bitmask value = 4)
	collision_layer = 4  # 2^(3-1) = 4 for Layer 3
	collision_mask = 2   # Hit enemies(2) only - no self damage
	
	# Add to projectiles group
	add_to_group("projectiles")
	
	# Validation with CollisionValidator if available
	if UnifiedDebugSystem:
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "Collision validation passed", "SpellProjectile")
	
	# Connect collision signals (now that this IS the Area2D)
	if not area_entered.is_connected(_on_area_entered):
		area_entered.connect(_on_area_entered)
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)
	
	# Connect lifetime timer if it exists
	var timer = get_node_or_null("LifetimeTimer")
	if timer and not timer.timeout.is_connected(_on_lifetime_timer_timeout):
		timer.timeout.connect(_on_lifetime_timer_timeout)
	
	# Auto-destroy setup
	start_position = global_position
	
	# Reduced log spam - only show for debugging
	# print("🚀 SpellProjectile initialized at " + str(global_position))

func setup(spell_data_resource: SpellData, damage_amount: float, direction_vector: Vector2):
	if not spell_data_resource:
		push_error("SpellProjectile setup failed: null SpellData provided")
		queue_free()
		return
	
	spell_data = spell_data_resource
	damage = damage_amount
	max_range = spell_data.projectile_range
	
	# Set movement direction and speed for Area2D
	direction = direction_vector.normalized()
	speed = spell_data.projectile_speed
	
	# Generate spell-specific texture
	_create_spell_texture(spell_data.spell_name)
	
	# Reduced log spam
	# print("✨ " + spell_data.spell_name + " projectile launched with " + str(damage) + " damage")

func _physics_process(delta):
	# Move the projectile using Area2D position-based movement
	if direction != Vector2.ZERO:
		global_position += direction * speed * delta
	
	# Check travel distance
	if start_position != Vector2.ZERO:
		travel_distance = start_position.distance_to(global_position)
		if travel_distance >= max_range:
			print("📏 " + (spell_data.spell_name if spell_data else "Projectile") + " reached max range (" + str(travel_distance) + "/" + str(max_range) + ")")
			_destroy_projectile()

func _on_body_entered(body: Node):
	if not is_instance_valid(body):
		return
	
	# Projectile hit detection
	
	if body.is_in_group("enemies"):
		_hit_enemy(body)
	elif body.collision_layer == 4:  # Environment layer
		_hit_environment()
	else:
		print("🔍 Projectile hit unhandled body type: " + body.name + " on layer " + str(body.collision_layer))

func _on_area_entered(area: Area2D):
	if not is_instance_valid(area):
		return
	
	# Projectile hit area detection
	
	# Handle area-based enemies (e.g., hitboxes)
	if area.is_in_group("enemies") or area.is_in_group("enemy_hitboxes"):
		var enemy_owner = area.get_parent() if area.get_parent() else area
		_hit_enemy(enemy_owner)
	else:
		print("🔍 Projectile hit unhandled area type: " + area.name)

func _on_lifetime_timer_timeout():
	print("⏰ Projectile lifetime expired")
	_destroy_projectile()

func _hit_enemy(enemy: Node):
	var spell_name = spell_data.spell_name if spell_data else "Unknown Spell"
	print("💥 " + spell_name + " hit " + enemy.name + " for " + str(damage) + " damage")
	
	# Deal damage to enemy - let the enemy handle damage numbers
	if enemy.has_method("take_damage"):
		var damage_dealt = enemy.take_damage(damage)
		if damage_dealt:
			pass  # Spell damage applied successfully
		else:
			pass  # Damage application failed
	else:
		# Fallback removed - only Enemy.gd creates damage numbers per fix
		# _show_optimized_damage_number()  # Disabled to prevent duplicates
		pass
	
	# Create visual effect SAFELY
	_create_safe_impact_effect()
	
	# Note: NOT creating damage number here - let enemy handle it
	
	# Emit damage event
	if GameEvents:
		GameEvents.spell_cast.emit(spell_name, damage)
	
	# Destroy projectile
	_destroy_projectile()

func _hit_environment():
	var spell_name = spell_data.spell_name if spell_data else "Unknown Spell"
	print("💥 " + spell_name + " hit environment")
	_create_safe_impact_effect()
	_destroy_projectile()

# SAFE METHODS - No animation library dependencies
func _create_safe_impact_effect():
	# Creates impact effect using pure Node2D and Tween - NO animation libraries
	# This prevents ERR_INVALID_PARAMETER errors from missing animation resources
	# Creating safe impact effect
	
	# Create effect directly without loading external scenes
	var effect = Node2D.new()
	effect.name = "ImpactEffect"
	
	# Add sprite child
	var sprite = Sprite2D.new()
	effect.add_child(sprite)
	
	# Create simple impact texture
	var image = Image.create(32, 32, false, Image.FORMAT_RGBA8)
	var center = Vector2(16, 16)
	
	# Draw impact circle
	for x in range(32):
		for y in range(32):
			var distance = Vector2(x, y).distance_to(center)
			if distance <= 14:
				var alpha = 1.0 - (distance / 14.0) * 0.5
				image.set_pixel(x, y, Color(1.0, 0.5, 0.0, alpha))
	
	var texture = ImageTexture.new()
	texture.set_image(image)
	sprite.texture = texture
	
	# Add to scene
	get_tree().current_scene.add_child(effect)
	effect.global_position = global_position
	
	# Animate with Tween (NO AnimationPlayer)
	var tween = effect.create_tween()
	tween.set_parallel(true)
	
	# Scale animation
	tween.tween_property(sprite, "scale", Vector2(1.5, 1.5), 0.15).set_ease(Tween.EASE_OUT)
	tween.tween_property(sprite, "scale", Vector2(0.0, 0.0), 0.15).set_delay(0.15)
	
	# Fade animation  
	tween.tween_property(sprite, "modulate:a", 0.0, 0.3)
	
	# Cleanup
	tween.tween_callback(effect.queue_free).set_delay(0.3)

func _show_optimized_damage_number():
	# Only use this as fallback when enemy doesn't handle damage numbers
	if damage_number_created:
		return  # Prevent duplicate damage numbers
	
	damage_number_created = true
	
	var damage_scene_path = "res://ui/DamageNumber.tscn"
	if ResourceLoader.exists(damage_scene_path):
		var damage_scene = load(damage_scene_path)
		if damage_scene:
			var damage_number = damage_scene.instantiate()
			if damage_number:
				get_tree().current_scene.add_child(damage_number)
				if damage_number.has_method("setup"):
					# Use appropriate setup method based on damage amount
					if damage >= 100:
						damage_number.setup_massive_damage(damage, global_position)
					elif damage >= 50:
						damage_number.setup_critical(damage, global_position)
					elif damage <= 10:
						damage_number.setup_small_damage(damage, global_position)
					else:
						damage_number.setup(damage, global_position)
				else:
					# Fallback if setup method doesn't exist
					if damage_number.has_property("text"):
						damage_number.text = str(int(damage))
					damage_number.global_position = global_position
					# Fallback damage number created

func _destroy_projectile():
	# Destroying projectile
	queue_free()

# Validation method for testing
func validate_setup() -> bool:
	var checks = [
		spell_data != null,
		damage > 0,
		max_range > 0,
		collision_layer == 4,
		collision_mask == 2
	]
	
	var passed = 0
	for check in checks:
		if check:
			passed += 1
	
	var success = passed == checks.size()
	print("🔍 SpellProjectile validation: " + str(passed) + "/" + str(checks.size()) + " " + ("PASSED" if success else "FAILED"))
	return success

# Generate spell-specific textures based on spell type
func _create_spell_texture(spell_name: String):
	var sprite = get_node_or_null("Sprite2D")
	if not sprite:
		return
	
	var size = 16
	var image = Image.create(size, size, false, Image.FORMAT_RGBA8)
	var center = Vector2(size / 2, size / 2)
	
	match spell_name:
		"Fireball":
			# Orange/red fireball with flicker effect
			_create_fireball_texture(image, center, size)
		"Magic Missile":
			# Purple arcane missile with sparkles
			_create_magic_missile_texture(image, center, size)
		"Ice Shard":
			# Blue/cyan crystalline shard
			_create_ice_shard_texture(image, center, size)
		"Lightning Bolt":
			# Yellow/white electric bolt
			_create_lightning_texture(image, center, size)
		_:
			# Default orange circle
			_create_default_texture(image, center, size)
	
	var texture = ImageTexture.new()
	texture.set_image(image)
	sprite.texture = texture

func _create_fireball_texture(image: Image, center: Vector2, size: int):
	# Create layered fireball: core (white), middle (orange), outer (red)
	for x in range(size):
		for y in range(size):
			var pos = Vector2(x, y)
			var distance = pos.distance_to(center)
			var max_radius = size / 2.0 - 1.0
			
			if distance <= max_radius:
				var intensity = 1.0 - (distance / max_radius)
				var color: Color
				
				if distance <= max_radius * 0.3:  # Core - bright white/yellow
					color = Color(1.0, 1.0, 0.8, intensity)
				elif distance <= max_radius * 0.6:  # Middle - orange
					color = Color(1.0, 0.6, 0.2, intensity)
				else:  # Outer - red
					color = Color(1.0, 0.3, 0.1, intensity * 0.8)
				
				image.set_pixel(x, y, color)

func _create_magic_missile_texture(image: Image, center: Vector2, size: int):
	# Create elongated purple missile with sparkle effect
	for x in range(size):
		for y in range(size):
			var pos = Vector2(x, y)
			var distance = pos.distance_to(center)
			var max_radius = size / 2.0 - 1.0
			
			# Create elongated shape
			var dx = abs(x - center.x)
			var dy = abs(y - center.y)
			var elongated_distance = dx * 0.6 + dy * 1.4  # More vertical
			
			if elongated_distance <= max_radius:
				var intensity = 1.0 - (elongated_distance / max_radius)
				var color = Color(0.8, 0.3, 1.0, intensity)  # Purple
				
				# Add sparkle effect
				if fmod(x + y, 3) == 0 and intensity > 0.5:
					color = Color(1.0, 0.9, 1.0, intensity)  # White sparkle
				
				image.set_pixel(x, y, color)

func _create_ice_shard_texture(image: Image, center: Vector2, size: int):
	# Create crystalline ice shard with sharp edges
	for x in range(size):
		for y in range(size):
			var pos = Vector2(x, y)
			var dx = x - center.x
			var dy = y - center.y
			
			# Create diamond/shard shape
			var shard_distance = abs(dx) + abs(dy * 1.5)  # Elongated diamond
			var max_shard = size / 2.0
			
			if shard_distance <= max_shard:
				var intensity = 1.0 - (shard_distance / max_shard)
				var color: Color
				
				# Add crystalline effect with lighter edges
				if shard_distance <= max_shard * 0.4:  # Core
					color = Color(0.3, 0.7, 1.0, intensity)  # Ice blue
				else:  # Edges - brighter
					color = Color(0.6, 0.9, 1.0, intensity * 0.9)  # Light blue
				
				image.set_pixel(x, y, color)

func _create_lightning_texture(image: Image, center: Vector2, size: int):
	# Create jagged lightning bolt effect
	for x in range(size):
		for y in range(size):
			var pos = Vector2(x, y)
			var distance = pos.distance_to(center)
			var max_radius = size / 2.0 - 1.0
			
			# Create jagged pattern
			var zigzag = sin((y - center.y) * 0.8) * 2.0
			var adjusted_x = x + zigzag
			var bolt_width = 3.0
			
			if distance <= max_radius and abs(adjusted_x - center.x) <= bolt_width:
				var intensity = 1.0 - (distance / max_radius)
				var color: Color
				
				if abs(adjusted_x - center.x) <= bolt_width * 0.5:  # Core
					color = Color(1.0, 1.0, 0.9, intensity)  # Bright white
				else:  # Edges
					color = Color(1.0, 1.0, 0.3, intensity * 0.8)  # Yellow
				
				image.set_pixel(x, y, color)

func _create_default_texture(image: Image, center: Vector2, size: int):
	# Simple orange circle (fallback)
	for x in range(size):
		for y in range(size):
			var pos = Vector2(x, y)
			var distance = pos.distance_to(center)
			var max_radius = size / 2.0 - 1.0
			
			if distance <= max_radius:
				var intensity = 1.0 - (distance / max_radius) * 0.5
				var color = Color(1.0, 0.5, 0.0, intensity)  # Orange
				image.set_pixel(x, y, color)
