extends Node
# test_spell_integration.gd - Comprehensive spell system validation
# Purpose: Validate complete spell casting and projectile systems
# Usage: Run this script to validate all Phase 2 spell integration components

var test_results: Array[String] = []
var test_passed: int = 0
var test_failed: int = 0

func _ready():
	print("🧪 Starting Spell Integration Test Suite...")
	print("=" * 60)
	
	# Run all test categories
	test_spell_data_system()
	test_projectile_system()
	test_spell_component()
	test_input_integration()
	test_mana_integration()
	test_event_integration()
	test_performance()
	
	# Generate final report
	print_test_results()

func test_spell_data_system() -> void:
	print("\n🔮 Testing SpellData System...")
	
	# Test SpellData class
	var spell_data = SpellData.new()
	if spell_data:
		log_pass("SpellData can be instantiated")
		
		# Test properties
		spell_data.spell_name = "Test Fireball"
		spell_data.base_damage = 25.0
		spell_data.mana_cost = 10
		spell_data.projectile_speed = 300.0
		spell_data.projectile_range = 600.0
		spell_data.cooldown_duration = 1.0
		
		if spell_data.spell_name == "Test Fireball":
			log_pass("SpellData properties can be set")
		else:
			log_fail("SpellData properties not setting correctly")
		
		# Test validation
		if spell_data.has_method("validate"):
			if spell_data.validate():
				log_pass("SpellData.validate() works for valid data")
			else:
				log_fail("SpellData.validate() failed for valid data")
			
			# Test invalid data
			spell_data.base_damage = -10.0  # Invalid
			if not spell_data.validate():
				log_pass("SpellData.validate() correctly rejects invalid data")
			else:
				log_fail("SpellData.validate() accepts invalid data")
		else:
			log_fail("SpellData.validate() method missing")
		
		# SpellData is a Resource, not a Node - no need to free it
		spell_data = null
	else:
		log_fail("SpellData cannot be instantiated")

func test_projectile_system() -> void:
	print("\n🚀 Testing Projectile System...")
	
	# Test SpellProjectile scene exists
	var projectile_path = "res://scenes/SpellProjectile.tscn"
	if ResourceLoader.exists(projectile_path):
		log_pass("SpellProjectile.tscn scene exists")
		
		# Test scene loading
		var projectile_scene = load(projectile_path)
		if projectile_scene:
			log_pass("SpellProjectile scene loads successfully")
			
			# Test instantiation
			var projectile_instance = projectile_scene.instantiate()
			if projectile_instance:
				log_pass("SpellProjectile can be instantiated")
				
				# Test required methods
				var required_methods = ["setup"]
				for method in required_methods:
					if projectile_instance.has_method(method):
						log_pass("SpellProjectile." + method + "() exists")
					else:
						log_fail("SpellProjectile." + method + "() missing")
				
				# Test collision setup
				if projectile_instance.collision_layer == 4:
					log_pass("SpellProjectile collision layer correct (4)")
				else:
					log_fail("SpellProjectile collision layer incorrect: " + str(projectile_instance.collision_layer))
				
				if projectile_instance.collision_mask == 2:
					log_pass("SpellProjectile collision mask correct (2)")
				else:
					log_fail("SpellProjectile collision mask incorrect: " + str(projectile_instance.collision_mask))
				
				projectile_instance.queue_free()
			else:
				log_fail("SpellProjectile cannot be instantiated")
		else:
			log_fail("SpellProjectile scene cannot be loaded")
	else:
		log_fail("SpellProjectile.tscn scene not found")

func test_spell_component() -> void:
	print("\n🧙 Testing SpellComponent...")
	
	# Test SpellComponent class
	var spell_comp = preload("res://scripts/components/SpellComponent.gd").new()
	
	if spell_comp:
		log_pass("SpellComponent can be instantiated")
		
		# Test required methods
		var required_methods = [
			"setup", "cast_spell", "get_equipped_spells", 
			"get_spell_cooldown", "is_spell_ready", "validate_setup"
		]
		
		for method in required_methods:
			if spell_comp.has_method(method):
				log_pass("SpellComponent." + method + "() exists")
			else:
				log_fail("SpellComponent." + method + "() missing")
		
		# SpellComponent is a Node - queue_free is correct
		spell_comp.queue_free()
	else:
		log_fail("SpellComponent cannot be instantiated")

func test_input_integration() -> void:
	print("\n🎮 Testing Input Integration...")
	
	# Test spell input actions
	var spell_actions = ["spell_1", "spell_2", "spell_3", "spell_4", "spell_5"]
	
	for action in spell_actions:
		if InputMap.has_action(action):
			log_pass("Input action '" + action + "' exists")
		else:
			log_fail("Input action '" + action + "' missing")
	
	# Test if actions have key assignments
	if InputMap.has_action("spell_1"):
		var events = InputMap.action_get_events("spell_1")
		if events.size() > 0:
			log_pass("spell_1 has key assignment")
		else:
			log_fail("spell_1 has no key assignment")

func test_mana_integration() -> void:
	print("\n💙 Testing Mana Integration...")
	
	# Test Player and HealthComponent exist
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_node_or_null("GameWorld/Player")
	
	if player:
		log_pass("Player node exists")
		
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp:
			log_pass("Player has HealthComponent")
			
			# Test mana methods
			if health_comp.has_method("consume_mana"):
				log_pass("HealthComponent.consume_mana() exists")
			else:
				log_fail("HealthComponent.consume_mana() missing")
			
			if health_comp.has_method("restore_mana"):
				log_pass("HealthComponent.restore_mana() exists")
			else:
				log_fail("HealthComponent.restore_mana() missing")
			
			# Test mana properties
			if "current_mana" in health_comp:
				log_pass("HealthComponent.current_mana property exists")
			else:
				log_fail("HealthComponent.current_mana property missing")
			
			if "max_mana" in health_comp:
				log_pass("HealthComponent.max_mana property exists")
			else:
				log_fail("HealthComponent.max_mana property missing")
		else:
			log_fail("Player missing HealthComponent")
	else:
		log_fail("Player node not found")

func test_event_integration() -> void:
	print("\n📡 Testing Event Integration...")
	
	# Test GameEvents singleton
	if GameEvents:
		log_pass("GameEvents singleton exists")
		
		# Test spell_cast signal
		if GameEvents.has_signal("spell_cast"):
			log_pass("GameEvents.spell_cast signal exists")
			
			# Test signal emission
			var signal_received = false
			var received_data = {}
			
			GameEvents.spell_cast.connect(func(spell_name, damage):
				signal_received = true
				received_data["spell_name"] = spell_name
				received_data["damage"] = damage
			)
			
			GameEvents.spell_cast.emit("Test Spell", 25.0)
			
			if signal_received and received_data.get("spell_name") == "Test Spell":
				log_pass("GameEvents.spell_cast emits correctly")
			else:
				log_fail("GameEvents.spell_cast emission failed")
		else:
			log_fail("GameEvents.spell_cast signal missing")
	else:
		log_fail("GameEvents singleton not found")

func test_performance() -> void:
	print("\n⚡ Testing Performance Characteristics...")
	
	# Test component memory usage
	var spell_comp = preload("res://scripts/components/SpellComponent.gd").new()
	
	if spell_comp:
		log_pass("SpellComponent instantiates without memory issues")
		# SpellComponent is a Node - queue_free is correct
		spell_comp.queue_free()
	else:
		log_fail("SpellComponent instantiation failed - memory issues")
	
	# Test SpellData creation performance
	var start_time = Time.get_ticks_msec()
	var spell_data_array: Array[SpellData] = []
	
	for i in range(100):
		var spell = SpellData.new()
		spell.spell_name = "Test Spell " + str(i)
		spell.base_damage = 25.0
		spell.mana_cost = 10
		spell_data_array.append(spell)
	
	var end_time = Time.get_ticks_msec()
	var duration = end_time - start_time
	
	if duration < 100:  # Should create 100 spells in under 100ms
		log_pass("SpellData creation performance acceptable (" + str(duration) + "ms)")
	else:
		log_fail("SpellData creation performance poor (" + str(duration) + "ms)")
	
	# Clean up - SpellData are Resources, just clear the array
	spell_data_array.clear()

func log_pass(message: String) -> void:
	test_results.append("✅ " + message)
	test_passed += 1
	print("✅ " + message)

func log_fail(message: String) -> void:
	test_results.append("❌ " + message)
	test_failed += 1
	print("❌ " + message)

func print_test_results() -> void:
	print("\n" + "=" * 60)
	print("🧪 SPELL INTEGRATION TEST RESULTS")
	print("=" * 60)
	
	print("\n📊 SUMMARY:")
	print("✅ Passed: " + str(test_passed))
	print("❌ Failed: " + str(test_failed))
	print("📋 Total:  " + str(test_passed + test_failed))
	
	var success_rate = float(test_passed) / float(test_passed + test_failed) * 100
	print("🎯 Success Rate: " + str(success_rate) + "%")
	
	if test_failed == 0:
		print("\n🎉 ALL TESTS PASSED! Spell integration is COMPLETE!")
		print("✨ System is ready for Phase 2 validation")
	else:
		print("\n⚠️  SOME TESTS FAILED - Review implementation")
		print("🔧 Failed tests need attention before Phase 2 completion")
	
	print("\n🎮 MANUAL TESTING INSTRUCTIONS:")
	print("1. Run the game (F5)")
	print("2. Press '1' key to cast fireball spell")
	print("3. Check mana consumption and regeneration")
	print("4. Test spell cooldown by rapid pressing '1'")
	print("5. Move mouse and verify projectile direction")
	print("6. Check console for spell casting debug messages")
	
	print("\n📋 DETAILED RESULTS:")
	for result in test_results:
		print(result)
	
	print("\n" + "=" * 60)

# Automated test runner
func run_spell_tests() -> bool:
	_ready()
	return test_failed == 0