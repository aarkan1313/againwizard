# TestValidation.gd
# Purpose: Comprehensive testing and validation for GameEvents and GameManager singletons
# Usage: Attach to a Node in your scene or run methods from debugger console
# Dependencies: GameEvents, GameManager

extends Node

# Test results tracking
var tests_passed: int = 0
var tests_failed: int = 0
var test_results: Array[String] = []

func _ready():
	print("🧪 TestValidation ready - Call run_all_tests() to begin comprehensive testing")
	
	# Automatically run tests if in debug mode
	if OS.is_debug_build():
		call_deferred("run_all_tests")

## Run all validation tests
func run_all_tests():
	print("\n" + "=".repeat(50))
	print("🧪 STARTING COMPREHENSIVE SINGLETON TESTS")
	print("=".repeat(50))
	
	# Reset test counters
	tests_passed = 0
	tests_failed = 0
	test_results.clear()
	
	# Run all test suites
	test_singleton_availability()
	test_game_events_functionality()
	test_game_manager_functionality()
	test_integration_scenarios()
	test_error_handling()
	test_spell_system_functionality()
	
	# Print final results
	print_test_summary()

## Test 1: Verify singletons are available
func test_singleton_availability():
	print("\n📋 TEST SUITE 1: Singleton Availability")
	print("-".repeat(30))
	
	_test("GameEvents singleton exists", GameEvents != null)
	_test("GameManager singleton exists", GameManager != null)
	_test("GameEvents is Node", GameEvents is Node)
	_test("GameManager is Node", GameManager is Node)

## Test 2: GameEvents functionality
func test_game_events_functionality():
	print("\n📋 TEST SUITE 2: GameEvents Functionality")
	print("-".repeat(30))
	
	# Test signal existence
	_test("player_moved signal exists", GameEvents.has_signal("player_moved"))
	_test("player_health_changed signal exists", GameEvents.has_signal("player_health_changed"))
	_test("enemy_died signal exists", GameEvents.has_signal("enemy_died"))
	_test("spell_cast signal exists", GameEvents.has_signal("spell_cast"))
	_test("wave_completed signal exists", GameEvents.has_signal("wave_completed"))
	
	# Test signal emissions with valid data
	var signal_received = false
	var received_data = {}
	
	# Test player_moved
	GameEvents.player_moved.connect(func(pos): 
		signal_received = true
		received_data["position"] = pos
	)
	GameEvents.emit_player_moved(Vector2(100, 200))
	_test("player_moved signal emits correctly", signal_received and received_data.get("position") == Vector2(100, 200))
	
	# Clean up connection
	if GameEvents.player_moved.is_connected(_on_player_moved):
		GameEvents.player_moved.disconnect(_on_player_moved)
	
	# Test validation functions
	_test("GameEvents has validation methods", GameEvents.has_method("emit_player_health_changed"))
	_test("GameEvents has test method", GameEvents.has_method("test_all_signals"))
	_test("GameEvents has summary method", GameEvents.has_method("get_signal_summary"))

## Test 3: GameManager functionality
func test_game_manager_functionality():
	print("\n📋 TEST SUITE 3: GameManager Functionality")
	print("-".repeat(30))
	
	# Test initial state
	_test("GameManager starts in PLAYING state", GameManager.current_state == GameManager.GameState.PLAYING)
	_test("Player starts with 100 health", GameManager.player_health == 100.0)
	_test("Player starts with 100 max health", GameManager.player_max_health == 100.0)
	_test("Game starts at wave 1", GameManager.current_wave == 1)
	
	# Test health management
	var initial_health = GameManager.player_health
	GameManager.damage_player(25.0)
	_test("Damage reduces health correctly", GameManager.player_health == initial_health - 25.0)
	
	GameManager.heal_player(10.0)
	_test("Healing increases health correctly", GameManager.player_health == initial_health - 15.0)
	
	# Test health bounds
	GameManager.set_player_health(150.0)  # Should clamp to max
	_test("Health clamped to maximum", GameManager.player_health == GameManager.player_max_health)
	
	GameManager.set_player_health(-10.0)  # Should clamp to 0
	_test("Health clamped to minimum", GameManager.player_health == 0.0)
	
	# Reset health for other tests
	GameManager.set_player_health(100.0)
	
	# Test wave progression
	var initial_wave = GameManager.current_wave
	GameManager.complete_wave()
	_test("Wave progression works", GameManager.current_wave == initial_wave + 1)
	
	# Test state methods
	_test("GameManager has state validation", GameManager.has_method("validate_game_state"))
	_test("GameManager has status method", GameManager.has_method("get_game_status"))
	_test("GameManager has reset method", GameManager.has_method("reset_game"))

## Test 4: Integration scenarios
func test_integration_scenarios():
	print("\n📋 TEST SUITE 4: Integration Scenarios")
	print("-".repeat(30))
	
	# Test GameManager → GameEvents communication
	var health_event_received = false
	var health_values = {}
	
	GameEvents.player_health_changed.connect(func(current, maximum):
		health_event_received = true
		health_values["current"] = current
		health_values["maximum"] = maximum
	)
	
	GameManager.set_player_health(75.0)
	await get_tree().process_frame  # Wait for signal propagation
	
	_test("Health change triggers GameEvents signal", health_event_received)
	_test("Correct health values in event", 
		health_values.get("current") == 75.0 and health_values.get("maximum") == 100.0)
	
	# Test pause functionality
	var was_paused = get_tree().paused
	GameManager.pause_game()
	_test("Pause changes tree state", get_tree().paused != was_paused)
	
	GameManager.pause_game()  # Unpause
	_test("Unpause restores tree state", get_tree().paused == was_paused)
	
	# Test game reset
	GameManager.damage_player(50.0)
	GameManager.complete_wave()
	var wave_before_reset = GameManager.current_wave
	var health_before_reset = GameManager.player_health
	
	GameManager.reset_game()
	_test("Reset restores health", GameManager.player_health == 100.0)
	_test("Reset restores wave", GameManager.current_wave == 1)
	_test("Reset restores playing state", GameManager.current_state == GameManager.GameState.PLAYING)

## Test 5: Error handling
func test_error_handling():
	print("\n📋 TEST SUITE 5: Error Handling")
	print("-".repeat(30))
	
	# Test invalid inputs don't crash
	var error_count_before = _get_error_count()
	
	# These should generate errors but not crash
	GameEvents.emit_player_health_changed(-10.0, 100.0)  # Negative health
	GameEvents.emit_player_health_changed(50.0, 0.0)     # Zero max health
	GameEvents.emit_enemy_died("", 25)                   # Empty name
	GameEvents.emit_spell_cast("", 30.0)                 # Empty spell name
	GameEvents.emit_wave_completed(0)                    # Invalid wave
	
	var error_count_after = _get_error_count()
	_test("Invalid inputs generate errors without crashing", error_count_after > error_count_before)
	
	# Test GameManager validation
	_test("GameManager state validation runs", GameManager.validate_game_state() is bool)
	
	# Test bounds checking
	var health_before = GameManager.player_health
	GameManager.heal_player(-5.0)  # Should generate error
	_test("Negative healing generates error", GameManager.player_health == health_before)
	
	GameManager.damage_player(-5.0)  # Should generate error  
	_test("Negative damage generates error", GameManager.player_health == health_before)

## Test 6: Spell System functionality (Phase 2)
func test_spell_system_functionality():
	print("\n📋 TEST SUITE 6: Spell System Functionality (Phase 2)")
	print("-".repeat(30))
	
	# Test SpellData resource creation
	var spell_data = SpellData.new()
	_test("SpellData resource can be created", spell_data != null)
	
	if spell_data:
		# Test spell data properties
		spell_data.spell_name = "Test Spell"
		spell_data.base_damage = 25.0
		spell_data.mana_cost = 10
		spell_data.projectile_speed = 300.0
		spell_data.projectile_range = 600.0
		spell_data.cooldown_duration = 1.0
		
		_test("SpellData properties can be set", spell_data.spell_name == "Test Spell")
		
		# Test spell validation
		if spell_data.has_method("validate"):
			_test("SpellData has validate method", spell_data.validate())
		else:
			_test("SpellData validate method exists", false)
		
		spell_data.queue_free()
	
	# Test SpellProjectile scene
	var projectile_path = "res://scenes/SpellProjectile.tscn"
	_test("SpellProjectile scene exists", ResourceLoader.exists(projectile_path))
	
	if ResourceLoader.exists(projectile_path):
		var projectile_scene = load(projectile_path)
		_test("SpellProjectile scene loads", projectile_scene != null)
		
		if projectile_scene:
			var projectile_instance = projectile_scene.instantiate()
			_test("SpellProjectile can be instantiated", projectile_instance != null)
			
			if projectile_instance:
				# Test projectile has setup method
				_test("SpellProjectile has setup method", projectile_instance.has_method("setup"))
				projectile_instance.queue_free()
	
	# Test SpellComponent functionality (if player exists)
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_node_or_null("GameWorld/Player")
	
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		_test("Player has SpellComponent", spell_comp != null)
		
		if spell_comp:
			# Test SpellComponent methods
			_test("SpellComponent has cast_spell method", spell_comp.has_method("cast_spell"))
			_test("SpellComponent has get_equipped_spells method", spell_comp.has_method("get_equipped_spells"))
			_test("SpellComponent has is_spell_ready method", spell_comp.has_method("is_spell_ready"))
			_test("SpellComponent has validate_setup method", spell_comp.has_method("validate_setup"))
			
			# Test equipped spells
			if spell_comp.has_method("get_equipped_spells"):
				var spells = spell_comp.get_equipped_spells()
				_test("SpellComponent has equipped spells", spells.size() > 0)
				
				if spells.size() > 0:
					_test("First spell is Fireball", spells[0].spell_name == "Fireball")
			
			# Test spell readiness
			if spell_comp.has_method("is_spell_ready"):
				var ready = spell_comp.is_spell_ready(0)
				_test("Spell readiness check works", ready is bool)
	else:
		print("⚠️ Player not found - skipping SpellComponent tests")
	
	# Test spell input actions
	var spell_actions = ["spell_1", "spell_2", "spell_3", "spell_4", "spell_5"]
	for action in spell_actions:
		_test("Input action '" + action + "' exists", InputMap.has_action(action))
	
	# Test GameEvents spell integration
	_test("GameEvents has spell_cast signal", GameEvents.has_signal("spell_cast"))
	
	# Test spell casting event emission
	var spell_event_received = false
	var spell_data_received = {}
	
	GameEvents.spell_cast.connect(func(spell_name, damage):
		spell_event_received = true
		spell_data_received["name"] = spell_name
		spell_data_received["damage"] = damage
	)
	
	GameEvents.spell_cast.emit("Test Spell", 25.0)
	_test("Spell cast event emits correctly", spell_event_received and spell_data_received.get("name") == "Test Spell")

## Helper function to track test results
func _test(test_name: String, condition: bool):
	if condition:
		tests_passed += 1
		print("✅ PASS: " + test_name)
		test_results.append("✅ " + test_name)
	else:
		tests_failed += 1
		print("❌ FAIL: " + test_name)
		test_results.append("❌ " + test_name)

## Helper to get current error count (simplified)
func _get_error_count() -> int:
	# In a real implementation, you'd track errors more precisely
	# For now, we'll use a simple counter
	return tests_failed

## Print comprehensive test summary
func print_test_summary():
	print("\n" + "=".repeat(50))
	print("📊 TEST SUMMARY")
	print("=".repeat(50))
	print("Total Tests: " + str(tests_passed + tests_failed))
	print("✅ Passed: " + str(tests_passed))
	print("❌ Failed: " + str(tests_failed))
	
	var success_rate = 0.0
	if tests_passed + tests_failed > 0:
		success_rate = float(tests_passed) / float(tests_passed + tests_failed) * 100.0
	
	print("📈 Success Rate: " + str(success_rate) + "%")
	
	if tests_failed == 0:
		print("🎉 ALL TESTS PASSED! Singletons are ready for production.")
	else:
		print("⚠️ Some tests failed. Review the issues above.")
		print("\nFailed tests:")
		for result in test_results:
			if result.begins_with("❌"):
				print("  " + result)
	
	print("=".repeat(50))

## Quick smoke test function
func smoke_test() -> bool:
	print("🔥 Running smoke test...")
	
	var checks = [
		GameEvents != null,
		GameManager != null,
		GameManager.current_state == GameManager.GameState.PLAYING,
		GameManager.player_health > 0,
		GameManager.current_wave > 0
	]
	
	var passed = 0
	for check in checks:
		if check:
			passed += 1
	
	var success = passed == checks.size()
	print("🔥 Smoke test: " + str(passed) + "/" + str(checks.size()) + " " + ("PASSED" if success else "FAILED"))
	
	return success

## Performance test
func performance_test():
	print("⚡ Running performance test...")
	
	var start_time = Time.get_ticks_msec()
	
	# Test rapid event emissions
	for i in range(1000):
		GameEvents.emit_player_moved(Vector2(i, i))
		if i % 100 == 0:
			GameEvents.emit_player_health_changed(100.0 - i * 0.01, 100.0)
	
	var end_time = Time.get_ticks_msec()
	var duration = end_time - start_time
	
	print("⚡ Performance test completed in " + str(duration) + "ms")
	print("⚡ Average time per event: " + str(float(duration) / 1100.0) + "ms")
	
	if duration < 100:
		print("✅ Performance: EXCELLENT")
	elif duration < 500:
		print("✅ Performance: GOOD")  
	else:
		print("⚠️ Performance: NEEDS OPTIMIZATION")

# Signal handlers for testing
func _on_player_moved(position: Vector2):
	pass