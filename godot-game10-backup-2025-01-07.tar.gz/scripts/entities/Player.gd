# Player_DodgeFixed.gd
# Player with fixed dodge collision handling
extends CharacterBody2D
class_name Player

# Signals
signal player_took_damage(damage: float, source: Node)
signal screen_shake_requested(intensity: float, duration: float)

# Movement properties
var base_speed: float = 300.0
var speed: float = 300.0
var acceleration: float = 2000.0
var friction: float = 2000.0

# Components
@onready var health_component: HealthComponent = $HealthComponent
@onready var movement_component: Node = $MovementComponent
@onready var player_visuals: Node = $PlayerVisuals
@onready var spell_component: Node = $SpellComponent
@onready var sprite: Sprite2D = $PlayerSprite
@onready var collision_shape: CollisionShape2D = $PlayerCollision
@onready var damage_receiver: Area2D = $DamageReceiver
@onready var camera: Camera2D = $PlayerCamera
var stat_sheet: PlayerStatSheet

# Dodge system
var dodge_speed: float = 1080.0  # Increased by 50% from 720 (80% total from original)
var dodge_duration: float = 0.72  # Increased by 50% from 0.48 (80% total from original)
var dodge_cooldown: float = 1.0
var dodge_cooldown_timer: float = 0.0
var is_dodging: bool = false
var dodge_direction: Vector2 = Vector2.ZERO
var dodge_timer: float = 0.0
var dodge_invulnerability_duration: float = 0.54  # Increased by 50% to match duration

# Damage immunity
var damage_immunity_timer: float = 0.0
var contact_damage_immunity_timer: float = 0.0

# Combat tracking
var dodges_attempted: int = 0
var dodges_successful: int = 0
var last_attacker: Node = null

# Visual feedback
var original_modulate: Color = Color.WHITE

# Store original collision mask for proper restoration
var original_collision_mask: int = 0

func _ready():
	add_to_group("players")  # Note: GameManager looks for "players" (plural)
	add_to_group("player")   # Keep both for compatibility
	
	# Ensure player is on layer 1 and collides with enemies (2) and environment (4)
	collision_layer = 1
	collision_mask = 6  # Binary: 0110 = enemies (2) + environment (4)
	
	# Store original collision mask
	original_collision_mask = collision_mask
	
	setup_components()
	connect_signals()

func setup_components():
	if not health_component:
		health_component = HealthComponent.new()
		add_child(health_component)
	
	# Create player stat sheet as RefCounted (not a Node)
	if not stat_sheet:
		stat_sheet = PlayerStatSheet.new()
		stat_sheet.owner_entity = self
	
	# Set up health component with stat sheet values
	health_component.setup(self)
	health_component.max_health = stat_sheet.get_stat_value("max_health")
	health_component.current_health = health_component.max_health
	
	# Update movement speed from stats
	if stat_sheet:
		speed = stat_sheet.get_stat_value("movement_speed")
		base_speed = speed
	
	# Setup movement component if available
	if movement_component and movement_component.has_method("setup"):
		movement_component.setup(self)
	
	# Setup player visuals if available
	if player_visuals and player_visuals.has_method("setup"):
		player_visuals.setup(self)
	
	# Setup spell component if available
	if spell_component and spell_component.has_method("setup"):
		spell_component.setup(self, health_component)

func connect_signals():
	# Connect damage receiver for contact damage
	if damage_receiver:
		damage_receiver.area_entered.connect(_on_damage_area_entered)
		damage_receiver.body_entered.connect(_on_damage_body_entered)
	
	# Connect health component if it has signals
	if health_component and health_component.has_signal("health_depleted"):
		health_component.health_depleted.connect(_on_health_depleted)
	
	# GameManager will find us through the player group
	# No need to explicitly register

func _physics_process(delta):
	# Update timers
	update_timers(delta)
	
	# Handle input
	handle_movement_input(delta)
	handle_dodge_input(delta)
	handle_spell_input()
	
	# Apply movement
	move_and_slide()
	
	# Update visuals
	update_visuals()

func update_timers(delta):
	# Dodge cooldown
	if dodge_cooldown_timer > 0:
		dodge_cooldown_timer -= delta
	
	# Dodge duration
	if is_dodging:
		dodge_timer -= delta
		if dodge_timer <= 0:
			end_dodge()
	
	# Damage immunity
	if damage_immunity_timer > 0:
		damage_immunity_timer -= delta
	
	if contact_damage_immunity_timer > 0:
		contact_damage_immunity_timer -= delta

func handle_movement_input(delta):
	if is_dodging:
		# During dodge, set velocity directly for first half, then apply strong friction
		if dodge_timer > dodge_duration * 0.5:
			# First half of dodge - maintain full speed
			velocity = dodge_direction * dodge_speed
		else:
			# Second half of dodge - apply very strong friction to stop
			velocity = velocity.move_toward(Vector2.ZERO, friction * 4.0 * delta)
		return
	
	# Normal movement - let MovementComponent handle it if available
	if movement_component and movement_component.has_method("physics_update"):
		movement_component.physics_update(delta)
		return
	
	# Fallback movement if MovementComponent isn't working
	var input_vector = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	
	if input_vector.length() > 0:
		velocity = velocity.move_toward(input_vector.normalized() * speed, acceleration * delta)
	else:
		velocity = velocity.move_toward(Vector2.ZERO, friction * delta)

func handle_dodge_input(delta):
	if Input.is_action_just_pressed("dodge") and can_dodge():
		start_dodge()

func handle_spell_input():
	if not spell_component:
		return
	
	# Handle spell inputs (number keys 1-5)
	for i in range(1, 6):
		var action_name = "spell_" + str(i)
		if Input.is_action_just_pressed(action_name):
			if spell_component.has_method("cast_spell"):
				# cast_spell only takes the spell index (0-based)
				spell_component.cast_spell(i - 1)

func can_dodge() -> bool:
	return dodge_cooldown_timer <= 0 and not is_dodging

func start_dodge():
	dodges_attempted += 1
	is_dodging = true
	dodge_timer = dodge_duration
	dodge_cooldown_timer = dodge_cooldown
	
	# Set dodge direction
	var input_vector = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	
	if input_vector.length() > 0:
		# Dodge in input direction
		dodge_direction = input_vector.normalized()
	else:
		# Emergency dodge - away from nearest enemy
		dodge_direction = get_emergency_dodge_direction()
	
	# Start invulnerability
	damage_immunity_timer = dodge_invulnerability_duration
	
	# FIXED: Properly disable collision during dodge
	# Temporarily remove player from collision layer 1 so enemies can't detect us
	collision_layer = 0  # Not on any layer during dodge
	collision_mask = 4  # Only collide with environment during dodge
	
	# Also disable the DamageReceiver Area2D to prevent damage detection
	if damage_receiver:
		damage_receiver.set_collision_mask_value(2, false)  # Disable enemy detection
	
	print("Dodge started - Enemy collision disabled, mask: ", collision_mask)
	
	# Visual feedback
	show_dodge_effect()
	
	# Emit dodge event
	if GameEvents:
		GameEvents.emit_player_dodged()

func get_emergency_dodge_direction() -> Vector2:
	# Find nearest enemy
	var nearest_enemy = null
	var nearest_distance = INF
	
	for enemy in get_tree().get_nodes_in_group("enemies"):
		var distance = global_position.distance_to(enemy.global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest_enemy = enemy
	
	if nearest_enemy:
		# Dodge away from nearest enemy
		return (global_position - nearest_enemy.global_position).normalized()
	else:
		# Default dodge backward
		return -velocity.normalized() if velocity.length() > 0 else Vector2.DOWN

func end_dodge():
	is_dodging = false
	dodge_direction = Vector2.ZERO
	
	# Apply strong friction to stop the player after dodge
	velocity = velocity * 0.3  # Reduce velocity more to stop sliding
	
	# FIXED: Restore original collision settings
	collision_layer = 1  # Put player back on layer 1
	collision_mask = original_collision_mask  # Restore to 6 (enemies + environment)
	
	# Also restore the DamageReceiver Area2D collision
	if damage_receiver:
		damage_receiver.set_collision_mask_value(2, true)  # Re-enable enemy detection
	
	print("Dodge ended - Collision restored, mask: ", collision_mask)
	
	# End visual effect
	end_dodge_effect()

func show_dodge_effect():
	# Visual dodge feedback
	modulate = Color(1, 1, 1, 0.5)  # Semi-transparent
	
	# Create afterimage trail
	create_afterimage()
	
	# Schedule more afterimages
	for i in range(3):
		get_tree().create_timer(i * 0.1).timeout.connect(create_afterimage)

func create_afterimage():
	if not is_dodging:
		return
	
	var afterimage = Sprite2D.new()
	afterimage.texture = sprite.texture
	afterimage.global_position = global_position
	afterimage.modulate = Color(0.5, 0.5, 1, 0.5)  # Blue tint
	afterimage.scale = Vector2(0.7, 0.7)  # 30% smaller
	afterimage.flip_h = sprite.flip_h  # Match player's facing direction
	get_tree().current_scene.add_child(afterimage)
	
	# Fade out - create tween on the afterimage to avoid freed object errors
	var tween = afterimage.create_tween()
	tween.tween_property(afterimage, "modulate:a", 0, 0.3)
	tween.tween_callback(afterimage.queue_free)

func end_dodge_effect():
	modulate = original_modulate

# Enhanced damage system
func take_damage(damage: float, source: Node = null, damage_type: String = "physical") -> bool:
	# Check for immunity
	if damage_immunity_timer > 0:
		# Successful dodge!
		dodges_successful += 1
		show_dodge_success()
		
		if GameEvents:
			GameEvents.emit_player_dodged()
			# Also emit local signal for damage tracking
			player_took_damage.emit(0.0, source)
		
		return false
	
	# Apply damage
	var damage_taken = health_component.take_damage(damage)
	
	if damage_taken:
		last_attacker = source
		show_damage_feedback(damage, damage_type)
		
		# Set brief immunity to prevent instant multi-hits
		damage_immunity_timer = 0.3
		
		# Check if dead
		check_health_status()
		
		# Emit damage event
		emit_signal("player_took_damage", damage, source)
		# GameEvents signal commented out - signal doesn't exist in GameEvents
		# if GameEvents:
		#	GameEvents.emit_signal("player_took_damage", damage, source, damage_type)
		
		return true
	
	return false

func take_contact_damage(damage: float, source: Node) -> bool:
	# Legacy contact damage with separate immunity
	if contact_damage_immunity_timer > 0:
		return false
	
	var damage_taken = take_damage(damage, source, "contact")
	
	if damage_taken:
		contact_damage_immunity_timer = 1.0  # Standard contact damage immunity
	
	return damage_taken

func show_dodge_success():
	# "DODGE!" text
	var dodge_text = Label.new()
	dodge_text.text = "DODGE!"
	dodge_text.add_theme_font_size_override("font_size", 24)
	dodge_text.add_theme_color_override("font_color", Color.CYAN)
	get_tree().current_scene.add_child(dodge_text)
	dodge_text.global_position = global_position + Vector2(0, -50)
	
	# Animate - create tween on the label to avoid freed object errors
	var tween = dodge_text.create_tween()
	tween.parallel().tween_property(dodge_text, "global_position", dodge_text.global_position + Vector2(0, -30), 0.5)
	tween.parallel().tween_property(dodge_text, "modulate:a", 0, 0.5)
	tween.tween_callback(dodge_text.queue_free)

func show_damage_feedback(damage: float, damage_type: String):
	# Screen flash
	modulate = Color.RED
	var tween = create_tween()
	tween.tween_property(self, "modulate", original_modulate, 0.2)
	
	# Screen shake based on damage
	var shake_intensity = min(damage / 10.0, 5.0)
	emit_signal("screen_shake_requested", shake_intensity, 0.3)
	
	# Also trigger camera shake if available
	if camera and camera.has_method("shake"):
		camera.shake(shake_intensity, 0.3)
	
	# Damage number
	create_damage_number(damage, damage_type)

func create_damage_number(damage: float, damage_type: String):
	var damage_text = Label.new()
	damage_text.text = "-" + str(int(damage))
	damage_text.add_theme_font_size_override("font_size", 24)
	
	# Color based on damage type
	match damage_type:
		"physical", "melee_rush", "melee_lunge":
			damage_text.add_theme_color_override("font_color", Color.RED)
		"ranged_projectile":
			damage_text.add_theme_color_override("font_color", Color.ORANGE)
		"heavy_slam":
			damage_text.add_theme_color_override("font_color", Color.DARK_RED)
			damage_text.add_theme_font_size_override("font_size", 32)  # Bigger for heavy
		_:
			damage_text.add_theme_color_override("font_color", Color.RED)
	
	get_tree().current_scene.add_child(damage_text)
	damage_text.global_position = global_position + Vector2(randf_range(-20, 20), -40)
	
	# Animate - create tween on the damage text to avoid freed object errors
	var tween = damage_text.create_tween()
	tween.parallel().tween_property(damage_text, "global_position", damage_text.global_position + Vector2(0, -60), 1.5)
	tween.parallel().tween_property(damage_text, "modulate:a", 0, 1.5)
	tween.tween_callback(damage_text.queue_free)

func update_visuals():
	# Update sprite based on movement (including dodge)
	var movement_direction = velocity.x
	
	# During dodge, use dodge direction for sprite flip
	if is_dodging and dodge_direction.x != 0:
		movement_direction = dodge_direction.x
	
	# Flip sprite based on direction
	if movement_direction != 0:
		sprite.flip_h = movement_direction < 0

func check_health_status():
	# Check if dead
	if health_component and health_component.current_health <= 0:
		if GameEvents:
			GameEvents.emit_signal("player_died")

# Utility functions
func is_invulnerable() -> bool:
	return damage_immunity_timer > 0 or is_dodging

func get_is_dodging() -> bool:
	return is_dodging

func get_dodge_stats() -> Dictionary:
	return {
		"can_dodge": can_dodge(),
		"cooldown_remaining": max(0, dodge_cooldown_timer),
		"attempts": dodges_attempted,
		"successes": dodges_successful,
		"success_rate": float(dodges_successful) / max(1, dodges_attempted) * 100.0
	}

func get_debug_info() -> Dictionary:
	return {
		"health": "%d/%d" % [health_component.current_health, health_component.max_health],
		"speed": speed,
		"dodging": is_dodging,
		"immunity": damage_immunity_timer > 0,
		"dodge_stats": get_dodge_stats()
	}

# Get stat sheet for other systems
func get_stat_sheet() -> PlayerStatSheet:
	return stat_sheet

# Get spell damage multiplier from stats
func get_spell_damage_multiplier() -> float:
	if stat_sheet:
		return stat_sheet.get_stat_value("spell_damage_multiplier")
	return 1.0

# Contact damage handlers
func _on_damage_area_entered(area: Area2D):
	# Check if it's an enemy damage area
	if area.is_in_group("enemy_damage") and contact_damage_immunity_timer <= 0:
		var enemy = area.get_parent()
		if enemy and enemy.has_method("get_contact_damage"):
			take_contact_damage(enemy.get_contact_damage(), enemy)

func _on_damage_body_entered(body: Node2D):
	# Direct body contact (for enemies without damage areas)
	if body.is_in_group("enemies") and contact_damage_immunity_timer <= 0:
		if body.has_method("get_contact_damage"):
			take_contact_damage(body.get_contact_damage(), body)

func _on_health_depleted():
	# Handle player death
	die()

func die():
	# Emit death event
	if GameEvents:
		GameEvents.emit_signal("player_died", self)
	
	# Visual death feedback
	modulate = Color(0.5, 0.5, 0.5)
	set_physics_process(false)
	
	# Disable collision
	if collision_shape:
		collision_shape.set_deferred("disabled", true)
	
	# Show game over after delay
	await get_tree().create_timer(1.0).timeout
	
	# Restart or show game over screen
	if GameManager and GameManager.has_method("handle_player_death"):
		GameManager.handle_player_death()
	else:
		get_tree().reload_current_scene()