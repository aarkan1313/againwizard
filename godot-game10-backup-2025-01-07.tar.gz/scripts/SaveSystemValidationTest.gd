# SaveSystemValidationTest.gd - Test script to validate save system fixes
extends Node

func _ready():
	print("\n=== 🧪 SAVE SYSTEM VALIDATION TEST ===\n")
	
	# Test 1: Check autoload availability
	print("📍 Test 1: Checking autoload availability...")
	var gm_exists = has_node("/root/GameManager")
	var sm_exists = has_node("/root/SaveManager")
	var ge_exists = has_node("/root/GameEvents")
	
	print("  - GameManager exists: ", gm_exists)
	print("  - SaveManager exists: ", sm_exists)
	print("  - GameEvents exists: ", ge_exists)
	
	if not (gm_exists and sm_exists):
		print("❌ CRITICAL: Required autoloads missing!")
		return
	
	# Test 2: Check SaveManager methods
	print("\n📍 Test 2: Checking SaveManager methods...")
	if SaveManager:
		print("  - has_active_game method: ", SaveManager.has_method("has_active_game"))
		print("  - ensure_active_save method: ", SaveManager.has_method("ensure_active_save"))
		print("  - save_current_game method: ", SaveManager.has_method("save_current_game"))
		print("  - load_saved_game method: ", SaveManager.has_method("load_saved_game"))
		print("  - has_save_file method: ", SaveManager.has_method("has_save_file"))
	
	# Test 3: Check GameManager integration
	print("\n📍 Test 3: Checking GameManager integration...")
	if GameManager:
		print("  - get_save_manager method: ", GameManager.has_method("get_save_manager"))
		print("  - save_game method: ", GameManager.has_method("save_game"))
		print("  - load_game method: ", GameManager.has_method("load_game"))
		print("  - has_saved_game method: ", GameManager.has_method("has_saved_game"))
		
		var sm_ref = GameManager.get_save_manager()
		print("  - get_save_manager returns: ", sm_ref != null)
		print("  - Returns correct SaveManager: ", sm_ref == SaveManager if sm_ref else false)
	
	# Test 4: Check active game detection
	print("\n📍 Test 4: Checking active game detection...")
	if SaveManager and SaveManager.has_method("has_active_game"):
		var has_active = SaveManager.has_active_game()
		print("  - Active game detected: ", has_active)
		
		# Check for player
		var player = get_tree().get_first_node_in_group("player")
		print("  - Player in scene: ", player != null)
	
	# Test 5: Check save file
	print("\n📍 Test 5: Checking save file...")
	if SaveManager and SaveManager.has_method("has_save_file"):
		var has_save = SaveManager.has_save_file()
		print("  - Save file exists: ", has_save)
		print("  - Current save data: ", SaveManager.current_save != null)
	
	# Test 6: UI Integration readiness
	print("\n📍 Test 6: UI Integration check...")
	var escape_menu = get_tree().get_first_node_in_group("escape_menu")
	if escape_menu:
		print("  - Escape menu found: true")
	else:
		print("  - Escape menu found: false (OK if not in game scene)")
	
	print("\n=== ✅ VALIDATION TEST COMPLETE ===")
	print("\n💡 Next: Run the game and press ESC to test the save menu!")
	
	# Auto-cleanup
	queue_free()