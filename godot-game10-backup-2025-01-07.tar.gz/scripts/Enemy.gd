# Enemy_PatternBased.gd
# Enhanced Enemy with pattern-based attack system (no coordination)
extends CharacterBody2D
class_name Enemy

# Core properties (preserved from original)
@export var enemy_data: EnemyData
var enemy_type: String = "goblin"
var health: float = 100.0
var max_health: float = 100.0
var damage: float = 20.0
var speed: float = 150.0
var xp_reward: int = 10
var wave_multipliers: Dictionary = {}

# Components
var health_component: HealthComponent
var movement_component: MovementComponent
var attack_pattern: EnemyAttackPattern
var enemy_abilities: EnemyAbilities  # Existing ability system

# Visual components



@onready var sprite: Sprite2D = $EnemySprite
@onready var health_bar: ProgressBar = $HealthBar
@onready var damage_area: Area2D = $DamageArea  # Kept for compatibility but disabled
@onready var main_collision: CollisionShape2D = $EnemyCollision
@onready var damage_area_collision: CollisionShape2D = $DamageArea/DamageAreaCollision

# State tracking
var target: Node2D = null
var is_dead: bool = false
var mass: float = 1.0  # For push mechanics

# Attack system
var contact_damage_enabled: bool = false
var contact_damage_cooldown: float = 0.0
var attack_cooldown: float = 0.0
var is_attacking: bool = false

# Movement speed multiplier for abilities
var movement_speed_multiplier: float = 1.0
var damage_multiplier: float = 1.0  # For ability damage scaling

func _ready():
	add_to_group("enemies")
	
	# Ensure enemies are on the correct collision layer
	collision_layer = 2  # Enemies are on layer 2
	collision_mask = 5   # Collide with player (1) and environment (4)
	
	setup_components()
	setup_attack_pattern()
	connect_signals()
	# Don't apply stats here - wait for initialize_with_wave_scaling
	
	# Disable contact damage by default
	if damage_area:
		damage_area.set_deferred("monitoring", false)

func setup_components():
	# Setup health component
	health_component = HealthComponent.new()
	add_child(health_component)
	health_component.max_health = max_health
	health_component.current_health = health
	
	# Setup movement component
	movement_component = MovementComponent.new()
	add_child(movement_component)
	movement_component.base_speed = speed
	
	# Setup ability system (existing phase abilities)
	enemy_abilities = EnemyAbilities.new()
	add_child(enemy_abilities)

func setup_attack_pattern():
	# Phase 3.7: Enhanced attack system using telegraphs
	# For now, we'll enhance the existing ability system with telegraphs
	pass
	
	# Configure mass for push mechanics and enable attacks
	match enemy_type:
		"goblin":
			mass = 0.8
			contact_damage_enabled = true
		"orc":
			mass = 1.5
			contact_damage_enabled = true
		"golem":
			mass = 3.0
			contact_damage_enabled = true
		"skeleton", "wizard":
			mass = 1.0
			contact_damage_enabled = false  # They use ranged attacks
		_:
			mass = 1.0
			contact_damage_enabled = true

func connect_signals():
	# HealthComponent doesn't have these signals, so we'll handle health changes differently
	pass
	
	# Legacy contact damage connection (if needed)
	if damage_area and contact_damage_enabled:
		damage_area.body_entered.connect(_on_body_entered)

func show_attack_telegraph():
	# Use the telegraph system to show attack warning
	if TelegraphSystem:
		# Match telegraph range to actual attack range
		var telegraph_range = 50.0  # Default
		var threat_level = "medium"  # Default threat level
		
		match enemy_type:
			"goblin":
				telegraph_range = 50.0
				threat_level = "low"
			"skeleton":
				telegraph_range = 55.0
				threat_level = "medium"
			"orc":
				telegraph_range = 60.0
				threat_level = "medium"
			"wizard":
				telegraph_range = 70.0
				threat_level = "high"
			"golem":
				telegraph_range = 80.0
				threat_level = "high"
		
		TelegraphSystem.show_melee_telegraph(self, telegraph_range, threat_level)

func start_melee_attack():
	if is_attacking or !target:
		return
	
	is_attacking = true
	# Much shorter cooldown for aggressive attacks
	attack_cooldown = 0.5  # Reduced from 0.8
	
	# Show telegraph
	show_attack_telegraph()
	
	# Create timer for attack execution
	var timer = Timer.new()
	timer.wait_time = 0.15  # Very fast telegraph for melee
	timer.one_shot = true
	add_child(timer)
	timer.timeout.connect(_execute_melee_attack)
	timer.start()

func _execute_melee_attack():
	is_attacking = false
	
	if target and is_instance_valid(target):
		var distance = global_position.distance_to(target.global_position)
		
		# Match execution range to attack range
		var execution_range = 60.0  # Default with some buffer
		match enemy_type:
			"goblin":
				execution_range = 60.0  # 50 + 10 buffer
			"orc":
				execution_range = 70.0  # 60 + 10 buffer
			"golem":
				execution_range = 90.0  # 80 + 10 buffer
		
		if distance < execution_range:
			if target.has_method("take_damage"):
				target.take_damage(damage, self, enemy_type + "_melee")

func apply_enemy_type_stats():
	# Load enemy data if available
	var data_path = "res://data/enemies/" + enemy_type + "_data.tres"
	if ResourceLoader.exists(data_path):
		enemy_data = load(data_path)
		if enemy_data:
			# Apply data-driven stats
			max_health = enemy_data.base_health
			damage = enemy_data.base_damage
			speed = enemy_data.base_speed
			xp_reward = int(enemy_data.base_xp)
			
			# Set sprite from data
			if sprite and enemy_data.sprite_path:
				var loaded_sprite = load(enemy_data.sprite_path)
				if loaded_sprite:
					sprite.texture = loaded_sprite
				sprite.scale = enemy_data.sprite_scale
			
			# Initialize abilities from data
			if enemy_abilities and enemy_data.abilities.size() > 0:
				enemy_abilities.initialize(enemy_data.abilities, self)
			
			# Apply collision settings from data
			apply_collision_settings(enemy_data)
	else:
		# Fallback stats if no data file (using original values)
		match enemy_type:
			"goblin":
				max_health = 40.0
				damage = 15.0
				speed = 144.0  # Original goblin speed
				xp_reward = 5
				if sprite:
					var goblin_sprite = load("res://assets/sprites/goblin2.png")
					if goblin_sprite:
						sprite.texture = goblin_sprite
					sprite.scale = Vector2(0.4, 0.4)
			"orc":
				max_health = 80.0
				damage = 30.0
				speed = 100.0
				xp_reward = 15
				if sprite:
					var orc_sprite = load("res://assets/sprites/orc_cut-removebg-preview.png")
					if orc_sprite:
						sprite.texture = orc_sprite
					sprite.scale = Vector2(0.5, 0.5)
			"skeleton":
				max_health = 50.0
				damage = 20.0
				speed = 89.0  # Original skeleton speed
				xp_reward = 8
				if sprite:
					var skeleton_sprite = load("res://assets/sprites/skeleton_archer-removebg-preview.png")
					if skeleton_sprite:
						sprite.texture = skeleton_sprite
					sprite.scale = Vector2(0.4, 0.4)
			"wizard":
				max_health = 60.0
				damage = 25.0
				speed = 115.0  # Original wizard speed
				xp_reward = 20
				if sprite:
					var wizard_sprite = load("res://assets/sprites/evil_wizard_cut-removebg-preview.png")
					if wizard_sprite:
						sprite.texture = wizard_sprite
					sprite.scale = Vector2(0.4, 0.4)
			"golem":
				max_health = 150.0
				damage = 50.0
				speed = 92.0  # Original golem speed
				xp_reward = 40
				if sprite:
					var golem_sprite = load("res://assets/sprites/golem_cut-removebg-preview.png")
					if golem_sprite:
						sprite.texture = golem_sprite
					sprite.scale = Vector2(0.7, 0.7)
			"elemental", "slime":
				max_health = 70.0
				damage = 30.0
				speed = 160.0
				xp_reward = 25
				if sprite:
					var slime_sprite = load("res://assets/sprites/slime_generated.png")
					if slime_sprite:
						sprite.texture = slime_sprite
					sprite.scale = Vector2(0.45, 0.45)
	
	# For fallback enemies, create basic enemy data and auto-adjust collision
	if not enemy_data:
		var fallback_data = EnemyData.new()
		fallback_data.sprite_path = sprite.texture.resource_path if sprite and sprite.texture else ""
		fallback_data.sprite_scale = sprite.scale if sprite else Vector2(1.0, 1.0)
		if fallback_data.auto_adjust_collision_to_sprite():
			apply_collision_settings(fallback_data)
	
	# Update components
	if health_component:
		health_component.max_health = max_health
		health_component.current_health = max_health
	
	if movement_component:
		movement_component.base_speed = speed

func apply_collision_settings(data: EnemyData):
	# Apply collision settings from enemy data
	if not data:
		return
	
	# Main collision shape
	if main_collision:
		var main_shape: Shape2D = null
		
		# Determine if we use rectangular or circular collision
		if data.main_collision_size != Vector2.ZERO:
			# Use rectangular collision
			var rect_shape = RectangleShape2D.new()
			rect_shape.size = data.main_collision_size
			main_shape = rect_shape
		else:
			# Use circular collision
			var circle_shape = CircleShape2D.new()
			circle_shape.radius = data.collision_radius
			main_shape = circle_shape
		
		main_collision.shape = main_shape
		main_collision.position = data.main_collision_offset
	
	# Damage area collision shape
	if damage_area_collision:
		var damage_shape: Shape2D = null
		
		# Determine if we use rectangular or circular collision
		if data.damage_area_size != Vector2.ZERO:
			# Use rectangular collision
			var rect_shape = RectangleShape2D.new()
			rect_shape.size = data.damage_area_size
			damage_shape = rect_shape
		else:
			# Use circular collision
			var circle_shape = CircleShape2D.new()
			circle_shape.radius = data.damage_area_radius
			damage_shape = circle_shape
		
		damage_area_collision.shape = damage_shape
		damage_area_collision.position = data.damage_area_offset

func apply_wave_scaling():
	if WaveManager:
		wave_multipliers = WaveManager.get_current_enemy_multipliers()
		
		if wave_multipliers.has("health"):
			max_health *= wave_multipliers.health
			health = max_health
		
		if wave_multipliers.has("damage"):
			damage *= wave_multipliers.damage
			damage_multiplier = wave_multipliers.damage
		
		if wave_multipliers.has("speed"):
			speed *= wave_multipliers.speed

func _physics_process(delta):
	if is_dead:
		return
	
	# Update cooldowns
	if attack_cooldown > 0:
		attack_cooldown -= delta
	if contact_damage_cooldown > 0:
		contact_damage_cooldown -= delta
	
	# Find target if we don't have one
	if not target:
		target = get_player()
	
	if target:
		var distance = global_position.distance_to(target.global_position)
		
		# Enemy-specific AI behavior (removed is_attacking check for better responsiveness)
		match enemy_type:
			"skeleton", "wizard":
				# Ranged AI - maintain distance
				handle_ranged_ai(distance, delta)
			"goblin":
				# Aggressive melee with charge ability
				handle_goblin_ai(distance, delta)
			"orc", "golem":
				# Standard melee behavior
				handle_melee_ai(distance, delta)
			_:
				# Default melee behavior
				handle_melee_ai(distance, delta)

func take_damage(amount: float, source: Node = null) -> bool:
	if is_dead:
		return false
	
	var damage_taken = health_component.take_damage(amount)
	
	if damage_taken:
		# Visual feedback
		show_damage_feedback(amount)
		
		# Update health bar
		update_health_bar()
		
		# Check if dead
		if health_component.current_health <= 0:
			die()
		
		# GameEvents doesn't have enemy_took_damage signal
		# if GameEvents:
		#	GameEvents.emit_signal("enemy_took_damage", self, amount)
		
		return true
	
	return false

func show_damage_feedback(damage: float):
	# Flash red
	modulate = Color.RED
	var tween = create_tween()
	tween.tween_property(self, "modulate", Color.WHITE, 0.2)
	
	# Damage number
	create_damage_number(damage)

func create_damage_number(damage: float):
	# Use enhanced DamageNumber class with failsafe cleanup
	var damage_scene_path = "res://ui/DamageNumber.tscn"
	if ResourceLoader.exists(damage_scene_path):
		var damage_scene = load(damage_scene_path)
		if damage_scene:
			var damage_number = damage_scene.instantiate()
			if damage_number:
				get_tree().current_scene.add_child(damage_number)
				if damage_number.has_method("setup"):
					var damage_position = global_position + Vector2(randf_range(-20, 20), -30)
					damage_number.setup(damage, damage_position, Color.YELLOW)
	else:
		# Fallback to simple label if DamageNumber scene not found
		var damage_text = Label.new()
		damage_text.text = str(int(damage))
		damage_text.add_theme_font_size_override("font_size", 20)
		damage_text.add_theme_color_override("font_color", Color.YELLOW)
		get_tree().current_scene.add_child(damage_text)
		damage_text.global_position = global_position + Vector2(randf_range(-20, 20), -30)
		
		# Animate with enhanced cleanup
		var tween = damage_text.create_tween()
		tween.parallel().tween_property(damage_text, "global_position", damage_text.global_position + Vector2(0, -50), 1.0)
		tween.parallel().tween_property(damage_text, "modulate:a", 0.0, 1.0)
		tween.tween_callback(damage_text.queue_free)

func apply_knockback(force: Vector2):
	# Apply knockback force
	velocity += force
	move_and_slide()

func apply_push(force: Vector2):
	# Apply push from heavy enemies
	velocity += force * (1.0 / mass)  # Heavier enemies resist push
	move_and_slide()

func update_health_bar():
	# Update health bar based on health component
	if health_bar and health_component:
		health_bar.value = health_component.get_health_percentage()
		health_bar.visible = health_component.current_health < health_component.max_health

func die():
	if is_dead:
		return
	
	is_dead = true
	
	# Clean up any active telegraphs
	if TelegraphSystem:
		TelegraphSystem.hide_telegraph(self)
	
	# Give XP directly to player (no orb drops)
	var player = GameManager.get_player()
	if player:
		# PlayerStatSheet is a property, not a child node
		if player.has_method("get") and player.get("stat_sheet"):
			var stat_sheet = player.stat_sheet
			if stat_sheet and stat_sheet.has_method("gain_experience"):
				stat_sheet.gain_experience(xp_reward)
				print("✅ XP granted to player: ", xp_reward)
		else:
			push_error("❌ Could not find stat_sheet on player!")
	
	# Death effect
	create_death_effect()
	
	# Emit death event
	if GameEvents:
		GameEvents.emit_signal("enemy_died", enemy_type, xp_reward)
	
	# Cleanup
	queue_free()

func drop_xp():
	# Create XP orb using deferred call to avoid physics state issues
	call_deferred("_spawn_xp_orb")

func _spawn_xp_orb():
	# Create XP orb
	var xp_orb = preload("res://scenes/items/XPOrb.tscn").instantiate()
	get_tree().current_scene.add_child(xp_orb)
	xp_orb.global_position = global_position
	xp_orb.xp_value = xp_reward

func create_death_effect():
	# Death particle effect using deferred call
	call_deferred("_spawn_death_effect")

func _spawn_death_effect():
	var death_effect = preload("res://scenes/effects/EnemyDeath.tscn").instantiate()
	get_tree().current_scene.add_child(death_effect)
	death_effect.global_position = global_position
	death_effect.emitting = true

# Legacy contact damage (disabled by default)
func _on_body_entered(body):
	if not contact_damage_enabled or is_dead:
		return
	
	if body.has_method("take_contact_damage") and contact_damage_cooldown <= 0:
		body.take_contact_damage(damage, self)
		contact_damage_cooldown = 1.0

func enable_contact_damage(enabled: bool):
	contact_damage_enabled = enabled
	if damage_area:
		damage_area.set_deferred("monitoring", enabled)

# Debug functions
func get_debug_info() -> Dictionary:
	var info = {
		"type": enemy_type,
		"health": "%d/%d" % [health_component.current_health, health_component.max_health],
		"damage": damage,
		"speed": speed,
		"mass": mass,
		"contact_damage": contact_damage_enabled
	}
	
	if attack_pattern:
		info["pattern"] = attack_pattern.get_pattern_info()
	
	return info

# Utility functions
func get_player() -> Node2D:
	return GameManager.get_player() if GameManager else null

func is_player_visible() -> bool:
	var player = get_player()
	if not player:
		return false
	
	return global_position.distance_to(player.global_position) < 500.0

# AI Behavior Handlers
func handle_melee_ai(distance: float, delta: float):
	# Standard melee behavior - chase and attack
	var direction = (target.global_position - global_position).normalized()
	
	# Slow down while attacking but don't stop
	var speed_modifier = 1.0
	if is_attacking:
		speed_modifier = 0.3  # Move slowly while attacking
	
	velocity = direction * speed * movement_speed_multiplier * speed_modifier
	move_and_slide()
	
	# Update sprite facing
	if velocity.x != 0 and sprite:
		sprite.flip_h = velocity.x < 0
	
	# Check for melee attack based on enemy type
	var attack_range = 50.0  # Default
	match enemy_type:
		"goblin":
			attack_range = 50.0
		"orc":
			attack_range = 60.0
		"golem":
			attack_range = 80.0
	
	if distance < attack_range and attack_cooldown <= 0:
		start_melee_attack()

func handle_ranged_ai(distance: float, delta: float):
	# Ranged AI - maintain optimal distance based on enemy type
	var optimal_distance = 420.0  # Default for skeleton
	var min_distance = 200.0
	
	# Set distances based on enemy type
	match enemy_type:
		"skeleton":
			optimal_distance = 420.0  # Half of their 840 attack range
			min_distance = 200.0
		"wizard":
			optimal_distance = 325.0  # Half of their 650 attack range
			min_distance = 150.0
	
	var direction = (target.global_position - global_position).normalized()
	
	if distance < min_distance:
		# Too close, back away quickly
		velocity = -direction * speed * movement_speed_multiplier
	elif distance < optimal_distance * 0.8:
		# A bit close, back away slowly
		velocity = -direction * speed * movement_speed_multiplier * 0.5
	elif distance > optimal_distance * 1.2:
		# Too far, move closer
		velocity = direction * speed * movement_speed_multiplier * 0.7
	else:
		# Good distance, slight repositioning/strafing
		var strafe_dir = direction.rotated(PI/2 * (1 if randf() > 0.5 else -1))
		velocity = strafe_dir * speed * movement_speed_multiplier * 0.3
	
	move_and_slide()
	
	# Update sprite facing
	if sprite:
		sprite.flip_h = (target.global_position.x < global_position.x)
	
	# Use abilities with proper cooldowns
	if enemy_abilities and attack_cooldown <= 0:
		if enemy_abilities.try_use_ability(target):
			# Set cooldown based on enemy type
			match enemy_type:
				"skeleton":
					attack_cooldown = 1.95  # Skeleton shoots frequently
				"wizard":
					attack_cooldown = 3.0   # Wizard has longer cooldown

func handle_goblin_ai(distance: float, delta: float):
	# Goblin AI - aggressive with charge ability
	var direction = (target.global_position - global_position).normalized()
	
	# Check if we should use charge ability (they have 1400 range on rush)
	if enemy_abilities and distance > 100 and distance < 600 and attack_cooldown <= 0:
		if enemy_abilities.try_use_ability(target):
			# Successfully started charge, 6 second cooldown
			attack_cooldown = 6.0
			return
	
	# Normal movement - goblins have base speed of 144
	velocity = direction * speed * movement_speed_multiplier
	move_and_slide()
	
	# Update sprite facing
	if velocity.x != 0 and sprite:
		sprite.flip_h = velocity.x < 0
	
	# Melee attack at 50 unit range
	if distance < 50 and attack_cooldown <= 0:
		start_melee_attack()

# Initialize enemy with wave scaling
func initialize_with_wave_scaling(wave_data: Dictionary, wave_num: int):
	# Apply wave multipliers to stats
	wave_multipliers = wave_data
	
	# Apply enemy type stats first (this loads sprites)
	apply_enemy_type_stats()
	
	# Then apply wave scaling on top
	apply_wave_scaling()
	
	# Log spawn for debugging
	if wave_num % 5 == 0:  # Log every 5th wave
		print("🌊 Enemy spawned for wave ", wave_num, " with multipliers: ", wave_data)
	
	print("🎯 Pattern-based enemy spawned: ", enemy_type)
