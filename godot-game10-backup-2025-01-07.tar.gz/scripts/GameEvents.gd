extends Node
# GameEvents.gd - Core Event System for Wizard RPG
# Purpose: Centralized event system for loose coupling between systems
# Godot Version: 4.4.1 compatible
# FIXES:
# - Added missing player_died signal and emit function

# Core gameplay events - only the 5 most essential for Phase 0
signal player_moved(new_position: Vector2)
signal player_health_changed(current: float, maximum: float)
signal player_mana_changed(current: float, maximum: float)
signal enemy_died(enemy_name: String, xp_awarded: int)
signal spell_cast(spell_name: String, damage: float)
signal wave_started(wave_number: int, enemy_multipliers: Dictionary)
signal wave_completed(wave_number: int)
signal player_died()  # ADDED: Missing player death signal
signal player_dodged()  # ADDED: For Phase 3.7 dodge system
signal screen_shake(duration: float, intensity: float)  # ADDED: For Phase 3.7 screen effects
signal player_damaged(damage: float, source: String)  # ADDED: For Phase 3.7 damage tracking

# REDUCED LOGGING: Removed event_log array storage
# var event_log: Array[String] = []
# var max_log_size: int = 100

func _ready() -> void:
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "GameEvents singleton initialized", "GameEvents")

# Validated signal emission functions
func emit_player_moved(new_position: Vector2) -> void:
	if new_position == Vector2.INF or new_position.length() > 100000:  # Increased to 100k for open world
		push_error("Invalid player position: " + str(new_position))
		return
	
	player_moved.emit(new_position)
	# REDUCED LOGGING: Changed to LogManager verbose level
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Player moved to: %s" % str(new_position), "GameEvents")

func emit_player_health_changed(current: float, maximum: float) -> void:
	# Allow current health to be 0 (player dead) or temporarily negative during damage calculation
	# Only validate that maximum is positive and current is not excessively negative
	if maximum <= 0:
		push_error("Invalid maximum health: " + str(maximum) + " (must be > 0)")
		return
	
	if current < -maximum:  # Allow temporary negatives but not excessive ones
		push_error("Invalid current health: " + str(current) + " (too far below 0, max: " + str(maximum) + ")")
		return
	
	# Clamp current health to valid range for emission
	var clamped_current = max(0.0, current)
	if current != clamped_current:
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Clamped health value: %.1f → %.1f" % [current, clamped_current], "GameEvents")
	
	player_health_changed.emit(clamped_current, maximum)
	# REDUCED LOGGING: Changed to LogManager verbose level
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Player health: %.0f/%.0f" % [clamped_current, maximum], "health_change")

func emit_player_mana_changed(current: float, maximum: float) -> void:
	if current < 0 or maximum <= 0 or current > maximum:
		push_error("Invalid mana values: " + str(current) + "/" + str(maximum))
		return
	
	player_mana_changed.emit(current, maximum)
	# REDUCED LOGGING: Changed to LogManager verbose level
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Player mana: %.0f/%.0f" % [current, maximum], "mana_change")

func emit_enemy_died(enemy_name: String, xp_awarded: int) -> void:
	if enemy_name.is_empty() or xp_awarded < 0:
		push_error("Invalid enemy death data: " + enemy_name + ", XP: " + str(xp_awarded))
		return
	
	enemy_died.emit(enemy_name, xp_awarded)
	# REDUCED LOGGING: Changed to LogManager verbose level
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Enemy died: %s (+%d XP)" % [enemy_name, xp_awarded], "enemy_death")

func emit_spell_cast(spell_name: String, damage: float) -> void:
	if spell_name.is_empty() or damage < 0:
		push_error("Invalid spell cast data: " + spell_name + ", damage: " + str(damage))
		return
	
	spell_cast.emit(spell_name, damage)
	# REDUCED LOGGING: Changed to LogManager verbose level
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Spell cast: %s (%.0f damage)" % [spell_name, damage], "spell_cast")

func emit_wave_started(wave_number: int, enemy_multipliers: Dictionary) -> void:
	if wave_number <= 0:
		push_error("Invalid wave number: " + str(wave_number))
		return
	
	wave_started.emit(wave_number, enemy_multipliers)
	# REDUCED LOGGING: Keep this as INFO level since waves are important
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "Wave %d started! (Health: %.2fx, Damage: %.2fx)" % 
		[wave_number, enemy_multipliers.get("health", 1.0), enemy_multipliers.get("damage", 1.0)], "GameEvents")

func emit_wave_completed(wave_number: int) -> void:
	if wave_number <= 0:
		push_error("Invalid wave number: " + str(wave_number))
		return
	
	wave_completed.emit(wave_number)
	# REDUCED LOGGING: Keep this as INFO level since waves are important
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "Wave %d completed!" % wave_number, "GameEvents")

# ADDED: Missing player died emission function
func emit_player_died() -> void:
	player_died.emit()
	UnifiedDebugSystem.log_warning_internal(UnifiedDebugSystem.LogCategory.PLAYER, "Player has died!", "GameEvents")

# ADDED: Phase 3.7 signal emission functions
func emit_player_dodged() -> void:
	player_dodged.emit()
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Player dodged!", "player_action")

func emit_screen_shake(duration: float, intensity: float) -> void:
	if duration <= 0 or intensity <= 0:
		push_error("Invalid screen shake parameters: duration=" + str(duration) + ", intensity=" + str(intensity))
		return
	
	screen_shake.emit(duration, intensity)
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Screen shake: %.2fs @ %.1f intensity" % [duration, intensity], "visual_effect")

func emit_player_damaged(damage: float, source: String) -> void:
	if damage < 0 or source.is_empty():
		push_error("Invalid player damage data: damage=" + str(damage) + ", source=" + source)
		return
	
	player_damaged.emit(damage, source)
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "Player damaged: %.1f from %s" % [damage, source], "damage_tracking")

# Debug and utility functions
# REDUCED LOGGING: Removed _log_event function
# func _log_event(message: String) -> void:
# 	event_log.append("[" + Time.get_datetime_string_from_system() + "] " + message)
# 	if event_log.size() > max_log_size:
# 		event_log.pop_front()

# REDUCED LOGGING: Modified to return empty array
func get_event_log() -> Array[String]:
	# Event logging disabled for performance
	return []

func clear_event_log() -> void:
	# Event logging disabled for performance
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "Event log clear requested (logging disabled)", "GameEvents")

func get_signal_summary() -> String:
	return """
GameEvents Signal Summary:
- player_moved(Vector2): Player position changes
- player_health_changed(float, float): Health updates
- player_mana_changed(float, float): Mana updates
- enemy_died(String, int): Enemy death with XP reward
- spell_cast(String, float): Spell casting with damage
- wave_started(int, Dictionary): Wave advancement with enemy scaling
- wave_completed(int): Wave progression
- player_died(): Player death event
- player_dodged(): Player dodge roll executed (Phase 3.7)
- screen_shake(float, float): Screen effect triggered (Phase 3.7)
- player_damaged(float, String): Player damage tracking (Phase 3.7)

Event logging disabled for performance
"""

# Test functions for validation
func test_all_signals() -> bool:
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.TESTING, "Testing all GameEvents signals...", "GameEvents")
	
	# Test each signal with valid data
	emit_player_moved(Vector2(100, 200))
	emit_player_health_changed(80.0, 100.0)
	emit_player_mana_changed(40.0, 50.0)
	emit_enemy_died("TestGoblin", 25)
	emit_spell_cast("Fireball", 35.0)
	emit_wave_started(2, {"health": 1.2, "damage": 1.15, "speed": 1.08})
	emit_wave_completed(1)
	emit_player_died()
	# Phase 3.7 signals
	emit_player_dodged()
	emit_screen_shake(0.5, 2.0)
	emit_player_damaged(15.0, "Goblin")
	
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.TESTING, "✅ All GameEvents signals tested successfully", "GameEvents")
	return true
