# Phase3VerificationTest.gd
# Purpose: Verify Phase 2 functionality still works after Phase 3 integration
# Run this test to ensure no regressions

extends Node

func _ready():
	print("🔍 Starting Phase 3 integration verification...")
	await get_tree().process_frame  # Wait for all singletons to initialize
	run_verification_tests()

func run_verification_tests():
	var all_tests_passed = true
	
	print("\n=== PHASE 3 INTEGRATION VERIFICATION ===")
	
	# Test 1: Singleton availability
	if not _test_singletons():
		all_tests_passed = false
	
	# Test 2: Player integrity
	if not _test_player_system():
		all_tests_passed = false
	
	# Test 3: Stat system integration
	if not _test_stat_system():
		all_tests_passed = false
	
	# Test 4: Phase 2 spell casting preservation
	if not _test_spell_system():
		all_tests_passed = false
	
	# Final results
	print("\n=== VERIFICATION RESULTS ===")
	if all_tests_passed:
		print("✅ ALL TESTS PASSED - Phase 3 integration successful!")
		print("🎯 Phase 2 functionality preserved")
		print("📊 Reactive stat system operational")
	else:
		print("❌ SOME TESTS FAILED - Check output above")
	
	print("=================================\n")

func _test_singletons() -> bool:
	print("\n🔍 Testing singleton availability...")
	
	var singletons = {
		"Logger": Logger,
		"GameEvents": GameEvents, 
		"GameManager": GameManager,
		"WaveManager": WaveManager,
		"InputHandler": InputHandler,
		"DebugMenuManager": DebugMenuManager
	}
	
	var all_available = true
	for name in singletons.keys():
		var singleton = singletons[name]
		if singleton:
			print("  ✅ " + name + " - Available")
		else:
			print("  ❌ " + name + " - Missing")
			all_available = false
	
	return all_available

func _test_player_system() -> bool:
	print("\n🔍 Testing player system integrity...")
	
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("  ❌ Player not found in scene")
		return false
	
	print("  ✅ Player found")
	
	# Test player components
	var components = ["MovementComponent", "HealthComponent", "SpellComponent", "PlayerVisuals"]
	for comp_name in components:
		var component = player.get_node_or_null(comp_name)
		if component:
			print("  ✅ " + comp_name + " - Available")
		else:
			print("  ❌ " + comp_name + " - Missing")
			return false
	
	# Test player stat sheet (Phase 3 addition)
	if player.has_method("get_stat_sheet"):
		var stat_sheet = player.get_stat_sheet()
		if stat_sheet:
			print("  ✅ PlayerStatSheet - Available")
		else:
			print("  ⚠️ PlayerStatSheet - Method exists but returns null")
	else:
		print("  ❌ PlayerStatSheet - get_stat_sheet method missing")
		return false
	
	return true

func _test_stat_system() -> bool:
	print("\n🔍 Testing reactive stat system...")
	
	var player = get_tree().get_first_node_in_group("players")
	if not player or not player.has_method("get_stat_sheet"):
		print("  ❌ Cannot test stats - Player or stat sheet unavailable")
		return false
	
	var stat_sheet = player.get_stat_sheet()
	if not stat_sheet:
		print("  ❌ Stat sheet is null")
		return false
	
	# Test core attributes
	var attributes = ["intelligence", "wisdom", "vitality", "dexterity"]
	for attr in attributes:
		var value = stat_sheet.get_stat_value(attr)
		if value > 0:
			print("  ✅ " + attr + ": " + str(value))
		else:
			print("  ⚠️ " + attr + ": " + str(value) + " (unexpected)")
	
	# Test computed stats
	var computed_stats = ["spell_damage_multiplier", "critical_chance", "max_health", "max_mana"]
	for stat in computed_stats:
		var value = stat_sheet.get_stat_value(stat)
		print("  📊 " + stat + ": " + str(value))
	
	return true

func _test_spell_system() -> bool:
	print("\n🔍 Testing Phase 2 spell system preservation...")
	
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("  ❌ Player not found")
		return false
	
	var spell_component = player.get_node_or_null("SpellComponent")
	if not spell_component:
		print("  ❌ SpellComponent not found")
		return false
	
	print("  ✅ SpellComponent available")
	
	# Test spell availability
	if spell_component.has_method("get_equipped_spells"):
		var spells = spell_component.get_equipped_spells()
		print("  ✅ Equipped spells: " + str(spells.size()))
		
		for i in range(spells.size()):
			var spell = spells[i]
			print("    [" + str(i) + "] " + spell.spell_name + " - " + str(spell.base_damage) + " damage")
	else:
		print("  ❌ get_equipped_spells method missing")
		return false
	
	# Test spell casting functionality
	if player.has_method("cast_spell_by_index"):
		print("  ✅ Spell casting method available")
	else:
		print("  ❌ cast_spell_by_index method missing")
		return false
	
	# Test stat integration
	if player.has_method("get_spell_damage_multiplier"):
		var multiplier = player.get_spell_damage_multiplier()
		print("  ✅ Spell damage multiplier: " + str(multiplier))
	else:
		print("  ❌ get_spell_damage_multiplier method missing")
		return false
	
	return true