# TelegraphRingDrawer.gd
# Draws animated telegraph rings
extends Node2D

@export var radius: float = 50.0
@export var thickness: float = 3.0
@export var color: Color = Color.YELLOW

func _ready():
	set_process(false)

func _draw():
	if radius > 0:
		draw_arc(Vector2.ZERO, radius, 0, TAU, 64, color, thickness, true)