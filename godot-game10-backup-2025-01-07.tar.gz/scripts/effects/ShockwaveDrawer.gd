# ShockwaveDrawer.gd
# Simple script for drawing expanding shockwave rings
extends Node2D

var radius: float = 20.0
var thickness: float = 5.0
var color: Color = Color(1, 1, 1, 0.8)

func _ready():
	set_process(false)  # We don't need process, just drawing

func _draw():
	# Draw expanding ring
	if radius > thickness:
		draw_arc(Vector2.ZERO, radius, 0, TAU, 64, color, thickness)
		
		# Inner glow
		var inner_color = color
		inner_color.a *= 0.5
		draw_arc(Vector2.ZERO, radius - thickness/2, 0, TAU, 32, inner_color, thickness/2)
		
		# Outer fade
		var outer_color = color
		outer_color.a *= 0.3
		draw_arc(Vector2.ZERO, radius + thickness/2, 0, TAU, 32, outer_color, thickness/2)