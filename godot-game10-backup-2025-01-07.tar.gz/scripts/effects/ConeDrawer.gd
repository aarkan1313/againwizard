# ConeDrawer.gd
# Draws cone shapes for cone attacks
extends Node2D

@export var angle: float = PI/4  # 45 degrees
@export var range: float = 100.0
@export var color: Color = Color(1, 0.5, 0, 0.5)

func _ready():
	set_process(false)

func _draw():
	if range <= 0 or angle <= 0:
		return
	
	# Draw cone arc
	var points = PackedVector2Array()
	points.append(Vector2.ZERO)
	
	# Generate arc points
	var segments = 16
	for i in range(segments + 1):
		var current_angle = -angle/2 + (angle * i / segments)
		var point = Vector2(cos(current_angle), sin(current_angle)) * range
		points.append(point)
	
	# Close the shape
	points.append(Vector2.ZERO)
	
	# Draw filled cone
	draw_colored_polygon(points, color)
	
	# Draw outline
	var outline_color = color
	outline_color.a = min(1.0, color.a * 2)
	draw_polyline(points, outline_color, 2.0)