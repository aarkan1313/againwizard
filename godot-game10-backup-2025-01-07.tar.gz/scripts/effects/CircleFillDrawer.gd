# CircleFillDrawer.gd
# Draws filled circles for area effects
extends Node2D

@export var radius: float = 100.0
@export var color: Color = Color(1, 0, 0, 0.2)

func _ready():
	set_process(false)

func _draw():
	if radius > 0:
		draw_circle(Vector2.ZERO, radius, color)