# TargetReticleDrawer.gd
# Draws animated target reticle
extends Node2D

@export var color: Color = Color.RED
@export var size: float = 30.0

func _ready():
	set_process(false)

func _draw():
	# Draw crosshair
	var half_size = size / 2
	var gap = size / 4
	
	# Horizontal lines
	draw_line(Vector2(-half_size, 0), Vector2(-gap, 0), color, 2.0)
	draw_line(Vector2(gap, 0), Vector2(half_size, 0), color, 2.0)
	
	# Vertical lines
	draw_line(Vector2(0, -half_size), Vector2(0, -gap), color, 2.0)
	draw_line(Vector2(0, gap), Vector2(0, half_size), color, 2.0)
	
	# Center circle
	draw_arc(Vector2.ZERO, gap/2, 0, TAU, 16, color, 2.0)
	
	# Outer circle
	draw_arc(Vector2.ZERO, half_size, 0, TAU, 32, color, 2.0)