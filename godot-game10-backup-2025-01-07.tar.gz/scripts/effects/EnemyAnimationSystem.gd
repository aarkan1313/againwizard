# EnemyAnimationSystem.gd
# Procedural animation system for enemy attacks and abilities
extends Node
class_name EnemyAnimationSystem

# This component adds visual flair to enemy attacks using only code
# No external assets required - all animations are procedural

# Animation types
enum AnimationType {
	MELEE_SLASH,
	MELEE_SLAM,
	PROJECTILE_LAUNCH,
	SPELL_CAST,
	CHARGE_UP,
	IMPACT,
	TELEGRAPH_PULSE
}

var enemy: CharacterBody2D
var sprite: Sprite2D

# Animation state
var active_tweens: Array = []
var active_effects: Array = []

# Colors for effects
const CHARGE_COLOR = Color(1.5, 1.2, 0.8, 1.0)  # Bright yellow
const ATTACK_COLOR = Color(2.0, 0.5, 0.5, 1.0)  # Bright red
const MAGIC_COLOR = Color(0.8, 1.5, 2.0, 1.0)  # Bright blue
const IMPACT_COLOR = Color.WHITE

func setup(enemy_node: CharacterBody2D):
	enemy = enemy_node
	sprite = enemy.get_node_or_null("Sprite2D")
	if not sprite:
		push_error("EnemyAnimationSystem: No sprite found on enemy")

# Main animation functions
func play_attack_animation(attack_type: String):
	match attack_type:
		"melee_rush", "melee_lunge":
			play_melee_slash_animation()
		"heavy_slam":
			play_slam_animation()
		"ranged_projectile":
			play_projectile_launch_animation()
		"spell_cast":
			play_spell_cast_animation()
		_:
			play_basic_attack_animation()

# MELEE SLASH ANIMATION
func play_melee_slash_animation():
	if not enemy or not sprite:
		return
	
	# Wind-up: Pull back
	var wind_up_tween = create_tween()
	wind_up_tween.tween_property(sprite, "position:x", -10, 0.15)
	wind_up_tween.tween_property(sprite, "scale", Vector2(0.8, 1.2), 0.15)
	
	# Strike: Lunge forward with slash effect
	wind_up_tween.tween_callback(create_slash_effect)
	wind_up_tween.tween_property(sprite, "position:x", 10, 0.1)
	wind_up_tween.parallel().tween_property(sprite, "scale", Vector2(1.3, 0.8), 0.1)
	
	# Recovery: Return to normal
	wind_up_tween.tween_property(sprite, "position", Vector2.ZERO, 0.2)
	wind_up_tween.parallel().tween_property(sprite, "scale", Vector2.ONE, 0.2)
	
	active_tweens.append(wind_up_tween)

func create_slash_effect():
	# Create a slash line using Line2D
	var slash = Line2D.new()
	enemy.get_parent().add_child(slash)
	slash.global_position = enemy.global_position
	slash.z_index = enemy.z_index + 1
	
	# Slash arc
	var start_angle = -PI/4
	var end_angle = PI/4
	var radius = 60
	
	# Generate arc points
	for i in range(5):
		var angle = lerp(start_angle, end_angle, i / 4.0)
		var point = Vector2(cos(angle), sin(angle)) * radius
		slash.add_point(point)
	
	# Style the slash
	slash.width = 8.0
	slash.default_color = Color(1, 1, 1, 0.8)
	slash.begin_cap_mode = Line2D.LINE_CAP_ROUND
	slash.end_cap_mode = Line2D.LINE_CAP_ROUND
	
	# Animate the slash
	var slash_tween = create_tween()
	slash_tween.tween_property(slash, "modulate:a", 0.0, 0.3)
	slash_tween.tween_callback(slash.queue_free)
	
	active_effects.append(slash)

# HEAVY SLAM ANIMATION
func play_slam_animation():
	if not enemy or not sprite:
		return
	
	# Raise up
	var slam_tween = create_tween()
	slam_tween.tween_property(sprite, "position:y", -20, 0.3).set_ease(Tween.EASE_OUT)
	slam_tween.parallel().tween_property(sprite, "scale", Vector2(1.2, 1.2), 0.3)
	slam_tween.parallel().tween_property(sprite, "modulate", CHARGE_COLOR, 0.3)
	
	# Slam down
	slam_tween.tween_property(sprite, "position:y", 5, 0.1).set_ease(Tween.EASE_IN)
	slam_tween.parallel().tween_property(sprite, "scale", Vector2(1.5, 0.5), 0.1)
	slam_tween.tween_callback(create_slam_impact)
	
	# Recovery
	slam_tween.tween_property(sprite, "position:y", 0, 0.2)
	slam_tween.parallel().tween_property(sprite, "scale", Vector2.ONE, 0.2)
	slam_tween.parallel().tween_property(sprite, "modulate", Color.WHITE, 0.2)
	
	active_tweens.append(slam_tween)

func create_slam_impact():
	# Create expanding shockwave ring
	var shockwave = Node2D.new()
	enemy.get_parent().add_child(shockwave)
	shockwave.global_position = enemy.global_position
	shockwave.z_index = enemy.z_index - 1
	
	# Custom draw for the ring
	shockwave.set_script(preload("res://scripts/effects/ShockwaveDrawer.gd"))
	
	# Animate expansion
	var shock_tween = create_tween()
	shock_tween.tween_property(shockwave, "scale", Vector2(3, 3), 0.5)
	shock_tween.parallel().tween_property(shockwave, "modulate:a", 0.0, 0.5)
	shock_tween.tween_callback(shockwave.queue_free)
	
	# Ground cracks
	for i in range(4):
		create_ground_crack(i * PI/2)
	
	active_effects.append(shockwave)

func create_ground_crack(angle: float):
	var crack = Line2D.new()
	enemy.get_parent().add_child(crack)
	crack.global_position = enemy.global_position
	crack.rotation = angle
	crack.z_index = enemy.z_index - 1
	
	# Crack line
	crack.add_point(Vector2.ZERO)
	crack.add_point(Vector2(randf_range(40, 80), 0))
	crack.width = 4.0
	crack.default_color = Color(0.2, 0.2, 0.2, 0.8)
	
	# Animate
	var crack_tween = create_tween()
	crack_tween.tween_property(crack, "modulate:a", 0.0, 1.0)
	crack_tween.tween_callback(crack.queue_free)
	
	active_effects.append(crack)

# PROJECTILE LAUNCH ANIMATION
func play_projectile_launch_animation():
	if not enemy or not sprite:
		return
	
	# Draw back (like drawing a bow)
	var launch_tween = create_tween()
	launch_tween.tween_property(sprite, "scale", Vector2(0.8, 1.1), 0.2)
	launch_tween.parallel().tween_property(sprite, "modulate", Color(1.2, 1.2, 1.2), 0.2)
	
	# Release with recoil
	launch_tween.tween_property(sprite, "scale", Vector2(1.2, 0.9), 0.1)
	launch_tween.tween_callback(create_launch_effect)
	
	# Recovery
	launch_tween.tween_property(sprite, "scale", Vector2.ONE, 0.2)
	launch_tween.parallel().tween_property(sprite, "modulate", Color.WHITE, 0.2)
	
	active_tweens.append(launch_tween)

func create_launch_effect():
	# Muzzle flash effect
	var flash = Sprite2D.new()
	enemy.get_parent().add_child(flash)
	flash.global_position = enemy.global_position + Vector2(30, 0)  # Offset to front
	flash.scale = Vector2(0.5, 0.5)
	
	# Create a simple circular texture
	var image = Image.create(64, 64, false, Image.FORMAT_RGBA8)
	for x in range(64):
		for y in range(64):
			var dist = Vector2(x - 32, y - 32).length()
			if dist < 32:
				var alpha = 1.0 - (dist / 32.0)
				image.set_pixel(x, y, Color(1, 0.8, 0.4, alpha))
	
	var texture = ImageTexture.create_from_image(image)
	flash.texture = texture
	
	# Animate flash
	var flash_tween = create_tween()
	flash_tween.tween_property(flash, "scale", Vector2(2, 2), 0.1)
	flash_tween.parallel().tween_property(flash, "modulate:a", 0.0, 0.2)
	flash_tween.tween_callback(flash.queue_free)
	
	active_effects.append(flash)

# SPELL CAST ANIMATION
func play_spell_cast_animation():
	if not enemy or not sprite:
		return
	
	# Magical charge up
	var cast_tween = create_tween()
	cast_tween.tween_property(sprite, "modulate", MAGIC_COLOR, 0.3)
	
	# Create orbiting particles
	for i in range(3):
		cast_tween.tween_callback(func(): create_magic_particle(i * 2 * PI / 3))
	
	# Release
	cast_tween.tween_property(sprite, "scale", Vector2(1.3, 1.3), 0.2)
	cast_tween.tween_property(sprite, "scale", Vector2.ONE, 0.2)
	cast_tween.parallel().tween_property(sprite, "modulate", Color.WHITE, 0.3)
	
	active_tweens.append(cast_tween)

func create_magic_particle(start_angle: float):
	var particle = Sprite2D.new()
	enemy.get_parent().add_child(particle)
	particle.scale = Vector2(0.3, 0.3)
	
	# Create glowing orb texture
	var image = Image.create(32, 32, false, Image.FORMAT_RGBA8)
	for x in range(32):
		for y in range(32):
			var dist = Vector2(x - 16, y - 16).length()
			if dist < 16:
				var alpha = 1.0 - pow(dist / 16.0, 2)
				image.set_pixel(x, y, Color(0.5, 0.8, 1.0, alpha))
	
	var texture = ImageTexture.create_from_image(image)
	particle.texture = texture
	
	# Orbit animation
	var orbit_tween = create_tween()
	orbit_tween.set_loops(2)
	
	# Orbit around enemy
	var radius = 40
	var duration = 0.5
	
	# Create orbit path
	orbit_tween.tween_method(
		func(t): 
			var angle = start_angle + t * 2 * PI
			particle.global_position = enemy.global_position + Vector2(cos(angle), sin(angle)) * radius,
		0.0, 1.0, duration
	)
	
	# Fade out
	orbit_tween.tween_property(particle, "modulate:a", 0.0, 0.2)
	orbit_tween.tween_callback(particle.queue_free)
	
	active_effects.append(particle)

# TELEGRAPH PULSE ANIMATION
func play_telegraph_pulse(telegraph_node: Node2D, threat_level: String = "medium"):
	if not telegraph_node:
		return
	
	var pulse_color = Color.YELLOW
	var pulse_speed = 1.0
	
	match threat_level:
		"low":
			pulse_color = Color.YELLOW
			pulse_speed = 1.5
		"medium":
			pulse_color = Color.ORANGE
			pulse_speed = 1.2
		"high":
			pulse_color = Color.RED
			pulse_speed = 1.0
		"extreme":
			pulse_color = Color.DARK_RED
			pulse_speed = 0.8
	
	# Pulsing animation
	var pulse_tween = create_tween()
	pulse_tween.set_loops()
	pulse_tween.tween_property(telegraph_node, "scale", Vector2(1.1, 1.1), 0.3 / pulse_speed)
	pulse_tween.tween_property(telegraph_node, "scale", Vector2(0.9, 0.9), 0.3 / pulse_speed)
	
	# Color flash
	pulse_tween.parallel().tween_property(telegraph_node, "modulate", pulse_color * 1.5, 0.3 / pulse_speed)
	pulse_tween.tween_property(telegraph_node, "modulate", pulse_color, 0.3 / pulse_speed)
	
	active_tweens.append(pulse_tween)

# CHARGE-UP ANIMATION
func play_charge_animation(duration: float = 1.0):
	if not enemy or not sprite:
		return
	
	# Growing energy effect
	var charge_tween = create_tween()
	
	# Sprite grows and glows
	charge_tween.tween_property(sprite, "scale", Vector2(1.3, 1.3), duration)
	charge_tween.parallel().tween_property(sprite, "modulate", CHARGE_COLOR, duration)
	
	# Create energy particles
	var particle_timer = 0.0
	charge_tween.tween_method(
		func(t):
			particle_timer += t
			if particle_timer > 0.1:
				create_charge_particle()
				particle_timer = 0.0,
		0.0, duration, duration
	)
	
	active_tweens.append(charge_tween)

func create_charge_particle():
	var particle = Sprite2D.new()
	enemy.get_parent().add_child(particle)
	
	# Random position around enemy
	var angle = randf() * 2 * PI
	var distance = randf_range(40, 60)
	particle.global_position = enemy.global_position + Vector2(cos(angle), sin(angle)) * distance
	particle.scale = Vector2(0.2, 0.2)
	
	# Simple dot texture
	var image = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for x in range(16):
		for y in range(16):
			var dist = Vector2(x - 8, y - 8).length()
			if dist < 8:
				image.set_pixel(x, y, Color(1, 1, 0.5, 1.0 - dist/8))
	
	var texture = ImageTexture.create_from_image(image)
	particle.texture = texture
	
	# Move toward enemy center
	var move_tween = create_tween()
	move_tween.tween_property(particle, "global_position", enemy.global_position, 0.5)
	move_tween.parallel().tween_property(particle, "scale", Vector2.ZERO, 0.5)
	move_tween.tween_callback(particle.queue_free)
	
	active_effects.append(particle)

# HIT REACTION ANIMATION
func play_hit_reaction():
	if not enemy or not sprite:
		return
	
	# Flash white
	var original_modulate = sprite.modulate
	sprite.modulate = Color.WHITE * 2
	
	# Knockback effect
	var hit_tween = create_tween()
	hit_tween.tween_property(sprite, "position:x", 10, 0.05)
	hit_tween.tween_property(sprite, "position:x", -5, 0.05)
	hit_tween.tween_property(sprite, "position:x", 0, 0.1)
	hit_tween.parallel().tween_property(sprite, "modulate", original_modulate, 0.2)
	
	active_tweens.append(hit_tween)

# BASIC ATTACK ANIMATION (fallback)
func play_basic_attack_animation():
	if not enemy or not sprite:
		return
	
	var attack_tween = create_tween()
	attack_tween.tween_property(sprite, "scale", Vector2(1.2, 0.8), 0.1)
	attack_tween.tween_property(sprite, "scale", Vector2(0.8, 1.2), 0.1)
	attack_tween.tween_property(sprite, "scale", Vector2.ONE, 0.2)
	
	active_tweens.append(attack_tween)

# Cleanup
func cleanup():
	for tween in active_tweens:
		if tween and tween.is_valid():
			tween.kill()
	active_tweens.clear()
	
	for effect in active_effects:
		if effect and is_instance_valid(effect):
			effect.queue_free()
	active_effects.clear()

func _exit_tree():
	cleanup()