# ImpactEffect.gd
# Purpose: Visual impact effect for spell projectile hits
# Godot Version: 4.4.1 compatible

extends Node2D
class_name ImpactEffect

@onready var impact_sprite: Sprite2D = $ImpactSprite
@onready var animation_player: AnimationPlayer = $AnimationPlayer
@onready var lifetime_timer: Timer = $LifetimeTimer

# Effect configuration
var effect_color: Color = Color.ORANGE
var effect_size: float = 1.0
var effect_duration: float = 0.3

func _ready():
	# Create a simple impact sprite if none provided
	if not impact_sprite.texture:
		_create_impact_texture()
	
	# Configure the effect
	impact_sprite.modulate = effect_color
	impact_sprite.scale = Vector2(effect_size, effect_size)
	
	# Start the impact animation
	if animation_player and animation_player.has_animation("Animation_impact_flash"):
		animation_player.play("Animation_impact_flash")
	else:
		# Fallback animation if the scene animation doesn't work
		_play_fallback_animation()
	
	print("✨ Impact effect created at " + str(global_position))

func _create_impact_texture():
	# Create a simple circle texture for the impact effect
	var image = Image.create(32, 32, false, Image.FORMAT_RGBA8)
	var center = Vector2(16, 16)
	
	# Draw a circle
	for x in range(32):
		for y in range(32):
			var distance = Vector2(x, y).distance_to(center)
			if distance <= 14:
				var alpha = 1.0 - (distance / 14.0) * 0.5  # Fade from center
				image.set_pixel(x, y, Color(1.0, 0.5, 0.0, alpha))
	
	var texture = ImageTexture.new()
	texture.set_image(image)
	impact_sprite.texture = texture

func _play_fallback_animation():
	# Simple fallback animation using tweens
	var tween = create_tween()
	tween.set_parallel(true)
	
	# Scale animation
	tween.tween_property(impact_sprite, "scale", Vector2(1.2, 1.2), 0.1)
	tween.tween_property(impact_sprite, "scale", Vector2(0.8, 0.8), 0.2).set_delay(0.1)
	
	# Fade animation
	tween.tween_property(impact_sprite, "modulate:a", 0.0, 0.3)
	
	# Clean up
	tween.tween_callback(queue_free).set_delay(0.3)

func setup(impact_color: Color = Color.ORANGE, size: float = 1.0):
	effect_color = impact_color
	effect_size = size
	
	if impact_sprite:
		impact_sprite.modulate = effect_color
		impact_sprite.scale = Vector2(effect_size, effect_size)

func _on_lifetime_timer_timeout():
	print("🗑️ Impact effect cleanup")
	queue_free()