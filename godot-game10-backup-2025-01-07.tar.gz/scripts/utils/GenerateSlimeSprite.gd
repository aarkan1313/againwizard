# GenerateSlimeSprite.gd
# Utility script to generate slime sprite - can be run from debug menu or directly
extends Node

func _ready():
	generate_slime_sprite()

func generate_slime_sprite():
	# Generate and save the slime sprite
	print("🎨 Generating procedural slime sprite...")
	
	# Load the generator class
	var generator_script = load("res://scripts/procedural/SlimeSpriteGenerator.gd")
	
	# Generate the texture
	var texture = generator_script.generate_slime_texture()
	
	# Save to assets folder
	var file_path = "res://assets/sprites/slime_generated.png"
	var success = generator_script.save_slime_texture_to_file(file_path)
	
	if success:
		print("✅ Slime sprite generated successfully!")
		print("📁 Location: %s" % file_path)
		
		# Update the slime data to use the new sprite
		update_slime_data_sprite_path(file_path)
	else:
		print("❌ Failed to generate slime sprite")

func update_slime_data_sprite_path(sprite_path: String):
	# Update the slime data file to use the new sprite
	print("📝 Updating slime data to use generated sprite...")
	
	# Load slime data
	var slime_data_path = "res://data/enemies/slime_data.tres"
	if ResourceLoader.exists(slime_data_path):
		var slime_data = load(slime_data_path)
		if slime_data:
			slime_data.sprite_path = sprite_path
			print("✅ Slime data updated to use: %s" % sprite_path)
		else:
			print("❌ Could not load slime data")
	else:
		print("❌ Slime data file not found")

# Alternative function to generate different slime variants
func generate_slime_variants():
	# Generate different colored slime variants
	var generator_script = load("res://scripts/procedural/SlimeSpriteGenerator.gd")
	
	var variants = [
		{"name": "green", "color": Color(0.2, 0.8, 0.3)},
		{"name": "blue", "color": Color(0.2, 0.4, 0.9)},
		{"name": "red", "color": Color(0.8, 0.2, 0.3)},
		{"name": "purple", "color": Color(0.6, 0.2, 0.8)}
	]
	
	for variant in variants:
		var texture = generator_script.generate_slime_texture()
		var file_path = "res://assets/sprites/slime_%s.png" % variant.name
		generator_script.save_slime_texture_to_file(file_path)
		print("✅ Generated %s slime variant" % variant.name)