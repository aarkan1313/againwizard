extends Control
# BasicHUD.gd - Simple UI foundation for Phase 0
# Purpose: Minimal health display that connects to GameEvents system
# Godot Version: 4.4.1 compatible

@onready var health_label: Label = $HealthLabel
@onready var mana_label: Label = $ManaLabel
@onready var debug_panel: Control = get_node("../DebugPanel")
@onready var fps_label: Label = get_node("../DebugPanel/DebugInfo/FPSLabel")
@onready var error_count_label: Label = get_node("../DebugPanel/DebugInfo/ErrorCountLabel")
@onready var quality_label: Label = get_node("../DebugPanel/DebugInfo/QualityLabel")

# UI update timer
var ui_timer: Timer

func _ready() -> void:
	print("🎨 BasicHUD initialized - Phase 0 UI foundation ready")
	
	# Connect to GameEvents for health and mana updates
	if GameEvents:
		GameEvents.player_health_changed.connect(_on_player_health_changed)
		GameEvents.player_mana_changed.connect(_on_player_mana_changed)
		print("🔗 BasicHUD connected to GameEvents.player_health_changed and player_mana_changed")
	else:
		push_error("BasicHUD: GameEvents not available!")
		return
	
	# Set up UI update timer for debug info
	ui_timer = Timer.new()
	ui_timer.wait_time = 0.5  # Update debug info every 0.5 seconds
	ui_timer.timeout.connect(_update_debug_info)
	ui_timer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui_timer)
	ui_timer.start()
	
	# Initialize display
	_update_health_display()
	_update_mana_display()
	_update_debug_info()
	
	print("✅ BasicHUD setup complete")

func _on_player_health_changed(current: float, maximum: float) -> void:
	# Update health display when player health changes
	print("📊 BasicHUD received health update: " + str(current) + "/" + str(maximum))
	_update_health_display()

func _on_player_mana_changed(current: float, maximum: float) -> void:
	# Update mana display when player mana changes
	print("📊 BasicHUD received mana update: " + str(current) + "/" + str(maximum))
	_update_mana_display()

func _update_health_display() -> void:
	if not health_label:
		return
	
	# Get current health from GameManager if available
	var current_health = 100.0
	var max_health = 100.0
	
	if GameManager:
		current_health = GameManager.player_health
		max_health = GameManager.player_max_health
	
	# Update label text
	health_label.text = "Health: " + str(int(current_health)) + "/" + str(int(max_health))
	
	# Change color based on health percentage
	var health_percentage = current_health / max_health if max_health > 0 else 0.0
	
	if health_percentage > 0.6:
		health_label.modulate = Color.WHITE
	elif health_percentage > 0.3:
		health_label.modulate = Color.YELLOW
	else:
		health_label.modulate = Color.RED

func _update_mana_display() -> void:
	if not mana_label:
		return
	
	# Get current mana from GameManager if available
	var current_mana = 100.0
	var max_mana = 100.0
	
	if GameManager:
		current_mana = GameManager.player_mana
		max_mana = GameManager.player_max_mana
	
	# Update label text
	mana_label.text = "Mana: " + str(int(current_mana)) + "/" + str(int(max_mana))
	
	# Change color based on mana percentage
	var mana_percentage = current_mana / max_mana if max_mana > 0 else 0.0
	
	if mana_percentage > 0.6:
		mana_label.modulate = Color.CYAN
	elif mana_percentage > 0.3:
		mana_label.modulate = Color.YELLOW
	else:
		mana_label.modulate = Color.RED

func _update_debug_info() -> void:
	if not debug_panel:
		return
	
	# Update FPS
	if fps_label:
		var current_fps = Engine.get_frames_per_second()
		fps_label.text = "FPS: " + str(current_fps)
		
		# Color code FPS
		if current_fps >= 55:
			fps_label.modulate = Color.GREEN
		elif current_fps >= 30:
			fps_label.modulate = Color.YELLOW
		else:
			fps_label.modulate = Color.RED
	
	# Update error count
	if error_count_label and UnifiedDebugSystem:
		var error_count = UnifiedDebugSystem.error_count if UnifiedDebugSystem else 0
		var warning_count = UnifiedDebugSystem.warning_count if UnifiedDebugSystem else 0
		error_count_label.text = "Errors: " + str(error_count) + " | Warnings: " + str(warning_count)
		
		# Color code error count
		if error_count == 0:
			error_count_label.modulate = Color.GREEN
		elif error_count <= 5:
			error_count_label.modulate = Color.YELLOW
		else:
			error_count_label.modulate = Color.RED
	
	# Update quality status
	if quality_label:
		var quality_gate = get_node_or_null("../../Systems/QualityGate")
		if quality_gate:
			var quality_status = quality_gate.get_current_quality_status()
			quality_label.text = "Quality: " + quality_status.quality_level
			
			# Color code quality
			match quality_status.quality_level:
				"EXCELLENT":
					quality_label.modulate = Color.GREEN
				"GOOD":
					quality_label.modulate = Color.LIGHT_GREEN
				"FAIR":
					quality_label.modulate = Color.YELLOW
				"POOR":
					quality_label.modulate = Color.ORANGE
				"CRITICAL":
					quality_label.modulate = Color.RED
				_:
					quality_label.modulate = Color.WHITE
		else:
			quality_label.text = "Quality: Unknown"
			quality_label.modulate = Color.GRAY

# Public interface for external testing
func test_ui_updates() -> bool:
	print("🧪 Testing BasicHUD functionality...")
	
	# Test health update
	_on_player_health_changed(80.0, 100.0)
	
	# Verify label was updated
	await get_tree().process_frame
	
	if health_label.text.contains("80/100"):
		print("✅ BasicHUD health update test PASSED")
		return true
	else:
		print("❌ BasicHUD health update test FAILED")
		return false

func get_ui_status() -> String:
	var status = "BasicHUD Status:\n"
	status += "- Health Label: " + (health_label.text if health_label else "Missing") + "\n"
	status += "- Debug Panel: " + ("Visible" if debug_panel and debug_panel.visible else "Hidden/Missing") + "\n"
	status += "- Update Timer: " + ("Running" if ui_timer and not ui_timer.is_stopped() else "Stopped/Missing") + "\n"
	status += "- GameEvents Connected: " + ("Yes" if GameEvents and GameEvents.player_health_changed.is_connected(_on_player_health_changed) else "No") + "\n"
	return status

# Toggle debug panel visibility
func toggle_debug_panel() -> void:
	if debug_panel:
		debug_panel.visible = not debug_panel.visible
		print("🔍 Debug panel " + ("shown" if debug_panel.visible else "hidden"))

# Manual refresh for testing
func force_refresh() -> void:
	_update_health_display()
	_update_mana_display()
	_update_debug_info()
	print("🔄 BasicHUD force refreshed")