# StatDisplayPanel.gd
# Purpose: Individual stat display component with tooltip and visual feedback
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: PlayerStatSheet, StatSheet signals
# API References: Official Godot Control and Tooltip documentation

extends Control
class_name StatDisplayPanel

# Stat display information
var stat_name: String = ""
var stat_description: String = ""
var stat_type: String = ""  # "attribute", "computed", "combat", "progression"
var current_value: float = 0.0
var base_value: float = 0.0
var has_modifiers: bool = false

# UI references
@onready var name_label: Label = $HBoxContainer/NameLabel
@onready var value_label: Label = $HBoxContainer/ValueLabel
@onready var modifier_indicator: Label = $HBoxContainer/ModifierIndicator

# Visual feedback
var default_color: Color = Color.WHITE
var modified_color: Color = Color.CYAN
var increased_color: Color = Color.GREEN
var decreased_color: Color = Color.RED

# Animation
var value_tween: Tween
var last_displayed_value: float = 0.0

signal stat_clicked(stat_name: String)

func _ready():
	# Setup tooltip functionality
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	gui_input.connect(_on_gui_input)
	
	# Initialize visual state
	_update_display()

# Initialize the stat panel with data
func setup_stat(name: String, description: String, type: String, initial_value: float = 0.0, initial_base: float = 0.0):
	stat_name = name
	stat_description = description
	stat_type = type
	current_value = initial_value
	base_value = initial_base
	last_displayed_value = initial_value
	
	_update_display()
	print("📊 StatDisplayPanel setup: ", stat_name, " = ", current_value)

# Update the stat value (called when stat changes)
func update_value(new_value: float, new_base: float = 0.0, modifier_count: int = 0):
	var old_value = current_value
	current_value = new_value
	base_value = new_base
	has_modifiers = modifier_count > 0
	
	# Check if UI is ready before animating
	if not is_inside_tree() or not value_label:
		_update_display()
		last_displayed_value = new_value
		return
	
	# Animate value change if significant
	if abs(new_value - last_displayed_value) > 0.1:
		_animate_value_change(old_value, new_value)
	else:
		_update_display()

# Update display elements
func _update_display():
	if not name_label or not value_label:
		return
	
	# Update name with proper formatting
	name_label.text = _format_stat_name(stat_name)
	
	# Update value with appropriate formatting
	value_label.text = _format_stat_value(current_value, stat_type)
	
	# Update modifier indicator
	_update_modifier_indicator()
	
	# Update colors based on stat state
	_update_colors()

# Format stat name for display
func _format_stat_name(name: String) -> String:
	# Convert snake_case to Title Case
	var words = name.split("_")
	var formatted_words: Array[String] = []
	
	for word in words:
		if word.length() > 0:
			formatted_words.append(word.capitalize())
	
	return " ".join(formatted_words) + ":"

# Format stat value based on type
func _format_stat_value(value: float, type: String) -> String:
	match type:
		"attribute", "progression":
			return str(int(value))  # Whole numbers
		"computed":
			if stat_name.contains("chance") or stat_name.contains("reduction"):
				return str(int(value * 100)) + "%"  # Percentages
			elif stat_name.contains("regen") or stat_name.contains("rate"):
				return str(value) + "/sec"  # Rates
			else:
				return str(int(value))  # Other computed stats as whole numbers
		"combat":
			if stat_name.contains("chance") or stat_name.contains("multiplier"):
				return str(value)  # Show decimals for multipliers
			else:
				return str(int(value))
		_:
			return str(value)

# Update modifier indicator
func _update_modifier_indicator():
	if not modifier_indicator:
		return
	
	if has_modifiers:
		modifier_indicator.text = "+"
		modifier_indicator.modulate = modified_color
		modifier_indicator.visible = true
	else:
		modifier_indicator.visible = false

# Update colors based on stat state
func _update_colors():
	if not value_label:
		return
	
	if has_modifiers:
		value_label.modulate = modified_color
		name_label.modulate = modified_color
	else:
		value_label.modulate = default_color
		name_label.modulate = default_color

# Animate value changes
func _animate_value_change(old_value: float, new_value: float):
	# Safety check
	if not is_inside_tree() or not value_label:
		_update_display()
		last_displayed_value = new_value
		return
	
	# Kill existing tween
	if value_tween:
		value_tween.kill()
	
	# Color flash to indicate change
	var flash_color = increased_color if new_value > old_value else decreased_color
	
	# Create flash animation
	value_tween = create_tween()
	if not value_tween:
		# Fallback if tween creation fails
		_update_display()
		last_displayed_value = new_value
		return
	
	value_tween.set_parallel(true)
	
	# Flash color with safety checks
	if value_label and is_instance_valid(value_label):
		value_tween.tween_property(value_label, "modulate", flash_color, 0.1)
		var tween2 = value_tween.tween_property(value_label, "modulate", _get_current_color(), 0.3)
		if tween2 and is_instance_valid(tween2):
			tween2.set_delay(0.1)
	
	# Update display after flash
	var tween3 = value_tween.tween_callback(_update_display)
	if tween3 and is_instance_valid(tween3):
		tween3.set_delay(0.15)
	
	last_displayed_value = new_value

# Get current color based on state
func _get_current_color() -> Color:
	return modified_color if has_modifiers else default_color

# Tooltip functionality
func _on_mouse_entered():
	_show_tooltip()

func _on_mouse_exited():
	_hide_tooltip()

func _on_gui_input(event: InputEvent):
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			stat_clicked.emit(stat_name)

# Show detailed tooltip
func _show_tooltip():
	var tooltip_text = _create_tooltip_text()
	tooltip_text = tooltip_text  # Set as tooltip
	
	# Create temporary tooltip (Godot 4.4.1 approach)
	var tooltip = _create_custom_tooltip(tooltip_text)
	get_viewport().add_child(tooltip)

# Hide tooltip
func _hide_tooltip():
	# Remove any existing custom tooltips
	var tooltips = get_viewport().get_children().filter(func(child): return child.has_meta("custom_tooltip"))
	for tooltip in tooltips:
		tooltip.queue_free()

# Create tooltip text
func _create_tooltip_text() -> String:
	var text = ""
	text += stat_name.capitalize() + "\n"
	text += stat_description + "\n\n"
	
	if stat_type == "computed":
		text += "Type: Computed (auto-calculated)\n"
	else:
		text += "Type: " + stat_type.capitalize() + "\n"
	
	text += "Current Value: " + _format_stat_value(current_value, stat_type) + "\n"
	
	if has_modifiers and base_value != current_value:
		text += "Base Value: " + _format_stat_value(base_value, stat_type) + "\n"
		text += "Modifier: +" + str(current_value - base_value) + "\n"
	
	return text

# Create custom tooltip for better control
func _create_custom_tooltip(text: String) -> Control:
	var tooltip = PanelContainer.new()
	tooltip.set_meta("custom_tooltip", true)
	
	# Styling
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.1, 0.1, 0.9)
	style.border_color = Color(0.4, 0.4, 0.4, 1.0)
	style.set_border_width_all(2)
	style.set_corner_radius_all(4)
	tooltip.add_theme_stylebox_override("panel", style)
	
	# Label
	var label = Label.new()
	label.text = text
	label.add_theme_color_override("font_color", Color.WHITE)
	tooltip.add_child(label)
	
	# Position near mouse
	var mouse_pos = get_global_mouse_position()
	tooltip.global_position = mouse_pos + Vector2(10, -50)
	
	return tooltip

# Utility functions for external access
func get_stat_name() -> String:
	return stat_name

func get_current_value() -> float:
	return current_value

func get_stat_type() -> String:
	return stat_type

func is_modified() -> bool:
	return has_modifiers

# Debug information
func get_debug_info() -> String:
	return """
StatDisplayPanel Debug:
- Name: %s
- Type: %s  
- Value: %s
- Base: %s
- Modified: %s
- Description: %s
""" % [stat_name, stat_type, current_value, base_value, has_modifiers, stat_description]
