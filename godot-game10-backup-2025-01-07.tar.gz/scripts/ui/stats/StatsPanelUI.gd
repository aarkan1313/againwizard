# StatsPanelUI.gd
# Purpose: Comprehensive visual stat display system for all player stats
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: StatDisplayPanel, PlayerStatSheet, StatSheet
# API References: Official Godot Control and scene management documentation

extends Control
class_name StatsPanelUI

# Core references
var player_stat_sheet: PlayerStatSheet
var stat_panels: Dictionary = {}  # stat_name -> StatDisplayPanel

# UI section containers
@onready var progression_container: VBoxContainer = $MainPanel/ScrollContainer/VBoxContainer/ProgressionSection/ProgressionContainer
@onready var attributes_container: VBoxContainer = $MainPanel/ScrollContainer/VBoxContainer/AttributesSection/AttributesContainer
@onready var computed_container: VBoxContainer = $MainPanel/ScrollContainer/VBoxContainer/ComputedSection/ComputedContainer
@onready var combat_container: VBoxContainer = $MainPanel/ScrollContainer/VBoxContainer/CombatSection/CombatContainer

# Section headers (for expand/collapse)
@onready var progression_header: Button = $MainPanel/ScrollContainer/VBoxContainer/ProgressionSection/ProgressionHeader
@onready var attributes_header: Button = $MainPanel/ScrollContainer/VBoxContainer/AttributesSection/AttributesHeader
@onready var computed_header: Button = $MainPanel/ScrollContainer/VBoxContainer/ComputedSection/ComputedHeader
@onready var combat_header: Button = $MainPanel/ScrollContainer/VBoxContainer/CombatSection/CombatHeader

# Special progression UI elements
@onready var level_display: Control = $MainPanel/ScrollContainer/VBoxContainer/ProgressionSection/ProgressionContainer/LevelDisplay
@onready var xp_label: Label = $MainPanel/ScrollContainer/VBoxContainer/ProgressionSection/ProgressionContainer/XPProgress/XPLabel
@onready var xp_bar: ProgressBar = $MainPanel/ScrollContainer/VBoxContainer/ProgressionSection/ProgressionContainer/XPProgress/XPBar
@onready var stat_points_label: Label = $MainPanel/ScrollContainer/VBoxContainer/ProgressionSection/ProgressionContainer/StatPointsLabel

# Control buttons
@onready var refresh_button: Button = $MainPanel/RefreshButton
@onready var toggle_button: Button = $MainPanel/ToggleButton

# Section visibility state
var sections_visible: Dictionary = {
	"progression": true,
	"attributes": true,
	"computed": true,
	"combat": true
}

# Update tracking
var last_update_time: float = 0.0
var update_interval: float = 0.5  # Update every 0.5 seconds
var is_visible_to_user: bool = true

# Stat definitions with categories
var stat_definitions: Dictionary = {
	# Base Attributes
	"intelligence": {"type": "attribute", "desc": "Increases spell damage, mana, and critical chance"},
	"wisdom": {"type": "attribute", "desc": "Increases mana regeneration and reduces cooldowns"},
	"vitality": {"type": "attribute", "desc": "Increases health and health regeneration"},
	"dexterity": {"type": "attribute", "desc": "Increases movement speed and casting speed"},
	
	# Computed Stats
	"max_health": {"type": "computed", "desc": "Maximum health points"},
	"health_regen_rate": {"type": "computed", "desc": "Health regeneration per second"},
	"max_mana": {"type": "computed", "desc": "Maximum mana points"},
	"mana_regen_rate": {"type": "computed", "desc": "Mana regeneration per second"},
	"spell_damage_multiplier": {"type": "computed", "desc": "Spell damage multiplier"},
	"critical_chance": {"type": "computed", "desc": "Critical hit chance"},
	"cooldown_reduction": {"type": "computed", "desc": "Spell cooldown reduction"},
	"movement_speed": {"type": "computed", "desc": "Character movement speed"},
	"cast_speed_multiplier": {"type": "computed", "desc": "Spell casting speed multiplier"},
	
	# Combat Stats
	"spell_projectile_speed": {"type": "combat", "desc": "Base projectile speed"},
	"spell_range_multiplier": {"type": "combat", "desc": "Spell range multiplier"},
	"free_cast_chance": {"type": "combat", "desc": "Chance to not consume mana"},
	"spell_penetration": {"type": "combat", "desc": "Spell damage penetration"},
	"dodge_chance": {"type": "combat", "desc": "Chance to avoid damage"},
	"experience_multiplier": {"type": "combat", "desc": "XP gain multiplier"},
	"item_find_bonus": {"type": "combat", "desc": "Item drop rate bonus"}
}

func _ready():
	print("📊 StatsPanelUI initializing...")
	
	# Setup UI connections
	_setup_ui_connections()
	
	# Find and connect to player stat sheet
	_connect_to_player_stats()
	
	# Create stat display panels
	_create_stat_panels()
	
	# Initial update
	_update_all_displays()
	
	print("✅ StatsPanelUI initialization complete")

func _setup_ui_connections():
	# Connect section headers for expand/collapse
	progression_header.pressed.connect(_toggle_section.bind("progression"))
	attributes_header.pressed.connect(_toggle_section.bind("attributes"))
	computed_header.pressed.connect(_toggle_section.bind("computed"))
	combat_header.pressed.connect(_toggle_section.bind("combat"))
	
	# Connect control buttons
	refresh_button.pressed.connect(_force_refresh)
	toggle_button.pressed.connect(_toggle_visibility)
	
	print("🔗 StatsPanelUI UI connections established")

func _connect_to_player_stats():
	# Find player entity
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		push_error("StatsPanelUI: Player not found!")
		return
	
	# Get player stat sheet
	if player.has_method("get_stat_sheet"):
		player_stat_sheet = player.get_stat_sheet()
	else:
		push_error("StatsPanelUI: Player does not have stat sheet!")
		return
	
	if not player_stat_sheet:
		push_error("StatsPanelUI: Player stat sheet is null!")
		return
	
	# Connect to stat changes
	player_stat_sheet.stat_value_changed.connect(_on_stat_value_changed)
	player_stat_sheet.level_up.connect(_on_level_up)
	player_stat_sheet.attribute_increased.connect(_on_attribute_increased)
	player_stat_sheet.milestone_reached.connect(_on_milestone_reached)
	
	print("🔗 Connected to PlayerStatSheet with ", player_stat_sheet.get_all_stat_names().size(), " stats")

func _create_stat_panels():
	if not player_stat_sheet:
		return
	
	# Create panels for each stat category
	_create_attribute_panels()
	_create_computed_panels()
	_create_combat_panels()
	
	print("🎨 Created ", stat_panels.size(), " stat display panels")

func _create_attribute_panels():
	var attributes = ["intelligence", "wisdom", "vitality", "dexterity"]
	
	for attr_name in attributes:
		if player_stat_sheet.has_stat(attr_name):
			var panel = _create_stat_panel(attr_name, "attribute")
			if panel:
				attributes_container.add_child(panel)
				panel.stat_clicked.connect(_on_stat_clicked)

func _create_computed_panels():
	var computed_stats = [
		"max_health", "health_regen_rate", "max_mana", "mana_regen_rate",
		"spell_damage_multiplier", "critical_chance", "cooldown_reduction",
		"movement_speed", "cast_speed_multiplier"
	]
	
	for stat_name in computed_stats:
		if player_stat_sheet.has_stat(stat_name):
			var panel = _create_stat_panel(stat_name, "computed")
			if panel:
				computed_container.add_child(panel)
				panel.stat_clicked.connect(_on_stat_clicked)

func _create_combat_panels():
	var combat_stats = [
		"spell_projectile_speed", "spell_range_multiplier", "free_cast_chance",
		"spell_penetration", "dodge_chance", "experience_multiplier", "item_find_bonus"
	]
	
	for stat_name in combat_stats:
		if player_stat_sheet.has_stat(stat_name):
			var panel = _create_stat_panel(stat_name, "combat")
			if panel:
				combat_container.add_child(panel)
				panel.stat_clicked.connect(_on_stat_clicked)

func _create_stat_panel(stat_name: String, type: String) -> StatDisplayPanel:
	# Load StatDisplayPanel scene or create programmatically
	var panel = _create_stat_display_panel()
	
	if not panel:
		push_error("Failed to create StatDisplayPanel for: " + stat_name)
		return null
	
	# Get stat info
	var description = stat_definitions.get(stat_name, {}).get("desc", "No description")
	var current_value = player_stat_sheet.get_stat_value(stat_name)
	var base_value = current_value  # For reactive stats, this would be different
	
	# Setup the panel
	panel.setup_stat(stat_name, description, type, current_value, base_value)
	
	# Store reference
	stat_panels[stat_name] = panel
	
	return panel

func _create_stat_display_panel() -> StatDisplayPanel:
	# Create programmatically since we're building a flexible system
	var panel = StatDisplayPanel.new()
	panel.custom_minimum_size = Vector2(0, 30)
	
	# Create the UI structure
	var hbox = HBoxContainer.new()
	panel.add_child(hbox)
	hbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	
	var name_label = Label.new()
	name_label.name = "NameLabel"
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hbox.add_child(name_label)
	
	var value_label = Label.new()
	value_label.name = "ValueLabel"
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hbox.add_child(value_label)
	
	var modifier_indicator = Label.new()
	modifier_indicator.name = "ModifierIndicator"
	modifier_indicator.custom_minimum_size = Vector2(20, 0)
	modifier_indicator.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	modifier_indicator.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	modifier_indicator.visible = false
	hbox.add_child(modifier_indicator)
	
	return panel

func _update_all_displays():
	if not player_stat_sheet:
		return
	
	# Update progression display
	_update_progression_display()
	
	# Update all stat panels
	for stat_name in stat_panels.keys():
		_update_stat_panel(stat_name)

func _update_progression_display():
	var progression_info = player_stat_sheet.get_progression_info()
	
	# Update XP display
	xp_label.text = "Experience: " + str(int(progression_info.total_xp)) + " / " + str(int(progression_info.xp_to_next))
	xp_bar.max_value = progression_info.xp_to_next
	xp_bar.value = progression_info.total_xp
	
	# Update stat points
	stat_points_label.text = "Available Stat Points: " + str(progression_info.available_points)
	
	# Update level display (if we have a level panel)
	if stat_panels.has("level"):
		var level_value = progression_info.level
		stat_panels["level"].update_value(level_value, level_value, 0)

func _update_stat_panel(stat_name: String):
	if not stat_panels.has(stat_name):
		return
	
	var panel = stat_panels[stat_name]
	var current_value = player_stat_sheet.get_stat_value(stat_name)
	
	# Get base value and modifier info
	var base_value = current_value
	var modifier_count = 0
	
	var stat = player_stat_sheet.get_stat(stat_name)
	if stat:
		base_value = stat.get_base_value()
		modifier_count = stat.get_modifier_count()
	
	# Update the panel
	panel.update_value(current_value, base_value, modifier_count)

func _toggle_section(section_name: String):
	var is_visible = sections_visible[section_name]
	sections_visible[section_name] = not is_visible
	
	# Get container and header
	var container: VBoxContainer
	var header: Button
	
	match section_name:
		"progression":
			container = progression_container
			header = progression_header
		"attributes":
			container = attributes_container
			header = attributes_header
		"computed":
			container = computed_container
			header = computed_header
		"combat":
			container = combat_container
			header = combat_header
	
	if container and header:
		container.visible = not is_visible
		header.text = ("▼ " if not is_visible else "▶ ") + header.text.substr(2)
	
	print("📊 Toggled section: ", section_name, " -> ", not is_visible)

func _toggle_visibility():
	is_visible_to_user = not is_visible_to_user
	visible = is_visible_to_user
	toggle_button.text = "Show" if not is_visible_to_user else "Hide"
	
	print("👁️ StatsPanelUI visibility: ", is_visible_to_user)

func _force_refresh():
	print("🔄 Force refreshing StatsPanelUI...")
	_connect_to_player_stats()
	_update_all_displays()

# Signal handlers
func _on_stat_value_changed(stat_name: String, old_value: float, new_value: float):
	# Only update if the change is significant
	if abs(new_value - old_value) > 0.01:
		_update_stat_panel(stat_name)

func _on_level_up(new_level: int, stat_points_gained: int):
	print("🎉 Level up detected: Level ", new_level, " (+", stat_points_gained, " points)")
	_update_progression_display()

func _on_attribute_increased(attribute_name: String, new_value: float):
	print("📈 Attribute increased: ", attribute_name, " -> ", new_value)
	_update_stat_panel(attribute_name)
	_update_progression_display()  # Update available points

func _on_milestone_reached(milestone_name: String, bonus_description: String):
	print("🏆 Milestone reached: ", milestone_name, " - ", bonus_description)
	# Could show a temporary notification here

func _on_stat_clicked(stat_name: String):
	print("🖱️ Stat clicked: ", stat_name)
	# Could open detailed stat window or allow stat point allocation

# Process for regular updates - DISABLED to prevent recursion
# func _process(delta):
# 	last_update_time += delta
# 	if last_update_time >= update_interval:
# 		if is_visible_to_user and player_stat_sheet:
# 			_update_all_displays()
# 		last_update_time = 0.0

# Utility functions
func get_stat_panel(stat_name: String) -> StatDisplayPanel:
	return stat_panels.get(stat_name)

func show_stats_panel():
	is_visible_to_user = true
	visible = true
	toggle_button.text = "Hide"

func hide_stats_panel():
	is_visible_to_user = false
	visible = false
	toggle_button.text = "Show"

func is_stats_panel_visible() -> bool:
	return is_visible_to_user

# Debug functions
func get_debug_info() -> String:
	return """
StatsPanelUI Debug Info:
- Connected to stat sheet: %s
- Stat panels created: %d
- Sections visible: %s
- Panel visible: %s
- Last update: %.2f seconds ago
""" % [
	str(player_stat_sheet != null),
	stat_panels.size(),
	str(sections_visible),
	str(is_visible_to_user),
	last_update_time
]
