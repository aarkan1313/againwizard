extends Control
# PlayerUI.gd - FIXED VERSION WITH PROPER STAT UPDATES
# Purpose: Displays and updates health/mana bars with proper stat integration
# FIXES:
# - Eliminate recursion by deferring updates
# - Always get fresh max values from stat sheet
# - Display health/mana regen rates
# - Force refresh method for stat allocation

# UI Element References
@onready var health_label: Label = $StatsPanel/VBoxContainer/HealthContainer/HealthLabel
@onready var health_bar: ProgressBar = $StatsPanel/VBoxContainer/HealthContainer/HealthBar
@onready var mana_label: Label = $StatsPanel/VBoxContainer/ManaContainer/ManaLabel
@onready var mana_bar: ProgressBar = $StatsPanel/VBoxContainer/ManaContainer/ManaBar
@onready var regen_status: Label = $StatsPanel/VBoxContainer/RegenStatus
@onready var level_label: Label = $StatsPanel/VBoxContainer/LevelLabel
@onready var xp_label: Label = $StatsPanel/VBoxContainer/XPLabel
@onready var xp_bar: ProgressBar = $StatsPanel/VBoxContainer/XPBar

# Tracking variables for current values only (max values fetched live)
var current_health: float = 100.0
var current_mana: float = 50.0
var current_level: int = 1
var current_xp: float = 0.0
var xp_to_next_level: float = 100.0

# Player references for direct stat access
var player_reference: Node = null
var player_stat_sheet: PlayerStatSheet = null
var health_component = null

# Animation settings for smooth bar transitions
var health_tween: Tween
var mana_tween: Tween
var xp_tween: Tween
var animation_duration: float = 0.15

# Health bar styling
var health_normal_color: Color = Color.GREEN
var health_warning_color: Color = Color.YELLOW
var health_critical_color: Color = Color.RED
var mana_color: Color = Color.CYAN
var xp_color: Color = Color.ORANGE

# Update control
var _update_scheduled: bool = false
var _force_update_scheduled: bool = false

func _ready() -> void:
	print("✅ PlayerUI initializing...")
	
	# Add to player_ui group for easy finding
	add_to_group("player_ui")
	
	# Validate UI elements exist
	if not _validate_ui_elements():
		push_error("PlayerUI: Critical UI elements missing!")
		return
	
	# Setup initial UI state
	_setup_ui_styling()
	_setup_tweens()
	
	# Connect to GameEvents for current value updates only
	if GameEvents:
		GameEvents.player_health_changed.connect(_on_player_health_changed)
		GameEvents.player_mana_changed.connect(_on_player_mana_changed)
		print("🔗 PlayerUI connected to GameEvents")
	else:
		push_error("PlayerUI: GameEvents not available!")
		return
	
	# Find player and setup direct stat access
	_initialize_from_player()
	
	print("✅ PlayerUI setup complete with live stat integration")

func _validate_ui_elements() -> bool:
	var elements = [health_label, health_bar, mana_label, mana_bar, regen_status, level_label, xp_label, xp_bar]
	for element in elements:
		if not element:
			push_error("PlayerUI: Missing UI element")
			return false
	return true

func _setup_ui_styling() -> void:
	# Configure health bar colors
	var health_style = StyleBoxFlat.new()
	health_style.bg_color = health_normal_color
	health_bar.add_theme_stylebox_override("fill", health_style)
	
	# Configure mana bar colors  
	var mana_style = StyleBoxFlat.new()
	mana_style.bg_color = mana_color
	mana_bar.add_theme_stylebox_override("fill", mana_style)
	
	# Configure XP bar colors
	var xp_style = StyleBoxFlat.new()
	xp_style.bg_color = xp_color
	xp_bar.add_theme_stylebox_override("fill", xp_style)

func _setup_tweens() -> void:
	# Create tweens for smooth bar animations
	health_tween = create_tween()
	health_tween.set_loops(0)
	health_tween.kill()
	
	mana_tween = create_tween()
	mana_tween.set_loops(0)
	mana_tween.kill()
	
	xp_tween = create_tween()
	xp_tween.set_loops(0)
	xp_tween.kill()

func _initialize_from_player() -> void:
	# Find player and get direct stat sheet access
	player_reference = get_tree().get_first_node_in_group("players")
	if not player_reference:
		print("⚠️ PlayerUI: Player not found, using default values")
		_update_display_immediate()
		return
	
	# Get player stat sheet for direct max value access
	if player_reference.has_method("get_stat_sheet"):
		player_stat_sheet = player_reference.get_stat_sheet()
		if player_stat_sheet:
			# Connect to stat changes for immediate max value updates
			if player_stat_sheet.has_signal("stat_value_changed") and not player_stat_sheet.stat_value_changed.is_connected(_on_stat_changed):
				player_stat_sheet.stat_value_changed.connect(_on_stat_changed)
			if player_stat_sheet.has_signal("level_up") and not player_stat_sheet.level_up.is_connected(_on_level_up):
				player_stat_sheet.level_up.connect(_on_level_up)
			if player_stat_sheet.has_signal("xp_gained") and not player_stat_sheet.xp_gained.is_connected(_on_xp_gained):
				player_stat_sheet.xp_gained.connect(_on_xp_gained)
			print("🔗 PlayerUI connected to stat sheet")
		else:
			print("⚠️ PlayerUI: Player stat sheet not available")
	
	# Get initial current values from HealthComponent
	health_component = player_reference.get_node_or_null("HealthComponent")
	if health_component:
		current_health = health_component.current_health
		current_mana = health_component.current_mana
	
	# Get initial level/xp if available
	if player_stat_sheet:
		current_level = int(player_stat_sheet.get_stat_value("level"))
		current_xp = player_stat_sheet.current_xp if "current_xp" in player_stat_sheet else 0.0
		xp_to_next_level = player_stat_sheet.xp_to_next_level if "xp_to_next_level" in player_stat_sheet else 100.0
	
	# Update display
	_update_display_immediate()
	
	var max_health = _get_live_max_health()
	var max_mana = _get_live_max_mana()
	print("📊 PlayerUI synchronized: Health ", current_health, "/", max_health, " Mana ", current_mana, "/", max_mana)

# Get fresh max health from stat sheet
func _get_live_max_health() -> float:
	if player_stat_sheet:
		return player_stat_sheet.get_stat_value("max_health")
	elif health_component:
		return health_component.max_health
	return 100.0

# Get fresh max mana from stat sheet
func _get_live_max_mana() -> float:
	if player_stat_sheet:
		return player_stat_sheet.get_stat_value("max_mana")
	elif health_component:
		return health_component.max_mana
	return 50.0

# Get regen rates from stat sheet
func _get_health_regen_rate() -> float:
	if player_stat_sheet:
		return player_stat_sheet.get_stat_value("health_regen_rate")
	return 2.0

func _get_mana_regen_rate() -> float:
	if player_stat_sheet:
		return player_stat_sheet.get_stat_value("mana_regen_rate")
	return 3.0

# Handle health changes
func _on_player_health_changed(new_current: float, _signal_maximum: float) -> void:
	# Only log significant changes (5+ damage/healing)
	if abs(new_current - current_health) >= 5.0:
		var max_health = _get_live_max_health()
		print("❤️ Health: ", new_current, "/", max_health, " (was ", current_health, "/", max_health, ")")
	
	# Validate current value
	if new_current < 0:
		push_error("PlayerUI: Invalid current health: " + str(new_current))
		return
	
	# Update current health
	current_health = new_current
	
	# Schedule update
	_schedule_update()

# Handle mana changes
func _on_player_mana_changed(new_current: float, signal_maximum: float) -> void:
	# Only log significant changes (5+ mana)
	if abs(new_current - current_mana) >= 5.0:
		var max_mana = _get_live_max_mana()
		print("💙 Mana: ", new_current, "/", max_mana, " (was ", current_mana, "/", max_mana, ")")
	
	# Validate current value
	if new_current < 0:
		push_error("PlayerUI: Invalid current mana: " + str(new_current))
		return
	
	# Update current mana
	current_mana = new_current
	
	# Schedule update
	_schedule_update()

# Handle stat changes - schedule deferred update to avoid recursion
func _on_stat_changed(stat_name: String, old_value: float, new_value: float) -> void:
	# Only log important stat changes
	if stat_name in ["vitality", "level", "intelligence", "wisdom", "max_health", "max_mana"]:
		if stat_name in ["max_health", "max_mana"]:
			print("📊 ", stat_name, " updated: ", old_value, " → ", new_value)
		
		# Schedule deferred update
		_schedule_update()

func _on_level_up(new_level: int, stat_points_gained: int) -> void:
	print("🎉 Level Up! Level ", new_level, " (+", stat_points_gained, " points)")
	current_level = new_level
	
	# Update XP tracking
	if player_stat_sheet:
		current_xp = player_stat_sheet.current_xp if "current_xp" in player_stat_sheet else 0.0
		xp_to_next_level = player_stat_sheet.xp_to_next_level if "xp_to_next_level" in player_stat_sheet else 100.0
	
	# Schedule update
	_schedule_update()

func _on_xp_gained(new_current_xp: float, _new_total_xp: float, new_xp_to_next: float, new_level: int) -> void:
	# Update XP values from signal
	current_xp = new_current_xp
	xp_to_next_level = new_xp_to_next
	current_level = new_level
	
	# Update XP display with animation
	_update_xp_bar_animated()
	_update_labels()
	
	print("📊 XP UI updated: ", int(current_xp), "/", int(xp_to_next_level), " (Level ", current_level, ")")

# Schedule deferred update to avoid recursion
func _schedule_update():
	if not _update_scheduled:
		_update_scheduled = true
		call_deferred("_perform_update")

func _perform_update():
	_update_scheduled = false
	_update_display_animated()

# Force immediate refresh (called after stat allocation)
func force_refresh():
	print("🔄 PlayerUI force refresh triggered")
	
	# Update current values from health component
	if health_component:
		current_health = health_component.current_health
		current_mana = health_component.current_mana
		
		# Force health component to use new max values
		health_component.on_stats_changed()
	
	# Update immediately
	_update_display_immediate()
	print("🔄 PlayerUI refreshed after stat allocation")

# Update display immediately (no animation)
func _update_display_immediate() -> void:
	_update_health_bar_immediate()
	_update_mana_bar_immediate()
	_update_xp_bar_immediate()
	_update_labels()

# Update display with animation
func _update_display_animated() -> void:
	_update_health_bar_animated()
	_update_mana_bar_animated()
	_update_xp_bar_animated()
	_update_labels()

# Update health bar immediately
func _update_health_bar_immediate() -> void:
	var max_health = _get_live_max_health()
	health_bar.max_value = max_health
	health_bar.value = current_health
	
	# Update color based on percentage
	var health_percent = current_health / max_health if max_health > 0 else 0.0
	_update_health_bar_color(health_percent)

# Update health bar with animation
func _update_health_bar_animated() -> void:
	var max_health = _get_live_max_health()
	health_bar.max_value = max_health
	
	# Animate value change
	if health_tween:
		health_tween.kill()
	health_tween = create_tween()
	health_tween.tween_property(health_bar, "value", current_health, animation_duration)
	health_tween.tween_callback(_update_health_color_animated)

func _update_health_color_animated() -> void:
	var max_health = _get_live_max_health()
	var health_percent = current_health / max_health if max_health > 0 else 0.0
	_update_health_bar_color(health_percent)

# Update mana bar immediately
func _update_mana_bar_immediate() -> void:
	var max_mana = _get_live_max_mana()
	mana_bar.max_value = max_mana
	mana_bar.value = current_mana

# Update mana bar with animation
func _update_mana_bar_animated() -> void:
	var max_mana = _get_live_max_mana()
	mana_bar.max_value = max_mana
	
	# Animate value change
	if mana_tween:
		mana_tween.kill()
	mana_tween = create_tween()
	mana_tween.tween_property(mana_bar, "value", current_mana, animation_duration)

# Update XP bar immediately
func _update_xp_bar_immediate() -> void:
	xp_bar.max_value = xp_to_next_level
	xp_bar.value = current_xp

# Update XP bar with animation
func _update_xp_bar_animated() -> void:
	xp_bar.max_value = xp_to_next_level
	
	# Animate value change
	if xp_tween:
		xp_tween.kill()
	xp_tween = create_tween()
	xp_tween.tween_property(xp_bar, "value", current_xp, animation_duration * 2)  # Slower for XP

# Update all text labels
func _update_labels() -> void:
	# Get fresh values
	var max_health = _get_live_max_health()
	var max_mana = _get_live_max_mana()
	var health_regen = _get_health_regen_rate()
	var mana_regen = _get_mana_regen_rate()
	
	# Update health/mana labels
	health_label.text = "%d / %d" % [int(current_health), int(max_health)]
	mana_label.text = "%d / %d" % [int(current_mana), int(max_mana)]
	
	# Update regen status with actual values
	regen_status.text = "HP Regen: +%.1f/s | MP Regen: +%.1f/s" % [health_regen, mana_regen]
	
	# Update level/XP labels
	level_label.text = "Level %d" % current_level
	xp_label.text = "XP: %d / %d" % [int(current_xp), int(xp_to_next_level)]

# Update health bar color based on percentage
func _update_health_bar_color(health_percent: float) -> void:
	var health_style = health_bar.get_theme_stylebox("fill") as StyleBoxFlat
	if not health_style:
		health_style = StyleBoxFlat.new()
		health_bar.add_theme_stylebox_override("fill", health_style)
	
	if health_percent > 0.5:
		health_style.bg_color = health_normal_color
	elif health_percent > 0.25:
		health_style.bg_color = health_warning_color
	else:
		health_style.bg_color = health_critical_color
