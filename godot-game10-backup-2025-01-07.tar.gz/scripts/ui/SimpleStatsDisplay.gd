# SimpleStatsDisplay.gd - REDIRECTED VERSION
# Purpose: Redirects to new draggable character sheet system
# This version keeps nodes functional but redirects to new character sheet

extends Control

var has_shown_redirect_message: bool = false

func _ready():
	print("📊 SimpleStatsDisplay redirecting to new character sheet system")
	# Hide this control
	visible = false
	
	# Show redirect message once
	if not has_shown_redirect_message:
		has_shown_redirect_message = true
		print("ℹ️ Stats display has been upgraded! Press C to open the new character sheet")

# Redirect all functionality to CharacterSheetManager
func show_stats():
	if get_node_or_null("/root/CharacterSheetManager"):
		get_node("/root/CharacterSheetManager").open_character_sheet()
	visible = false  # Keep old UI hidden

func hide_stats():
	if get_node_or_null("/root/CharacterSheetManager"):
		get_node("/root/CharacterSheetManager").close_character_sheet()
	visible = false

func toggle_stats():
	if get_node_or_null("/root/CharacterSheetManager"):
		get_node("/root/CharacterSheetManager").toggle_character_sheet()
	visible = false

func _input(event):
	# CharacterSheetManager now handles all C key input
	pass

# Keep these methods for compatibility but make them no-ops
func _mark_update_needed(stat_name: String = "", old_value: float = 0.0, new_value: float = 0.0):
	pass

func _on_level_up(new_level: int, stat_points_gained: int):
	pass

func _update_display():
	pass
