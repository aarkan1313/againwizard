extends Control
# StatAllocationPanel.gd
# Purpose: Interactive UI system for allocating stat points to player attributes
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: PlayerStatSheet, GameEvents
# API References: Official Godot Control and UI documentation

# === SIGNAL DEFINITIONS ===
signal allocation_completed(allocations: Dictionary)
signal allocation_cancelled()

# === UI ELEMENT REFERENCES ===
# Status display elements
@onready var level_label: Label = $MainPanel/VBoxContainer/StatusContainer/LevelLabel
@onready var points_label: Label = $MainPanel/VBoxContainer/StatusContainer/PointsLabel
@onready var pending_label: Label = $MainPanel/VBoxContainer/StatusContainer/PendingLabel

# Attribute row elements - Intelligence
@onready var intelligence_current_label: Label = $MainPanel/VBoxContainer/AttributesContainer/IntelligenceRow/IntelligenceCurrentLabel
@onready var intelligence_plus_button: Button = $MainPanel/VBoxContainer/AttributesContainer/IntelligenceRow/IntelligencePlusButton
@onready var intelligence_preview_label: Label = $MainPanel/VBoxContainer/AttributesContainer/IntelligenceRow/IntelligencePreviewLabel

# Attribute row elements - Wisdom
@onready var wisdom_current_label: Label = $MainPanel/VBoxContainer/AttributesContainer/WisdomRow/WisdomCurrentLabel
@onready var wisdom_plus_button: Button = $MainPanel/VBoxContainer/AttributesContainer/WisdomRow/WisdomPlusButton
@onready var wisdom_preview_label: Label = $MainPanel/VBoxContainer/AttributesContainer/WisdomRow/WisdomPreviewLabel

# Attribute row elements - Vitality
@onready var vitality_current_label: Label = $MainPanel/VBoxContainer/AttributesContainer/VitalityRow/VitalityCurrentLabel
@onready var vitality_plus_button: Button = $MainPanel/VBoxContainer/AttributesContainer/VitalityRow/VitalityPlusButton
@onready var vitality_preview_label: Label = $MainPanel/VBoxContainer/AttributesContainer/VitalityRow/VitalityPreviewLabel

# Attribute row elements - Dexterity
@onready var dexterity_current_label: Label = $MainPanel/VBoxContainer/AttributesContainer/DexterityRow/DexterityCurrentLabel
@onready var dexterity_plus_button: Button = $MainPanel/VBoxContainer/AttributesContainer/DexterityRow/DexterityPlusButton
@onready var dexterity_preview_label: Label = $MainPanel/VBoxContainer/AttributesContainer/DexterityRow/DexterityPreviewLabel

# Preview and control elements
@onready var preview_label: RichTextLabel = $MainPanel/VBoxContainer/PreviewContainer/PreviewScrollContainer/PreviewLabel
@onready var reset_button: Button = $MainPanel/VBoxContainer/ButtonContainer/ResetButton
@onready var confirm_button: Button = $MainPanel/VBoxContainer/ButtonContainer/ConfirmButton
@onready var close_button: Button = $MainPanel/VBoxContainer/TitleContainer/CloseButton

# === STATE VARIABLES ===
# Player stat sheet reference
var player_stat_sheet: PlayerStatSheet = null

# Current attribute values (from stat sheet)
var current_attributes: Dictionary = {}

# Pending allocations (changes not yet applied)
var pending_allocations: Dictionary = {
	"intelligence": 0,
	"wisdom": 0,
	"vitality": 0,
	"dexterity": 0
}

# Available stat points (from player progression)
var available_points: int = 0
var total_pending_points: int = 0

# UI element mapping for easy access
var attribute_ui_elements: Dictionary = {}

# === INITIALIZATION ===
func _ready() -> void:
	print("🎯 StatAllocationPanel initializing...")
	
	# Validate UI elements exist
	if not _validate_ui_elements():
		push_error("StatAllocationPanel: Critical UI elements missing!")
		return
	
	# Setup UI element mapping
	_setup_ui_mapping()
	
	# Initially hide the panel
	hide()
	
	# Connect input handling for ESC key
	set_process_unhandled_input(true)
	
	print("✅ StatAllocationPanel setup complete")

func _validate_ui_elements() -> bool:
	var required_elements = [
		level_label, points_label, pending_label,
		intelligence_current_label, intelligence_plus_button, intelligence_preview_label,
		wisdom_current_label, wisdom_plus_button, wisdom_preview_label,
		vitality_current_label, vitality_plus_button, vitality_preview_label,
		dexterity_current_label, dexterity_plus_button, dexterity_preview_label,
		preview_label, reset_button, confirm_button, close_button
	]
	
	for element in required_elements:
		if not element:
			push_error("StatAllocationPanel: Missing UI element")
			return false
	
	return true

func _setup_ui_mapping() -> void:
	# Create mapping for easy attribute UI access
	attribute_ui_elements = {
		"intelligence": {
			"current_label": intelligence_current_label,
			"plus_button": intelligence_plus_button,
			"preview_label": intelligence_preview_label
		},
		"wisdom": {
			"current_label": wisdom_current_label,
			"plus_button": wisdom_plus_button,
			"preview_label": wisdom_preview_label
		},
		"vitality": {
			"current_label": vitality_current_label,
			"plus_button": vitality_plus_button,
			"preview_label": vitality_preview_label
		},
		"dexterity": {
			"current_label": dexterity_current_label,
			"plus_button": dexterity_plus_button,
			"preview_label": dexterity_preview_label
		}
	}

# === INPUT HANDLING ===
func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_ESCAPE:
				_close_panel()
				get_viewport().set_input_as_handled()
			# Removed KEY_C handling - CharacterSheetManager uses C for character sheet

# === PUBLIC INTERFACE ===

# Open the allocation panel with current player stats
func open_allocation_panel(stat_sheet: PlayerStatSheet) -> void:
	if not stat_sheet:
		push_error("StatAllocationPanel: Cannot open without valid PlayerStatSheet")
		return
	
	player_stat_sheet = stat_sheet
	
	# Load current data
	_load_current_stats()
	
	# Reset any pending allocations
	_reset_allocations()
	
	# Update UI display
	_update_all_displays()
	
	# Show the panel
	show()
	
	print("🎯 Stat allocation panel opened")
	print("📊 Available points: ", available_points)

# Close the allocation panel
func close_allocation_panel() -> void:
	_close_panel()

# === PRIVATE METHODS ===

# Load current stats from player stat sheet
func _load_current_stats() -> void:
	if not player_stat_sheet:
		return
	
	# Get current attribute values
	current_attributes = {
		"intelligence": player_stat_sheet.get_stat_value("intelligence"),
		"wisdom": player_stat_sheet.get_stat_value("wisdom"),
		"vitality": player_stat_sheet.get_stat_value("vitality"),
		"dexterity": player_stat_sheet.get_stat_value("dexterity"),
		"level": player_stat_sheet.get_stat_value("level")
	}
	
	# Get available stat points
	available_points = player_stat_sheet.available_stat_points
	
	print("📊 Loaded current stats: ", current_attributes)
	print("🎯 Available points: ", available_points)
	print("🔍 Level value: ", current_attributes.get("level", "MISSING"))

# Reset all pending allocations
func _reset_allocations() -> void:
	for attribute in pending_allocations.keys():
		pending_allocations[attribute] = 0
	
	total_pending_points = 0
	print("🔄 Allocations reset")

# Update all UI displays
func _update_all_displays() -> void:
	_update_status_display()
	_update_attribute_displays()
	_update_computed_stat_preview()
	_update_button_states()

# Update status labels (level, points, pending)
func _update_status_display() -> void:
	if not player_stat_sheet:
		return
	
	var level = int(player_stat_sheet.get_stat_value("level"))
	level_label.text = "Level: " + str(level)
	points_label.text = "Available Points: " + str(available_points - total_pending_points)
	pending_label.text = "Pending: " + str(total_pending_points)

# Update attribute row displays
func _update_attribute_displays() -> void:
	# Only iterate over allocatable attributes (not level)
	for attribute in attribute_ui_elements.keys():
		var ui_elements = attribute_ui_elements[attribute]
		var current_value = current_attributes[attribute]
		var pending_value = pending_allocations[attribute]
		
		# Update current value display
		ui_elements.current_label.text = str(int(current_value))
		
		# Update preview display
		if pending_value > 0:
			ui_elements.preview_label.text = "(+" + str(pending_value) + ")"
			ui_elements.preview_label.modulate = Color.GREEN
		else:
			ui_elements.preview_label.text = "(+0)"
			ui_elements.preview_label.modulate = Color.WHITE

# Update computed stat preview
func _update_computed_stat_preview() -> void:
	if not player_stat_sheet or total_pending_points == 0:
		preview_label.text = "Select attributes to see computed stat changes..."
		return
	
	# Calculate preview changes
	var preview_text = "[font_size=14][color=yellow]Computed Stat Changes:[/color][/font_size]\n\n"
	
	# Create temporary attribute values with pending changes
	var preview_attributes = {}
	for attribute in pending_allocations.keys():  # Only allocatable attributes
		preview_attributes[attribute] = current_attributes[attribute] + pending_allocations[attribute]
	
	# Calculate health changes
	var current_max_health = player_stat_sheet.get_stat_value("max_health")
	var current_level = current_attributes.get("level", 1.0)  # Safe access with default
	var preview_max_health = 100 + preview_attributes.vitality * 5 + current_level * 3
	var health_change = preview_max_health - current_max_health
	
	if health_change > 0:
		preview_text += "[color=green]Max Health: +" + str(int(health_change)) + " (" + str(int(current_max_health)) + " -> " + str(int(preview_max_health)) + ")[/color]\n"
	
	# Calculate mana changes
	var current_max_mana = player_stat_sheet.get_stat_value("max_mana")
	var preview_max_mana = 50 + preview_attributes.intelligence * 3 + preview_attributes.wisdom * 2 + current_level * 2
	var mana_change = preview_max_mana - current_max_mana
	
	if mana_change > 0:
		preview_text += "[color=cyan]Max Mana: +" + str(int(mana_change)) + " (" + str(int(current_max_mana)) + " -> " + str(int(preview_max_mana)) + ")[/color]\n"
	
	# Calculate health regen changes
	var current_health_regen = player_stat_sheet.get_stat_value("health_regen_rate")
	var preview_health_regen = 2.0 + preview_attributes.vitality * 0.5
	var health_regen_change = preview_health_regen - current_health_regen
	
	if health_regen_change > 0:
		preview_text += "[color=green]Health Regen: +" + str(health_regen_change) + "/sec (" + str(current_health_regen) + " -> " + str(preview_health_regen) + ")[/color]\n"
	
	# Calculate mana regen changes
	var current_mana_regen = player_stat_sheet.get_stat_value("mana_regen_rate")
	var preview_mana_regen = 3.0 + preview_attributes.wisdom * 0.8 + preview_attributes.intelligence * 0.2
	var mana_regen_change = preview_mana_regen - current_mana_regen
	
	if mana_regen_change > 0:
		preview_text += "[color=cyan]Mana Regen: +" + str(mana_regen_change) + "/sec (" + str(current_mana_regen) + " -> " + str(preview_mana_regen) + ")[/color]\n"
	
	# Calculate spell damage changes
	var current_spell_damage = player_stat_sheet.get_stat_value("spell_damage_multiplier")
	var preview_spell_damage = 1.0 + preview_attributes.intelligence * 0.02
	var spell_damage_change = preview_spell_damage - current_spell_damage
	
	if spell_damage_change > 0:
		var damage_percent_change = spell_damage_change * 100
		preview_text += "[color=orange]Spell Damage: +" + str(damage_percent_change) + "% (" + str((current_spell_damage - 1.0) * 100) + "% -> " + str((preview_spell_damage - 1.0) * 100) + "%)[/color]\n"
	
	# Calculate movement speed changes
	var current_movement_speed = player_stat_sheet.get_stat_value("movement_speed")
	var preview_movement_speed = 144 + preview_attributes.dexterity * 2
	var movement_speed_change = preview_movement_speed - current_movement_speed
	
	if movement_speed_change > 0:
		preview_text += "[color=yellow]Movement Speed: +" + str(int(movement_speed_change)) + " (" + str(int(current_movement_speed)) + " -> " + str(int(preview_movement_speed)) + ")[/color]\n"
	
	# Calculate critical chance changes
	var current_crit_chance = player_stat_sheet.get_stat_value("critical_chance")
	var preview_crit_chance = 0.05 + preview_attributes.intelligence * 0.001
	var crit_chance_change = preview_crit_chance - current_crit_chance
	
	if crit_chance_change > 0:
		var crit_percent_change = crit_chance_change * 100
		preview_text += "[color=red]Critical Chance: +" + str(crit_percent_change) + "% (" + str(current_crit_chance * 100) + "% -> " + str(preview_crit_chance * 100) + "%)[/color]\n"
	
	preview_label.text = preview_text

# Update button states based on current allocations
func _update_button_states() -> void:
	var points_remaining = available_points - total_pending_points
	
	# Update plus buttons - disable if no points remaining
	for attribute in attribute_ui_elements.keys():
		var ui_elements = attribute_ui_elements[attribute]
		ui_elements.plus_button.disabled = (points_remaining <= 0)
	
	# Update reset button - disable if no pending changes
	reset_button.disabled = (total_pending_points == 0)
	
	# Update confirm button - disable if no pending changes
	confirm_button.disabled = (total_pending_points == 0)

# Close the panel
func _close_panel(emit_cancelled: bool = true) -> void:
	hide()
	if emit_cancelled:
		allocation_cancelled.emit()
	print("🎯 Stat allocation panel closed")

# === UI EVENT HANDLERS ===

func _on_close_button_pressed() -> void:
	_close_panel()

func _on_attribute_plus_pressed(attribute_name: String) -> void:
	if not _can_allocate_point():
		return
	
	# Add point to pending allocations
	pending_allocations[attribute_name] += 1
	total_pending_points += 1
	
	# Update displays
	_update_all_displays()
	
	print("🎯 Allocated 1 point to ", attribute_name, " (Pending: ", pending_allocations[attribute_name], ")")

func _on_reset_button_pressed() -> void:
	_reset_allocations()
	_update_all_displays()
	print("🔄 All allocations reset")

func _on_confirm_button_pressed() -> void:
	if total_pending_points == 0:
		print("⚠️ No pending allocations to confirm")
		return
	
	# Apply allocations to player stat sheet
	_apply_allocations()
	
	# Close panel without emitting cancelled signal (since this is completion)
	_close_panel(false)

# === ALLOCATION LOGIC ===

# Check if a stat point can be allocated
func _can_allocate_point() -> bool:
	var points_remaining = available_points - total_pending_points
	
	if points_remaining <= 0:
		print("❌ No stat points remaining")
		return false
	
	return true

# Apply pending allocations to the player stat sheet
func _apply_allocations() -> void:
	if not player_stat_sheet:
		push_error("StatAllocationPanel: Cannot apply allocations without PlayerStatSheet")
		return
	
	var applied_allocations = {}
	var total_points_spent = 0
	
	# Apply each attribute allocation
	for attribute in pending_allocations.keys():
		var points_to_spend = pending_allocations[attribute]
		if points_to_spend > 0:
			var success = player_stat_sheet.increase_attribute(attribute, points_to_spend)
			if success:
				applied_allocations[attribute] = points_to_spend
				total_points_spent += points_to_spend
				print("✅ Applied ", points_to_spend, " points to ", attribute)
			else:
				push_error("StatAllocationPanel: Failed to apply allocation to " + attribute)
	
	# Emit completion signal
	allocation_completed.emit(applied_allocations)
	
	print("🎉 Stat allocation completed! Total points spent: ", total_points_spent)
	print("📊 Applied allocations: ", applied_allocations)

# === DEBUG AND UTILITY ===

func get_allocation_status() -> String:
	return """
StatAllocationPanel Status:
- Panel Visible: %s
- Available Points: %d
- Pending Points: %d
- Pending Allocations: %s
- Player StatSheet: %s
""" % [
	str(visible),
	available_points,
	total_pending_points,
	str(pending_allocations),
	str(player_stat_sheet != null)
]

# Manual refresh for external systems
func refresh_display() -> void:
	if visible and player_stat_sheet:
		_load_current_stats()
		_update_all_displays()
		print("🔄 StatAllocationPanel display refreshed")
