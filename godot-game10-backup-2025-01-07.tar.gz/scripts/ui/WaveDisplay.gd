extends Control
# WaveDisplay.gd - Prominent wave progress display
# Shows current wave and kill progress in the center of the screen

@onready var wave_label: Label = $Panel/VBoxContainer/WaveLabel
@onready var kill_progress_label: Label = $Panel/VBoxContainer/KillProgressLabel
@onready var progress_bar: ProgressBar = $Panel/VBoxContainer/ProgressBar

# Wave tracking
var current_wave: int = 1
var total_kills: int = 0
var kills_to_next_wave: int = 25
var kills_for_current_wave: int = 0

# Animation
var tween: Tween

func _ready():
	# Connect to WaveManager
	if WaveManager:
		if WaveManager.has_signal("wave_started"):
			WaveManager.wave_started.connect(_on_wave_started)
		if WaveManager.has_signal("wave_progress_updated"):
			WaveManager.wave_progress_updated.connect(_on_wave_progress_updated)
		print("🌊 WaveDisplay connected to WaveManager")
		
		# Get initial wave info
		refresh_from_wave_manager()
	
	# Connect to SaveManager to refresh after load
	if SaveManager:
		if SaveManager.has_signal("game_loaded"):
			SaveManager.game_loaded.connect(_on_game_loaded)
	
	# Initial update
	update_display()

func refresh_from_wave_manager():
	# Get current wave info from WaveManager
	if WaveManager:
		var wave_info = WaveManager.get_wave_info()
		current_wave = wave_info.current_wave
		total_kills = wave_info.total_kills
		kills_to_next_wave = WaveManager.get_kills_to_next_wave()
		
		# Calculate kills needed for current wave
		update_wave_progress()
		
		print("🌊 WaveDisplay refreshed: Wave ", current_wave, ", Kills: ", total_kills)

func _on_game_loaded():
	# Refresh display after save game is loaded
	print("🌊 WaveDisplay: Refreshing after game load")
	refresh_from_wave_manager()
	update_display()

func _exit_tree():
	# Clean up signal connections
	if WaveManager:
		if WaveManager.has_signal("wave_started") and WaveManager.wave_started.is_connected(_on_wave_started):
			WaveManager.wave_started.disconnect(_on_wave_started)
		if WaveManager.has_signal("wave_progress_updated") and WaveManager.wave_progress_updated.is_connected(_on_wave_progress_updated):
			WaveManager.wave_progress_updated.disconnect(_on_wave_progress_updated)
	
	# Kill tween if active
	if tween and tween.is_valid():
		tween.kill()

func _on_wave_started(wave_number: int, enemy_multipliers: Dictionary):
	current_wave = wave_number
	kills_to_next_wave = WaveManager.get_kills_to_next_wave()
	
	# Animate wave change
	animate_wave_change()
	update_display()
	
	print("🌊 Wave ", wave_number, " started!")

func _on_wave_progress_updated(current_kills: int, target_kills: int, _percentage: float):
	total_kills = current_kills
	kills_to_next_wave = WaveManager.get_kills_to_next_wave()
	update_wave_progress()
	update_display()

func update_wave_progress():
	# Calculate progress for current wave
	var thresholds = WaveManager.wave_kill_thresholds if WaveManager else [25, 50, 100, 150, 200]
	var previous_threshold = 0
	
	if current_wave > 1 and current_wave <= thresholds.size() + 1:
		previous_threshold = thresholds[current_wave - 2]
	
	kills_for_current_wave = total_kills - previous_threshold

func update_display():
	# Update wave label
	wave_label.text = "WAVE %d" % current_wave
	
	# Update kill progress
	if kills_to_next_wave > 0:
		kill_progress_label.text = "Kills: %d / %d" % [total_kills, total_kills + kills_to_next_wave]
		
		# Update progress bar
		var progress_percent = (float(kills_for_current_wave) / float(kills_to_next_wave + kills_for_current_wave)) * 100.0
		progress_bar.value = progress_percent
	else:
		# Max wave or infinite mode
		kill_progress_label.text = "Total Kills: %d" % total_kills
		progress_bar.value = 100.0

func animate_wave_change():
	# Kill existing tween
	if tween and tween.is_valid():
		tween.kill()
	
	# Create new tween for wave change animation
	tween = create_tween()
	
	# Scale up and flash
	var original_scale = scale
	tween.set_parallel(true)
	tween.tween_property(self, "scale", Vector2(1.2, 1.2), 0.2)
	tween.tween_property(self, "modulate", Color(2, 2, 2, 1), 0.2)
	
	tween.set_parallel(false)
	tween.tween_property(self, "scale", original_scale, 0.3).set_ease(Tween.EASE_OUT)
	tween.tween_property(self, "modulate", Color(1, 1, 1, 1), 0.3)
