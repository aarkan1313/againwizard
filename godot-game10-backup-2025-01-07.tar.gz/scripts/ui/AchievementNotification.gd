# AchievementNotification.gd
# Purpose: Display achievement/milestone notifications above wave UI
# Godot Version: 4.4.1 compatible

extends Control
class_name AchievementNotification

@onready var panel: Panel = $Panel
@onready var title_label: Label = $Panel/VBoxContainer/TitleLabel
@onready var description_label: Label = $Panel/VBoxContainer/DescriptionLabel

# Animation settings
var show_duration: float = 3.0
var fade_in_duration: float = 0.3
var fade_out_duration: float = 0.5
var slide_distance: float = 30.0  # Increased for more dramatic entrance
var scale_factor: float = 1.1     # Scale during animation for emphasis

# Tween for animations
var notification_tween: Tween

func _ready():
	# Start invisible and slightly offset downward
	modulate.a = 0.0
	position.y += slide_distance
	scale = Vector2(0.9, 0.9)  # Start slightly smaller
	hide()
	print("🏆 AchievementNotification ready, initial state: hidden")

func show_achievement(achievement_name: String, description: String):
	"""Display an achievement notification with animation"""
	
	print("🏆 Showing achievement: ", achievement_name, " - ", description)
	
	# Set text content
	title_label.text = "🏆 " + achievement_name
	description_label.text = description
	
	# Make visible and start animation
	show()
	visible = true  # Force visibility
	
	# Debug current state
	print("🏆 Notification visibility: ", visible)
	print("🏆 Notification position: ", global_position)
	print("🏆 Notification size: ", size)
	print("🏆 Parent: ", get_parent())
	
	# Create animation tween
	if notification_tween:
		notification_tween.kill()
	notification_tween = create_tween()
	notification_tween.set_parallel(true)
	
	# Fade in, slide up, and scale up
	notification_tween.tween_property(self, "modulate:a", 1.0, fade_in_duration)
	notification_tween.tween_property(self, "position:y", position.y - slide_distance, fade_in_duration).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	notification_tween.tween_property(self, "scale", Vector2(1.0, 1.0), fade_in_duration).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	
	# Small scale pulse for emphasis
	notification_tween.tween_interval(fade_in_duration)
	notification_tween.tween_property(self, "scale", Vector2(scale_factor, scale_factor), 0.2).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	notification_tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.2).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	
	# Wait for show duration
	notification_tween.tween_interval(show_duration)
	
	# Fade out and slide down slightly
	notification_tween.tween_property(self, "modulate:a", 0.0, fade_out_duration)
	notification_tween.tween_property(self, "position:y", position.y + slide_distance/2, fade_out_duration).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	notification_tween.tween_property(self, "scale", Vector2(0.9, 0.9), fade_out_duration).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	
	# Hide when animation completes
	notification_tween.tween_callback(_on_animation_complete)
	
	print("🏆 Achievement animation started")

func _on_animation_complete():
	"""Called when notification animation finishes"""
	print("🏆 Achievement animation complete, hiding notification")
	hide()
	# Reset position and scale for next notification
	position.y += slide_distance - slide_distance/2  # Account for the partial slide down
	scale = Vector2(0.9, 0.9)
