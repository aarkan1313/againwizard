# DamageNumber.gd
# Purpose: Readable floating damage numbers for combat feedback
# Godot Version: 4.4.1 compatible
# Performance: Optimized for readability and visibility

extends Node2D
class_name DamageNumber

@onready var damage_label: Label = get_node_or_null("DamageLabel")
@onready var animation_player: AnimationPlayer = get_node_or_null("AnimationPlayer")

# Optimized damage display configuration
var damage_amount: float = 0.0
var damage_color: Color = Color.WHITE
var float_distance: float = 40.0  # Distance to float upward
var display_duration: float = 1.4  # Extended for better readability
var fade_start_delay: float = 0.6  # Longer delay before fade starts

# Performance optimization - static reference counting
static var active_damage_numbers: int = 0
static var max_concurrent_numbers: int = 20

# Cleanup prevention
var is_cleaning_up: bool = false

func _ready():
	# Performance check - limit concurrent damage numbers
	if active_damage_numbers >= max_concurrent_numbers:
		# Queue for immediate cleanup if too many are active
		queue_free()
		return
	
	active_damage_numbers += 1
	
	# Create label if it doesn't exist in the scene
	if not damage_label:
		damage_label = Label.new()
		add_child(damage_label)
		
		# Configure the created label with optimized settings
		damage_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		damage_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		
		# Optimized font size for readability and performance
		damage_label.add_theme_font_size_override("font_size", 14)
	
	# Use optimized fallback animation
	_play_optimized_animation()

func setup(damage: float, position: Vector2, color: Color = Color.WHITE):
	damage_amount = damage
	damage_color = color
	global_position = position
	
	# Configure the label with performance optimizations
	if damage_label:
		damage_label.text = str(int(damage))
		damage_label.modulate = damage_color
		
		# Optimized shadow for better visibility with less rendering cost
		damage_label.add_theme_color_override("font_shadow_color", Color.BLACK)
		damage_label.add_theme_constant_override("shadow_offset_x", 1)
		damage_label.add_theme_constant_override("shadow_offset_y", 1)
		
		# Optimized scale system for visual impact
		var scale_factor = 1.0
		if damage >= 50:
			scale_factor = 1.2  # Reduced from 1.3
			damage_label.modulate = Color.RED
		elif damage >= 25:
			scale_factor = 1.05  # Reduced from 1.1
			damage_label.modulate = Color.ORANGE
		else:
			scale_factor = 0.95  # Slightly reduced from 0.9
			damage_label.modulate = Color.YELLOW
		
		damage_label.scale = Vector2(scale_factor, scale_factor)

func _play_optimized_animation():
	# Safety check - ensure damage_label exists
	if not damage_label:
		push_error("DamageNumber: damage_label is null, cannot animate")
		_cleanup_and_destroy()
		return
	
	# Optimized animation using single tween with parallel animations
	var tween = create_tween()
	tween.set_parallel(true)
	
	# Faster float upward movement
	tween.tween_property(self, "position", position + Vector2(0, -float_distance), display_duration).set_ease(Tween.EASE_OUT)
	
	# Readable fade timing - starts fading later for visibility
	tween.tween_property(damage_label, "modulate:a", 0.0, display_duration * 0.5).set_delay(fade_start_delay)
	
	# Faster scale animation with less dramatic scaling
	var initial_scale = damage_label.scale
	tween.tween_property(damage_label, "scale", initial_scale * 1.15, 0.15).set_ease(Tween.EASE_OUT)  # Faster and less dramatic
	tween.tween_property(damage_label, "scale", initial_scale * 0.9, display_duration - 0.15).set_delay(0.15).set_ease(Tween.EASE_IN)
	
	# Enhanced cleanup with failsafe timer
	var cleanup_delay = max(display_duration, 1.4)  # movement_duration equivalent
	tween.tween_callback(_cleanup_and_destroy).set_delay(cleanup_delay)
	
	# Failsafe timer for guaranteed cleanup
	var failsafe_timer = Timer.new()
	failsafe_timer.wait_time = cleanup_delay + 0.8
	failsafe_timer.timeout.connect(_cleanup_and_destroy)
	failsafe_timer.one_shot = true
	add_child(failsafe_timer)
	failsafe_timer.start()

func _cleanup_and_destroy():
	# Cleanup prevention - prevent duplicate cleanup
	if is_cleaning_up:
		return
	
	is_cleaning_up = true
	
	# Decrease active counter before destruction
	active_damage_numbers -= 1
	queue_free()

# Alternative setup methods optimized for different damage types
func setup_healing(heal_amount: float, position: Vector2):
	setup(heal_amount, position, Color.GREEN)
	if damage_label:
		damage_label.text = "+" + str(int(heal_amount))

func setup_critical(damage: float, position: Vector2):
	setup(damage, position, Color.RED)
	if damage_label:
		damage_label.text = str(int(damage)) + "!"
		# Critical hits get slightly more dramatic scaling
		damage_label.scale = Vector2(1.3, 1.3)
		# Longer duration for critical hits
		display_duration = 1.6

func setup_small_damage(damage: float, position: Vector2):
	# Readable display for small damage numbers
	display_duration = 1.2
	float_distance = 25.0
	setup(damage, position, Color.WHITE)

func setup_massive_damage(damage: float, position: Vector2):
	# Longer for massive damage to appreciate the number
	display_duration = 1.8
	float_distance = 60.0
	setup(damage, position, Color.RED)
	if damage_label:
		damage_label.text = str(int(damage)) + "!!"
		damage_label.scale = Vector2(1.4, 1.4)

# Performance monitoring
static func get_active_damage_numbers() -> int:
	return active_damage_numbers

static func get_max_concurrent_numbers() -> int:
	return max_concurrent_numbers

static func set_max_concurrent_numbers(new_max: int):
	max_concurrent_numbers = max(5, new_max)  # Minimum of 5
