# SaveLoadMenu.gd
# Purpose: UI controller for save/load slot selection
# Shows all save slots and allows selection, deletion, and overwriting

extends Control
class_name SaveLoadMenu

signal slot_selected(slot: int)
signal menu_closed()
signal save_completed()  # Emitted when save is successful and menu should fully close

enum MenuMode { SAVE, LOAD }

@onready var title_label: Label = $Panel/VBoxContainer/TitleLabel
@onready var slot_container: VBoxContainer = $Panel/VBoxContainer/ScrollContainer/SlotContainer
@onready var cancel_button: Button = $Panel/VBoxContainer/CancelButton
@onready var confirmation_dialog: ConfirmationDialog = $ConfirmationDialog

var mode: MenuMode = MenuMode.SAVE
var selected_slot: int = -1
var slot_buttons: Array[Button] = []

# UI Settings
const SLOT_BUTTON_HEIGHT = 80
const SLOT_BUTTON_MARGIN = 5

func _ready():
	# Set process mode to always so UI works while paused
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	cancel_button.pressed.connect(_on_cancel_pressed)
	confirmation_dialog.confirmed.connect(_on_confirmation_confirmed)
	confirmation_dialog.canceled.connect(_on_confirmation_canceled)
	
	# Create slot buttons
	_create_slot_buttons()
	
	# Start hidden
	hide()

func _create_slot_buttons():
	# Create buttons for each save slot
	for i in range(SaveManager.MAX_SAVE_SLOTS):
		var slot_button = _create_slot_button(i)
		slot_container.add_child(slot_button)
		slot_buttons.append(slot_button)

func _create_slot_button(slot: int) -> Button:
	# Create a single slot button
	var button = Button.new()
	button.custom_minimum_size = Vector2(500, SLOT_BUTTON_HEIGHT)
	button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	
	# Create horizontal container for button content
	var hbox = HBoxContainer.new()
	hbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(hbox)
	
	# Main text label
	var text_label = Label.new()
	text_label.custom_minimum_size = Vector2(400, 0)
	text_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	text_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hbox.add_child(text_label)
	
	# Delete button (only for save mode)
	var delete_button = Button.new()
	delete_button.text = "X"
	delete_button.custom_minimum_size = Vector2(40, 40)
	delete_button.hide()  # Hidden by default
	hbox.add_child(delete_button)
	
	# Connect signals
	button.pressed.connect(_on_slot_pressed.bind(slot))
	delete_button.pressed.connect(_on_delete_pressed.bind(slot))
	
	# Store references
	button.set_meta("text_label", text_label)
	button.set_meta("delete_button", delete_button)
	button.set_meta("slot_number", slot)
	
	return button

func show_save_menu():
	# Show menu in save mode
	mode = MenuMode.SAVE
	title_label.text = "Save Game - Select Slot"
	_refresh_slots()
	show()
	# Ensure game stays paused
	get_tree().paused = true

func show_load_menu():
	# Show menu in load mode
	mode = MenuMode.LOAD
	title_label.text = "Load Game - Select Slot"
	_refresh_slots()
	show()
	# Ensure game stays paused
	get_tree().paused = true

func _refresh_slots():
	# Update all slot buttons with current save info
	var save_slots = SaveManager.get_save_slots_info()
	
	for i in range(slot_buttons.size()):
		var button = slot_buttons[i]
		var slot_info = save_slots[i]
		var text_label: Label = button.get_meta("text_label")
		var delete_button: Button = button.get_meta("delete_button")
		
		# Update main text
		if slot_info.exists:
			text_label.text = "Slot %d: %s" % [i + 1, slot_info.get_display_text()]
			button.modulate = Color.WHITE
			button.disabled = false
			
			# Show delete button in save mode for existing saves
			delete_button.visible = (mode == MenuMode.SAVE)
		else:
			text_label.text = "Slot %d: Empty" % [i + 1]
			
			if mode == MenuMode.SAVE:
				button.modulate = Color.WHITE
				button.disabled = false
			else:
				# Disable empty slots in load mode
				button.modulate = Color(0.5, 0.5, 0.5)
				button.disabled = true
			
			delete_button.hide()
		
		# Add tooltip with detailed info
		button.tooltip_text = slot_info.get_detailed_text()

func _on_slot_pressed(slot: int):
	# Handle slot selection
	selected_slot = slot
	var slot_info = SaveManager.save_slots[slot]
	
	if mode == MenuMode.SAVE:
		if slot_info.exists:
			# Show overwrite confirmation
			confirmation_dialog.dialog_text = "Overwrite save in Slot %d?\n\n%s" % [slot + 1, slot_info.get_detailed_text()]
			confirmation_dialog.popup_centered()
		else:
			# Empty slot, save directly
			_perform_save()
	else:
		# Load mode
		if slot_info.exists:
			# Show load confirmation if game in progress
			if SaveManager.has_active_game():
				confirmation_dialog.dialog_text = "Load game from Slot %d?\n\nCurrent progress will be lost!" % [slot + 1]
				confirmation_dialog.popup_centered()
			else:
				_perform_load()

func _on_delete_pressed(slot: int):
	# Handle delete button press
	selected_slot = slot
	var slot_info = SaveManager.save_slots[slot]
	
	confirmation_dialog.dialog_text = "Delete save in Slot %d?\n\n%s\n\nThis cannot be undone!" % [slot + 1, slot_info.get_detailed_text()]
	confirmation_dialog.set_meta("delete_mode", true)
	confirmation_dialog.popup_centered()

func _on_confirmation_confirmed():
	# Handle confirmation dialog yes
	if confirmation_dialog.has_meta("delete_mode") and confirmation_dialog.get_meta("delete_mode"):
		# Delete mode
		_perform_delete()
		confirmation_dialog.remove_meta("delete_mode")
	elif mode == MenuMode.SAVE:
		_perform_save()
	else:
		_perform_load()

func _on_confirmation_canceled():
	# Handle confirmation dialog no
	if confirmation_dialog.has_meta("delete_mode"):
		confirmation_dialog.remove_meta("delete_mode")
	selected_slot = -1

func _perform_save():
	# Execute save to selected slot
	if selected_slot < 0:
		return
	
	var success = SaveManager.save_to_slot(selected_slot)
	
	if success:
		# Show success feedback
		_show_feedback("Game saved to Slot %d!" % [selected_slot + 1], Color.GREEN)
		# Refresh to show updated info
		_refresh_slots()
		# Close menu after short delay
		await get_tree().create_timer(1.0).timeout
		hide()
		print("💾 SaveLoadMenu: Emitting save_completed signal")
		save_completed.emit()  # Signal to close escape menu too
		menu_closed.emit()
		# Don't unpause here - let EscapeMenuController handle it
	else:
		_show_feedback("Failed to save game!", Color.RED)

func _perform_load():
	# Execute load from selected slot
	if selected_slot < 0:
		return
	
	var success = await SaveManager.load_from_slot(selected_slot)
	
	if success:
		# Close menu immediately on successful load
		hide()
		print("💾 SaveLoadMenu: Load successful, emitting signals")
		slot_selected.emit(selected_slot)
		menu_closed.emit()
		# Don't unpause here - SaveManager and EscapeMenuController will handle it
	else:
		_show_feedback("Failed to load game!", Color.RED)

func _perform_delete():
	# Execute delete on selected slot
	if selected_slot < 0:
		return
	
	var success = SaveManager.delete_save_slot(selected_slot)
	
	if success:
		_show_feedback("Save deleted from Slot %d" % [selected_slot + 1], Color.YELLOW)
		_refresh_slots()
	else:
		_show_feedback("Failed to delete save!", Color.RED)
	
	selected_slot = -1

func _show_feedback(message: String, color: Color):
	# Show temporary feedback message
	var feedback_label = Label.new()
	feedback_label.text = message
	feedback_label.add_theme_color_override("font_color", color)
	feedback_label.add_theme_font_size_override("font_size", 20)
	
	var container = $Panel/VBoxContainer
	container.add_child(feedback_label)
	container.move_child(feedback_label, 1)  # After title
	
	# Remove after delay
	await get_tree().create_timer(2.0).timeout
	feedback_label.queue_free()

func _on_cancel_pressed():
	# Handle cancel button
	hide()
	menu_closed.emit()
	# Don't unpause here - let EscapeMenuController handle it

func _unhandled_input(event):
	# Handle escape key
	if visible and event.is_action_pressed("ui_cancel"):
		_on_cancel_pressed()
		get_viewport().set_input_as_handled()
