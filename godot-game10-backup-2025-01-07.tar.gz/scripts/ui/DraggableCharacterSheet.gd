# DraggableCharacterSheet_Simple.gd
# Simplified version that works with Window nodes in Godot 4.4.1

extends Window

# UI Components
var stats_text: RichTextLabel
var available_points_label: Label

# Data reference
var player_stat_sheet = null
var update_timer: Timer

# State
var is_open: bool = false

func _init():
	# Configure window
	title = "Character Sheet"
	size = Vector2i(400, 600)
	min_size = Vector2i(350, 500)
	
	# Center window
	var screen_size = DisplayServer.screen_get_size()
	position = Vector2i(screen_size.x / 2 - 200, screen_size.y / 2 - 300)
	
	# Window settings
	unresizable = false
	borderless = false
	always_on_top = false
	
	# Process mode
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	# Hide initially
	visible = false

func _ready():
	print("📊 Simple Character Sheet initializing...")
	
	# Create simple UI
	_create_simple_interface()
	_find_player_stat_sheet()
	_create_update_timer()
	
	# Connect signals
	close_requested.connect(_on_close_requested)
	
	if player_stat_sheet:
		_connect_stat_signals()
		_update_stats_display()
	
	print("✅ Simple Character Sheet ready - Press C to open")

func _create_simple_interface():
	# Main container
	var main_vbox = VBoxContainer.new()
	main_vbox.add_theme_constant_override("separation", 10)
	main_vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(main_vbox)
	
	# Title
	var title_label = Label.new()
	title_label.text = "CHARACTER SHEET"
	title_label.add_theme_font_size_override("font_size", 24)
	title_label.add_theme_color_override("font_color", Color(1, 0.84, 0))
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_vbox.add_child(title_label)
	
	# Available points
	available_points_label = Label.new()
	available_points_label.text = "Available Points: 0"
	available_points_label.add_theme_font_size_override("font_size", 18)
	available_points_label.add_theme_color_override("font_color", Color(1, 0.84, 0))
	available_points_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_vbox.add_child(available_points_label)
	
	# Separator
	main_vbox.add_child(HSeparator.new())
	
	# Stats display using RichTextLabel
	var scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(scroll)
	
	stats_text = RichTextLabel.new()
	stats_text.bbcode_enabled = true
	stats_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	stats_text.fit_content = true
	scroll.add_child(stats_text)
	
	# Instructions
	var instructions = Label.new()
	instructions.text = "Press C to close | TAB for allocation"
	instructions.add_theme_font_size_override("font_size", 12)
	instructions.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	instructions.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_vbox.add_child(instructions)

func _find_player_stat_sheet():
	var player = get_tree().get_first_node_in_group("player")
	if player and player.has_method("get_stat_sheet"):
		player_stat_sheet = player.get_stat_sheet()
		print("✅ Found player stat sheet")

func _connect_stat_signals():
	if not player_stat_sheet:
		return
	
	if player_stat_sheet.has_signal("stat_value_changed"):
		player_stat_sheet.stat_value_changed.connect(_on_stat_changed)

func _create_update_timer():
	update_timer = Timer.new()
	add_child(update_timer)
	update_timer.wait_time = 0.5
	update_timer.timeout.connect(_update_stats_display)
	update_timer.start()

func _on_stat_changed(stat_name: String, old_value: float, new_value: float):
	if is_open:
		_update_stats_display()

func _update_stats_display():
	if not player_stat_sheet or not is_open:
		return
	
	# Update available points
	var points = 0
	if "available_stat_points" in player_stat_sheet:
		points = player_stat_sheet.available_stat_points
	available_points_label.text = "Available Points: " + str(points)
	if points > 0:
		available_points_label.add_theme_color_override("font_color", Color(1, 0.84, 0))
	else:
		available_points_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	
	# Build stats text
	var text = ""
	
	# Add allocation info if points available
	if points > 0:
		text += "[color=gold][b]Press TAB to open allocation menu![/b][/color]\n\n"
	
	# Base Attributes (5 stats)
	text += "[color=cyan][b]━━━ BASE ATTRIBUTES ━━━[/b][/color]\n"
	text += _format_stat("Level", player_stat_sheet.get_stat_value("level"), true)
	text += _format_stat("Intelligence", player_stat_sheet.get_stat_value("intelligence"), true)
	text += _format_stat("Wisdom", player_stat_sheet.get_stat_value("wisdom"), true)
	text += _format_stat("Vitality", player_stat_sheet.get_stat_value("vitality"), true)
	text += _format_stat("Dexterity", player_stat_sheet.get_stat_value("dexterity"), true)
	
	# Vital Stats (4 stats)
	text += "\n[color=green][b]━━━ VITAL STATS ━━━[/b][/color]\n"
	text += _format_stat("Max Health", player_stat_sheet.get_stat_value("max_health"), true)
	text += _format_stat("Health Regen", player_stat_sheet.get_stat_value("health_regen_rate"), false, "/s")
	text += _format_stat("Max Mana", player_stat_sheet.get_stat_value("max_mana"), true)
	text += _format_stat("Mana Regen", player_stat_sheet.get_stat_value("mana_regen_rate"), false, "/s")
	
	# Combat Stats (8 stats)
	text += "\n[color=orange][b]━━━ COMBAT STATS ━━━[/b][/color]\n"
	text += _format_stat("Spell Damage", player_stat_sheet.get_stat_value("spell_damage_multiplier"), false, "x")
	text += _format_stat("Critical Chance", player_stat_sheet.get_stat_value("critical_chance") * 100, false, "%")
	text += _format_stat("Critical Damage", player_stat_sheet.get_stat_value("critical_hit_multiplier"), false, "x")
	text += _format_stat("Cooldown Reduction", player_stat_sheet.get_stat_value("cooldown_reduction") * 100, false, "%")
	text += _format_stat("Projectile Speed", player_stat_sheet.get_stat_value("spell_projectile_speed"), true)
	text += _format_stat("Spell Range", player_stat_sheet.get_stat_value("spell_range_multiplier"), false, "x")
	text += _format_stat("Free Cast Chance", player_stat_sheet.get_stat_value("free_cast_chance") * 100, false, "%")
	text += _format_stat("Spell Penetration", player_stat_sheet.get_stat_value("spell_penetration") * 100, false, "%")
	
	# Movement & Defense (7 stats)
	text += "\n[color=yellow][b]━━━ MOVEMENT & DEFENSE ━━━[/b][/color]\n"
	text += _format_stat("Movement Speed", player_stat_sheet.get_stat_value("movement_speed"), true)
	text += _format_stat("Dodge Chance", player_stat_sheet.get_stat_value("dodge_chance") * 100, false, "%")
	text += _format_stat("Dodge Speed", player_stat_sheet.get_stat_value("dodge_speed"), true)
	text += _format_stat("Dodge Duration", player_stat_sheet.get_stat_value("dodge_duration"), false, "s")
	text += _format_stat("Dodge Cooldown", player_stat_sheet.get_stat_value("dodge_cooldown"), false, "s")
	text += _format_stat("Acceleration", player_stat_sheet.get_stat_value("acceleration"), false)
	text += _format_stat("Friction", player_stat_sheet.get_stat_value("friction"), false)
	
	# Progression (2 stats)
	text += "\n[color=magenta][b]━━━ PROGRESSION ━━━[/b][/color]\n"
	text += _format_stat("Experience Mult", player_stat_sheet.get_stat_value("experience_multiplier"), false, "x")
	text += _format_stat("Item Find Bonus", player_stat_sheet.get_stat_value("item_find_bonus") * 100, false, "%")
	
	# Total stat count
	text += "\n[color=gray][i]Total: 26 Character Stats[/i][/color]"
	
	stats_text.text = text

func _format_stat(name: String, value: float, is_int: bool = false, suffix: String = "") -> String:
	var formatted_value = str(int(value)) if is_int else "%.1f" % value
	return name + ": [b]" + formatted_value + suffix + "[/b]\n"

func show_character_sheet():
	if not player_stat_sheet:
		_find_player_stat_sheet()
	
	is_open = true
	visible = true
	_update_stats_display()

func hide_character_sheet():
	is_open = false
	visible = false

func toggle_character_sheet():
	if is_open:
		hide_character_sheet()
	else:
		show_character_sheet()

func _on_close_requested():
	hide_character_sheet()
