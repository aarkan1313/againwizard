# EscapeMenuController.gd - Streamlined escape menu with save/load functionality
# Purpose: Quick-access pause menu that opens with Escape key
# Godot Version: 4.4.1 compatible
# Features: Save/load, resume, main menu, quit with minimal UI

extends Control
class_name EscapeMenuController

# UI References
@onready var menu_panel: Panel = $MenuPanel
@onready var title_label: Label = $MenuPanel/VBox/TitleLabel
@onready var resume_button: Button = $MenuPanel/VBox/ButtonContainer/ResumeButton
@onready var save_button: Button = $MenuPanel/VBox/ButtonContainer/SaveButton
@onready var load_button: Button = $MenuPanel/VBox/ButtonContainer/LoadButton
@onready var main_menu_button: Button = $MenuPanel/VBox/ButtonContainer/MainMenuButton
@onready var quit_button: Button = $MenuPanel/VBox/ButtonContainer/QuitButton

# Feedback
@onready var feedback_label: Label = $MenuPanel/VBox/FeedbackLabel

# Confirmation Dialog
@onready var confirmation_dialog: ConfirmationDialog = $ConfirmationDialog
@onready var confirmation_label: Label = $ConfirmationDialog/Label

# State
var is_open: bool = false
var is_operation_in_progress: bool = false
var pending_operation: String = ""

# Multi-slot save system
var save_load_menu_scene = preload("res://scenes/ui/SaveLoadMenu.tscn")
var save_load_menu: SaveLoadMenu = null

# Fade animation
var fade_tween: Tween

func _ready():
	print("🎮 EscapeMenuController initialized")
	setup_ui()
	connect_signals()
	_connect_to_save_system()
	
	# Initially hidden
	visible = false
	set_process_mode(Node.PROCESS_MODE_ALWAYS)  # Process even when paused
	
	# Set process unhandled input
	set_process_unhandled_input(true)

func setup_ui():
	# Setup UI elements
	title_label.text = "Game Paused"
	
	resume_button.text = "Resume"
	save_button.text = "Save Game"
	load_button.text = "Load Game"
	main_menu_button.text = "Main Menu"
	quit_button.text = "Quit Game"
	
	# Set up feedback label
	feedback_label.text = ""
	feedback_label.visible = false
	
	# Style the menu panel
	menu_panel.custom_minimum_size = Vector2(300, 400)

func connect_signals():
	# Connect button signals
	resume_button.pressed.connect(_on_resume_pressed)
	save_button.pressed.connect(_on_save_pressed)
	load_button.pressed.connect(_on_load_pressed)
	main_menu_button.pressed.connect(_on_main_menu_pressed)
	quit_button.pressed.connect(_on_quit_pressed)
	
	confirmation_dialog.confirmed.connect(_on_confirmation_confirmed)
	confirmation_dialog.canceled.connect(_on_confirmation_canceled)

func _connect_to_save_system():
	# Connect to save system if available
	if GameManager and GameManager.has_method("get_save_manager"):
		var save_manager = GameManager.get_save_manager()
		if save_manager:
			save_manager.save_completed.connect(_on_save_completed)
			save_manager.load_completed.connect(_on_load_completed)
			print("🔗 Escape menu connected to save system")

func _unhandled_input(event):
	# Handle escape key input
	if event.is_action_pressed("pause_game"):
		toggle_menu()
		get_viewport().set_input_as_handled()

func toggle_menu():
	# Toggle menu visibility
	if is_open:
		close_menu()
	else:
		open_menu()

func open_menu():
	# Open the escape menu
	if is_open or is_operation_in_progress:
		return
	
	is_open = true
	visible = true
	get_tree().paused = true
	
	# Update button states
	_update_button_states()
	
	# Fade in animation
	modulate.a = 0.0
	if fade_tween:
		fade_tween.kill()
	fade_tween = create_tween()
	fade_tween.tween_property(self, "modulate:a", 1.0, 0.2)
	
	# Focus resume button
	resume_button.grab_focus()
	
	print("⏸️ Escape menu opened")

func close_menu():
	# Close the escape menu
	if not is_open or is_operation_in_progress:
		return
	
	# Clear any feedback
	_hide_feedback()
	
	# Fade out animation
	if fade_tween:
		fade_tween.kill()
	fade_tween = create_tween()
	fade_tween.tween_property(self, "modulate:a", 0.0, 0.2)
	fade_tween.tween_callback(_complete_close)

func _complete_close():
	# Complete the close operation
	visible = false
	is_open = false
	
	# Use GameManager's pause system for proper coordination
	if GameManager and GameManager.has_method("set_game_state"):
		print("🎮 EscapeMenuController: Setting game state to PLAYING")
		GameManager.set_game_state(GameManager.GameState.PLAYING)
	else:
		# Fallback to direct unpause
		print("⚠️ EscapeMenuController: GameManager not available, using direct unpause")
		get_tree().paused = false
	
	print("▶️ Escape menu closed - game resumed")

func _update_button_states():
	# Update button availability
	var buttons_enabled = not is_operation_in_progress
	
	resume_button.disabled = not buttons_enabled
	main_menu_button.disabled = not buttons_enabled
	quit_button.disabled = not buttons_enabled
	
	# Save button - check if we have an active game
	if buttons_enabled and GameManager and GameManager.has_method("get_save_manager"):
		var save_manager = GameManager.get_save_manager()
		if save_manager:
			# Enable save button if there's an active game OR existing save
			var has_active = save_manager.has_method("has_active_game") and save_manager.has_active_game()
			var has_save = save_manager.current_save != null
			save_button.disabled = not (has_active or has_save)
		else:
			save_button.disabled = true
	else:
		save_button.disabled = true
	
	# Load button - check if save file exists
	if buttons_enabled and GameManager and GameManager.has_method("has_saved_game"):
		load_button.disabled = not GameManager.has_saved_game()
	else:
		load_button.disabled = true

# === BUTTON HANDLERS ===

func _on_resume_pressed():
	# Resume the game
	close_menu()

func _on_save_pressed():
	# Show save slot menu
	if is_operation_in_progress:
		return
	
	if not save_load_menu:
		save_load_menu = save_load_menu_scene.instantiate()
		get_parent().add_child(save_load_menu)
		save_load_menu.menu_closed.connect(_on_save_load_menu_closed)
		save_load_menu.save_completed.connect(_on_save_menu_completed)
	
	save_load_menu.show_save_menu()
	hide()  # Hide escape menu
	# Keep game paused while save menu is open

func _on_load_pressed():
	# Show load slot menu
	if is_operation_in_progress:
		return
	
	if not save_load_menu:
		save_load_menu = save_load_menu_scene.instantiate()
		get_parent().add_child(save_load_menu)
		save_load_menu.menu_closed.connect(_on_save_load_menu_closed)
		save_load_menu.save_completed.connect(_on_save_menu_completed)
		save_load_menu.slot_selected.connect(_on_slot_loaded)
	
	save_load_menu.show_load_menu()
	hide()  # Hide escape menu
	# Keep game paused while load menu is open

func _on_main_menu_pressed():
	# Return to main menu
	if is_operation_in_progress:
		return
	
	# Show confirmation
	confirmation_label.text = "Return to main menu?\nUnsaved progress will be lost."
	pending_operation = "main_menu"
	confirmation_dialog.popup_centered()

func _on_quit_pressed():
	# Quit the game
	if is_operation_in_progress:
		return
	
	# Show confirmation
	confirmation_label.text = "Quit game?\nUnsaved progress will be lost."
	pending_operation = "quit"
	confirmation_dialog.popup_centered()

# === CONFIRMATION HANDLERS ===

func _on_confirmation_confirmed():
	# Handle confirmed operations
	match pending_operation:
		"load":
			_perform_load()
		"main_menu":
			_perform_main_menu()
		"quit":
			_perform_quit()
	
	pending_operation = ""

func _on_confirmation_canceled():
	# Handle canceled operations
	pending_operation = ""

func _perform_load():
	# Perform load operation
	is_operation_in_progress = true
	_update_button_states()
	
	_show_feedback("Loading game...", Color.YELLOW)
	
	if GameManager and GameManager.has_method("load_game"):
		var success = await GameManager.load_game()
		if not success:
			is_operation_in_progress = false
			_update_button_states()
			_show_feedback("Load failed!", Color.RED)
	else:
		is_operation_in_progress = false
		_update_button_states()
		_show_feedback("Load system not available", Color.RED)

func _perform_main_menu():
	# Return to main menu
	is_operation_in_progress = true
	_show_feedback("Returning to main menu...", Color.YELLOW)
	
	# Optional: Save before returning to menu
	if GameManager and GameManager.has_method("save_game"):
		GameManager.save_game()
		await get_tree().create_timer(0.5).timeout
	
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/ui/MainMenu.tscn")

func _perform_quit():
	# Quit the game
	is_operation_in_progress = true
	_show_feedback("Saving and quitting...", Color.YELLOW)
	
	# Save before quitting
	if GameManager and GameManager.has_method("save_game"):
		GameManager.save_game()
		await get_tree().create_timer(0.5).timeout
	
	get_tree().quit()

# === SAVE SYSTEM CALLBACKS ===

func _on_save_completed(success: bool, message: String):
	# Handle save completion
	is_operation_in_progress = false
	_update_button_states()
	
	if success:
		_show_feedback("Game saved!", Color.GREEN)
	else:
		_show_feedback("Save failed: " + message, Color.RED)

func _on_load_completed(success: bool, message: String, _save_data):
	# Handle load completion
	is_operation_in_progress = false
	_update_button_states()
	
	if success:
		_show_feedback("Game loaded!", Color.GREEN)
		# Close menu after successful load
		await get_tree().create_timer(0.5).timeout
		close_menu()
	else:
		_show_feedback("Load failed: " + message, Color.RED)

# === FEEDBACK SYSTEM ===

func _show_feedback(text: String, color: Color = Color.WHITE):
	# Show feedback message
	feedback_label.text = text
	feedback_label.modulate = color
	feedback_label.visible = true
	
	# Auto-hide after 3 seconds
	var timer = get_tree().create_timer(3.0)
	timer.timeout.connect(_hide_feedback)

func _hide_feedback():
	# Hide feedback message
	if feedback_label:
		feedback_label.visible = false

# === SAVE/LOAD MENU CALLBACKS ===

func _on_save_load_menu_closed():
	# Handle save/load menu closed
	show()  # Show escape menu again

func _on_slot_loaded(_slot: int):
	# Handle successful load from slot
	print("🎮 EscapeMenuController: Load completed from slot ", _slot + 1, ", closing menu")
	# Close escape menu after successful load
	close_menu()

func _on_save_menu_completed():
	# Handle successful save from save menu - close everything and unpause
	print("🎮 EscapeMenuController: Save completed, closing menu")
	close_menu()

# === KEYBOARD SHORTCUTS ===

func _input(event):
	# Handle additional keyboard shortcuts
	if not is_open:
		return
	
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_S:
				if event.ctrl_pressed and not save_button.disabled:
					_on_save_pressed()
					get_viewport().set_input_as_handled()
			KEY_L:
				if event.ctrl_pressed and not load_button.disabled:
					_on_load_pressed()
					get_viewport().set_input_as_handled()
