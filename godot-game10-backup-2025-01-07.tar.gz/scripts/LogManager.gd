extends Node
# LogManager.gd - Centralized logging configuration
# Purpose: Control logging verbosity across the game
# Can be added as an autoload singleton

enum LogLevel {
	NONE = 0,
	ERROR = 1,
	WARNING = 2,
	INFO = 3,
	DEBUG = 4,
	VERBOSE = 5
}

enum LogCategory {
	COMBAT = 0,
	STATS = 1,
	SPELLS = 2,
	MOVEMENT = 3,
	EVENTS = 4,
	UI = 5,
	SPAWNING = 6,
	INITIALIZATION = 7,
	DEBUG = 8,
	GAMEPLAY = 9,
	PERFORMANCE = 10,
	SYSTEM = 11,
	AI = 12
}

# Global log level - controls overall verbosity
var global_log_level: LogLevel = LogLevel.ERROR

# Category-specific log levels
var category_levels: Dictionary = {
	LogCategory.COMBAT: LogLevel.ERROR,
	LogCategory.STATS: LogLevel.ERROR,
	LogCategory.SPELLS: LogLevel.ERROR,
	LogCategory.MOVEMENT: LogLevel.ERROR,
	LogCategory.EVENTS: LogLevel.WARNING,
	LogCategory.UI: LogLevel.WARNING,
	LogCategory.SPAWNING: LogLevel.ERROR,
	LogCategory.INITIALIZATION: LogLevel.INFO,
	LogCategory.DEBUG: LogLevel.ERROR,
	LogCategory.GAMEPLAY: LogLevel.ERROR,
	LogCategory.PERFORMANCE: LogLevel.WARNING,
	LogCategory.SYSTEM: LogLevel.INFO,
	LogCategory.AI: LogLevel.ERROR
}

# Configuration for reducing repetitive logs
var log_throttling: Dictionary = {
	"contact_damage": {"enabled": true, "interval": 1.0, "last_logged": 0.0},
	"spell_cast": {"enabled": true, "interval": 0.5, "last_logged": 0.0},
	"stat_change": {"enabled": true, "interval": 2.0, "last_logged": 0.0},
	"damage_dealt": {"enabled": true, "interval": 0.3, "last_logged": 0.0}
}

func _ready():
	print("📊 LogManager initialized - Logging verbosity reduced")
	print("   Use F9 to toggle verbose logging on/off")

func _input(event: InputEvent):
	if event.is_action_pressed("toggle_verbose_logging"):
		toggle_verbose_mode()

func should_log(category: LogCategory, level: LogLevel) -> bool:
	# Check if this message should be logged based on category and level
	if level <= LogLevel.ERROR:
		return true  # Always log errors
	
	if level <= global_log_level:
		var category_level = category_levels.get(category, LogLevel.WARNING)
		return level <= category_level
	
	return false

func should_log_throttled(log_type: String) -> bool:
	# Check if enough time has passed for this type of log
	if not log_throttling.has(log_type):
		return true
	
	var throttle_data = log_throttling[log_type]
	if not throttle_data.enabled:
		return true
	
	var current_time = Time.get_ticks_msec() / 1000.0
	if current_time - throttle_data.last_logged >= throttle_data.interval:
		throttle_data.last_logged = current_time
		return true
	
	return false

func log(category: LogCategory, level: LogLevel, message: String, throttle_key: String = ""):
	# Main logging function that respects configuration
	if not should_log(category, level):
		return
	
	if throttle_key != "" and not should_log_throttled(throttle_key):
		return
	
	# Actually log the message
	if level == LogLevel.ERROR:
		push_error(message)
	elif level == LogLevel.WARNING:
		push_warning(message)
	else:
		print(message)

func toggle_verbose_mode():
	# Toggle between minimal and verbose logging
	if global_log_level == LogLevel.ERROR:
		global_log_level = LogLevel.VERBOSE
		for cat in category_levels:
			category_levels[cat] = LogLevel.VERBOSE
		print("🔊 VERBOSE LOGGING ENABLED - Press F9 to disable")
	else:
		global_log_level = LogLevel.ERROR
		for cat in category_levels:
			category_levels[cat] = LogLevel.ERROR
		print("🔇 VERBOSE LOGGING DISABLED - Press F9 to enable")

func set_category_level(category: LogCategory, level: LogLevel):
	category_levels[category] = level

func set_global_level(level: LogLevel):
	global_log_level = level
