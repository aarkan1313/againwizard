class_name CollisionValidator
extends RefCounted
# CollisionValidator.gd - Collision layer validation system
# Purpose: Prevents collision layer configuration mistakes and validates physics setup
# Godot Version: 4.4.1 compatible

# Expected collision layer configuration
enum ExpectedLayers {
	PLAYER = 1,
	ENEMIES = 2,
	PROJECTILES = 3,
	ENVIRONMENT = 4
}

# Expected collision masks for each entity type
const PLAYER_MASK = 4  # Player should only collide with environment
const ENEMY_MASK = 5   # Enemies collide with player(1) + environment(4) = 5
const PROJECTILE_MASK = 2  # Projectiles collide with enemies(2) only - no self damage
const ENVIRONMENT_MASK = 0  # Environment doesn't need to detect collisions

# Validation results structure
class ValidationResult:
	var is_valid: bool = false
	var issues: Array = []
	var entity_name: String = ""
	var entity_type: String = ""
	
	func _init(name: String, type: String):
		entity_name = name
		entity_type = type
	
	func add_issue(issue: String) -> void:
		issues.append(issue)
		is_valid = false
	
	func get_summary() -> String:
		if is_valid:
			return "✅ " + entity_name + " (" + entity_type + "): VALID collision setup"
		else:
			var summary = "❌ " + entity_name + " (" + entity_type + "): INVALID collision setup\n"
			for issue in issues:
				summary += "  - " + issue + "\n"
			return summary

# Main validation functions
static func validate_player_collision(body: CharacterBody2D) -> ValidationResult:
	var result = ValidationResult.new(body.name, "Player")
	
	if not body:
		result.add_issue("Player body is null")
		return result
	
	# Validate collision layer
	if body.collision_layer != ExpectedLayers.PLAYER:
		result.add_issue("Wrong collision layer: " + str(body.collision_layer) + " (expected " + str(ExpectedLayers.PLAYER) + ")")
	
	# Validate collision mask
	if body.collision_mask != PLAYER_MASK:
		result.add_issue("Wrong collision mask: " + str(body.collision_mask) + " (expected " + str(PLAYER_MASK) + ")")
	
	# Validate player is in correct group
	if not body.is_in_group("players"):
		result.add_issue("Player not in 'players' group")
	
	# Validate CollisionShape2D exists
	var collision_shape = body.get_node_or_null("PlayerCollision")
	if not collision_shape:
		# Try alternative names
		collision_shape = body.get_node_or_null("CollisionShape2D")
		if not collision_shape:
			result.add_issue("No CollisionShape2D found (checked 'PlayerCollision' and 'CollisionShape2D')")
	
	# If no issues found, mark as valid
	if result.issues.is_empty():
		result.is_valid = true
	
	# Log result
	_log_validation_result(result)
	return result

static func validate_enemy_collision(body: CharacterBody2D) -> ValidationResult:
	var result = ValidationResult.new(body.name, "Enemy")
	
	if not body:
		result.add_issue("Enemy body is null")
		return result
	
	# Validate collision layer
	if body.collision_layer != ExpectedLayers.ENEMIES:
		result.add_issue("Wrong collision layer: " + str(body.collision_layer) + " (expected " + str(ExpectedLayers.ENEMIES) + ")")
	
	# Validate collision mask
	if body.collision_mask != ENEMY_MASK:
		result.add_issue("Wrong collision mask: " + str(body.collision_mask) + " (expected " + str(ENEMY_MASK) + ")")
	
	# Validate enemy is in correct group
	if not body.is_in_group("enemies"):
		result.add_issue("Enemy not in 'enemies' group")
	
	# If no issues found, mark as valid
	if result.issues.is_empty():
		result.is_valid = true
	
	_log_validation_result(result)
	return result

static func validate_projectile_collision(body: Area2D) -> ValidationResult:
	var result = ValidationResult.new(body.name, "Projectile")
	
	if not body:
		result.add_issue("Projectile body is null")
		return result
	
	# Validate collision layer (convert from layer number to bitmask)
	var expected_layer_bitmask = 1 << (ExpectedLayers.PROJECTILES - 1)
	if body.collision_layer != expected_layer_bitmask:
		result.add_issue("Wrong collision layer: " + str(body.collision_layer) + " (expected " + str(expected_layer_bitmask) + " for layer " + str(ExpectedLayers.PROJECTILES) + ")")
	
	# Validate collision mask
	if body.collision_mask != PROJECTILE_MASK:
		result.add_issue("Wrong collision mask: " + str(body.collision_mask) + " (expected " + str(PROJECTILE_MASK) + ")")
	
	# Validate projectile is in correct group
	if not body.is_in_group("projectiles"):
		result.add_issue("Projectile not in 'projectiles' group")
	
	# If no issues found, mark as valid
	if result.issues.is_empty():
		result.is_valid = true
	
	_log_validation_result(result)
	return result

static func validate_environment_collision(body: StaticBody2D) -> ValidationResult:
	var result = ValidationResult.new(body.name, "Environment")
	
	if not body:
		result.add_issue("Environment body is null")
		return result
	
	# Validate collision layer
	if body.collision_layer != ExpectedLayers.ENVIRONMENT:
		result.add_issue("Wrong collision layer: " + str(body.collision_layer) + " (expected " + str(ExpectedLayers.ENVIRONMENT) + ")")
	
	# Environment typically doesn't need to detect collisions
	if body.collision_mask != ENVIRONMENT_MASK:
		result.add_issue("Wrong collision mask: " + str(body.collision_mask) + " (expected " + str(ENVIRONMENT_MASK) + " for static environment)")
	
	# If no issues found, mark as valid
	if result.issues.is_empty():
		result.is_valid = true
	
	_log_validation_result(result)
	return result

# Project-wide validation functions
static func validate_project_collision_layers() -> bool:
	print("🔍 Validating project collision layer configuration...")
	
	var all_valid = true
	
	# Check layer names in project settings
	var expected_layers = {
		1: "player",
		2: "enemies", 
		3: "projectiles",
		4: "environment"
	}
	
	for layer_num in expected_layers:
		var layer_name = ProjectSettings.get_setting("layer_names/2d_physics/layer_" + str(layer_num), "")
		var expected_name = expected_layers[layer_num]
		
		if layer_name.to_lower() != expected_name:
			_log_error("Collision layer " + str(layer_num) + " should be named '" + expected_name + "' but is '" + layer_name + "'")
			all_valid = false
		else:
			print("✅ Layer " + str(layer_num) + " ('" + expected_name + "'): Correctly configured")
	
	if all_valid:
		print("✅ All collision layers properly configured")
	else:
		print("❌ Collision layer configuration issues found")
	
	return all_valid

# Scene validation functions
static func validate_all_entities_in_scene(scene_root: Node) -> Array:
	var results: Array = []
	
	print("🔍 Validating all entities in scene: " + scene_root.name)
	
	# Find all players
	var players = scene_root.get_tree().get_nodes_in_group("players")
	for player in players:
		if player is CharacterBody2D:
			results.append(validate_player_collision(player))
	
	# Find all enemies
	var enemies = scene_root.get_tree().get_nodes_in_group("enemies")
	for enemy in enemies:
		if enemy is CharacterBody2D:
			results.append(validate_enemy_collision(enemy))
	
	# Find all projectiles
	var projectiles = scene_root.get_tree().get_nodes_in_group("projectiles")
	for projectile in projectiles:
		if projectile is RigidBody2D:
			results.append(validate_projectile_collision(projectile))
	
	# Report summary
	var valid_count = 0
	var total_count = results.size()
	
	for result in results:
		if result.is_valid:
			valid_count += 1
	
	print("📊 Collision validation summary: " + str(valid_count) + "/" + str(total_count) + " entities valid")
	
	return results

# Auto-correction functions
static func auto_fix_player_collision(body: CharacterBody2D) -> bool:
	if not body:
		return false
	
	print("🔧 Auto-fixing player collision setup for: " + body.name)
	
	body.collision_layer = ExpectedLayers.PLAYER
	body.collision_mask = PLAYER_MASK
	
	if not body.is_in_group("players"):
		body.add_to_group("players")
	
	# Validate the fix worked
	var result = validate_player_collision(body)
	return result.is_valid

static func auto_fix_enemy_collision(body: CharacterBody2D) -> bool:
	if not body:
		return false
	
	print("🔧 Auto-fixing enemy collision setup for: " + body.name)
	
	body.collision_layer = ExpectedLayers.ENEMIES
	body.collision_mask = ENEMY_MASK
	
	if not body.is_in_group("enemies"):
		body.add_to_group("enemies")
	
	# Validate the fix worked
	var result = validate_enemy_collision(body)
	return result.is_valid

# Helper functions
static func _log_validation_result(result: ValidationResult) -> void:
	if UnifiedDebugSystem:
		if result.is_valid:
			# Collision validation passed - logging reduced for performance
		else:
			for issue in result.issues:
				UnifiedDebugSystem.log_error_internal(UnifiedDebugSystem.LogCategory.GENERAL, result.entity_name + ": " + issue, "CollisionValidator")
	else:
		# Fallback if Logger not available
		print(result.get_summary())

static func _log_error(message: String) -> void:
	if UnifiedDebugSystem:
		UnifiedDebugSystem.log_error_internal(UnifiedDebugSystem.LogCategory.GENERAL, message, "CollisionValidator")
	else:
		print("❌ CollisionValidator: " + message)

# Testing and debugging functions
static func run_comprehensive_test() -> bool:
	print("🧪 Running comprehensive collision validation test...")
	
	var all_tests_passed = true
	
	# Test 1: Project layer configuration
	if not validate_project_collision_layers():
		all_tests_passed = false
	
	# Test 2: Scene validation (if available)
	var main_scene = Engine.get_main_loop().current_scene
	if main_scene:
		var results = validate_all_entities_in_scene(main_scene)
		for result in results:
			if not result.is_valid:
				all_tests_passed = false
	
	if all_tests_passed:
		print("✅ All collision validation tests PASSED")
	else:
		print("❌ Some collision validation tests FAILED")
	
	return all_tests_passed

# Utility functions for getting collision info
static func get_layer_name(layer_number: int) -> String:
	return ProjectSettings.get_setting("layer_names/2d_physics/layer_" + str(layer_number), "Unnamed")

static func get_collision_info(body: PhysicsBody2D) -> String:
	if not body:
		return "Invalid body"
	
	var info = "Collision Info for " + body.name + ":\n"
	info += "- Type: " + body.get_class() + "\n"
	info += "- Layer: " + str(body.collision_layer) + " (" + get_layer_name(body.collision_layer) + ")\n"
	info += "- Mask: " + str(body.collision_mask) + "\n"
	info += "- Groups: " + str(body.get_groups()) + "\n"
	return info