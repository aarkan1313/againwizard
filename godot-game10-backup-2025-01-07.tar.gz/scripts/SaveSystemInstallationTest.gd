# SaveSystemInstallationTest.gd
# Comprehensive test to validate Phase 3.6 save system installation

extends Node

func _ready():
	print("🧪 === PHASE 3.6 SAVE SYSTEM INSTALLATION TEST ===")
	test_class_availability()
	test_singleton_access()
	test_gamemanager_integration()
	test_save_operations()
	print("🧪 === INSTALLATION TEST COMPLETE ===")

func test_class_availability():
	print("\n🔍 Testing Class Availability...")
	
	# Test SaveData class
	if ClassDB.class_exists("SaveData"):
		print("✅ SaveData class found")
		var save_data = SaveData.new()
		if save_data:
			print("✅ SaveData can be instantiated")
			save_data.character_name = "Test Wizard"
			print("✅ SaveData properties work: ", save_data.character_name)
		else:
			print("❌ SaveData instantiation failed")
	else:
		print("❌ SaveData class not found")
	
	# Test SaveDataValidator class  
	if ClassDB.class_exists("SaveDataValidator"):
		print("✅ SaveDataValidator class found")
		var validator = SaveDataValidator.new()
		if validator:
			print("✅ SaveDataValidator can be instantiated")
		else:
			print("❌ SaveDataValidator instantiation failed")
	else:
		print("❌ SaveDataValidator class not found")
	
	# Test SaveManager singleton availability
	if SaveManager:
		print("✅ SaveManager singleton accessible")
	else:
		print("❌ SaveManager singleton not accessible")

func test_singleton_access():
	print("\n🔧 Testing Singleton Access...")
	
	# Test SaveManager singleton
	if SaveManager:
		print("✅ SaveManager singleton accessible")
		if SaveManager.has_method("create_new_save"):
			print("✅ SaveManager has create_new_save method")
		else:
			print("❌ SaveManager missing create_new_save method")
		
		if SaveManager.has_method("save_current_game"):
			print("✅ SaveManager has save_current_game method")
		else:
			print("❌ SaveManager missing save_current_game method")
			
		if SaveManager.has_method("load_saved_game"):
			print("✅ SaveManager has load_saved_game method")
		else:
			print("❌ SaveManager missing load_saved_game method")
	else:
		print("❌ SaveManager singleton not accessible")
	
	# Test GameManager singleton
	if GameManager:
		print("✅ GameManager singleton accessible")
	else:
		print("❌ GameManager singleton not accessible")

func test_gamemanager_integration():
	print("\n🎮 Testing GameManager Integration...")
	
	if not GameManager:
		print("❌ GameManager not available - skipping integration tests")
		return
	
	# Test save system API methods
	var methods_to_test = [
		"start_new_game", "save_game", "load_game", 
		"has_saved_game", "get_save_summary"
	]
	
	for method in methods_to_test:
		if GameManager.has_method(method):
			print("✅ GameManager has ", method, " method")
		else:
			print("❌ GameManager missing ", method, " method")
	
	# Test GameManager save manager reference
	if GameManager.save_manager:
		print("✅ GameManager has save_manager reference")
		if GameManager.save_manager == SaveManager:
			print("✅ GameManager save_manager correctly references singleton")
		else:
			print("⚠️ GameManager save_manager is not the singleton")
	else:
		print("❌ GameManager has no save_manager reference")

func test_save_operations():
	print("\n💾 Testing Save Operations...")
	
	if not GameManager or not SaveManager:
		print("❌ Required managers not available - skipping save operations test")
		return
	
	# Test basic save file operations
	try:
		var has_save_before = GameManager.has_saved_game()
		print("📁 Has save file before test: ", has_save_before)
		
		# Test save summary (should handle no save gracefully)
		var summary = GameManager.get_save_summary()
		print("📊 Save summary result: ", summary)
		
		# Test SaveManager direct access
		if SaveManager.has_method("has_save_file"):
			var has_file = SaveManager.has_save_file()
			print("💾 SaveManager has_save_file: ", has_file)
		
		print("✅ Basic save operations test completed")
		
	except Exception as e:
		print("❌ Save operations test failed: ", e.message)

func try_create_test_save():
	print("\n🧪 Testing Save Creation (Advanced)...")
	
	if not GameManager:
		print("❌ GameManager not available")
		return
	
	try:
		print("🔨 Attempting to create test save...")
		var success = GameManager.start_new_game("Test_Installation")
		
		if success:
			print("✅ Test save created successfully")
			
			# Test saving
			var save_success = GameManager.save_game()
			print("💾 Save operation result: ", save_success)
			
			# Test save file existence
			var has_save = GameManager.has_saved_game()
			print("📁 Save file exists after creation: ", has_save)
			
			# Get save summary
			var summary = GameManager.get_save_summary()
			print("📊 Save summary: ", summary)
			
		else:
			print("❌ Test save creation failed")
			
	except Exception as e:
		print("❌ Save creation test failed: ", e.message)

# Auto-run advanced test after a delay
func _on_timer_timeout():
	try_create_test_save()

func _on_ready_delayed():
	var timer = Timer.new()
	timer.wait_time = 2.0
	timer.one_shot = true
	timer.timeout.connect(_on_timer_timeout)
	add_child(timer)
	timer.start()
	
	_on_ready_delayed()