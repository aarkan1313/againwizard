# AbilityData.gd - Enhanced ability data resource
# Godot 4.4.1 Compatible - Based on proven system architecture
extends Resource
class_name AbilityData

# Core ability properties
@export var ability_name: String = ""
@export var ability_type: String = "basic"  # "aoe", "ranged", "speed_boost", "heal", "teleport", "melee_aoe"
@export var ability_description: String = ""

# Timing and availability
@export var cooldown_time: float = 3.0
@export var cast_time: float = 0.0  # Channel time before ability executes
@export var range: float = 200.0
@export var min_range: float = 0.0  # Minimum range (for charge abilities)

# Damage and effects
@export var damage: int = 30
@export var damage_type: String = "physical"  # "physical", "magical", "elemental"
@export var element_type: String = "none"  # "fire", "ice", "lightning", "earth", "wind"

# Movement abilities (charge, teleport) - Enhanced from proven system
@export var charge_speed: float = 400.0
@export var charge_damage_radius: float = 50.0
@export var knockback_force: float = 0.0

# Enhanced charge system properties (from proven implementation)
@export var warning_duration: float = 1.0  # Time to show warning before charge
@export var warning_color: Color = Color.ORANGE_RED  # Warning phase color
@export var impact_color: Color = Color.RED  # Impact phase color
@export var aoe_damage_multiplier: float = 0.7  # AOE damage as percentage of main damage
@export var enhanced_knockback_multiplier: float = 1.5  # Enhanced knockback for AOE
@export var blast_radius_multiplier: float = 1.2  # Final blast radius multiplier

# Projectile abilities (ranged)
@export var projectile_speed: float = 300.0
@export var projectile_lifetime: float = 3.0
@export var projectile_piercing: bool = false
@export var projectile_homing: bool = false
@export var projectile_explosion_radius: float = 0.0
@export var projectile_accuracy: float = 1.0  # 1.0 = perfect aim, 0.9 = 10% spread, etc.

# Buff/Debuff abilities (speed_boost, heal)
@export var effect_duration: float = 2.0
@export var speed_multiplier: float = 1.5
@export var heal_amount: int = 0
@export var heal_percentage: float = 0.0  # Heal as % of max health

# Status effects
@export var status_effects: Array[String] = []  # ["burning", "slowed", "stunned", etc.]
@export var status_duration: float = 3.0

# Visual and audio
@export var ability_color: Color = Color.WHITE
@export var cast_effect: String = ""  # Path to effect scene
@export var impact_effect: String = ""  # Path to impact effect
@export var sound_effect: String = ""  # Path to audio file

# AI behavior hints - CRITICAL for AI ability selection
@export var ai_priority: int = 1  # Higher = more likely to use (0-10 scale)
@export var use_when_health_below: float = 1.0  # Use only when health below this % (1.0 = always)
@export var use_when_health_above: float = 0.0  # Use only when health above this % (0.0 = always)
@export var use_when_player_distance_min: float = 0.0
@export var use_when_player_distance_max: float = 1000.0

# Advanced properties
@export var requires_line_of_sight: bool = true
@export var can_use_while_moving: bool = true
@export var interrupts_movement: bool = false
@export var max_uses_per_combat: int = -1  # -1 = unlimited

# Quick setup functions (from proven system)
func setup_enhanced_charge_ability(damage_val: int, speed_val: float, range_val: float, duration_val: float = 8.0, cooldown_val: float = 6.0, priority_val: int = 10):
	# Quick setup for enhanced charge abilities with AOE and warning
	ability_type = "enhanced_charge"
	damage = damage_val
	charge_speed = speed_val
	range = range_val
	effect_duration = duration_val
	cooldown_time = cooldown_val
	ai_priority = priority_val
	ability_color = Color.DARK_RED
	interrupts_movement = true
	charge_damage_radius = 180.0
	cast_time = 0.0  # No cast time, has warning phase instead
	requires_line_of_sight = false
	
	# Enhanced charge specific properties
	warning_duration = 1.5
	warning_color = Color.ORANGE_RED
	impact_color = Color.RED
	aoe_damage_multiplier = 0.7
	enhanced_knockback_multiplier = 1.5
	blast_radius_multiplier = 1.2

func setup_ranged_ability(damage_val: int, speed_val: float, range_val: float, cooldown_val: float = 2.5, priority_val: int = 6):
	# Quick setup for ranged abilities
	ability_type = "ranged"
	damage = damage_val
	projectile_speed = speed_val
	range = range_val
	cooldown_time = cooldown_val
	ai_priority = priority_val
	ability_color = Color.BLUE
	requires_line_of_sight = true
	projectile_lifetime = 3.0
	cast_time = 0.2  # Aiming time

func validate() -> bool:
	# Enhanced validation from proven system
	if ability_name.is_empty():
		return false
	if ability_type.is_empty():
		return false
	if cooldown_time < 0:
		return false
	if ai_priority < 0:
		return false
	return true

func is_valid_ability() -> bool:
	# Alias for validate() to match existing code
	return validate()