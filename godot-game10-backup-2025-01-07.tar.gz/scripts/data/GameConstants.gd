# GameConstants.gd - Centralized configuration system
# Purpose: Move all magic numbers to data-driven configuration
# Godot Version: 4.4.1
# Benefits: Live tuning, easy balancing, modding support

extends Resource
class_name GameConstants

# AI Performance Settings
@export_group("AI Performance")
@export var ai_update_interval: float = 0.3
@export var player_cache_lifetime: float = 2.0
@export var ability_spam_prevention: float = 0.5
@export var ai_distance_check_interval: float = 0.2

# Enemy Behavior Settings  
@export_group("Enemy Behavior")
@export var enemy_separation_distance: float = 50.0
@export var separation_check_interval: float = 0.1
@export var separation_force_strength: float = 30.0
@export var contact_damage_immunity: float = 0.5
@export var damage_immunity_duration: float = 0.1

# Combat Settings
@export_group("Combat System")
@export var damage_number_lifetime: float = 1.5
@export var damage_number_float_speed: float = 50.0
@export var damage_flash_duration: float = 0.15
@export var death_fade_duration: float = 0.5
@export var knockback_base_force: float = 200.0

# Performance Limits
@export_group("Performance")
@export var max_simultaneous_enemies: int = 25
@export var particle_count_multiplier: float = 1.0
@export var logging_probability: float = 0.2
@export var max_damage_numbers: int = 10
@export var physics_separation_limit: int = 20

# Visual Effects Settings
@export_group("Visual Effects")
@export var warning_pulse_speed: float = 0.25
@export var warning_line_width: float = 5.0
@export var aoe_warning_duration: float = 1.0
@export var charge_warning_intensity: float = 0.7
@export var particle_emission_scale: float = 1.0

# Audio Settings
@export_group("Audio")
@export var enemy_audio_enabled: bool = true
@export var ability_sound_volume: float = 0.7
@export var combat_audio_distance: float = 800.0
@export var audio_overlap_prevention: float = 0.1

# Wave System Settings
@export_group("Wave Progression")
@export var base_wave_multiplier: float = 1.2
@export var health_scaling_per_wave: float = 0.2
@export var damage_scaling_per_wave: float = 0.15
@export var speed_scaling_per_wave: float = 0.08
@export var xp_scaling_per_wave: float = 0.1

# Spawning Settings
@export_group("Enemy Spawning")
@export var spawn_distance_min: float = 300.0
@export var spawn_distance_max: float = 600.0
@export var spawn_rate_base: float = 2.0
@export var spawn_rate_scaling: float = 0.1
@export var enemy_density_target: int = 15

# Ability System Settings
@export_group("Ability System")
@export var ability_range_multiplier: float = 1.0
@export var cooldown_reduction_factor: float = 1.0
@export var projectile_speed_multiplier: float = 1.0
@export var aoe_damage_multiplier: float = 0.7
@export var enhanced_knockback_multiplier: float = 1.5

# Debug and Development
@export_group("Debug")
@export var debug_mode_enabled: bool = false
@export var show_ai_states: bool = false
@export var show_ability_ranges: bool = false
@export var performance_monitoring: bool = true
@export var verbose_logging: bool = false

func validate() -> bool:
    # Validate all configuration values are sensible
    var valid = true
    
    # Check critical timing values
    if ai_update_interval <= 0:
        push_error("Invalid ai_update_interval: " + str(ai_update_interval))
        valid = false
    
    if separation_check_interval <= 0:
        push_error("Invalid separation_check_interval: " + str(separation_check_interval))
        valid = false
        
    # Check performance limits
    if max_simultaneous_enemies <= 0:
        push_error("Invalid max_simultaneous_enemies: " + str(max_simultaneous_enemies))
        valid = false
        
    # Check scaling values
    if health_scaling_per_wave < 0:
        push_error("Invalid health_scaling_per_wave: " + str(health_scaling_per_wave))
        valid = false
    
    return valid

func get_wave_health_multiplier(wave: int) -> float:
    # Calculate health multiplier for given wave
    return 1.0 + (health_scaling_per_wave * (wave - 1))

func get_wave_damage_multiplier(wave: int) -> float:
    # Calculate damage multiplier for given wave
    return 1.0 + (damage_scaling_per_wave * (wave - 1))

func get_wave_speed_multiplier(wave: int) -> float:
    # Calculate speed multiplier for given wave
    return 1.0 + (speed_scaling_per_wave * (wave - 1))

func get_scaled_particle_count(base_count: int) -> int:
    # Get particle count adjusted for performance settings
    return int(base_count * particle_count_multiplier)

func should_log_event() -> bool:
    # Probabilistic logging for performance
    return randf() < logging_probability

func create_default() -> GameConstants:
    # Create default configuration if resource missing
    var defaults = GameConstants.new()
    # All values already set via @export defaults
    return defaults