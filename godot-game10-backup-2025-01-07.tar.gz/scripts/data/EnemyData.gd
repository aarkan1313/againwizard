# EnemyData.gd - Data-driven enemy configuration
# Godot 4.4.1 Compatible Resource System
extends Resource
class_name EnemyData

@export_group("Basic Info")
@export var enemy_name: String = "Goblin"
@export var enemy_type: String = "goblin"
@export var description: String = "A small, aggressive creature"

@export_group("Base Stats")
@export var base_health: float = 40.0
@export var base_damage: float = 8.0
@export var base_speed: float = 120.0
@export var base_xp: float = 8.0

@export_group("Behavior")
@export var ai_behavior: String = "melee_aggressive"  # melee_aggressive, ranged_kiting, support_healing
@export var attack_range: float = 50.0
@export var detection_range: float = 200.0
@export var movement_pattern: String = "direct"  # direct, circling, hit_and_run

@export_group("Visual Assets")
@export var sprite_path: String = "res://assets/sprites/goblin2.png"
@export var sprite_scale: Vector2 = Vector2(0.5, 0.5)
@export var health_bar_offset: Vector2 = Vector2(-20, -45)

@export_group("Collision Settings")
@export var collision_radius: float = 20.0  # Main hitbox size (for movement/spells hitting enemy)
@export var damage_area_radius: float = 32.0  # Contact damage reach (how close player needs to be)
@export var main_collision_offset: Vector2 = Vector2.ZERO  # Position offset for main collision shape
@export var damage_area_offset: Vector2 = Vector2.ZERO  # Position offset for damage area shape
@export var main_collision_size: Vector2 = Vector2.ZERO  # Rectangle size for main collision (if Vector2.ZERO, use radius*2)
@export var damage_area_size: Vector2 = Vector2.ZERO  # Rectangle size for damage area (if Vector2.ZERO, use radius*2)

@export_group("Abilities")
@export var abilities: Array[AbilityData] = []
@export var passive_abilities: Array[String] = []  # "regeneration", "armor", "berserker"

@export_group("Audio")
@export var death_sound: String = "enemy_death_small"
@export var attack_sound: String = "enemy_attack_melee"
@export var hurt_sound: String = "enemy_hurt_generic"

@export_group("Elemental System (Phase 7 Ready)")
@export var elemental_affinity: String = "none"  # fire, water, earth, air, etc.
@export var resistances: Dictionary = {}  # "fire": 0.5, "water": 1.5
@export var weaknesses: Dictionary = {}

func validate() -> bool:
	# Validate enemy data for completeness
	var is_valid = true
	
	if enemy_name.is_empty():
		push_error("EnemyData: enemy_name cannot be empty")
		is_valid = false
	
	if base_health <= 0:
		push_error("EnemyData: base_health must be > 0")
		is_valid = false
	
	if not ResourceLoader.exists(sprite_path):
		push_warning("EnemyData: sprite_path does not exist: " + sprite_path)
	
	return is_valid

func get_ability_by_name(ability_name: String) -> AbilityData:
	# Get specific ability by name
	for ability in abilities:
		if ability and ability.ability_name == ability_name:
			return ability
	return null

func has_passive_ability(passive_name: String) -> bool:
	# Check if enemy has specific passive ability
	return passive_name in passive_abilities

func auto_adjust_collision_to_sprite() -> bool:
	# Auto-adjust collision sizes based on sprite dimensions
	if not ResourceLoader.exists(sprite_path):
		print("❌ Cannot auto-adjust: sprite not found at %s" % sprite_path)
		return false
	
	var texture = load(sprite_path) as Texture2D
	if not texture:
		print("❌ Cannot auto-adjust: failed to load sprite texture")
		return false
	
	# Get sprite dimensions
	var sprite_size = texture.get_size()
	var scaled_size = Vector2(sprite_size.x * sprite_scale.x, sprite_size.y * sprite_scale.y)
	
	# Calculate collision sizes based on sprite bounds
	# Main collision: 70% of sprite width/height (smaller, tighter collision)
	collision_radius = min(scaled_size.x, scaled_size.y) * 0.35
	
	# Damage area: 85% of sprite width/height (larger, for contact damage)
	damage_area_radius = min(scaled_size.x, scaled_size.y) * 0.425
	
	# Reset offsets to center
	main_collision_offset = Vector2.ZERO
	damage_area_offset = Vector2.ZERO
	
	print("✅ Auto-adjusted %s collision to sprite bounds:" % enemy_type.to_upper())
	print("  Sprite size: %.0fx%.0f (scaled: %.1fx%.1f)" % [sprite_size.x, sprite_size.y, scaled_size.x, scaled_size.y])
	print("  Main collision: %.1f" % collision_radius)
	print("  Damage area: %.1f" % damage_area_radius)
	
	return true