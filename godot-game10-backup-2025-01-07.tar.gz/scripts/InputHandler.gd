extends Node
# InputHandler.gd - Centralized input handling for Wizard RPG
# Purpose: Provides clean input abstraction for all game systems
# Godot Version: 4.4.1 compatible

var input_enabled: bool = true

func _ready() -> void:
	print("✅ InputHandler singleton initialized")
	print("🎮 Input systems ready: movement, spells, debug")

# Movement input
func get_movement_vector() -> Vector2:
	if not input_enabled:
		return Vector2.ZERO
	
	return Input.get_vector("move_left", "move_right", "move_up", "move_down")

# Spell casting input
func is_spell_cast_pressed(spell_index: int) -> bool:
	if not input_enabled:
		return false
	
	match spell_index:
		1:
			return Input.is_action_just_pressed("spell_1")
		2:
			return Input.is_action_just_pressed("spell_2")
		3:
			return Input.is_action_just_pressed("spell_3")
		4:
			return Input.is_action_just_pressed("spell_4")
		5:
			return Input.is_action_just_pressed("spell_5")
		_:
			return false

# System control
func is_pause_pressed() -> bool:
	return Input.is_action_just_pressed("pause_game")

func is_dodge_pressed() -> bool:
	if not input_enabled:
		return false
	# Use Space key (dodge action) for dodge
	return Input.is_action_just_pressed("dodge")

func is_character_sheet_pressed() -> bool:
	return Input.is_action_just_pressed("character_sheet")

# Input control
func enable_input() -> void:
	input_enabled = true
	print("🎮 Input enabled")

func disable_input() -> void:
	input_enabled = false
	print("🎮 Input disabled")

# Debug functions
func get_input_status() -> String:
	return """
InputHandler Status:
- Input Enabled: %s
- Movement Vector: %s
- Mouse Position: %s
""" % [
	str(input_enabled),
	str(get_movement_vector()),
	str(get_viewport().get_mouse_position())
]
