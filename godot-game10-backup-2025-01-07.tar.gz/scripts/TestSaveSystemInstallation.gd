# TestSaveSystemInstallation.gd - Verify Phase 3.6 installation
# Purpose: Test that all save system components are properly installed
# Usage: Add to any node in the scene temporarily to test

extends Node

func _ready():
	print("\n🧪 === SAVE SYSTEM INSTALLATION TEST ===\n")
	
	# Test 1: Check if SaveData class exists
	print("1️⃣ Testing SaveData class...")
	var save_data = SaveData.new()
	if save_data:
		print("✅ SaveData class loaded successfully")
		print("   - Save version: ", save_data.save_version)
		print("   - Save format: ", save_data.save_format)
	else:
		print("❌ SaveData class not found!")
	
	# Test 2: Check if SaveDataValidator exists
	print("\n2️⃣ Testing SaveDataValidator class...")
	var test_json = '{"save_version": 1, "character_name": "Test", "run_data": {}}'
	var validation = SaveDataValidator.validate_json_string(test_json)
	if validation.has("valid"):
		print("✅ SaveDataValidator class loaded successfully")
		print("   - Validation test: ", "PASSED" if validation.valid else "FAILED")
	else:
		print("❌ SaveDataValidator class not found!")
	
	# Test 3: Check GameManager save integration
	print("\n3️⃣ Testing GameManager save integration...")
	if GameManager:
		if GameManager.has_method("save_game"):
			print("✅ GameManager has save_game() method")
		else:
			print("❌ GameManager missing save_game() method")
			
		if GameManager.has_method("load_game"):
			print("✅ GameManager has load_game() method")
		else:
			print("❌ GameManager missing load_game() method")
			
		if GameManager.has_method("has_saved_game"):
			print("✅ GameManager has has_saved_game() method")
		else:
			print("❌ GameManager missing has_saved_game() method")
			
		if GameManager.get("save_manager"):
			print("✅ GameManager has save_manager property")
			var save_manager = GameManager.get_save_manager()
			if save_manager:
				print("✅ SaveManager is initialized")
			else:
				print("⚠️ SaveManager exists but not yet initialized (this is normal on first frame)")
		else:
			print("❌ GameManager missing save_manager property")
	else:
		print("❌ GameManager singleton not found!")
	
	# Test 4: Check EscapeMenuController
	print("\n4️⃣ Testing EscapeMenuController...")
	var script_path = "res://scripts/ui/EscapeMenuController.gd"
	if ResourceLoader.exists(script_path):
		print("✅ EscapeMenuController.gd found at correct location")
		var script = load(script_path)
		if script:
			print("✅ EscapeMenuController.gd loads successfully")
		else:
			print("❌ EscapeMenuController.gd failed to load")
	else:
		print("❌ EscapeMenuController.gd not found at: ", script_path)
	
	# Test 5: Test creating a save
	print("\n5️⃣ Testing save creation...")
	await get_tree().create_timer(0.5).timeout  # Wait for GameManager initialization
	
	if GameManager and GameManager.has_method("start_new_game"):
		var success = GameManager.start_new_game("InstallationTest")
		if success:
			print("✅ Successfully created test save")
			
			# Test saving
			var save_success = GameManager.save_game()
			print("✅ Save operation: ", "SUCCESS" if save_success else "FAILED")
			
			# Test checking for save
			var has_save = GameManager.has_saved_game()
			print("✅ Has saved game: ", has_save)
			
			# Test save summary
			var summary = GameManager.get_save_summary()
			if not summary.is_empty():
				print("✅ Save summary retrieved:")
				print("   - Character: ", summary.get("character_name", "Unknown"))
				print("   - Level: ", summary.get("level", 0))
				print("   - Wave: ", summary.get("wave", 0))
		else:
			print("❌ Failed to create test save")
	
	print("\n🏁 === INSTALLATION TEST COMPLETE ===")
	print("\n📋 Next Steps:")
	print("1. Create EscapeMenu.tscn scene using ESCAPE_MENU_SCENE_STRUCTURE.md")
	print("2. Add EscapeMenu to Main.tscn as UI overlay")
	print("3. Test Escape key to open menu")
	print("4. Test save/load functionality through menu")
	
	# Self-destruct after test
	queue_free()