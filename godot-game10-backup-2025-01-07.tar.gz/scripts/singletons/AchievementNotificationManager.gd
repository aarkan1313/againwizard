# AchievementNotificationManager.gd
# Purpose: Singleton to manage achievement notifications in UI
# Godot Version: 4.4.1 compatible
# AutoLoad: Add to project.godot as "AchievementNotificationManager"

extends Node

# Preload the notification scene
const ACHIEVEMENT_NOTIFICATION_SCENE = preload("res://scenes/ui/AchievementNotification.tscn")

# Current active notification
var current_notification: AchievementNotification = null

# Queue for multiple notifications
var notification_queue: Array[Dictionary] = []
var is_showing_notification: bool = false

# Canvas layer for notifications to ensure they appear on top
var notification_layer: CanvasLayer = null

func _ready():
	print("🏆 AchievementNotificationManager initialized")
	_create_notification_layer()

func _create_notification_layer():
	"""Create a dedicated CanvasLayer for notifications to ensure they appear on top"""
	notification_layer = CanvasLayer.new()
	notification_layer.name = "AchievementNotificationLayer"
	notification_layer.layer = 10  # High layer to appear on top
	add_child(notification_layer)
	print("🏆 Created dedicated notification layer with z-index 10")

func show_achievement(achievement_name: String, description: String):
	"""Show an achievement notification"""
	
	# Create notification data
	var notification_data = {
		"name": achievement_name,
		"description": description
	}
	
	# If currently showing a notification, queue this one
	if is_showing_notification:
		notification_queue.append(notification_data)
		print("🏆 Queued achievement: %s" % achievement_name)
		return
	
	# Show the notification immediately
	_display_notification(notification_data)

func _display_notification(notification_data: Dictionary):
	"""Actually display the notification"""
	is_showing_notification = true
	
	# Create and add the notification to our dedicated layer
	current_notification = ACHIEVEMENT_NOTIFICATION_SCENE.instantiate()
	notification_layer.add_child(current_notification)
	
	print("🏆 Added notification to layer, parent: ", current_notification.get_parent())
	
	# Show the achievement
	current_notification.show_achievement(
		notification_data.name, 
		notification_data.description
	)
	
	# Set up timer to clean up after animation
	var cleanup_timer = get_tree().create_timer(current_notification.show_duration + current_notification.fade_out_duration + 0.5)
	cleanup_timer.timeout.connect(_on_notification_finished)

func _on_notification_finished():
	"""Called when notification finishes displaying"""
	is_showing_notification = false
	
	# Clean up current notification
	if current_notification and is_instance_valid(current_notification):
		current_notification.queue_free()
		current_notification = null
	
	# Show next queued notification if any
	if notification_queue.size() > 0:
		var next_notification = notification_queue.pop_front()
		_display_notification(next_notification)

# Public API for different types of achievements
func show_milestone_achievement(milestone_name: String, bonus_description: String):
	"""Show a milestone achievement specifically"""
	show_achievement("Milestone: " + milestone_name, bonus_description)

func show_kill_milestone(kills: int, milestone_type: String):
	"""Show a kill milestone achievement"""
	var title = "Kill Milestone"
	var description = "%d %s defeated!" % [kills, milestone_type]
	show_achievement(title, description)

func show_level_up(new_level: int, stat_points_gained: int):
	"""Show a level up notification"""
	var title = "Level Up!"
	var description = "Reached level %d! (+%d stat points)" % [new_level, stat_points_gained]
	show_achievement(title, description)
