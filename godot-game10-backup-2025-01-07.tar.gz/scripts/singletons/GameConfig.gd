# GameConfig.gd - Configuration management singleton
# Purpose: Centralized access to game constants and settings
# Godot Version: 4.4.1
# Benefits: Live configuration updates, easy balancing, modding support

extends Node

signal config_loaded()
signal config_error(error_message: String)

var constants: GameConstants
var config_file_path: String = "res://data/game_constants.tres"
var is_loaded: bool = false

func _ready():
    load_configuration()

func load_configuration():
    # Load game constants from resource file with fallback
    print("🔧 GameConfig: Loading configuration...")
    
    if ResourceLoader.exists(config_file_path):
        var resource = load(config_file_path)
        if resource is GameConstants:
            constants = resource
            if constants.validate():
                is_loaded = true
                print("✅ GameConfig: Configuration loaded successfully")
                config_loaded.emit()
                return
            else:
                push_error("❌ GameConfig: Configuration validation failed")
                config_error.emit("Configuration validation failed")
        else:
            push_error("❌ GameConfig: Invalid resource type at " + config_file_path)
            config_error.emit("Invalid resource type")
    else:
        print("⚠️ GameConfig: No configuration file found, creating defaults")
    
    # Create default configuration
    create_default_configuration()

func create_default_configuration():
    # Create default configuration when resource is missing
    constants = GameConstants.new()
    if constants.validate():
        is_loaded = true
        print("✅ GameConfig: Default configuration created")
        config_loaded.emit()
        
        # Optionally save default configuration
        save_configuration()
    else:
        push_error("❌ GameConfig: Failed to create valid default configuration")
        config_error.emit("Failed to create defaults")

func save_configuration():
    # Save current configuration to resource file
    if not constants:
        push_error("❌ GameConfig: No configuration to save")
        return false
        
    var error = ResourceSaver.save(constants, config_file_path)
    if error == OK:
        print("💾 GameConfig: Configuration saved to " + config_file_path)
        return true
    else:
        push_error("❌ GameConfig: Failed to save configuration: " + str(error))
        return false

func reload_configuration():
    # Reload configuration from file - useful for live tuning
    load_configuration()

# CONVENIENT GETTER METHODS - Fast access to common values

# AI Performance
func get_ai_update_interval() -> float:
    return constants.ai_update_interval if is_loaded else 0.3

func get_player_cache_lifetime() -> float:
    return constants.player_cache_lifetime if is_loaded else 2.0

func get_ability_spam_prevention() -> float:
    return constants.ability_spam_prevention if is_loaded else 0.5

# Enemy Behavior
func get_separation_distance() -> float:
    return constants.enemy_separation_distance if is_loaded else 50.0

func get_separation_check_interval() -> float:
    return constants.separation_check_interval if is_loaded else 0.1

func get_contact_damage_immunity() -> float:
    return constants.contact_damage_immunity if is_loaded else 0.5

func get_damage_immunity_duration() -> float:
    return constants.damage_immunity_duration if is_loaded else 0.1

# Visual Effects
func get_damage_flash_duration() -> float:
    return constants.damage_flash_duration if is_loaded else 0.15

func get_death_fade_duration() -> float:
    return constants.death_fade_duration if is_loaded else 0.5

func get_warning_pulse_speed() -> float:
    return constants.warning_pulse_speed if is_loaded else 0.25

# Performance Settings
func get_max_simultaneous_enemies() -> int:
    return constants.max_simultaneous_enemies if is_loaded else 25

func get_particle_count_multiplier() -> float:
    return constants.particle_count_multiplier if is_loaded else 1.0

func get_logging_probability() -> float:
    return constants.logging_probability if is_loaded else 0.2

# Wave Scaling
func get_wave_multipliers(wave: int) -> Dictionary:
    # Get complete wave multipliers for enemy scaling
    if not is_loaded:
        return {"health": 1.2, "damage": 1.15, "speed": 1.08, "xp": 1.1}
    
    return {
        "health": constants.get_wave_health_multiplier(wave),
        "damage": constants.get_wave_damage_multiplier(wave),
        "speed": constants.get_wave_speed_multiplier(wave),
        "xp": 1.0 + (constants.xp_scaling_per_wave * (wave - 1))
    }

# Utility Methods
func should_log_event() -> bool:
    # Probabilistic logging check for performance
    return constants.should_log_event() if is_loaded else (randf() < 0.2)

func get_scaled_particle_count(base_count: int) -> int:
    # Get performance-adjusted particle count
    return constants.get_scaled_particle_count(base_count) if is_loaded else base_count

func is_debug_mode() -> bool:
    # Check if debug mode is enabled
    return constants.debug_mode_enabled if is_loaded else false

func get_spawn_distance_range() -> Vector2:
    # Get min/max spawn distances
    if not is_loaded:
        return Vector2(300.0, 600.0)
    return Vector2(constants.spawn_distance_min, constants.spawn_distance_max)

# LIVE TUNING SUPPORT

func set_ai_update_interval(value: float):
    # Live tuning: Update AI interval
    if is_loaded and value > 0:
        constants.ai_update_interval = value
        print("🔧 GameConfig: AI update interval set to ", value)

func set_particle_multiplier(value: float):
    # Live tuning: Adjust particle performance
    if is_loaded and value >= 0:
        constants.particle_count_multiplier = value
        print("🔧 GameConfig: Particle multiplier set to ", value)

func set_logging_probability(value: float):
    # Live tuning: Adjust logging frequency
    if is_loaded and value >= 0 and value <= 1:
        constants.logging_probability = value
        print("🔧 GameConfig: Logging probability set to ", value)

func toggle_debug_mode():
    # Toggle debug mode on/off
    if is_loaded:
        constants.debug_mode_enabled = not constants.debug_mode_enabled
        print("🔧 GameConfig: Debug mode ", "enabled" if constants.debug_mode_enabled else "disabled")

# MODDING SUPPORT

func apply_mod_configuration(mod_constants: Dictionary):
    # Apply configuration overrides from mods
    if not is_loaded:
        return false
        
    var applied_count = 0
    for key in mod_constants:
        if key in constants:
            var old_value = constants.get(key)
            constants.set(key, mod_constants[key])
            print("🔧 Mod Config: ", key, " changed from ", old_value, " to ", mod_constants[key])
            applied_count += 1
    
    if applied_count > 0:
        print("✅ Mod Config: Applied ", applied_count, " configuration overrides")
        return constants.validate()
    
    return true

func get_configuration_snapshot() -> Dictionary:
    # Get current configuration as dictionary for debugging/modding
    if not is_loaded:
        return {}
    
    var snapshot = {}
    var property_list = constants.get_property_list()
    for property in property_list:
        if property.usage & PROPERTY_USAGE_STORAGE:
            snapshot[property.name] = constants.get(property.name)
    
    return snapshot