# EnemySpawner.gd
# Purpose: Spawns enemies based on wave progression from WaveManager
# Godot Version: 4.4.1 compatible
# Dependencies: WaveManager, Enemy.tscn, GameEvents

extends Node
class_name EnemySpawner

# Spawning configuration
var enemy_scene: PackedScene
var spawn_timer: Timer
var spawn_radius: float = 400.0
var max_enemies: int = 20
var base_spawn_interval: float = 1.3

# State tracking
var active_enemies: Array[Node] = []
var spawning_enabled: bool = false
var current_spawn_interval: float

# Enemy rarity and spawn control system
var enemy_spawn_counts: Dictionary = {}
var total_enemies_spawned: int = 0

# Enemy spawn percentage caps and weights
var enemy_spawn_config: Dictionary = {
	"goblin": {"weight": 35, "max_percentage": 45},
	"skeleton": {"weight": 30, "max_percentage": 35},
	"orc": {"weight": 20, "max_percentage": 25},
	"wizard": {"weight": 10, "max_percentage": 15},
	"golem": {"weight": 5, "max_percentage": 7}
}

func _ready():
	name = "EnemySpawner"
	add_to_group("enemy_spawner")
	
	# Load enemy scene
	var enemy_path = "res://scenes/Enemy.tscn"
	if ResourceLoader.exists(enemy_path):
		enemy_scene = load(enemy_path)
		print("✅ Enemy scene loaded successfully")
	else:
		push_error("Enemy scene not found at " + enemy_path)
		print("❌ Enemy spawning disabled - scene not found")
		return
	
	# Setup spawn timer
	spawn_timer = Timer.new()
	spawn_timer.timeout.connect(_spawn_enemy)
	add_child(spawn_timer)
	
	# Connect to game events
	if GameEvents:
		GameEvents.enemy_died.connect(_on_enemy_died)
		print("✅ EnemySpawner connected to GameEvents")
	
	# Wait for WaveManager to initialize
	await get_tree().process_frame
	_update_spawn_settings()
	
	print("✅ EnemySpawner initialized")

func start_spawning():
	spawning_enabled = true
	_update_spawn_settings()
	if not spawn_timer.is_stopped():
		spawn_timer.stop()
	spawn_timer.start()
	print("🌊 Enemy spawning started")

func stop_spawning():
	spawning_enabled = false
	spawn_timer.stop()
	print("⏹️ Enemy spawning stopped")

func _update_spawn_settings():
	if not WaveManager:
		current_spawn_interval = base_spawn_interval
		return
	
	var wave_info = WaveManager.get_wave_info()
	
	# Increase spawn rate with higher waves (shorter intervals)
	var wave_multiplier = 1.0 - (wave_info.current_wave - 1) * 0.15
	wave_multiplier = max(wave_multiplier, 0.15)  # Minimum 0.15x interval (6.67x spawn rate)
	
	current_spawn_interval = base_spawn_interval * wave_multiplier
	
	if spawn_timer:
		spawn_timer.wait_time = current_spawn_interval
	
	print("🔄 Spawn interval updated: ", current_spawn_interval, "s (Wave ", wave_info.current_wave, ")")

func _spawn_enemy():
	if not spawning_enabled:
		return
	
	# Check enemy limit
	_clean_dead_enemies()
	if active_enemies.size() >= max_enemies:
		return
	
	# Get player reference
	var player = get_tree().get_first_node_in_group("players")
	if not player:
		print("⚠️ Cannot spawn enemy - player not found")
		return
	
	# Create enemy
	var enemy = enemy_scene.instantiate()
	if not enemy:
		push_error("Failed to instantiate enemy")
		return
	
	# Add to scene
	get_tree().current_scene.add_child(enemy)
	
	# Position around player
	var angle = randf() * TAU
	var distance = spawn_radius + randf() * 800.0  # Add variation 400-1200 units
	enemy.global_position = player.global_position + Vector2.from_angle(angle) * distance
	
	# Get wave scaling data
	var available_types = []
	var wave_multipliers = {}
	
	if WaveManager:
		available_types = WaveManager.get_available_enemy_types()
		wave_multipliers = WaveManager.get_current_enemy_multipliers()
	else:
		# Fallback enemy types
		available_types = ["goblin", "orc", "skeleton"]
		wave_multipliers = {"health": 1.0, "damage": 1.0, "speed": 1.0}
	
	# Select enemy type using weighted system with percentage caps
	var enemy_type = _select_weighted_enemy_type(available_types)
	if enemy_type == "":
		# Fallback to most common type if all caps reached
		enemy_type = "goblin"
	
	# Only log enemy type selection occasionally (every 10th spawn)
	if total_enemies_spawned % 10 == 0:
		print("🎲 Selected enemy type: %s (weight-based selection)" % enemy_type)
	
	# Set enemy type first
	enemy.enemy_type = enemy_type
	
	# Initialize enemy with wave scaling (correct argument order: wave_data, wave_num)
	if enemy.has_method("initialize_with_wave_scaling"):
		var current_wave = 1
		if WaveManager:
			current_wave = WaveManager.get_wave_info().current_wave
		enemy.initialize_with_wave_scaling(wave_multipliers, current_wave)
	else:
		push_error("Enemy missing initialize_with_wave_scaling method")
		enemy.queue_free()
		return
	
	# Track enemy
	active_enemies.append(enemy)
	
	# Update spawn tracking
	_update_spawn_statistics(enemy_type)
	
	# Minimal logging - only show every 10th spawn
	if active_enemies.size() % 10 == 1:
		print("👹 Spawned ", enemy_type, " (", active_enemies.size(), "/", max_enemies, " enemies)")

func _clean_dead_enemies():
	var valid_enemies: Array[Node] = []
	for enemy in active_enemies:
		if is_instance_valid(enemy) and not enemy.is_queued_for_deletion():
			valid_enemies.append(enemy)
	active_enemies = valid_enemies

func _on_enemy_died(_enemy_name: String, xp_awarded: int):
	# Clean up dead enemies from tracking
	_clean_dead_enemies()
	
	# Update spawn rate based on new wave progression
	if WaveManager:
		var old_wave = WaveManager.get_wave_info().current_wave
		
		# Let WaveManager handle the kill count update
		await get_tree().process_frame
		
		var new_wave = WaveManager.get_wave_info().current_wave
		if new_wave > old_wave:
			_update_spawn_settings()
			print("🌊 Wave advanced! Updating spawn rate")

# Public API
func get_active_enemy_count() -> int:
	_clean_dead_enemies()
	return active_enemies.size()

func set_spawn_radius(radius: float):
	spawn_radius = max(radius, 200.0)  # Minimum radius
	print("📍 Spawn radius set to ", spawn_radius)

func set_max_enemies(count: int):
	max_enemies = max(count, 1)  # Minimum 1 enemy
	print("👹 Max enemies set to ", max_enemies)

func set_base_spawn_interval(interval: float):
	base_spawn_interval = max(interval, 0.1)  # Minimum 0.1 seconds
	_update_spawn_settings()
	print("⏰ Base spawn interval set to ", base_spawn_interval, "s")

func clear_all_enemies():
	for enemy in active_enemies:
		if is_instance_valid(enemy):
			enemy.queue_free()
	active_enemies.clear()
	print("💀 All enemies cleared")

func get_debug_info() -> String:
	_clean_dead_enemies()
	var info = "EnemySpawner Debug Info:\n"
	info += "- Spawning Enabled: " + str(spawning_enabled) + "\n"
	info += "- Active Enemies: " + str(active_enemies.size()) + "/" + str(max_enemies) + "\n"
	info += "- Spawn Interval: " + str(current_spawn_interval) + "s\n"
	info += "- Spawn Radius: " + str(spawn_radius) + "\n"
	info += "- Enemy Scene Loaded: " + str(enemy_scene != null) + "\n"
	
	if WaveManager:
		var wave_info = WaveManager.get_wave_info()
		info += "- Current Wave: " + str(wave_info.current_wave) + "\n"
		info += "- Available Enemy Types: " + str(WaveManager.get_available_enemy_types().size()) + "\n"
	
	return info

# Validation method
func validate_setup() -> bool:
	var checks = [
		enemy_scene != null,
		spawn_timer != null,
		WaveManager != null,
		GameEvents != null
	]
	
	var passed = 0
	for check in checks:
		if check:
			passed += 1
	
	var success = passed == checks.size()
	print("🔍 EnemySpawner validation: " + str(passed) + "/" + str(checks.size()) + " " + ("PASSED" if success else "FAILED"))
	return success

# === WEIGHTED SPAWN SYSTEM ===

func _select_weighted_enemy_type(available_types: Array) -> String:
	# Select enemy type using weighted system with percentage caps
	# Filter out types that have reached their caps
	var eligible_types: Array = []
	var eligible_weights: Array = []
	
	for enemy_type in available_types:
		if not enemy_type in enemy_spawn_config:
			continue  # Skip unknown enemy types
		
		# Check if this type has reached its percentage cap
		var current_percentage = _get_enemy_spawn_percentage(enemy_type)
		var max_percentage = enemy_spawn_config[enemy_type].max_percentage
		
		if current_percentage < max_percentage:
			eligible_types.append(enemy_type)
			eligible_weights.append(enemy_spawn_config[enemy_type].weight)
	
	# If no types are eligible (all caps reached), allow all types with reduced weights
	if eligible_types.is_empty():
		for enemy_type in available_types:
			if enemy_type in enemy_spawn_config:
				eligible_types.append(enemy_type)
				# Use 20% of normal weight when over cap
				eligible_weights.append(max(1, enemy_spawn_config[enemy_type].weight * 0.2))
	
	# Perform weighted selection
	if eligible_types.is_empty():
		return ""  # No valid types
	
	# Calculate cumulative weights
	var total_weight = 0
	for weight in eligible_weights:
		total_weight += weight
	
	var random_value = randf() * total_weight
	var cumulative_weight = 0
	
	for i in range(eligible_types.size()):
		cumulative_weight += eligible_weights[i]
		if random_value <= cumulative_weight:
			return eligible_types[i]
	
	# Fallback to first eligible type
	return eligible_types[0]

func _get_enemy_spawn_percentage(enemy_type: String) -> float:
	# Get current spawn percentage for enemy type
	if total_enemies_spawned == 0:
		return 0.0
	
	var count = enemy_spawn_counts.get(enemy_type, 0)
	return (float(count) / float(total_enemies_spawned)) * 100.0

func _update_spawn_statistics(enemy_type: String):
	# Update spawn statistics for enemy type
	if not enemy_type in enemy_spawn_counts:
		enemy_spawn_counts[enemy_type] = 0
	
	enemy_spawn_counts[enemy_type] += 1
	total_enemies_spawned += 1
	
	# Log spawn statistics every 20 spawns
	if total_enemies_spawned % 20 == 0:
		_log_spawn_statistics()

func _log_spawn_statistics():
	# Log current spawn distribution
	print("📊 Enemy Spawn Distribution (Total: %d):" % total_enemies_spawned)
	for enemy_type in enemy_spawn_counts.keys():
		var count = enemy_spawn_counts[enemy_type]
		var percentage = _get_enemy_spawn_percentage(enemy_type)
		var max_percentage = enemy_spawn_config.get(enemy_type, {}).get("max_percentage", 100)
		var status = "✅" if percentage < max_percentage else "🔶"
		print("  %s %s: %d (%.1f%% / %.0f%% max)" % [status, enemy_type.capitalize(), count, percentage, max_percentage])

# Public API for spawn statistics
func get_spawn_statistics() -> Dictionary:
	# Get detailed spawn statistics
	var stats = {
		"total_spawned": total_enemies_spawned,
		"enemy_counts": enemy_spawn_counts.duplicate(),
		"enemy_percentages": {},
		"cap_status": {}
	}
	
	for enemy_type in enemy_spawn_counts.keys():
		stats.enemy_percentages[enemy_type] = _get_enemy_spawn_percentage(enemy_type)
		var max_percentage = enemy_spawn_config.get(enemy_type, {}).get("max_percentage", 100)
		stats.cap_status[enemy_type] = {
			"current": stats.enemy_percentages[enemy_type],
			"max": max_percentage,
			"at_cap": stats.enemy_percentages[enemy_type] >= max_percentage
		}
	
	return stats

func reset_spawn_statistics():
	# Reset spawn statistics (useful for testing)
	enemy_spawn_counts.clear()
	total_enemies_spawned = 0
	print("🗑️ Spawn statistics reset")
