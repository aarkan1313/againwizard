# WaveManager.gd
# Purpose: Wave progression through kill count with enemy scaling
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: GameEvents, GameManager, StatModifier
# API References: Official Godot singleton and signal documentation

extends Node

# Wave progression signals
signal wave_started(wave_number: int, enemy_multipliers: Dictionary)
signal kill_milestone_reached(kills: int, milestone_type: String)
signal rare_enemy_unlocked(enemy_type: String, wave: int)
signal wave_progress_updated(current_kills: int, target_kills: int, percentage: float)

# Wave progression
var current_wave: int = 1
var total_kills: int = 0
var kills_in_current_wave: int = 0

# Kill thresholds for wave advancement
var wave_kill_thresholds: Array[int] = [
	25,   # Wave 2 at 25 kills
	50,   # Wave 3 at 50 kills  
	100,  # Wave 4 at 100 kills
	150,  # Wave 5 at 150 kills
	200,  # Wave 6 at 200 kills
	300,  # Wave 7 at 300 kills
	400,  # Wave 8 at 400 kills
	500,  # Wave 9 at 500 kills
	750,  # Wave 10 at 750 kills
	1000  # Wave 11 at 1000 kills
]

# Enemy scaling per wave - THIS MAKES WAVES HARDER
var health_scaling: float = 0.20    # +20% health per wave
var damage_scaling: float = 0.15    # +15% damage per wave
var speed_scaling: float = 0.08     # +8% speed per wave

# Current wave multipliers applied to enemies
var current_health_multiplier: float = 1.0
var current_damage_multiplier: float = 1.0
var current_speed_multiplier: float = 1.0

# Milestone tracking
var awarded_milestones: Array[String] = []

func _ready():
	print("🌊 WaveManager initialized - Kill-based wave progression active")
	connect_to_kill_events()
	calculate_initial_multipliers()

func connect_to_kill_events():
	if GameEvents:
		if not GameEvents.enemy_died.is_connected(_on_enemy_killed):
			GameEvents.enemy_died.connect(_on_enemy_killed)
		print("✅ WaveManager connected to GameEvents.enemy_died")
	else:
		push_error("WaveManager: GameEvents singleton not found!")

func calculate_initial_multipliers():
	# Calculate multipliers for wave 1
	current_health_multiplier = 1.0 + (current_wave - 1) * health_scaling
	current_damage_multiplier = 1.0 + (current_wave - 1) * damage_scaling
	current_speed_multiplier = 1.0 + (current_wave - 1) * speed_scaling
	
	print("🌊 Wave ", current_wave, " multipliers calculated:")
	print("   Health: ", current_health_multiplier, "x")
	print("   Damage: ", current_damage_multiplier, "x")
	print("   Speed: ", current_speed_multiplier, "x")

# === KILL TRACKING ===

func _on_enemy_killed(enemy_type: String, _xp_reward: int):
	total_kills += 1
	kills_in_current_wave += 1
	
	print("💀 Kill #", total_kills, " (Wave ", current_wave, ") - ", enemy_type)
	
	# Check for wave advancement
	check_wave_advancement()
	
	# Check for kill milestones (separate from wave progression)
	check_kill_milestones()
	
	# Update progress
	emit_progress_update()

func emit_progress_update():
	if current_wave <= wave_kill_thresholds.size():
		var target_kills = wave_kill_thresholds[current_wave - 1]
		var progress_percentage = get_wave_progress_percentage()
		wave_progress_updated.emit(total_kills, target_kills, progress_percentage)

# === WAVE PROGRESSION ===

func check_wave_advancement():
	if current_wave <= wave_kill_thresholds.size():
		var kills_needed = wave_kill_thresholds[current_wave - 1]
		
		if total_kills >= kills_needed:
			advance_wave()

func advance_wave():
	current_wave += 1
	kills_in_current_wave = 0
	
	# Calculate new enemy multipliers - ENEMIES GET STRONGER
	current_health_multiplier = 1.0 + (current_wave - 1) * health_scaling
	current_damage_multiplier = 1.0 + (current_wave - 1) * damage_scaling
	current_speed_multiplier = 1.0 + (current_wave - 1) * speed_scaling
	
	# Check for new enemy type unlocks
	check_enemy_unlocks()
	
	# Emit wave started event
	var multipliers = get_current_enemy_multipliers()
	wave_started.emit(current_wave, multipliers)
	
	print("🌊 WAVE ", current_wave, " BEGINS!")
	print("💪 Enemy scaling - Health: ", current_health_multiplier, "x, Damage: ", current_damage_multiplier, "x, Speed: ", current_speed_multiplier, "x")
	
	# Show next wave target if there is one
	if current_wave <= wave_kill_thresholds.size():
		var next_target = wave_kill_thresholds[current_wave - 1]
		print("🎯 Next wave at ", next_target, " total kills")

func check_enemy_unlocks():
	# Enemy types unlock at specific waves, not kill counts
	match current_wave:
		3:  # Wave 3 (50 kills) - Wizard unlocked
			rare_enemy_unlocked.emit("wizard", current_wave)
			print("✨ NEW ENEMY TYPE: Dark Wizard (Wave 3)")
		
		5:  # Wave 5 (150 kills) - Golem unlocked
			rare_enemy_unlocked.emit("golem", current_wave)
			print("✨ NEW ENEMY TYPE: Stone Golem (Wave 5)")
		
		# Elemental enemy removed

# === MILESTONE SYSTEM ===

func check_kill_milestones():
	# Milestones can happen independent of waves
	# These provide small player bonuses but don't drive progression
	
	var milestone_to_award = ""
	var description = ""
	
	match total_kills:
		10:
			if not "first_blood" in awarded_milestones:
				milestone_to_award = "first_blood"
				description = "Extra starting health"
		
		50:
			if not "apprentice_slayer" in awarded_milestones:
				milestone_to_award = "apprentice_slayer"
				description = "Mana regeneration bonus"
		
		100:
			if not "monster_hunter" in awarded_milestones:
				milestone_to_award = "monster_hunter"
				description = "Critical chance increase"
		
		250:
			if not "death_dealer" in awarded_milestones:
				milestone_to_award = "death_dealer"
				description = "Spell damage bonus"
		
		500:
			if not "destroyer" in awarded_milestones:
				milestone_to_award = "destroyer"
				description = "Major stat boost"
		
		1000:
			if not "legend" in awarded_milestones:
				milestone_to_award = "legend"
				description = "Ultimate power unlock"
	
	if milestone_to_award != "":
		award_kill_milestone(milestone_to_award, description)

func award_kill_milestone(milestone_name: String, description: String):
	awarded_milestones.append(milestone_name)
	kill_milestone_reached.emit(total_kills, milestone_name)
	
	# Apply player bonuses through stat system
	apply_milestone_stat_bonus(milestone_name)
	
	print("🏆 MILESTONE: ", milestone_name, " (", total_kills, " kills) - ", description)

func apply_milestone_stat_bonus(milestone_name: String):
	# Get player's stat sheet
	var player = get_player_reference()
	if not player or not player.has_method("get_stat_sheet"):
		push_warning("WaveManager: Cannot apply milestone bonus - no player stat sheet")
		return
	
	var stat_sheet = player.get_stat_sheet()
	if not stat_sheet:
		push_warning("WaveManager: Cannot apply milestone bonus - stat sheet is null")
		return
	
	# Apply milestone bonus through PlayerStatSheet
	if stat_sheet.has_method("apply_milestone_bonus"):
		stat_sheet.apply_milestone_bonus(milestone_name)
	else:
		push_warning("WaveManager: PlayerStatSheet missing apply_milestone_bonus method")

func get_player_reference() -> Node:
	# Try GameManager first
	if GameManager and GameManager.has_method("get_player"):
		return GameManager.get_player()
	elif GameManager and GameManager.player_reference:
		return GameManager.player_reference
	
	# Fallback to scene tree search
	var players = get_tree().get_nodes_in_group("players")
	if players.size() > 0:
		return players[0]
	
	return null

# === API FOR OTHER SYSTEMS ===

func get_current_enemy_multipliers() -> Dictionary:
	return {
		"health": current_health_multiplier,
		"damage": current_damage_multiplier,
		"speed": current_speed_multiplier,
		"wave": current_wave
	}

func get_kills_to_next_wave() -> int:
	if current_wave > wave_kill_thresholds.size():
		return 0
	return wave_kill_thresholds[current_wave - 1] - total_kills

func get_wave_progress_percentage() -> float:
	if current_wave > wave_kill_thresholds.size():
		return 100.0
	
	var current_target = wave_kill_thresholds[current_wave - 1]
	var previous_target = wave_kill_thresholds[current_wave - 2] if current_wave > 1 else 0
	
	# Prevent division by zero
	var denominator = current_target - previous_target
	if denominator <= 0:
		return 100.0
	
	var progress = float(total_kills - previous_target) / float(denominator)
	return clamp(progress * 100.0, 0.0, 100.0)

func get_available_enemy_types() -> Array[String]:
	# Enemy types unlock based on current wave
	var available: Array[String] = ["goblin", "orc", "skeleton"]  # Always available
	
	if current_wave >= 3:
		available.append("wizard")
	
	if current_wave >= 5:
		available.append("golem")
	
	# Elemental enemy removed
	
	return available

func get_current_wave() -> int:
	return current_wave

func set_current_wave(wave: int, kills_in_wave: int = 0) -> void:
	# Restore wave state from save data
	current_wave = max(1, wave)
	kills_in_current_wave = max(0, kills_in_wave)
	
	# Don't recalculate total kills - it will be set separately by SaveManager
	# The SaveManager knows the actual total kills from the save file
	
	# Recalculate multipliers for current wave
	calculate_initial_multipliers()
	
	print("🌊 WaveManager.set_current_wave() called: Wave ", current_wave, " with ", kills_in_current_wave, " kills this wave")
	
	# Emit signals to refresh UI after load
	var multipliers = {
		"health": current_health_multiplier,
		"damage": current_damage_multiplier,
		"speed": current_speed_multiplier
	}
	wave_started.emit(current_wave, multipliers)
	emit_progress_update()

func get_total_kills() -> int:
	return total_kills

func set_total_kills(kills: int) -> void:
	# Set total kills (used by save system)
	total_kills = max(0, kills)
	print("🌊 WaveManager total kills set to: ", total_kills)

func get_wave_info() -> Dictionary:
	return {
		"current_wave": current_wave,
		"total_kills": total_kills,
		"kills_this_wave": kills_in_current_wave,
		"kills_to_next": get_kills_to_next_wave(),
		"progress_percentage": get_wave_progress_percentage(),
		"available_enemies": get_available_enemy_types(),
		"awarded_milestones": awarded_milestones.duplicate()
	}

# === WAVE SCALING CONFIGURATION ===

func set_scaling_rates(health: float, damage: float, speed: float):
	health_scaling = health
	damage_scaling = damage
	speed_scaling = speed
	
	# Recalculate current multipliers
	calculate_initial_multipliers()
	print("🔧 Wave scaling rates updated")

func get_scaling_rates() -> Dictionary:
	return {
		"health": health_scaling,
		"damage": damage_scaling,
		"speed": speed_scaling
	}

# === DEBUG AND TESTING ===

func debug_add_kills(kill_count: int):
	print("🐛 DEBUG: Adding ", kill_count, " kills")
	for i in range(kill_count):
		_on_enemy_killed("debug_enemy", 1)

func debug_set_wave(wave_number: int):
	print("🐛 DEBUG: Setting wave to ", wave_number)
	current_wave = wave_number
	calculate_initial_multipliers()

func get_debug_info() -> String:
	var info = "=== WaveManager Debug Info ===\n"
	info += "Current Wave: " + str(current_wave) + "\n"
	info += "Total Kills: " + str(total_kills) + "\n"
	info += "Kills This Wave: " + str(kills_in_current_wave) + "\n"
	info += "Kills to Next Wave: " + str(get_kills_to_next_wave()) + "\n"
	info += "Progress: " + str(get_wave_progress_percentage()).pad_decimals(1) + "%\n"
	info += "Enemy Multipliers:\n"
	info += "  Health: " + str(current_health_multiplier) + "x\n"
	info += "  Damage: " + str(current_damage_multiplier) + "x\n"
	info += "  Speed: " + str(current_speed_multiplier) + "x\n"
	info += "Available Enemy Types: " + str(get_available_enemy_types()) + "\n"
	info += "Awarded Milestones: " + str(awarded_milestones)
	return info
