# SpellData.gd
# Purpose: Resource class for spell definitions and validation
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: Godot Resource system
# API References: Official Godot Resource documentation

extends Resource
class_name SpellData

@export var spell_name: String = ""
@export var base_damage: float = 25.0
@export var mana_cost: int = 10
@export var projectile_speed: float = 300.0
@export var projectile_range: float = 600.0
@export var cooldown_duration: float = 1.0

# Visual/audio references
@export var projectile_scene: PackedScene
@export var projectile_texture: Texture2D
@export var cast_sound: AudioStream

func validate() -> bool:
	var is_valid = true
	
	if spell_name == "":
		push_error("SpellData validation failed: spell_name is empty")
		is_valid = false
	
	if base_damage == 0:
		push_error("SpellData validation failed: base_damage cannot be 0, got " + str(base_damage))
		is_valid = false
	
	if mana_cost <= 0:
		push_error("SpellData validation failed: mana_cost must be > 0, got " + str(mana_cost))
		is_valid = false
	
	# Allow healing spells (negative damage) to have 0 speed and range
	if base_damage > 0:  # Only validate for damage spells
		if projectile_speed <= 0:
			push_error("SpellData validation failed: projectile_speed must be > 0 for damage spells, got " + str(projectile_speed))
			is_valid = false
		
		if projectile_range <= 0:
			push_error("SpellData validation failed: projectile_range must be > 0 for damage spells, got " + str(projectile_range))
			is_valid = false
	else:  # Healing spells can have 0 speed and range
		if projectile_speed < 0:
			push_error("SpellData validation failed: projectile_speed cannot be negative, got " + str(projectile_speed))
			is_valid = false
		
		if projectile_range < 0:
			push_error("SpellData validation failed: projectile_range cannot be negative, got " + str(projectile_range))
			is_valid = false
	
	if cooldown_duration < 0:
		push_error("SpellData validation failed: cooldown_duration must be >= 0, got " + str(cooldown_duration))
		is_valid = false
	
	if is_valid:
		print("✅ SpellData validation passed for spell: " + spell_name)
	
	return is_valid

func get_debug_info() -> String:
	return "Spell: " + spell_name + " | Damage: " + str(base_damage) + " | Mana: " + str(mana_cost) + " | Speed: " + str(projectile_speed) + " | Range: " + str(projectile_range) + " | Cooldown: " + str(cooldown_duration)
