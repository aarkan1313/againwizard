# ParserValidator.gd
# Purpose: Prevent duplicate class_name declarations that cause parser errors
# Run this before committing to verify no class conflicts exist

extends Node

func _ready():
	print("🔍 Parser Validation: Checking for duplicate class declarations...")
	validate_class_declarations()

func validate_class_declarations():
	var class_declarations = {}
	var script_files = []
	
	# Find all .gd files in the project
	_find_gd_files("res://", script_files)
	
	for file_path in script_files:
		var file = FileAccess.open(file_path, FileAccess.READ)
		if file:
			var line_number = 0
			while not file.eof_reached():
				line_number += 1
				var line = file.get_line().strip_edges()
				if line.begins_with("class_name "):
					var class_name = line.substr(11).strip_edges()
					
					if class_declarations.has(class_name):
						push_error("🚨 DUPLICATE CLASS FOUND!")
						push_error("Class '" + class_name + "' declared in:")
						push_error("  1. " + class_declarations[class_name])
						push_error("  2. " + file_path + ":" + str(line_number))
						push_error("This will cause parser error: 'Class hides a global script class'")
						return
					else:
						class_declarations[class_name] = file_path + ":" + str(line_number)
			file.close()
	
	print("✅ Parser Validation PASSED")
	print("Found " + str(class_declarations.size()) + " unique class declarations:")
	
	var class_names = class_declarations.keys()
	class_names.sort()
	for class_name in class_names:
		print("  - " + class_name + " in " + class_declarations[class_name])

func _find_gd_files(dir_path: String, file_list: Array):
	var dir = DirAccess.open(dir_path)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			var full_path = dir_path + "/" + file_name
			if dir.current_is_dir() and not file_name.begins_with("."):
				_find_gd_files(full_path, file_list)
			elif file_name.ends_with(".gd"):
				file_list.append(full_path)
			file_name = dir.get_next()
		dir.list_dir_end()