extends Node
# QualityGate.gd - Continuous quality assurance system
# Purpose: Monitors system health during development and catches regressions
# Godot Version: 4.4.1 compatible

# Quality monitoring settings
var monitoring_enabled: bool = true  # Enable monitoring with smart startup handling
var monitoring_interval: float = 30.0  # seconds
var quality_history: Array = []
var max_history_entries: int = 50

# Quality thresholds (more reasonable for development)
const ERROR_THRESHOLD = 20
const WARNING_THRESHOLD = 50
const FPS_THRESHOLD = 25  # Lower threshold to avoid startup interference
const MEMORY_GROWTH_THRESHOLD = 100.0  # MB

# Monitoring timer
var monitor_timer: Timer
var baseline_memory: float = 0.0
var last_check_time: float = 0.0
var startup_grace_period: float = 10.0  # Wait 10 seconds after startup
var startup_time: float = 0.0

# Quality status tracking
var current_quality_level: String = "UNKNOWN"
var quality_issues: Array = []
var consecutive_failures: int = 0

enum QualityLevel {
	EXCELLENT,
	GOOD,
	FAIR,
	POOR,
	CRITICAL
}

func _ready() -> void:
	# Ensure quality monitoring works even when paused
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	print("🔒 QualityGate initialized - Continuous monitoring ready")
	
	# Set up monitoring timer
	monitor_timer = Timer.new()
	monitor_timer.wait_time = monitoring_interval
	monitor_timer.timeout.connect(_run_quality_check)
	monitor_timer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(monitor_timer)
	
	# Take baseline measurement
	_establish_baseline()
	
	# Record startup time for grace period
	startup_time = Time.get_time_dict_from_system().hour * 3600 + Time.get_time_dict_from_system().minute * 60 + Time.get_time_dict_from_system().second
	
	# Start monitoring with startup grace period
	if monitoring_enabled:
		print("🔍 Quality monitoring starting (10 second startup grace period)")
		start_monitoring()

func start_monitoring() -> void:
	if not monitoring_enabled:
		monitoring_enabled = true
		print("🔍 Quality monitoring started")
	
	if UnifiedDebugSystem:
		if UnifiedDebugSystem:
			UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.TESTING, "Quality monitoring started", "QualityGate")
	
	monitor_timer.start()
	_run_quality_check()  # Run initial check

func stop_monitoring() -> void:
	monitoring_enabled = false
	monitor_timer.stop()
	print("⏸️ Quality monitoring stopped")
	
	if UnifiedDebugSystem:
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.TESTING, "Quality monitoring stopped", "QualityGate")

func _establish_baseline() -> void:
	baseline_memory = _get_memory_usage()
	last_check_time = Time.get_time_dict_from_system().hour * 3600 + Time.get_time_dict_from_system().minute * 60 + Time.get_time_dict_from_system().second
	print("📊 Quality baseline established - Memory: " + str(baseline_memory) + " MB")

func _run_quality_check() -> void:
	if not monitoring_enabled:
		return
	
	# Skip checks during startup grace period
	var current_time = Time.get_time_dict_from_system().hour * 3600 + Time.get_time_dict_from_system().minute * 60 + Time.get_time_dict_from_system().second
	if current_time - startup_time < startup_grace_period:
		print("🔍 Quality check skipped (startup grace period)")
		return
	
	var check_result = _perform_comprehensive_check()
	_record_quality_check(check_result)
	_analyze_quality_trends()
	
	# Alert on quality degradation
	if check_result.quality_level == QualityLevel.POOR or check_result.quality_level == QualityLevel.CRITICAL:
		consecutive_failures += 1
		_handle_quality_alert(check_result)
	else:
		consecutive_failures = 0

func _perform_comprehensive_check() -> Dictionary:
	var check_result = {
		"timestamp": Time.get_datetime_string_from_system(),
		"fps": Engine.get_frames_per_second(),
		"memory_usage": _get_memory_usage(),
		"memory_growth": 0.0,
		"error_count": 0,
		"warning_count": 0,
		"quality_level": QualityLevel.EXCELLENT,
		"issues": []
	}
	
	# Calculate memory growth
	check_result.memory_growth = check_result.memory_usage - baseline_memory
	
	# Get error/warning counts from Logger
	if UnifiedDebugSystem:
		check_result.error_count = UnifiedDebugSystem.error_count
		check_result.warning_count = UnifiedDebugSystem.warning_count
	
	# Assess FPS
	if check_result.fps < 30:
		check_result.issues.append("Critical FPS: " + str(check_result.fps))
		check_result.quality_level = QualityLevel.CRITICAL
	elif check_result.fps < FPS_THRESHOLD:
		check_result.issues.append("Low FPS: " + str(check_result.fps))
		check_result.quality_level = max(check_result.quality_level, QualityLevel.POOR)
	
	# Assess error counts
	if check_result.error_count > ERROR_THRESHOLD:
		check_result.issues.append("High error count: " + str(check_result.error_count))
		check_result.quality_level = max(check_result.quality_level, QualityLevel.POOR)
	
	if check_result.warning_count > WARNING_THRESHOLD:
		check_result.issues.append("High warning count: " + str(check_result.warning_count))
		check_result.quality_level = max(check_result.quality_level, QualityLevel.FAIR)
	
	# Assess memory growth
	if check_result.memory_growth > MEMORY_GROWTH_THRESHOLD:
		check_result.issues.append("Memory growth: +" + str(check_result.memory_growth) + " MB")
		check_result.quality_level = max(check_result.quality_level, QualityLevel.FAIR)
	
	# Additional system checks
	_check_autoload_health(check_result)
	_check_scene_stability(check_result)
	_check_input_responsiveness(check_result)
	
	# Final quality level assessment
	if check_result.issues.is_empty() and check_result.quality_level == QualityLevel.EXCELLENT:
		current_quality_level = "EXCELLENT"
	elif check_result.quality_level <= QualityLevel.GOOD:
		current_quality_level = "GOOD"
	elif check_result.quality_level <= QualityLevel.FAIR:
		current_quality_level = "FAIR"
	elif check_result.quality_level <= QualityLevel.POOR:
		current_quality_level = "POOR"
	else:
		current_quality_level = "CRITICAL"
	
	quality_issues = check_result.issues.duplicate()
	
	return check_result

func _check_autoload_health(check_result: Dictionary) -> void:
	# Verify critical singletons are still accessible
	var critical_autoloads = [
		{"name": "GameEvents", "ref": GameEvents},
		{"name": "GameManager", "ref": GameManager},
		{"name": "InputHandler", "ref": InputHandler},
		{"name": "Logger", "ref": Logger}
	]
	
	for autoload in critical_autoloads:
		if not autoload.ref:
			check_result.issues.append("Autoload failure: " + autoload.name + " not accessible")
			check_result.quality_level = QualityLevel.CRITICAL

func _check_scene_stability(check_result: Dictionary) -> void:
	var main_scene = get_tree().current_scene
	if not main_scene:
		check_result.issues.append("No current scene loaded")
		check_result.quality_level = QualityLevel.CRITICAL
		return
	
	# Check for scene integrity
	if main_scene.scene_file_path.is_empty():
		check_result.issues.append("Scene has no file path")
		check_result.quality_level = max(check_result.quality_level, QualityLevel.POOR)

func _check_input_responsiveness(check_result: Dictionary) -> void:
	if not InputHandler:
		return
	
	# Basic input system check
	var movement_vector = InputHandler.get_movement_vector()
	if not movement_vector is Vector2:
		check_result.issues.append("Input system returning invalid data")
		check_result.quality_level = max(check_result.quality_level, QualityLevel.POOR)

func _record_quality_check(check_result: Dictionary) -> void:
	quality_history.append(check_result)
	
	# Trim history if needed
	while quality_history.size() > max_history_entries:
		quality_history.pop_front()
	
	# Log quality status
	var quality_text = QualityLevel.keys()[check_result.quality_level]
	print("📊 Quality Check: " + quality_text + " (" + str(check_result.fps) + " FPS, " + str(check_result.error_count) + " errors)")
	
	if UnifiedDebugSystem and check_result.issues.size() > 0:
		for issue in check_result.issues:
			UnifiedDebugSystem.log_warning_internal(UnifiedDebugSystem.LogCategory.TESTING, "Quality issue detected: " + issue, "QualityGate")

func _analyze_quality_trends() -> void:
	if quality_history.size() < 3:
		return  # Need at least 3 data points for trend analysis
	
	# Check for declining performance trends
	var recent_fps = []
	var recent_errors = []
	var check_count = min(5, quality_history.size())
	
	for i in range(quality_history.size() - check_count, quality_history.size()):
		recent_fps.append(quality_history[i].fps)
		recent_errors.append(quality_history[i].error_count)
	
	# Analyze FPS trend
	var fps_declining = true
	for i in range(1, recent_fps.size()):
		if recent_fps[i] >= recent_fps[i-1]:
			fps_declining = false
			break
	
	if fps_declining and recent_fps.size() >= 3:
		print("⚠️ Quality Alert: FPS consistently declining over " + str(recent_fps.size()) + " checks")
		if UnifiedDebugSystem:
			UnifiedDebugSystem.log_warning_internal(UnifiedDebugSystem.LogCategory.PERFORMANCE, "FPS trend declining: " + str(recent_fps), "QualityGate")
	
	# Analyze error trend
	var errors_increasing = true
	for i in range(1, recent_errors.size()):
		if recent_errors[i] <= recent_errors[i-1]:
			errors_increasing = false
			break
	
	if errors_increasing and recent_errors.size() >= 3:
		print("⚠️ Quality Alert: Error count consistently increasing")
		if UnifiedDebugSystem:
			UnifiedDebugSystem.log_warning_internal(UnifiedDebugSystem.LogCategory.TESTING, "Error trend increasing: " + str(recent_errors), "QualityGate")

func _handle_quality_alert(check_result: Dictionary) -> void:
	var quality_text = QualityLevel.keys()[check_result.quality_level]
	
	print("🚨 QUALITY ALERT: System quality is " + quality_text)
	print("   Issues found:")
	for issue in check_result.issues:
		print("   - " + issue)
	
	if consecutive_failures >= 3:
		print("🚨 CRITICAL: " + str(consecutive_failures) + " consecutive quality failures!")
		if UnifiedDebugSystem:
			UnifiedDebugSystem.log_error_internal(UnifiedDebugSystem.LogCategory.TESTING, "Critical quality degradation: " + str(consecutive_failures) + " consecutive failures", "QualityGate")
	
	# Consider automatic actions for critical issues
	if check_result.quality_level == QualityLevel.CRITICAL:
		_handle_critical_quality_failure(check_result)

func _handle_critical_quality_failure(check_result: Dictionary) -> void:
	print("🚨 CRITICAL QUALITY FAILURE - Taking emergency actions...")
	
	# Log critical failure
	if UnifiedDebugSystem:
		UnifiedDebugSystem.log_error_internal(UnifiedDebugSystem.LogCategory.TESTING, "Critical quality failure detected", "QualityGate")
		print("📝 Current error summary:")
		print(UnifiedDebugSystem.get_error_summary())
	
	# Stop monitoring temporarily to prevent spam
	stop_monitoring()
	
	# Schedule restart of monitoring
	await get_tree().create_timer(60.0).timeout  # Wait 1 minute
	start_monitoring()

# Public interface functions
func get_current_quality_status() -> Dictionary:
	return {
		"quality_level": current_quality_level,
		"issues": quality_issues.duplicate(),
		"monitoring_enabled": monitoring_enabled,
		"consecutive_failures": consecutive_failures,
		"last_check": quality_history[-1] if quality_history.size() > 0 else null
	}

func get_quality_report() -> String:
	var report = "🔒 QUALITY GATE REPORT\n"
	report += "=====================\n\n"
	report += "Current Status: " + current_quality_level + "\n"
	report += "Monitoring: " + ("ENABLED" if monitoring_enabled else "DISABLED") + "\n"
	report += "Consecutive Failures: " + str(consecutive_failures) + "\n\n"
	report += "Recent Issues:\n"
	report += ("\n".join(quality_issues) if quality_issues.size() > 0 else "None") + "\n\n"
	report += "Quality History (last 5 checks):\n"
	report += _format_recent_history() + "\n\n"
	report += "Memory Usage:\n"
	report += "- Baseline: " + str(baseline_memory) + " MB\n"
	report += "- Current: " + str(_get_memory_usage()) + " MB\n"
	report += "- Growth: " + str(_get_memory_usage() - baseline_memory) + " MB\n"
	
	return report

func _format_recent_history() -> String:
	if quality_history.is_empty():
		return "No history available"
	
	var formatted_history = ""
	var recent_count = min(5, quality_history.size())
	
	for i in range(quality_history.size() - recent_count, quality_history.size()):
		var entry = quality_history[i]
		var quality_text = QualityLevel.keys()[entry.quality_level]
		formatted_history += "- " + quality_text + " (FPS: " + str(entry.fps) + ", Errors: " + str(entry.error_count) + ")\n"
	
	return formatted_history

func _get_memory_usage() -> float:
	# Get memory usage in MB (Godot 4.4.1 compatible)
	var memory_info = OS.get_memory_info()
	if memory_info.has("physical"):
		return memory_info.physical / 1024.0 / 1024.0
	else:
		# Fallback - return a simple estimate
		return 100.0  # Default placeholder value

# Testing and validation functions
func run_manual_quality_check() -> Dictionary:
	print("🔍 Running manual quality check...")
	var result = _perform_comprehensive_check()
	_record_quality_check(result)
	
	print("📊 Manual Quality Check Results:")
	print("   Quality Level: " + QualityLevel.keys()[result.quality_level])
	print("   FPS: " + str(result.fps))
	print("   Errors: " + str(result.error_count))
	print("   Warnings: " + str(result.warning_count))
	print("   Memory: " + str(result.memory_usage) + " MB")
	
	if result.issues.size() > 0:
		print("   Issues:")
		for issue in result.issues:
			print("     - " + issue)
	
	return result

func reset_quality_baseline() -> void:
	print("🔄 Resetting quality baseline...")
	_establish_baseline()
	quality_history.clear()
	consecutive_failures = 0
	current_quality_level = "UNKNOWN"
	quality_issues.clear()
	
	if UnifiedDebugSystem:
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.TESTING, "Quality baseline reset", "QualityGate")

# Integration with Phase validation
func validate_phase_readiness(phase_name: String) -> bool:
	print("🔍 Validating system readiness for " + phase_name + "...")
	
	var quality_check = run_manual_quality_check()
	
	# Phase readiness criteria
	var fps_acceptable = quality_check.fps >= FPS_THRESHOLD
	var errors_acceptable = quality_check.error_count <= ERROR_THRESHOLD
	var warnings_acceptable = quality_check.warning_count <= WARNING_THRESHOLD
	var no_critical_issues = quality_check.quality_level != QualityLevel.CRITICAL
	
	var ready = fps_acceptable and errors_acceptable and warnings_acceptable and no_critical_issues
	
	if ready:
		print("✅ System ready for " + phase_name)
	else:
		print("❌ System NOT ready for " + phase_name)
		print("   Requirements not met:")
		if not fps_acceptable:
			print("   - FPS too low: " + str(quality_check.fps) + " < " + str(FPS_THRESHOLD))
		if not errors_acceptable:
			print("   - Too many errors: " + str(quality_check.error_count) + " > " + str(ERROR_THRESHOLD))
		if not warnings_acceptable:
			print("   - Too many warnings: " + str(quality_check.warning_count) + " > " + str(WARNING_THRESHOLD))
		if not no_critical_issues:
			print("   - Critical quality issues present")
	
	return ready