# SaveData.gd - Enhanced save data structure for Phase 4+ complexity
# Purpose: Comprehensive save system that works with PlayerStatSheet and reactive stat system
# Godot Version: 4.4.1 compatible
# Supports: Enhanced stat system, milestone bonuses, reactive stats, computed stats

extends RefCounted
class_name SaveData

# Save version for future compatibility and migration
const SAVE_VERSION: int = 1
const SAVE_FORMAT_NAME: String = "ExtendoRPG_Enhanced"

# Save metadata
var save_version: int = SAVE_VERSION
var save_format: String = SAVE_FORMAT_NAME
var save_timestamp: String = ""
var character_name: String = ""
var total_playtime: float = 0.0
var save_created_time: String = ""

# Current run state (comprehensive for Phase 4+ features)
var run_data: RunData = RunData.new()

func _init():
	save_timestamp = Time.get_datetime_string_from_system()
	save_created_time = save_timestamp

func to_dictionary() -> Dictionary:
	# Convert to dictionary for JSON serialization
	return {
		"save_version": save_version,
		"save_format": save_format,
		"save_timestamp": save_timestamp,
		"character_name": character_name,
		"total_playtime": total_playtime,
		"save_created_time": save_created_time,
		"run_data": run_data.to_dictionary()
	}

func from_dictionary(data: Dictionary) -> bool:
	# Load from dictionary with validation
	if not data.has("save_version"):
		push_error("Invalid save data: missing version")
		return false
	
	save_version = data.get("save_version", SAVE_VERSION)
	save_format = data.get("save_format", SAVE_FORMAT_NAME)
	save_timestamp = data.get("save_timestamp", "")
	character_name = data.get("character_name", "")
	total_playtime = data.get("total_playtime", 0.0)
	save_created_time = data.get("save_created_time", save_timestamp)
	
	var run_dict = data.get("run_data", {})
	return run_data.from_dictionary(run_dict)

func is_valid() -> bool:
	# Validate save data integrity
	if character_name.is_empty():
		push_error("SaveData: Character name is empty")
		return false
	
	if total_playtime < 0:
		push_error("SaveData: Invalid playtime: " + str(total_playtime))
		return false
	
	if save_version <= 0:
		push_error("SaveData: Invalid save version: " + str(save_version))
		return false
	
	return run_data.is_valid()

func update_playtime(session_time: float):
	# Update total playtime and timestamp
	total_playtime += session_time
	save_timestamp = Time.get_datetime_string_from_system()

func get_save_summary() -> Dictionary:
	# Get summary information for save display
	return {
		"character_name": character_name,
		"level": run_data.character_level,
		"wave": run_data.current_wave,
		"playtime": total_playtime,
		"created": save_created_time,
		"last_saved": save_timestamp,
		"health": str(int(run_data.player_health)) + "/" + str(int(run_data.player_max_health)),
		"total_kills": run_data.total_kills
	}

# RunData class for comprehensive current run state
class RunData extends RefCounted:
	
	# === PLAYER CORE STATE ===
	var player_health: float = 100.0
	var player_max_health: float = 100.0
	var player_mana: float = 50.0
	var player_max_mana: float = 50.0
	var player_position: Vector2 = Vector2.ZERO
	var player_level: int = 1
	var player_experience: int = 0
	
	# === ENHANCED STAT SYSTEM (PlayerStatSheet Integration) ===
	
	# Base attributes (the ones players allocate points to)
	var base_intelligence: float = 10.0
	var base_wisdom: float = 10.0
	var base_vitality: float = 10.0
	var base_dexterity: float = 10.0
	var character_level: float = 1.0
	
	# XP and progression
	var available_stat_points: int = 0
	var total_xp: float = 0.0
	var current_xp: float = 0.0
	var xp_to_next_level: float = 100.0
	
	# Computed stats (calculated from base stats + modifiers)
	var computed_stats: Dictionary = {}
	
	# All stat modifiers (for milestone bonuses, equipment, etc.)
	var stat_modifiers: Dictionary = {}  # stat_name: Array[modifier_data]
	
	# === SPELL AND PROGRESSION SYSTEM ===
	var unlocked_spells: Array[String] = ["fireball", "heal"]
	var spell_levels: Dictionary = {}
	var spell_experience: Dictionary = {}
	var spell_cooldowns: Dictionary = {}
	
	# === WAVE AND COMBAT PROGRESSION ===
	var current_wave: int = 1
	var waves_completed: int = 0
	var distance_from_spawn: float = 0.0
	var total_kills: int = 0
	var kills_this_wave: int = 0
	
	# === WORLD STATE ===
	var world_seed: int = 0
	var current_chunk_position: Vector2 = Vector2.ZERO
	var discovered_special_chunks: Array[Vector2] = []
	var world_explored_chunks: Array[Vector2] = []
	
	# === SESSION STATISTICS ===
	var run_start_time: float = 0.0
	var run_duration: float = 0.0
	var damage_dealt: float = 0.0
	var damage_taken: float = 0.0
	var spells_cast: int = 0
	var highest_wave_reached: int = 1
	var milestone_bonuses_earned: Array[String] = []
	
	# === EQUIPMENT SYSTEM (Future-ready) ===
	var equipped_items: Dictionary = {}  # slot_name: item_data
	var inventory_items: Array[Dictionary] = []
	var equipment_bonuses: Dictionary = {}  # stat_name: total_bonus
	
	# === GAME SETTINGS ===
	var master_volume: float = 1.0
	var sfx_volume: float = 1.0
	var music_volume: float = 1.0
	var auto_save_enabled: bool = true
	var auto_save_interval: float = 30.0
	
	func to_dictionary() -> Dictionary:
		# Convert run data to comprehensive dictionary
		return {
			# Player core state
			"player_health": player_health,
			"player_max_health": player_max_health,
			"player_mana": player_mana,
			"player_max_mana": player_max_mana,
			"player_position": {"x": player_position.x, "y": player_position.y},
			"player_level": player_level,
			"player_experience": player_experience,
			
			# Enhanced stat system
			"base_intelligence": base_intelligence,
			"base_wisdom": base_wisdom,
			"base_vitality": base_vitality,
			"base_dexterity": base_dexterity,
			"character_level": character_level,
			"available_stat_points": available_stat_points,
			"total_xp": total_xp,
			"current_xp": current_xp,
			"xp_to_next_level": xp_to_next_level,
			
			# Computed stats and modifiers
			"computed_stats": computed_stats,
			"stat_modifiers": _serialize_stat_modifiers(),
			
			# Spell and progression
			"unlocked_spells": unlocked_spells,
			"spell_levels": spell_levels,
			"spell_experience": spell_experience,
			"spell_cooldowns": spell_cooldowns,
			
			# Wave and combat
			"current_wave": current_wave,
			"waves_completed": waves_completed,
			"distance_from_spawn": distance_from_spawn,
			"total_kills": total_kills,
			"kills_this_wave": kills_this_wave,
			
			# World state
			"world_seed": world_seed,
			"current_chunk_position": {"x": current_chunk_position.x, "y": current_chunk_position.y},
			"discovered_special_chunks": _serialize_vector2_array(discovered_special_chunks),
			"world_explored_chunks": _serialize_vector2_array(world_explored_chunks),
			
			# Session statistics
			"run_start_time": run_start_time,
			"run_duration": run_duration,
			"damage_dealt": damage_dealt,
			"damage_taken": damage_taken,
			"spells_cast": spells_cast,
			"highest_wave_reached": highest_wave_reached,
			"milestone_bonuses_earned": milestone_bonuses_earned,
			
			# Equipment system
			"equipped_items": equipped_items,
			"inventory_items": inventory_items,
			"equipment_bonuses": equipment_bonuses,
			
			# Settings
			"master_volume": master_volume,
			"sfx_volume": sfx_volume,
			"music_volume": music_volume,
			"auto_save_enabled": auto_save_enabled,
			"auto_save_interval": auto_save_interval
		}
	
	func from_dictionary(data: Dictionary) -> bool:
		# Load run data from comprehensive dictionary
		# Validate input data
		if data.is_empty():
			push_error("Failed to parse run data from dictionary: empty data")
			return false
		
		# Validate critical fields exist
		var required_fields = ["player_health", "player_max_health", "base_intelligence", "character_level"]
		for field in required_fields:
			if not data.has(field):
				push_error("Missing required field in save data: " + field)
				return false
		
		# Player core state - with validation
		var health_val = data.get("player_health", 100.0)
		var max_health_val = data.get("player_max_health", 100.0)
		if health_val < 0 or max_health_val <= 0 or health_val > max_health_val:
			push_error("Invalid health values in save data")
			return false
		player_health = health_val
		player_max_health = max_health_val
		
		var mana_val = data.get("player_mana", 50.0)
		var max_mana_val = data.get("player_max_mana", 50.0)
		if mana_val < 0 or max_mana_val <= 0 or mana_val > max_mana_val:
			push_error("Invalid mana values in save data")
			return false
		player_mana = mana_val
		player_max_mana = max_mana_val
		
		# Safe Vector2 parsing
		var pos_data = data.get("player_position", {"x": 0, "y": 0})
		if pos_data is Dictionary and pos_data.has("x") and pos_data.has("y"):
			player_position = Vector2(pos_data.x, pos_data.y)
		else:
			player_position = Vector2.ZERO
		
		player_level = max(1, data.get("player_level", 1))
		player_experience = max(0, data.get("player_experience", 0))
		
		# Enhanced stat system - with validation
		base_intelligence = max(1.0, data.get("base_intelligence", 10.0))
		base_wisdom = max(1.0, data.get("base_wisdom", 10.0))
		base_vitality = max(1.0, data.get("base_vitality", 10.0))
		base_dexterity = max(1.0, data.get("base_dexterity", 10.0))
		character_level = max(1.0, data.get("character_level", 1.0))
		available_stat_points = max(0, data.get("available_stat_points", 0))
		total_xp = max(0.0, data.get("total_xp", 0.0))
		current_xp = max(0.0, data.get("current_xp", 0.0))
		xp_to_next_level = max(1.0, data.get("xp_to_next_level", 100.0))
		
		# Computed stats and modifiers - safe assignment
		var comp_stats = data.get("computed_stats", {})
		if comp_stats is Dictionary:
			computed_stats = comp_stats
		else:
			computed_stats = {}
		
		_deserialize_stat_modifiers(data.get("stat_modifiers", {}))
		
		# Spell and progression - safe assignment
		var unlocked = data.get("unlocked_spells", ["fireball", "heal"])
		if unlocked is Array:
			unlocked_spells.clear()
			for spell in unlocked:
				if spell is String:
					unlocked_spells.append(spell)
		else:
			unlocked_spells = ["fireball", "heal"]
		
		var spell_lvls = data.get("spell_levels", {})
		spell_levels = spell_lvls if spell_lvls is Dictionary else {}
		
		var spell_exp = data.get("spell_experience", {})
		spell_experience = spell_exp if spell_exp is Dictionary else {}
		
		var spell_cds = data.get("spell_cooldowns", {})
		spell_cooldowns = spell_cds if spell_cds is Dictionary else {}
		
		# Wave and combat - with validation
		current_wave = max(1, data.get("current_wave", 1))
		waves_completed = max(0, data.get("waves_completed", 0))
		distance_from_spawn = max(0.0, data.get("distance_from_spawn", 0.0))
		total_kills = max(0, data.get("total_kills", 0))
		kills_this_wave = max(0, data.get("kills_this_wave", 0))
		
		# World state - safe assignment
		world_seed = data.get("world_seed", 0)
		
		var chunk_data = data.get("current_chunk_position", {"x": 0, "y": 0})
		if chunk_data is Dictionary and chunk_data.has("x") and chunk_data.has("y"):
			current_chunk_position = Vector2(chunk_data.x, chunk_data.y)
		else:
			current_chunk_position = Vector2.ZERO
		
		discovered_special_chunks = _deserialize_vector2_array(data.get("discovered_special_chunks", []))
		world_explored_chunks = _deserialize_vector2_array(data.get("world_explored_chunks", []))
		
		# Session statistics - with validation
		run_start_time = max(0.0, data.get("run_start_time", 0.0))
		run_duration = max(0.0, data.get("run_duration", 0.0))
		damage_dealt = max(0.0, data.get("damage_dealt", 0.0))
		damage_taken = max(0.0, data.get("damage_taken", 0.0))
		spells_cast = max(0, data.get("spells_cast", 0))
		highest_wave_reached = max(1, data.get("highest_wave_reached", 1))
		
		var milestones = data.get("milestone_bonuses_earned", [])
		milestone_bonuses_earned.clear()
		if milestones is Array:
			for milestone in milestones:
				if milestone is String:
					milestone_bonuses_earned.append(milestone)
		
		# Equipment system - safe assignment
		var equipped = data.get("equipped_items", {})
		equipped_items = equipped if equipped is Dictionary else {}
		
		var inventory = data.get("inventory_items", [])
		inventory_items.clear()
		if inventory is Array:
			for item in inventory:
				if item is Dictionary:
					inventory_items.append(item)
		
		var eq_bonuses = data.get("equipment_bonuses", {})
		equipment_bonuses = eq_bonuses if eq_bonuses is Dictionary else {}
		
		# Settings - with validation
		master_volume = clamp(data.get("master_volume", 1.0), 0.0, 1.0)
		sfx_volume = clamp(data.get("sfx_volume", 1.0), 0.0, 1.0)
		music_volume = clamp(data.get("music_volume", 1.0), 0.0, 1.0)
		auto_save_enabled = data.get("auto_save_enabled", true)
		auto_save_interval = max(5.0, data.get("auto_save_interval", 30.0))
		
		return true
	
	func _serialize_stat_modifiers() -> Dictionary:
		# Serialize StatModifier objects to dictionary format
		var serialized = {}
		for stat_name in stat_modifiers:
			var modifier_list = stat_modifiers[stat_name]
			serialized[stat_name] = []
			for modifier in modifier_list:
				if modifier and modifier.has_method("to_dictionary"):
					serialized[stat_name].append(modifier.to_dictionary())
		return serialized
	
	func _deserialize_stat_modifiers(data: Dictionary):
		# Deserialize dictionary format back to StatModifier objects
		stat_modifiers.clear()
		for stat_name in data:
			stat_modifiers[stat_name] = []
			var modifier_list = data[stat_name]
			for modifier_data in modifier_list:
				# This will be implemented when StatModifier.from_dictionary() exists
				# For now, store as dictionary and convert during load
				stat_modifiers[stat_name].append(modifier_data)
	
	func _serialize_vector2_array(array: Array[Vector2]) -> Array:
		# Convert Vector2 array to serializable format
		var result = []
		for vec in array:
			result.append({"x": vec.x, "y": vec.y})
		return result
	
	func _deserialize_vector2_array(data: Array) -> Array[Vector2]:
		# Convert serialized data back to Vector2 array
		var result: Array[Vector2] = []
		for item in data:
			if item is Dictionary and item.has("x") and item.has("y"):
				result.append(Vector2(item.x, item.y))
		return result
	
	func is_valid() -> bool:
		# Validate run data integrity
		# Basic sanity checks
		if player_health < 0 or player_max_health <= 0:
			push_error("RunData: Invalid health values")
			return false
		
		if player_mana < 0 or player_max_mana <= 0:
			push_error("RunData: Invalid mana values")
			return false
		
		if current_wave < 1:
			push_error("RunData: Invalid wave number")
			return false
		
		if character_level < 1:
			push_error("RunData: Invalid character level")
			return false
		
		if base_intelligence < 0 or base_wisdom < 0 or base_vitality < 0 or base_dexterity < 0:
			push_error("RunData: Invalid base stats")
			return false
		
		return true
	
	func start_new_run(random_seed: int = 0):
		# Initialize for new run with Enhanced StatSheet defaults
		# Reset player state
		player_health = 100.0
		player_max_health = 100.0
		player_mana = 50.0
		player_max_mana = 50.0
		player_position = Vector2.ZERO
		player_level = 1
		player_experience = 0
		
		# Initialize base stats (match PlayerStatSheet defaults)
		base_intelligence = 10.0
		base_wisdom = 10.0
		base_vitality = 10.0
		base_dexterity = 10.0
		character_level = 1.0
		
		# Initialize progression
		available_stat_points = 0
		total_xp = 0.0
		current_xp = 0.0
		xp_to_next_level = 100.0
		
		# Clear computed stats and modifiers
		computed_stats.clear()
		stat_modifiers.clear()
		
		# Initialize computed stats with default formulas
		_initialize_default_computed_stats()
		
		# Clear spell progression
		unlocked_spells = ["fireball", "heal"]
		spell_levels.clear()
		spell_experience.clear()
		spell_cooldowns.clear()
		
		# Reset wave progression
		current_wave = 1
		waves_completed = 0
		distance_from_spawn = 0.0
		total_kills = 0
		kills_this_wave = 0
		
		# Set world
		world_seed = random_seed if random_seed != 0 else randi()
		current_chunk_position = Vector2.ZERO
		discovered_special_chunks.clear()
		world_explored_chunks.clear()
		
		# Reset statistics
		run_start_time = Time.get_ticks_msec() / 1000.0
		run_duration = 0.0
		damage_dealt = 0.0
		damage_taken = 0.0
		spells_cast = 0
		highest_wave_reached = 1
		milestone_bonuses_earned.clear()
		
		# Clear equipment
		equipped_items.clear()
		inventory_items.clear()
		equipment_bonuses.clear()
		
		print("🎮 New run initialized with Enhanced StatSheet compatibility")
	
	func _initialize_default_computed_stats():
		# Initialize computed stats with default calculated values
		# These match the PlayerStatSheet computed stat formulas
		computed_stats["max_health"] = 100.0 + base_vitality * 5.0 + character_level * 3.0
		computed_stats["max_mana"] = 50.0 + base_intelligence * 3.0 + base_wisdom * 2.0 + character_level * 2.0
		computed_stats["spell_damage_multiplier"] = 1.0 + base_intelligence * 0.02
		computed_stats["mana_regen_rate"] = 3.0 + base_wisdom * 0.8 + base_intelligence * 0.2
		computed_stats["health_regen_rate"] = 2.0 + base_vitality * 0.5
		computed_stats["cast_speed_multiplier"] = 1.0 + base_dexterity * 0.015
		computed_stats["cooldown_reduction"] = base_wisdom * 0.01
		computed_stats["critical_chance"] = 0.05 + base_intelligence * 0.001
		computed_stats["movement_speed"] = 120.0 + base_dexterity * 2.0
	
	# Progress tracking helpers
	func update_run_duration():
		# Update current run duration
		var current_time = Time.get_ticks_msec() / 1000.0
		run_duration = current_time - run_start_time
	
	func add_kill():
		# Add enemy kill and update wave progress
		total_kills += 1
		kills_this_wave += 1
		highest_wave_reached = max(highest_wave_reached, current_wave)
	
	func advance_wave():
		# Advance to next wave
		waves_completed += 1
		current_wave += 1
		kills_this_wave = 0
		highest_wave_reached = max(highest_wave_reached, current_wave)
	
	func add_spell_cast():
		# Track spell usage
		spells_cast += 1
	
	func add_damage_dealt(damage: float):
		# Track combat statistics
		damage_dealt += damage
	
	func add_damage_taken(damage: float):
		# Track damage received
		damage_taken += damage
	
	func update_position(new_position: Vector2):
		# Update player position and distance tracking
		player_position = new_position
		distance_from_spawn = player_position.length()
	
	func discover_special_chunk(chunk_pos: Vector2):
		# Add discovered special chunk
		if chunk_pos not in discovered_special_chunks:
			discovered_special_chunks.append(chunk_pos)
	
	func explore_chunk(chunk_pos: Vector2):
		# Add explored regular chunk
		if chunk_pos not in world_explored_chunks:
			world_explored_chunks.append(chunk_pos)
	
	func add_milestone_bonus(milestone_name: String):
		# Track milestone bonus application
		if milestone_name not in milestone_bonuses_earned:
			milestone_bonuses_earned.append(milestone_name)
			print("🏆 Milestone bonus recorded: ", milestone_name)
