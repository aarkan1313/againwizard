# SaveSlotInfo.gd
# Purpose: Data structure for save slot metadata
# Used for displaying save information in UI without loading full save

extends Resource
class_name SaveSlotInfo

var slot_number: int = 0
var exists: bool = false
var character_name: String = ""
var level: int = 1
var wave: int = 1
var total_kills: int = 0
var playtime: float = 0.0
var save_date: String = ""
var save_timestamp: int = 0
var file_path: String = ""

func _init(slot: int = 0):
	slot_number = slot
	file_path = "user://save_slot_%d.save" % slot_number

func from_save_data(save_data: SaveData) -> void:
	# Update slot info from full save data
	exists = true
	character_name = save_data.character_name
	level = int(save_data.run_data.character_level)
	wave = save_data.run_data.current_wave
	total_kills = save_data.run_data.total_kills
	playtime = save_data.total_playtime
	save_timestamp = int(Time.get_unix_time_from_system())
	save_date = Time.get_datetime_string_from_system()

func to_dictionary() -> Dictionary:
	# Convert to dictionary for saving metadata
	return {
		"slot_number": slot_number,
		"exists": exists,
		"character_name": character_name,
		"level": level,
		"wave": wave,
		"total_kills": total_kills,
		"playtime": playtime,
		"save_date": save_date,
		"save_timestamp": save_timestamp,
		"file_path": file_path
	}

func from_dictionary(data: Dictionary) -> void:
	# Load from dictionary
	slot_number = data.get("slot_number", slot_number)
	exists = data.get("exists", false)
	character_name = data.get("character_name", "")
	level = data.get("level", 1)
	wave = data.get("wave", 1)
	total_kills = data.get("total_kills", 0)
	playtime = data.get("playtime", 0.0)
	save_date = data.get("save_date", "")
	save_timestamp = data.get("save_timestamp", 0)
	file_path = data.get("file_path", file_path)

func get_display_text() -> String:
	# Get formatted text for UI display
	if not exists:
		return "Empty Slot"
	
	var time_str = _format_playtime(playtime)
	return "%s - Lvl %d | Wave %d | %s" % [character_name, level, wave, time_str]

func get_detailed_text() -> String:
	# Get detailed info for tooltips
	if not exists:
		return "Click to create new save"
	
	var time_str = _format_playtime(playtime)
	return """Character: %s
Level: %d
Wave: %d
Kills: %d
Play Time: %s
Saved: %s""" % [character_name, level, wave, total_kills, time_str, save_date]

func _format_playtime(seconds: float) -> String:
	# Format playtime into readable string
	var hours = int(seconds / 3600)
	var minutes = int((seconds - hours * 3600) / 60)
	
	if hours > 0:
		return "%dh %dm" % [hours, minutes]
	else:
		return "%dm" % minutes

func is_older_than(other: SaveSlotInfo) -> bool:
	# Compare save timestamps for sorting
	return save_timestamp < other.save_timestamp
