# SaveDataValidator.gd - Enhanced validation for save data with Phase 4+ complexity
# Purpose: Comprehensive validation and migration support for enhanced stat system
# Godot Version: 4.4.1 compatible

extends RefCounted
class_name SaveDataValidator

# Migration support
const MINIMUM_SUPPORTED_VERSION: int = 1
const CURRENT_VERSION: int = 1
const SUPPORTED_FORMATS: Array[String] = ["ExtendoRPG_Enhanced", "ExtendoRPG_Legacy"]

# Validation constants
const MIN_HEALTH: float = 1.0
const MAX_HEALTH: float = 10000.0
const MIN_MANA: float = 1.0
const MAX_MANA: float = 10000.0
const MIN_STAT_VALUE: float = 1.0
const MAX_STAT_VALUE: float = 10000.0  # Increased for high-level gameplay
const MIN_LEVEL: int = 1
const MAX_LEVEL: int = 100

static func validate_json_string(json_string: String) -> Dictionary:
	# Validate and parse JSON save data with comprehensive checks
	var result = {"valid": false, "data": null, "error": "", "warnings": []}
	
	if json_string.is_empty():
		result.error = "Empty save data"
		return result
	
	# Parse JSON
	var json = JSON.new()
	var parse_result = json.parse(json_string)
	
	if parse_result != OK:
		result.error = "Invalid JSON format: " + json.get_error_message()
		return result
	
	var data = json.data
	if not data is Dictionary:
		result.error = "Save data is not a dictionary"
		return result
	
	# Validate structure and content
	var validation_result = validate_save_structure(data)
	result.valid = validation_result.valid
	result.error = validation_result.error
	result.warnings = validation_result.warnings
	result.data = data
	
	return result

static func validate_save_structure(data: Dictionary) -> Dictionary:
	# Comprehensive save data structure validation
	var result = {"valid": true, "error": "", "warnings": []}
	
	# Check required top-level fields
	var required_fields = ["save_version", "save_format", "character_name", "run_data"]
	for field in required_fields:
		if not data.has(field):
			result.valid = false
			result.error = "Missing required field: " + field
			return result
	
	# Validate save version
	var save_version = data.get("save_version", 0)
	if save_version < MINIMUM_SUPPORTED_VERSION or save_version > CURRENT_VERSION:
		result.valid = false
		result.error = "Unsupported save version: " + str(save_version)
		return result
	
	# Validate save format
	var save_format = data.get("save_format", "")
	if save_format not in SUPPORTED_FORMATS:
		result.warnings.append("Unknown save format: " + save_format)
	
	# Validate character name
	var character_name = data.get("character_name", "")
	if character_name.is_empty():
		result.valid = false
		result.error = "Character name cannot be empty"
		return result
	
	if character_name.length() > 50:
		result.warnings.append("Character name is very long: " + str(character_name.length()) + " characters")
	
	# Validate playtime
	var total_playtime = data.get("total_playtime", 0.0)
	if total_playtime < 0:
		result.valid = false
		result.error = "Invalid playtime: " + str(total_playtime)
		return result
	
	# Validate run data
	var run_data = data.get("run_data", {})
	var run_validation = validate_run_data(run_data)
	if not run_validation.valid:
		result.valid = false
		result.error = "Run data validation failed: " + run_validation.error
		return result
	
	result.warnings.append_array(run_validation.warnings)
	return result

static func validate_run_data(run_data: Dictionary) -> Dictionary:
	# Validate run data structure and values
	var result = {"valid": true, "error": "", "warnings": []}
	
	# Validate player health/mana
	var player_health = run_data.get("player_health", 100.0)
	var player_max_health = run_data.get("player_max_health", 100.0)
	var player_mana = run_data.get("player_mana", 50.0)
	var player_max_mana = run_data.get("player_max_mana", 50.0)
	
	if player_health < 0 or player_health > player_max_health:
		result.valid = false
		result.error = "Invalid player health: " + str(player_health) + "/" + str(player_max_health)
		return result
	
	if player_max_health < MIN_HEALTH or player_max_health > MAX_HEALTH:
		result.valid = false
		result.error = "Invalid max health range: " + str(player_max_health)
		return result
	
	if player_mana < 0 or player_mana > player_max_mana:
		result.valid = false
		result.error = "Invalid player mana: " + str(player_mana) + "/" + str(player_max_mana)
		return result
	
	if player_max_mana < MIN_MANA or player_max_mana > MAX_MANA:
		result.valid = false
		result.error = "Invalid max mana range: " + str(player_max_mana)
		return result
	
	# Validate base stats
	var base_stats = ["base_intelligence", "base_wisdom", "base_vitality", "base_dexterity"]
	for stat_name in base_stats:
		var stat_value = run_data.get(stat_name, 10.0)
		if stat_value < MIN_STAT_VALUE or stat_value > MAX_STAT_VALUE:
			result.valid = false
			result.error = "Invalid " + stat_name + ": " + str(stat_value)
			return result
	
	# Validate character level
	var character_level = run_data.get("character_level", 1.0)
	if character_level < MIN_LEVEL or character_level > MAX_LEVEL:
		result.valid = false
		result.error = "Invalid character level: " + str(character_level)
		return result
	
	# Validate XP values
	var total_xp = run_data.get("total_xp", 0.0)
	var current_xp = run_data.get("current_xp", 0.0)
	var xp_to_next_level = run_data.get("xp_to_next_level", 100.0)
	
	if total_xp < 0:
		result.valid = false
		result.error = "Invalid total XP: " + str(total_xp)
		return result
	
	if current_xp < 0 or current_xp > xp_to_next_level:
		result.warnings.append("Unusual current XP value: " + str(current_xp) + "/" + str(xp_to_next_level))
	
	if xp_to_next_level <= 0:
		result.valid = false
		result.error = "Invalid XP to next level: " + str(xp_to_next_level)
		return result
	
	# Validate wave progression
	var current_wave = run_data.get("current_wave", 1)
	var waves_completed = run_data.get("waves_completed", 0)
	var total_kills = run_data.get("total_kills", 0)
	
	if current_wave < 1:
		result.valid = false
		result.error = "Invalid current wave: " + str(current_wave)
		return result
	
	if waves_completed < 0:
		result.valid = false
		result.error = "Invalid waves completed: " + str(waves_completed)
		return result
	
	if total_kills < 0:
		result.valid = false
		result.error = "Invalid total kills: " + str(total_kills)
		return result
	
	# Validate computed stats (if present)
	var computed_stats = run_data.get("computed_stats", {})
	var computed_validation = validate_computed_stats(computed_stats)
	if not computed_validation.valid:
		result.warnings.append("Computed stats validation: " + computed_validation.error)
	
	# Validate stat modifiers (if present)
	var stat_modifiers = run_data.get("stat_modifiers", {})
	var modifier_validation = validate_stat_modifiers(stat_modifiers)
	if not modifier_validation.valid:
		result.warnings.append("Stat modifiers validation: " + modifier_validation.error)
	
	return result

static func validate_computed_stats(computed_stats: Dictionary) -> Dictionary:
	# Validate computed stats structure
	var result = {"valid": true, "error": "", "warnings": []}
	
	var _expected_computed_stats = [
		"max_health", "max_mana", "spell_damage_multiplier", 
		"mana_regen_rate", "health_regen_rate", "cast_speed_multiplier",
		"cooldown_reduction", "critical_chance", "movement_speed"
	]
	
	for stat_name in computed_stats:
		var stat_value = computed_stats[stat_name]
		
		if not stat_value is float and not stat_value is int:
			result.valid = false
			result.error = "Non-numeric computed stat " + stat_name + ": " + str(stat_value)
			return result
		
		# Validate specific stat ranges
		match stat_name:
			"max_health":
				if stat_value < MIN_HEALTH or stat_value > MAX_HEALTH:
					result.warnings.append("Computed max_health out of range: " + str(stat_value))
			"max_mana":
				if stat_value < MIN_MANA or stat_value > MAX_MANA:
					result.warnings.append("Computed max_mana out of range: " + str(stat_value))
			"critical_chance":
				if stat_value < 0.0 or stat_value > 1.0:
					result.warnings.append("Critical chance out of range: " + str(stat_value))
			"spell_damage_multiplier":
				if stat_value < 0.1 or stat_value > 10.0:
					result.warnings.append("Spell damage multiplier unusual: " + str(stat_value))
	
	return result

static func validate_stat_modifiers(stat_modifiers: Dictionary) -> Dictionary:
	# Validate stat modifiers structure
	var result = {"valid": true, "error": "", "warnings": []}
	
	for stat_name in stat_modifiers:
		var modifier_list = stat_modifiers[stat_name]
		
		if not modifier_list is Array:
			result.valid = false
			result.error = "Stat modifiers for " + stat_name + " is not an array"
			return result
		
		for modifier in modifier_list:
			if not modifier is Dictionary:
				result.warnings.append("Non-dictionary modifier in " + stat_name)
				continue
			
			# Validate modifier structure
			if not modifier.has("value") or not modifier.has("type") or not modifier.has("source"):
				result.warnings.append("Incomplete modifier structure in " + stat_name)
	
	return result

static func validate_save_file_path(file_path: String) -> bool:
	# Validate save file path format
	if not file_path.begins_with("user://"):
		return false
	
	if not file_path.ends_with(".save"):
		return false
	
	# Check for invalid characters
	var invalid_chars = ["<", ">", ":", "\"", "|", "?", "*"]
	var filename = file_path.get_file()
	for invalid_char in invalid_chars:
		if invalid_char in filename:
			return false
	
	return true

static func can_create_save_file(file_path: String) -> bool:
	# Check if save file can be created
	if not validate_save_file_path(file_path):
		return false
	
	# Try to create and delete test file
	var test_file = FileAccess.open(file_path + ".test", FileAccess.WRITE)
	if not test_file:
		return false
	
	test_file.close()
	DirAccess.open("user://").remove(file_path.get_file() + ".test")
	return true

static func sanitize_character_name(name: String) -> String:
	# Sanitize character name for safe usage
	var sanitized = name.strip_edges()
	
	# Remove invalid filesystem characters
	var invalid_chars = ["/", "\\", ":", "*", "?", "\"", "<", ">", "|", "\t", "\n", "\r"]
	for char in invalid_chars:
		sanitized = sanitized.replace(char, "_")
	
	# Replace multiple underscores with single
	while "__" in sanitized:
		sanitized = sanitized.replace("__", "_")
	
	# Remove leading/trailing underscores
	sanitized = sanitized.strip_edges()
	if sanitized.begins_with("_"):
		sanitized = sanitized.substr(1)
	if sanitized.ends_with("_"):
		sanitized = sanitized.substr(0, sanitized.length() - 1)
	
	# Limit length
	if sanitized.length() > 50:
		sanitized = sanitized.substr(0, 50)
	
	# Ensure not empty
	if sanitized.is_empty():
		sanitized = "Unnamed_Wizard"
	
	return sanitized

static func generate_safe_filename(character_name: String, timestamp: String = "") -> String:
	# Generate safe filename from character name
	var safe_name = sanitize_character_name(character_name)
	
	if timestamp.is_empty():
		timestamp = Time.get_datetime_string_from_system().replace(":", "-").replace(" ", "_")
	
	return safe_name + "_" + timestamp + ".save"

static func get_save_file_info(file_path: String) -> Dictionary:
	# Get information about a save file without fully loading it
	var result = {"valid": false, "info": {}, "error": ""}
	
	if not FileAccess.file_exists(file_path):
		result.error = "File does not exist"
		return result
	
	var file = FileAccess.open(file_path, FileAccess.READ)
	if not file:
		result.error = "Cannot open file for reading"
		return result
	
	var file_size = file.get_length()
	var content = file.get_as_text()
	file.close()
	
	# Quick JSON validation
	var validation_result = validate_json_string(content)
	if not validation_result.valid:
		result.error = validation_result.error
		return result
	
	var data = validation_result.data
	var save_data = SaveData.new()
	if not save_data.from_dictionary(data):
		result.error = "Failed to parse save data"
		return result
	
	result.valid = true
	result.info = {
		"file_size": file_size,
		"summary": save_data.get_save_summary(),
		"version": data.get("save_version", 0),
		"format": data.get("save_format", "unknown"),
		"warnings": validation_result.warnings
	}
	
	return result

static func repair_save_data(data: Dictionary) -> Dictionary:
	# Attempt to repair corrupted save data
	var result = {"success": false, "data": data, "repairs": []}
	
	# Fix missing required fields
	if not data.has("save_version"):
		data["save_version"] = CURRENT_VERSION
		result.repairs.append("Added missing save_version")
	
	if not data.has("save_format"):
		data["save_format"] = "ExtendoRPG_Enhanced"
		result.repairs.append("Added missing save_format")
	
	if not data.has("character_name") or data["character_name"].is_empty():
		data["character_name"] = "Recovered_Wizard"
		result.repairs.append("Added default character_name")
	
	if not data.has("total_playtime"):
		data["total_playtime"] = 0.0
		result.repairs.append("Added missing total_playtime")
	
	# Fix run data
	if not data.has("run_data"):
		data["run_data"] = {}
		result.repairs.append("Created missing run_data")
	
	var run_data = data["run_data"]
	
	# Fix player stats
	var player_defaults = {
		"player_health": 100.0,
		"player_max_health": 100.0,
		"player_mana": 50.0,
		"player_max_mana": 50.0,
		"player_position": {"x": 0, "y": 0},
		"base_intelligence": 10.0,
		"base_wisdom": 10.0,
		"base_vitality": 10.0,
		"base_dexterity": 10.0,
		"character_level": 1.0,
		"current_wave": 1,
		"total_kills": 0
	}
	
	for key in player_defaults:
		if not run_data.has(key):
			run_data[key] = player_defaults[key]
			result.repairs.append("Added missing " + key)
	
	# Validate and fix ranges
	run_data["player_health"] = clamp(run_data.get("player_health", 100.0), 0.0, run_data.get("player_max_health", 100.0))
	run_data["player_mana"] = clamp(run_data.get("player_mana", 50.0), 0.0, run_data.get("player_max_mana", 50.0))
	run_data["character_level"] = max(1.0, run_data.get("character_level", 1.0))
	run_data["current_wave"] = max(1, run_data.get("current_wave", 1))
	
	result.success = true
	result.data = data
	return result

static func migrate_save_data(data: Dictionary) -> Dictionary:
	# Migrate save data from older versions
	var result = {"success": true, "data": data, "migrations": []}
	
	var version = data.get("save_version", 1)
	
	# Currently only version 1 exists, but this provides migration framework
	if version < CURRENT_VERSION:
		# Apply migrations step by step
		for migrate_version in range(version, CURRENT_VERSION):
			match migrate_version:
				0:
					# Migration from version 0 to 1 (example)
					result.migrations.append("Migrated from version 0 to 1")
				_:
					result.migrations.append("Applied migration for version " + str(migrate_version))
		
		data["save_version"] = CURRENT_VERSION
		result.migrations.append("Updated save version to " + str(CURRENT_VERSION))
	
	return result
