# SaveManager.gd - Advanced save/load system for Phase 4+ complexity
# Purpose: Deep integration with PlayerStatSheet, GameManager, and component systems
# Godot Version: 4.4.1 compatible
# Features: Auto-save, validation, error recovery, performance optimization

extends Node
# SaveManager - Autoload singleton (no class_name needed)

# Save configuration
var SAVE_FILE_PATH = "user://current_game.save"  # Changed to var for multi-slot
const BACKUP_SAVE_PATH = "user://current_game_backup.save"
const AUTO_SAVE_INTERVAL = 30.0  # seconds
const SAVE_BACKUP_COUNT = 3

# Multi-slot save system
const MAX_SAVE_SLOTS = 5
const SAVE_FILE_PATTERN = "user://save_slot_%d.save"
const SAVE_METADATA_FILE = "user://save_metadata.json"

# Current save data
var current_save: SaveData = null
var session_start_time: float = 0.0
var auto_save_timer: float = 0.0
var auto_save_enabled: bool = false
var last_save_time: float = 0.0

# Multi-slot variables
var current_slot: int = 0
var save_slots: Array[SaveSlotInfo] = []

# Performance tracking
var save_operations_count: int = 0
var total_save_time: float = 0.0
var load_operations_count: int = 0
var total_load_time: float = 0.0

# Error tracking
var save_errors: Array[String] = []
var load_errors: Array[String] = []

# Signals for UI feedback
signal save_completed(success: bool, message: String)
signal load_completed(success: bool, message: String, save_data: SaveData)
signal auto_save_triggered(success: bool)
signal save_progress_update(step: String, progress: float)
signal game_loaded()  # Emitted when game is fully loaded and ready to play

func _ready():
	print("💾 SaveManager initialized for Phase 4+ complexity")
	session_start_time = Time.get_ticks_msec() / 1000.0
	set_process(false)  # Only process when auto-save enabled
	
	# Ensure save directory exists
	_ensure_save_directory_exists()
	
	# Initialize save slots
	_initialize_save_slots()
	
	# Validate dependencies after all autoloads are ready
	call_deferred("_validate_dependencies")

func _validate_dependencies() -> bool:
	# Validate that all required dependencies are available
	var validation_passed = true
	
	# Check for SaveData class (simplified check)
	var _save_data_available = true
	var test_save_data = SaveData.new()
	if not test_save_data:
		push_warning("SaveManager: SaveData class not found - some features may not work")
		validation_passed = false
	
	# Check for SaveDataValidator class (simplified check)
	var _validator_available = true
	var test_validator = SaveDataValidator.new()
	if not test_validator:
		push_warning("SaveManager: SaveDataValidator class not found - some features may not work")
		validation_passed = false
	
	# Check for GameManager singleton (autoload, not engine singleton)
	if not has_node("/root/GameManager"):
		push_warning("SaveManager: GameManager autoload not found - some features may not work")
		# This is a warning, not a critical error
	
	# Check for GameEvents singleton (optional but recommended)
	if not has_node("/root/GameEvents"):
		push_warning("SaveManager: GameEvents autoload not found - UI updates may not work properly")
		# This is a warning, not a critical error
	
	if validation_passed:
		print("✅ SaveManager dependencies validation passed")
	else:
		print("❌ SaveManager dependencies validation failed")
	
	return validation_passed

func _process(delta):
	# Handle auto-save timer
	if auto_save_enabled and current_save:
		auto_save_timer += delta
		if auto_save_timer >= AUTO_SAVE_INTERVAL:
			_perform_auto_save()
			auto_save_timer = 0.0

func _ensure_save_directory_exists():
	# Ensure the save directory exists
	var dir = DirAccess.open("user://")
	if not dir:
		push_error("Cannot access user directory")
		return
	
	# Create saves subdirectory if it doesn't exist
	if not dir.dir_exists("saves"):
		dir.make_dir("saves")
		print("📁 Created saves directory")

# === CORE SAVE/LOAD OPERATIONS ===

func create_new_save(character_name: String) -> bool:
	# Create new save with character name and deep system integration
	save_progress_update.emit("Creating new save", 0.1)
	
	if character_name.strip_edges().is_empty():
		var error_msg = "Character name cannot be empty"
		push_error(error_msg)
		save_completed.emit(false, error_msg)
		return false
	
	# Create new save data
	current_save = SaveData.new()
	current_save.character_name = SaveDataValidator.sanitize_character_name(character_name)
	
	save_progress_update.emit("Initializing run data", 0.3)
	
	# Initialize run data for new game
	current_save.run_data.start_new_run()
	
	save_progress_update.emit("Syncing with game systems", 0.6)
	
	# Immediately sync with current game state
	_update_save_from_comprehensive_game_state()
	
	save_progress_update.emit("Save creation complete", 1.0)
	
	print("💾 Created new save for: ", current_save.character_name)
	return true

func has_active_game() -> bool:
	# Check if there's an active game that can be saved
	# Check if player exists and game is running
	if has_node("/root/GameManager") and GameManager:
		# Check for active player
		var player = get_tree().get_first_node_in_group("player")
		if player:
			return true
	return false

func ensure_active_save() -> bool:
	# Ensure we have a current_save for the active game session
	if current_save:
		return true
	
	# Auto-create save with default or player name
	var character_name = "Wizard"  # Default name
	
	# Try to get player name from UI or player data
	if has_node("/root/GameManager") and GameManager:
		var player = get_tree().get_first_node_in_group("player")
		if player and player.has_method("get_character_name"):
			var player_name = player.get_character_name()
			if player_name and not player_name.is_empty():
				character_name = player_name
	
	# Create the save
	return create_new_save(character_name)

func save_current_game() -> bool:
	# Save current game state with comprehensive system integration
	var start_time = Time.get_ticks_msec() / 1000.0
	
	if not current_save:
		# Auto-create a save if we have an active game
		if has_active_game():
			print("🔄 No current save exists, creating one automatically...")
			ensure_active_save()
		else:
			var error_msg = "No active game to save"
			_record_save_error(error_msg)
			save_completed.emit(false, error_msg)
			return false
	
	save_progress_update.emit("Updating game state", 0.2)
	
	# Update save data with current comprehensive game state
	_update_save_from_comprehensive_game_state()
	
	save_progress_update.emit("Validating save data", 0.4)
	
	# Validate save data before writing
	if not current_save.is_valid():
		var error_msg = "Save data validation failed"
		_record_save_error(error_msg)
		save_completed.emit(false, error_msg)
		return false
	
	save_progress_update.emit("Creating backup", 0.6)
	
	# Create backup of existing save
	_create_save_backup()
	
	save_progress_update.emit("Writing save file", 0.8)
	
	# Convert to JSON
	var save_dict = current_save.to_dictionary()
	var json_string = JSON.stringify(save_dict, "\t")  # Pretty print for debugging
	
	# Write to file with error handling
	var file = FileAccess.open(SAVE_FILE_PATH, FileAccess.WRITE)
	if not file:
		var error_msg = "Failed to open save file for writing: " + str(FileAccess.get_open_error())
		_record_save_error(error_msg)
		save_completed.emit(false, error_msg)
		return false
	
	file.store_string(json_string)
	file.close()
	
	save_progress_update.emit("Save complete", 1.0)
	
	# Track performance
	var save_time = Time.get_ticks_msec() / 1000.0 - start_time
	save_operations_count += 1
	total_save_time += save_time
	last_save_time = Time.get_ticks_msec() / 1000.0
	
	print("💾 Game saved successfully in ", save_time, " seconds")
	save_completed.emit(true, "Game saved successfully")
	return true

func load_saved_game() -> bool:
	# Load game with comprehensive system integration and validation
	var start_time = Time.get_ticks_msec() / 1000.0
	
	if not FileAccess.file_exists(SAVE_FILE_PATH):
		var error_msg = "No save file found"
		print("💾 ", error_msg)
		load_completed.emit(false, error_msg, null)
		return false
	
	save_progress_update.emit("Reading save file", 0.2)
	
	# Read file
	var file = FileAccess.open(SAVE_FILE_PATH, FileAccess.READ)
	if not file:
		var error_msg = "Failed to open save file for reading: " + str(FileAccess.get_open_error())
		_record_load_error(error_msg)
		load_completed.emit(false, error_msg, null)
		return false
	
	var json_string = file.get_as_text()
	file.close()
	
	save_progress_update.emit("Validating save data", 0.4)
	
	# Validate JSON with comprehensive validation
	var validation_result = SaveDataValidator.validate_json_string(json_string)
	if not validation_result.valid:
		var error_msg = "Invalid save file: " + validation_result.error
		_record_load_error(error_msg)
		
		# Attempt to repair save data
		if validation_result.data:
			var repair_result = SaveDataValidator.repair_save_data(validation_result.data)
			if repair_result.success:
				print("🔧 Attempting to repair corrupted save data")
				validation_result.data = repair_result.data
				validation_result.valid = true
				for repair in repair_result.repairs:
					print("🔧 Repair applied: ", repair)
			else:
				load_completed.emit(false, error_msg, null)
				return false
	
	save_progress_update.emit("Loading save data", 0.6)
	
	# Create save data and load from dictionary
	current_save = SaveData.new()
	if not current_save.from_dictionary(validation_result.data):
		var error_msg = "Failed to load save data structure"
		_record_load_error(error_msg)
		load_completed.emit(false, error_msg, null)
		return false
	
	save_progress_update.emit("Applying to game systems", 0.8)
	
	# Apply save data to game with comprehensive integration
	_apply_save_to_comprehensive_game_state()
	
	# Ensure input is restored after load
	await _ensure_input_restored_after_load()
	
	save_progress_update.emit("Load complete", 1.0)
	
	# Track performance
	var load_time = Time.get_ticks_msec() / 1000.0 - start_time
	load_operations_count += 1
	total_load_time += load_time
	
	print("💾 Game loaded successfully in ", load_time, " seconds: ", current_save.character_name)
	
	# Wait a moment before emitting completion to ensure everything is settled
	await get_tree().process_frame
	
	load_completed.emit(true, "Game loaded successfully", current_save)
	return true

# === COMPREHENSIVE GAME STATE INTEGRATION ===

func _update_save_from_comprehensive_game_state():
	# Update save data from current comprehensive game state
	if not current_save:
		return
	
	var run_data = current_save.run_data
	
	# Update session time
	var current_time = Time.get_ticks_msec() / 1000.0
	var session_time = current_time - session_start_time
	current_save.update_playtime(session_time)
	session_start_time = current_time
	
	# Update run duration
	run_data.update_run_duration()
	
	# === COMPREHENSIVE PLAYER DATA INTEGRATION ===
	var player = GameManager.get_player()
	if player:
		# Update player position
		print("📍 Saving player position: ", player.global_position)
		run_data.update_position(player.global_position)
		
		# Update health/mana from HealthComponent
		var health_component = player.get_node_or_null("HealthComponent")
		if health_component:
			run_data.player_health = health_component.current_health
			run_data.player_max_health = health_component._get_current_max_health()
			run_data.player_mana = health_component.current_mana
			run_data.player_max_mana = health_component._get_current_max_mana()
		
		# === COMPREHENSIVE PLAYERSTATSHEET INTEGRATION ===
		var stat_sheet = player.get_stat_sheet()
		if stat_sheet:
			# Base attributes (the ones players allocate points to)
			run_data.base_intelligence = stat_sheet.get_stat_value("intelligence")
			run_data.base_wisdom = stat_sheet.get_stat_value("wisdom")
			run_data.base_vitality = stat_sheet.get_stat_value("vitality")
			run_data.base_dexterity = stat_sheet.get_stat_value("dexterity")
			run_data.character_level = stat_sheet.get_stat_value("level")
			
			# XP and progression data
			if stat_sheet.has_method("get_total_xp"):
				run_data.total_xp = stat_sheet.get_total_xp()
			if stat_sheet.has_method("get_current_xp"):
				run_data.current_xp = stat_sheet.get_current_xp()
			if stat_sheet.has_method("get_xp_to_next_level"):
				run_data.xp_to_next_level = stat_sheet.get_xp_to_next_level()
			if stat_sheet.has_method("get_available_stat_points"):
				run_data.available_stat_points = stat_sheet.get_available_stat_points()
			
			# All computed stats from PlayerStatSheet
			var computed_stat_names = [
				"max_health", "max_mana", "spell_damage_multiplier",
				"mana_regen_rate", "health_regen_rate",
				"cooldown_reduction", "critical_chance", "movement_speed"
			]
			
			for stat_name in computed_stat_names:
				run_data.computed_stats[stat_name] = stat_sheet.get_stat_value(stat_name)
			
			# Additional combat stats
			run_data.computed_stats["spell_projectile_speed"] = stat_sheet.get_stat_value("spell_projectile_speed")
			run_data.computed_stats["spell_range_multiplier"] = stat_sheet.get_stat_value("spell_range_multiplier")
			
			# Save stat modifiers (milestone bonuses, equipment, etc.)
			_save_stat_modifiers(stat_sheet, run_data)
	
	# === WAVE PROGRESSION INTEGRATION ===
	# Get wave data from WaveManager for more accuracy
	if has_node("/root/WaveManager") and WaveManager:
		run_data.current_wave = WaveManager.get_current_wave()
		run_data.total_kills = WaveManager.get_total_kills()
		run_data.kills_this_wave = WaveManager.kills_in_current_wave
		print("📊 Saving wave data from WaveManager: Wave ", run_data.current_wave, 
			", Total kills: ", run_data.total_kills, ", Kills this wave: ", run_data.kills_this_wave)
	else:
		# Fallback to GameManager
		if GameManager.has_method("get_current_wave"):
			run_data.current_wave = GameManager.get_current_wave()
		if GameManager.has_method("get_total_kills"):
			run_data.total_kills = GameManager.get_total_kills()
		run_data.kills_this_wave = GameManager.enemies_killed_this_wave if "enemies_killed_this_wave" in GameManager else 0
		print("📊 Saving wave data from GameManager: Wave ", run_data.current_wave, 
			", Total kills: ", run_data.total_kills, ", Kills this wave: ", run_data.kills_this_wave)
	
	if GameManager.has_method("get_waves_completed"):
		run_data.waves_completed = GameManager.get_waves_completed()
	
	run_data.highest_wave_reached = max(run_data.highest_wave_reached, run_data.current_wave)
	
	# === SPELL SYSTEM INTEGRATION ===
	var spell_component = player.get_node_or_null("SpellComponent") if player else null
	if spell_component:
		# Track unlocked spells and cooldowns
		if spell_component.has_method("get_unlocked_spells"):
			run_data.unlocked_spells = spell_component.get_unlocked_spells()
		if spell_component.has_method("get_spell_cooldowns"):
			run_data.spell_cooldowns = spell_component.get_spell_cooldowns()
	
	# === WORLD STATE INTEGRATION ===
	var world_generator = get_tree().get_first_node_in_group("world_generator")
	if world_generator:
		if world_generator.has_method("get_world_seed"):
			run_data.world_seed = world_generator.get_world_seed()
		if world_generator.has_method("get_current_chunk"):
			run_data.current_chunk_position = world_generator.get_current_chunk()
	
	# TODO: Future chunk-based world saving
	# - Save active enemy positions, types, health states
	# - Save chunk states (explored/unexplored, modifications)
	# - Save dropped items, environmental changes
	# - Consider saving only enemies within X chunks of player
	
	# === SESSION STATISTICS ===
	run_data.spells_cast = GameManager.total_spells_cast if GameManager.has_method("get_total_spells_cast") else run_data.spells_cast
	run_data.damage_dealt = GameManager.total_damage_dealt if GameManager.has_method("get_total_damage_dealt") else run_data.damage_dealt
	
	print("📊 Comprehensive game state synchronized to save data")

func _save_stat_modifiers(stat_sheet, run_data):
	# Save stat modifiers from PlayerStatSheet (milestone bonuses, equipment, etc.)
	run_data.stat_modifiers.clear()
	
	# Get all stats that might have modifiers
	var stats_with_modifiers = [
		"max_health", "max_mana", "spell_damage_multiplier",
		"critical_chance", "mana_regen_rate", "health_regen_rate"
	]
	
	for stat_name in stats_with_modifiers:
		if stat_sheet.has_method("get_modifier_summary"):
			var modifier_summary = stat_sheet.get_modifier_summary(stat_name)
			if modifier_summary.has("modifiers") and modifier_summary.modifiers > 0:
				# For now, store the modifier summary
				# When StatModifier.to_dictionary() is available, this will be enhanced
				run_data.stat_modifiers[stat_name] = modifier_summary

func _apply_save_to_comprehensive_game_state():
	# Apply save data to current comprehensive game state
	if not current_save:
		return
	
	var run_data = current_save.run_data
	
	print("📥 Applying comprehensive save data to game state...")
	
	# === CLEAR EXISTING WORLD STATE ===
	_clear_world_state()
	
	# === COMPREHENSIVE PLAYER STATE APPLICATION ===
	var player = GameManager.get_player()
	
	# If player doesn't exist (e.g., died), try to respawn them first
	if not player:
		print("⚠️ Player not found, attempting to respawn...")
		# Try to get the player scene and instance it
		var main_scene = get_tree().current_scene
		if main_scene:
			# Look for the player scene
			var player_scene = load("res://scenes/gameplay/Player.tscn")
			if player_scene:
				player = player_scene.instantiate()
				main_scene.add_child(player)
				# Ensure player is in the correct group
				player.add_to_group("player")
				player.add_to_group("players")
				print("✅ Player respawned for save load")
				# Give the player a frame to initialize
				await get_tree().process_frame
				player = GameManager.get_player()
			else:
				push_error("Could not load player scene for respawn")
				load_completed.emit(false, "Failed to respawn player", null)
				return
	
	if player:
		# Re-enable player if they were dead
		_revive_player_if_dead(player)
		
		# Apply player position
		print("📍 Restoring player position: ", run_data.player_position)
		player.global_position = run_data.player_position
		
		# Apply health/mana to HealthComponent
		var health_component = player.get_node_or_null("HealthComponent")
		if health_component:
			# First ensure the health component recalculates max values from stats
			if health_component.has_method("_update_from_stat_changes"):
				health_component._update_from_stat_changes()
			
			# Then apply current values (but not max, as those come from stats)
			health_component.current_health = min(run_data.player_health, health_component._get_current_max_health())
			health_component.current_mana = min(run_data.player_mana, health_component._get_current_max_mana())
			
			# Emit signals to update UI with proper max values
			if GameEvents:
				GameEvents.emit_player_health_changed(health_component.current_health, health_component._get_current_max_health())
				GameEvents.emit_player_mana_changed(health_component.current_mana, health_component._get_current_max_mana())
		
		# === COMPREHENSIVE PLAYERSTATSHEET APPLICATION ===
		var stat_sheet = player.get_stat_sheet()
		if stat_sheet:
			# Apply base attributes
			if stat_sheet.has_method("set_stat_base_value"):
				stat_sheet.set_stat_base_value("intelligence", run_data.base_intelligence)
				stat_sheet.set_stat_base_value("wisdom", run_data.base_wisdom)
				stat_sheet.set_stat_base_value("vitality", run_data.base_vitality)
				stat_sheet.set_stat_base_value("dexterity", run_data.base_dexterity)
				stat_sheet.set_stat_base_value("level", run_data.character_level)
			
			# Apply XP and progression - these are direct properties, not methods
			if "total_xp" in stat_sheet:
				stat_sheet.total_xp = run_data.total_xp
			if "current_xp" in stat_sheet:
				stat_sheet.current_xp = run_data.current_xp
			if "xp_to_next_level" in stat_sheet:
				stat_sheet.xp_to_next_level = run_data.xp_to_next_level
			if "available_stat_points" in stat_sheet:
				stat_sheet.available_stat_points = run_data.available_stat_points
			
			# Force UI update by emitting the stat sheet's signal
			if stat_sheet.has_signal("xp_gained"):
				stat_sheet.xp_gained.emit(run_data.current_xp, run_data.total_xp, run_data.xp_to_next_level, int(run_data.character_level))
			
			# Restore stat modifiers (milestone bonuses)
			_restore_stat_modifiers(stat_sheet, run_data)
			
			print("📊 PlayerStatSheet state restored from save")
	
	# === WAVE PROGRESSION APPLICATION ===
	print("📊 Loading wave data: Wave ", run_data.current_wave, 
		", Total kills: ", run_data.total_kills, ", Kills this wave: ", run_data.kills_this_wave)
	
	if GameManager.has_method("set_current_wave"):
		GameManager.set_current_wave(run_data.current_wave)
	else:
		GameManager.current_wave = run_data.current_wave
	
	if GameManager.has_method("set_total_kills"):
		GameManager.set_total_kills(run_data.total_kills)
	else:
		GameManager.total_enemies_killed = run_data.total_kills
	
	# Set kills this wave
	if "enemies_killed_this_wave" in GameManager:
		GameManager.enemies_killed_this_wave = run_data.kills_this_wave
	
	# Notify WaveManager about restored wave state
	if has_node("/root/WaveManager") and WaveManager:
		if WaveManager.has_method("set_current_wave"):
			WaveManager.set_current_wave(run_data.current_wave, run_data.kills_this_wave)
			print("🌊 Wave state restored to WaveManager: Wave ", run_data.current_wave, " with ", run_data.kills_this_wave, " kills")
		else:
			push_warning("WaveManager.set_current_wave() method not found!")
		
		# Also set total kills
		if WaveManager.has_method("set_total_kills"):
			WaveManager.set_total_kills(run_data.total_kills)
		else:
			push_warning("WaveManager.set_total_kills() method not found!")
	else:
		push_warning("WaveManager not found during load!")
	
	# Restart enemy spawning after load
	var enemy_spawner = get_tree().get_first_node_in_group("enemy_spawner")
	if not enemy_spawner:
		# Try to find it in the scene
		var main_scene = get_tree().current_scene
		if main_scene:
			enemy_spawner = main_scene.get_node_or_null("GameWorld/EnemySpawner")
	
	if enemy_spawner:
		# Clear any existing enemies first
		if enemy_spawner.has_method("clear_all_enemies"):
			enemy_spawner.clear_all_enemies()
		
		# Reset spawn statistics
		if enemy_spawner.has_method("reset_spawn_statistics"):
			enemy_spawner.reset_spawn_statistics()
		
		# Give a moment for everything to settle
		await get_tree().create_timer(0.5).timeout
		
		# Start spawning with fresh state
		if enemy_spawner.has_method("start_spawning"):
			enemy_spawner.start_spawning()
			print("🌊 Enemy spawning restarted after load with clean state")
	
	# === WORLD STATE APPLICATION ===
	var world_generator = get_tree().get_first_node_in_group("world_generator")
	if world_generator and world_generator.has_method("set_world_seed"):
		world_generator.set_world_seed(run_data.world_seed)
	
	# === ENSURE GAME IS PLAYABLE AFTER LOAD ===
	# Re-enable input if it was disabled
	if has_node("/root/InputHandler") and InputHandler:
		InputHandler.enable_input()
		print("🎮 Input re-enabled after load")
	
	# Ensure game state is PLAYING
	if GameManager:
		GameManager.set_game_state(GameManager.GameState.PLAYING)
		print("▶️ Game state set to PLAYING after load")
	
	print("🌍 Game systems restored from comprehensive save data")

func _ensure_input_restored_after_load():
	# Ensure all input systems are properly restored after loading
	# Wait a few frames to ensure menus are closed
	await get_tree().create_timer(0.1).timeout
	
	print("🔄 SaveManager: Starting input restoration after load...")
	
	# 1. Re-enable InputHandler first
	var input_handler = get_node_or_null("/root/InputHandler")
	if input_handler:
		if input_handler.has_method("enable_input"):
			input_handler.enable_input()
			print("🎮 InputHandler enabled via method")
		
		# Also try direct property access as fallback
		if "input_enabled" in input_handler:
			input_handler.input_enabled = true
			print("🎮 InputHandler enabled via property")
		
		# Ensure process mode is correct
		input_handler.process_mode = Node.PROCESS_MODE_ALWAYS
		print("🎮 InputHandler process mode set to ALWAYS")
	else:
		push_warning("InputHandler not found after load!")
	
	# 2. Find and enable the player node
	var player = get_tree().get_first_node_in_group("player")
	if player:
		player.process_mode = Node.PROCESS_MODE_INHERIT
		player.set_physics_process(true)
		player.set_process(true)
		player.set_process_input(true)
		player.set_process_unhandled_input(true)
		
		# Enable movement component if it exists
		if player.has_node("MovementComponent"):
			var movement = player.get_node("MovementComponent")
			movement.set_physics_process(true)
			movement.process_mode = Node.PROCESS_MODE_INHERIT
			print("🏃 Player movement component enabled")
		
		print("🎮 Player node fully enabled")
	else:
		push_warning("Player node not found after load!")
	
	# 3. DO NOT unpause here - let the UI handle it
	# The EscapeMenuController will handle unpausing when it closes
	print("⏸️ SaveManager: Not unpausing - UI will handle it")
	
	# 4. Additional safety: emit a signal that loading is complete
	if has_signal("game_loaded"):
		game_loaded.emit()
	
	print("✅ Input restoration complete - waiting for UI to unpause")

func _restore_stat_modifiers(stat_sheet, run_data):
	# Restore stat modifiers to PlayerStatSheet
	# Clear existing milestone modifiers to avoid duplicates
	if stat_sheet.has_method("remove_modifiers_by_source"):
		# Remove all milestone modifiers first
		for milestone in run_data.milestone_bonuses_earned:
			stat_sheet.remove_modifiers_by_source("milestone_" + milestone)
	
	# Reapply all earned milestones
	if stat_sheet.has_method("apply_milestone_bonus"):
		for milestone in run_data.milestone_bonuses_earned:
			stat_sheet.apply_milestone_bonus(milestone)
			print("🏆 Restored milestone bonus: ", milestone)
	
	# Note any other modifiers that need restoration
	for stat_name in run_data.stat_modifiers:
		if run_data.stat_modifiers[stat_name] is Dictionary:
			var mod_data = run_data.stat_modifiers[stat_name]
			if mod_data.has("modifiers") and mod_data.modifiers > 0:
				print("📈 Note: ", stat_name, " has ", mod_data.modifiers, " saved modifiers to restore")

# === AUTO-SAVE SYSTEM ===

func enable_auto_save():
	# Enable auto-save with performance optimization
	auto_save_enabled = true
	auto_save_timer = 0.0
	set_process(true)
	print("💾 Auto-save enabled (interval: ", AUTO_SAVE_INTERVAL, "s)")

func disable_auto_save():
	# Disable auto-save
	auto_save_enabled = false
	set_process(false)
	print("💾 Auto-save disabled")

func _perform_auto_save():
	# Perform optimized auto-save
	if not current_save:
		return
	
	print("⏰ Auto-save triggered...")
	var success = save_current_game()
	auto_save_triggered.emit(success)
	
	if success:
		print("⏰ Auto-save completed successfully")
	else:
		print("⚠️ Auto-save failed")

# === BACKUP AND RECOVERY ===

func _create_save_backup():
	# Create backup of existing save file
	if not FileAccess.file_exists(SAVE_FILE_PATH):
		return
	
	var dir = DirAccess.open("user://")
	if dir:
		# Copy current save to backup
		dir.copy(SAVE_FILE_PATH, BACKUP_SAVE_PATH)
		print("💾 Save backup created")

func restore_from_backup() -> bool:
	# Restore save from backup file
	if not FileAccess.file_exists(BACKUP_SAVE_PATH):
		print("⚠️ No backup file found")
		return false
	
	var dir = DirAccess.open("user://")
	if dir:
		dir.copy(BACKUP_SAVE_PATH, SAVE_FILE_PATH)
		print("🔄 Save restored from backup")
		return true
	
	return false

# === PLAYER REVIVAL ===

func _revive_player_if_dead(player: Node) -> void:
	# Re-enable player after death when loading a save
	# Re-enable physics and processing
	if player.has_method("set_physics_process"):
		player.set_physics_process(true)
	if player.has_method("set_process"):
		player.set_process(true)
	
	# Restore visibility
	if player.has_node("Sprite2D"):
		var sprite = player.get_node("Sprite2D")
		sprite.modulate.a = 1.0  # Full opacity
	
	# Re-enable collision
	if player.has_node("CollisionShape2D"):
		var collision = player.get_node("CollisionShape2D")
		collision.set_deferred("disabled", false)
	
	print("🔄 Player revived from save load")

func _clear_world_state():
	# Clear all existing enemies and projectiles before loading
	print("🧹 Clearing world state before load...")
	
	# Stop enemy spawning first
	var enemy_spawner = get_tree().get_first_node_in_group("enemy_spawner")
	if not enemy_spawner:
		var main_scene = get_tree().current_scene
		if main_scene:
			enemy_spawner = main_scene.get_node_or_null("GameWorld/EnemySpawner")
	
	if enemy_spawner and enemy_spawner.has_method("stop_spawning"):
		enemy_spawner.stop_spawning()
		print("⏸️ Enemy spawning stopped for world reset")
	
	# Clear all enemies
	var enemies = get_tree().get_nodes_in_group("enemies")
	for enemy in enemies:
		enemy.queue_free()
	print("🧹 Cleared ", enemies.size(), " enemies")
	
	# Clear all projectiles
	var projectiles = get_tree().get_nodes_in_group("projectiles")
	for projectile in projectiles:
		projectile.queue_free()
	print("🧹 Cleared ", projectiles.size(), " projectiles")
	
	# Clear any enemy projectiles
	var enemy_projectiles = get_tree().get_nodes_in_group("enemy_projectiles")
	for projectile in enemy_projectiles:
		projectile.queue_free()
	print("🧹 Cleared ", enemy_projectiles.size(), " enemy projectiles")
	
	# Wait for entities to be cleared
	await get_tree().process_frame
	print("🧹 World state cleared")

# === ERROR TRACKING ===

func _record_save_error(error_msg: String):
	# Record save error for debugging
	save_errors.append(Time.get_datetime_string_from_system() + ": " + error_msg)
	if save_errors.size() > 10:
		save_errors.pop_front()
	push_error("SaveManager: " + error_msg)

func _record_load_error(error_msg: String):
	# Record load error for debugging
	load_errors.append(Time.get_datetime_string_from_system() + ": " + error_msg)
	if load_errors.size() > 10:
		load_errors.pop_front()
	push_error("SaveManager: " + error_msg)

# === UTILITY METHODS ===

func has_save_file() -> bool:
	# Check if save file exists
	return FileAccess.file_exists(SAVE_FILE_PATH)

func delete_save_file() -> bool:
	# Delete current save file
	if not has_save_file():
		return true
	
	var success = DirAccess.open("user://").remove("current_game.save") == OK
	if success:
		current_save = null
		disable_auto_save()
		print("💾 Save file deleted")
	return success

func get_save_file_info() -> Dictionary:
	# Get comprehensive save file information
	if not has_save_file():
		return {"exists": false}
	
	var file_info = SaveDataValidator.get_save_file_info(SAVE_FILE_PATH)
	return file_info

# === DATA ACCESS METHODS ===

func get_current_save() -> SaveData:
	# Get current save data
	return current_save

func get_character_name() -> String:
	# Get current character name
	return current_save.character_name if current_save else ""

func get_playtime() -> float:
	# Get total playtime
	return current_save.total_playtime if current_save else 0.0

func get_current_wave() -> int:
	# Get current wave from save
	return current_save.run_data.current_wave if current_save else 1

func get_total_kills() -> int:
	# Get total kills from save
	return current_save.run_data.total_kills if current_save else 0

func get_save_summary() -> Dictionary:
	# Get save summary for UI display
	if current_save:
		return current_save.get_save_summary()
	else:
		return {"character_name": "", "level": 0, "wave": 0}

# === PERFORMANCE MONITORING ===

func get_performance_stats() -> Dictionary:
	# Get save/load performance statistics
	var avg_save_time = total_save_time / max(1, save_operations_count)
	var avg_load_time = total_load_time / max(1, load_operations_count)
	
	return {
		"save_operations": save_operations_count,
		"load_operations": load_operations_count,
		"avg_save_time": avg_save_time,
		"avg_load_time": avg_load_time,
		"total_save_time": total_save_time,
		"total_load_time": total_load_time,
		"last_save_time": last_save_time,
		"auto_save_enabled": auto_save_enabled,
		"save_errors": save_errors.size(),
		"load_errors": load_errors.size()
	}

# === DEBUG AND TESTING ===

func quick_save() -> bool:
	# Quick save (F5)
	if not current_save:
		create_new_save("Quick Save")
	return save_current_game()

func quick_load() -> bool:
	# Quick load (F6)
	return await load_saved_game()

func debug_print_save_info():
	# Print comprehensive save information
	if not current_save:
		print("💾 No save data loaded")
		return
	
	print("💾 === COMPREHENSIVE SAVE INFO ===")
	print("💾 Character: ", current_save.character_name)
	print("💾 Playtime: ", current_save.total_playtime, " seconds")
	print("💾 Level: ", current_save.run_data.character_level)
	print("💾 Wave: ", current_save.run_data.current_wave)
	print("💾 Kills: ", current_save.run_data.total_kills)
	print("💾 Position: ", current_save.run_data.player_position)
	print("💾 Health: ", current_save.run_data.player_health, "/", current_save.run_data.player_max_health)
	print("💾 Mana: ", current_save.run_data.player_mana, "/", current_save.run_data.player_max_mana)
	print("💾 Intelligence: ", current_save.run_data.base_intelligence)
	print("💾 Available Stat Points: ", current_save.run_data.available_stat_points)
	print("💾 Computed Stats: ", current_save.run_data.computed_stats.size(), " stats tracked")
	print("💾 Stat Modifiers: ", current_save.run_data.stat_modifiers.size(), " stats with modifiers")

func debug_create_test_save():
	# Create test save with realistic Phase 4+ data
	create_new_save("Test Wizard Enhanced")
	
	# Set realistic Phase 4+ test data
	current_save.run_data.current_wave = 8
	current_save.run_data.total_kills = 350
	current_save.run_data.character_level = 12
	current_save.run_data.base_intelligence = 25
	current_save.run_data.base_wisdom = 18
	current_save.run_data.base_vitality = 20
	current_save.run_data.base_dexterity = 15
	current_save.run_data.available_stat_points = 4
	current_save.run_data.total_xp = 5500
	current_save.run_data.current_xp = 150
	current_save.run_data.xp_to_next_level = 650
	
	# Set computed stats
	current_save.run_data.computed_stats["max_health"] = 328  # 100 + 20*5 + 12*3
	current_save.run_data.computed_stats["max_mana"] = 175   # 50 + 25*3 + 18*2 + 12*2
	current_save.run_data.computed_stats["spell_damage_multiplier"] = 1.5  # 1.0 + 25*0.02
	current_save.run_data.computed_stats["critical_chance"] = 0.075  # 0.05 + 25*0.001
	
	# Add milestone bonuses earned
	current_save.run_data.milestone_bonuses_earned = ["first_blood", "apprentice_slayer", "monster_hunter"]
	
	save_current_game()
	print("🧪 Created enhanced test save with Phase 4+ complexity")

# === INPUT HANDLING FOR TESTING ===

func _input(event):
	# Handle input for quick save/load during development
	if OS.is_debug_build() and event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_F5:
				quick_save()
			KEY_F6:
				quick_load()
			KEY_F7:
				debug_print_save_info()
			KEY_F8:
				debug_create_test_save()
			KEY_F9:
				var stats = get_performance_stats()
				print("📊 Save Performance: ", stats)

# === APPLICATION EXIT HANDLING ===

func _notification(what):
	# Handle application exit with emergency save
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		if current_save and auto_save_enabled:
			print("🚨 Emergency save on exit...")
			save_current_game()
			print("💾 Emergency save completed")
# === MULTI-SLOT SAVE SYSTEM ADDITIONS ===
# Add these methods to the end of SaveManager.gd

func _initialize_save_slots():
	# Initialize save slot metadata
	save_slots.clear()
	
	# Create slot info for each slot
	for i in range(MAX_SAVE_SLOTS):
		var slot_info = SaveSlotInfo.new(i)
		save_slots.append(slot_info)
	
	# Load metadata
	_load_save_metadata()
	
	# Scan for existing saves
	_scan_save_files()
	
	print("💾 Multi-slot save system initialized with ", MAX_SAVE_SLOTS, " slots")

func _load_save_metadata():
	# Load save metadata from file
	if not FileAccess.file_exists(SAVE_METADATA_FILE):
		return
	
	var file = FileAccess.open(SAVE_METADATA_FILE, FileAccess.READ)
	if not file:
		return
	
	var json_string = file.get_as_text()
	file.close()
	
	var json = JSON.new()
	var parse_result = json.parse(json_string)
	
	if parse_result != OK:
		push_warning("Failed to parse save metadata")
		return
	
	var metadata = json.data
	if metadata is Array:
		for i in range(min(metadata.size(), MAX_SAVE_SLOTS)):
			if metadata[i] is Dictionary:
				save_slots[i].from_dictionary(metadata[i])

func _save_metadata():
	# Save metadata for all slots
	var metadata = []
	for slot in save_slots:
		metadata.append(slot.to_dictionary())
	
	var json_string = JSON.stringify(metadata, "\t")
	
	var file = FileAccess.open(SAVE_METADATA_FILE, FileAccess.WRITE)
	if file:
		file.store_string(json_string)
		file.close()

func _scan_save_files():
	# Scan for existing save files and update metadata
	for i in range(MAX_SAVE_SLOTS):
		var file_path = SAVE_FILE_PATTERN % i
		if FileAccess.file_exists(file_path):
			# Quick load to get basic info
			var temp_save = _quick_load_save_info(file_path)
			if temp_save:
				save_slots[i].from_save_data(temp_save)
		else:
			save_slots[i].exists = false

func _quick_load_save_info(file_path: String) -> SaveData:
	# Quick load just to get save info without full validation
	var file = FileAccess.open(file_path, FileAccess.READ)
	if not file:
		return null
	
	var json_string = file.get_as_text()
	file.close()
	
	var json = JSON.new()
	var parse_result = json.parse(json_string)
	
	if parse_result != OK:
		return null
	
	var save_data = SaveData.new()
	if save_data.from_dictionary(json.data):
		return save_data
	
	return null

# === ENHANCED SAVE/LOAD METHODS ===

func save_to_slot(slot: int) -> bool:
	# Save current game to specific slot
	if slot < 0 or slot >= MAX_SAVE_SLOTS:
		push_error("Invalid save slot: ", slot)
		return false
	
	current_slot = slot
	
	# Update file path for this slot
	var original_path = SAVE_FILE_PATH
	SAVE_FILE_PATH = SAVE_FILE_PATTERN % slot
	
	# Perform the save
	var success = save_current_game()
	
	if success:
		# Update slot metadata
		save_slots[slot].from_save_data(current_save)
		_save_metadata()
		print("💾 Game saved to slot ", slot + 1)
	
	# Restore original path (for compatibility)
	SAVE_FILE_PATH = original_path
	
	return success

func load_from_slot(slot: int) -> bool:
	# Load game from specific slot
	if slot < 0 or slot >= MAX_SAVE_SLOTS:
		push_error("Invalid save slot: ", slot)
		return false
	
	if not save_slots[slot].exists:
		push_warning("No save in slot ", slot + 1)
		return false
	
	current_slot = slot
	
	# Update file path for this slot
	var original_path = SAVE_FILE_PATH
	SAVE_FILE_PATH = SAVE_FILE_PATTERN % slot
	
	# Perform the load
	var success = await load_saved_game()
	
	if success:
		print("💾 Game loaded from slot ", slot + 1)
	
	# Restore original path
	SAVE_FILE_PATH = original_path
	
	return success

func delete_save_slot(slot: int) -> bool:
	# Delete save in specific slot
	if slot < 0 or slot >= MAX_SAVE_SLOTS:
		return false
	
	var file_path = SAVE_FILE_PATTERN % slot
	
	if FileAccess.file_exists(file_path):
		var dir = DirAccess.open("user://")
		if dir:
			var error = dir.remove(file_path)
			if error == OK:
				# Reset slot info
				save_slots[slot] = SaveSlotInfo.new(slot)
				_save_metadata()
				print("💾 Deleted save in slot ", slot + 1)
				return true
			else:
				push_error("Failed to delete save file: ", error)
	
	return false

func get_save_slots_info() -> Array[SaveSlotInfo]:
	# Get info for all save slots
	return save_slots

func has_save_in_slot(slot: int) -> bool:
	# Check if slot has a save
	if slot < 0 or slot >= MAX_SAVE_SLOTS:
		return false
	return save_slots[slot].exists

func get_current_slot() -> int:
	# Get current active slot
	return current_slot

func set_current_slot(slot: int) -> void:
	# Set current active slot
	if slot >= 0 and slot < MAX_SAVE_SLOTS:
		current_slot = slot

func get_newest_save_slot() -> int:
	# Get slot with most recent save
	var newest_slot = -1
	var newest_time = 0
	
	for i in range(MAX_SAVE_SLOTS):
		if save_slots[i].exists and save_slots[i].save_timestamp > newest_time:
			newest_time = save_slots[i].save_timestamp
			newest_slot = i
	
	return newest_slot

func get_oldest_save_slot() -> int:
	# Get slot with oldest save (for auto-overwrite)
	var oldest_slot = 0
	var oldest_time = 9223372036854775807  # max int
	
	for i in range(MAX_SAVE_SLOTS):
		if not save_slots[i].exists:
			return i  # Empty slot takes priority
		
		if save_slots[i].save_timestamp < oldest_time:
			oldest_time = save_slots[i].save_timestamp
			oldest_slot = i
	
	return oldest_slot

func get_next_empty_slot() -> int:
	# Get next available empty slot
	for i in range(MAX_SAVE_SLOTS):
		if not save_slots[i].exists:
			return i
	return -1  # All slots full
