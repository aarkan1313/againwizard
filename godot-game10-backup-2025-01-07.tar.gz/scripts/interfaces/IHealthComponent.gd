# IHealthComponent.gd - Standardized health management interface
# Purpose: Consistent health/damage operations across all entities
# Godot Version: 4.4.1
# Benefits: Type safety, error handling, consistent behavior

extends RefCounted
class_name IHealthComponent

# Standard health management interface for all entities

static func take_damage(target: Node, amount: float) -> bool:
	# Apply damage to target using best available method
	if not _validate_health_target(target):
		return false
	
	# Method 1: Standard take_damage method
	if target.has_method("take_damage"):
		return target.take_damage(amount)
	
	# Method 2: Direct health property manipulation
	elif "current_health" in target:
		var old_health = target.current_health
		target.current_health = max(0, target.current_health - amount)
		
		# Trigger visual effects if available
		if target.has_method("trigger_damage_visual_effects"):
			target.trigger_damage_visual_effects(amount)
		
		# Check for death
		if target.current_health <= 0 and target.has_method("die"):
			target.die()
		
		return true
	
	# Method 3: Health component delegation
	elif target.has_method("get_health_component"):
		var health_comp = target.get_health_component()
		if health_comp and health_comp.has_method("take_damage"):
			return health_comp.take_damage(amount)
	
	_log_warning("No valid damage interface for: " + str(target))
	return false

static func heal(target: Node, amount: float) -> bool:
	# Heal target using best available method
	if not _validate_health_target(target):
		return false
	
	# Method 1: Standard heal method
	if target.has_method("heal"):
		target.heal(amount)
		return true
	
	# Method 2: Direct health property manipulation
	elif "current_health" in target and "max_health" in target:
		var old_health = target.current_health
		target.current_health = min(target.max_health, target.current_health + amount)
		
		# Trigger heal effects if available
		if target.has_method("trigger_heal_effects"):
			target.trigger_heal_effects(amount)
		
		return target.current_health > old_health
	
	# Method 3: Health component delegation
	elif target.has_method("get_health_component"):
		var health_comp = target.get_health_component()
		if health_comp and health_comp.has_method("heal"):
			health_comp.heal(amount)
			return true
	
	_log_warning("No valid heal interface for: " + str(target))
	return false

static func get_health_percentage(target: Node) -> float:
	# Get health as percentage (0.0 to 1.0)
	if not _validate_health_target(target):
		return 0.0
	
	# Method 1: Dedicated percentage method
	if target.has_method("get_health_percentage"):
		return target.get_health_percentage()
	
	# Method 2: Calculate from properties
	elif "current_health" in target and "max_health" in target:
		return target.current_health / target.max_health if target.max_health > 0 else 0.0
	
	# Method 3: Health component delegation
	elif target.has_method("get_health_component"):
		var health_comp = target.get_health_component()
		if health_comp and health_comp.has_method("get_health_percentage"):
			return health_comp.get_health_percentage()
	
	return 0.0

static func get_current_health(target: Node) -> float:
	# Get current health value
	if not _validate_health_target(target):
		return 0.0
	
	if "current_health" in target:
		return target.current_health
	elif target.has_method("get_current_health"):
		return target.get_current_health()
	elif target.has_method("get_health_component"):
		var health_comp = target.get_health_component()
		if health_comp and "current_health" in health_comp:
			return health_comp.current_health
	
	return 0.0

static func get_max_health(target: Node) -> float:
	# Get maximum health value
	if not _validate_health_target(target):
		return 0.0
	
	if "max_health" in target:
		return target.max_health
	elif target.has_method("get_max_health"):
		return target.get_max_health()
	elif target.has_method("get_health_component"):
		var health_comp = target.get_health_component()
		if health_comp and "max_health" in health_comp:
			return health_comp.max_health
	
	return 0.0

static func is_alive(target: Node) -> bool:
	# Check if target is alive
	if not _validate_health_target(target):
		return false
	
	# Check dead flag first
	if "is_dead" in target:
		return not target.is_dead
	
	# Check health values
	var current = get_current_health(target)
	return current > 0

static func is_at_full_health(target: Node) -> bool:
	# Check if target is at full health
	if not _validate_health_target(target):
		return false
	
	var current = get_current_health(target)
	var maximum = get_max_health(target)
	return current >= maximum and maximum > 0

static func get_missing_health(target: Node) -> float:
	# Get amount of missing health
	if not _validate_health_target(target):
		return 0.0
	
	var current = get_current_health(target)
	var maximum = get_max_health(target)
	return max(0, maximum - current)

# Damage type specific methods

static func apply_elemental_damage(target: Node, amount: float, element_type: String) -> bool:
	# Apply elemental damage with resistance calculations
	if not _validate_health_target(target):
		return false
	
	var final_damage = amount
	
	# Apply resistances if target supports them
	if "resistances" in target and element_type in target.resistances:
		final_damage *= (1.0 - target.resistances[element_type])
	
	# Apply weaknesses if target supports them
	if "weaknesses" in target and element_type in target.weaknesses:
		final_damage *= target.weaknesses[element_type]
	
	return take_damage(target, final_damage)

static func apply_status_damage(target: Node, amount: float, status_type: String) -> bool:
	# Apply damage with status effect
	var damage_applied = take_damage(target, amount)
	
	if damage_applied and target.has_method("apply_status_effect"):
		target.apply_status_effect(status_type)
	
	return damage_applied

# Utility and validation methods

static func _validate_health_target(target: Node) -> bool:
	# Validate that target is a valid health target
	return target != null and is_instance_valid(target)

static func _log_warning(message: String):
	# Log warning with health component context
	if GameConfig and GameConfig.should_log_event():
		push_warning("[HealthInterface] " + message)

static func get_health_info(target: Node) -> Dictionary:
	# Get complete health information for debugging
	if not _validate_health_target(target):
		return {"valid": false}
	
	return {
		"valid": true,
		"current_health": get_current_health(target),
		"max_health": get_max_health(target),
		"health_percentage": get_health_percentage(target),
		"is_alive": is_alive(target),
		"is_full_health": is_at_full_health(target),
		"missing_health": get_missing_health(target),
		"has_take_damage": target.has_method("take_damage"),
		"has_heal": target.has_method("heal"),
		"has_health_properties": "current_health" in target and "max_health" in target
	}

# Batch operations for performance

static func apply_damage_to_multiple(targets: Array, amount: float) -> int:
	# Apply damage to multiple targets, return count of successful applications
	var success_count = 0
	for target in targets:
		if take_damage(target, amount):
			success_count += 1
	return success_count

static func heal_multiple(targets: Array, amount: float) -> int:
	# Heal multiple targets, return count of successful heals
	var success_count = 0
	for target in targets:
		if heal(target, amount):
			success_count += 1
	return success_count
