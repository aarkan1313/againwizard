# IEnemyComponent.gd - Base interface for all enemy components
# Purpose: Standardize component communication and lifecycle management
# Godot Version: 4.4.1
# Benefits: Consistent patterns, better error handling, easier testing

extends Node
class_name IEnemyComponent

signal component_ready()
signal component_error(error_message: String)
signal component_state_changed(new_state: String)

var parent_enemy: Enemy
var component_name: String
var is_initialized: bool = false
var is_active: bool = true
var component_state: String = "inactive"

# Component lifecycle methods - MUST be implemented by subclasses

func initialize(enemy: Enemy) -> bool:
    # Initialize component with parent enemy reference
    if not is_instance_valid(enemy):
        _emit_error("Invalid enemy reference provided")
        return false
    
    parent_enemy = enemy
    component_name = get_component_name()
    
    var success = _on_initialize()
    if success:
        is_initialized = true
        component_state = "ready"
        component_ready.emit()
        print("✅ Component initialized: ", component_name)
    else:
        _emit_error("Component initialization failed")
    
    return success

func activate() -> void:
    # Activate component for processing
    if not is_initialized:
        _emit_error("Cannot activate uninitialized component")
        return
    
    is_active = true
    component_state = "active"
    _on_activate()
    component_state_changed.emit(component_state)

func deactivate() -> void:
    # Deactivate component (but keep initialized)
    is_active = false
    component_state = "inactive"
    _on_deactivate()
    component_state_changed.emit(component_state)

func cleanup() -> void:
    # Clean up component resources
    _on_cleanup()
    is_initialized = false
    is_active = false
    component_state = "destroyed"
    parent_enemy = null

func validate() -> bool:
    # Validate component state and parent reference
    return is_initialized and is_instance_valid(parent_enemy) and _validate_internal()

# Information methods

func get_component_name() -> String:
    # Get component name for identification
    var script_name = get_script().get_global_name()
    return script_name if script_name != "" else get_class()

func get_component_state() -> String:
    # Get current component state
    return component_state

func is_component_ready() -> bool:
    # Check if component is ready for use
    return is_initialized and is_active

# Virtual methods for subclasses to override

func _on_initialize() -> bool:
    # Override: Component-specific initialization logic
    return true

func _on_activate() -> void:
    # Override: Component-specific activation logic
    pass

func _on_deactivate() -> void:
    # Override: Component-specific deactivation logic
    pass

func _on_cleanup() -> void:
    # Override: Component-specific cleanup logic
    pass

func _validate_internal() -> bool:
    # Override: Component-specific validation logic
    return true

# Error handling

func _emit_error(error_message: String):
    # Emit error with component context
    var full_message = "[" + component_name + "] " + error_message
    push_error(full_message)
    component_error.emit(full_message)

func _emit_warning(warning_message: String):
    # Emit warning with component context
    var full_message = "[" + component_name + "] " + warning_message
    push_warning(full_message)

# Safe parent enemy access

func get_enemy() -> Enemy:
    # Get parent enemy with validation
    if validate():
        return parent_enemy
    return null

func get_enemy_position() -> Vector2:
    # Get enemy position safely
    var enemy = get_enemy()
    return enemy.global_position if enemy else Vector2.ZERO

func get_enemy_property(property_name: String, default_value = null):
    # Get enemy property safely with default fallback
    var enemy = get_enemy()
    if enemy and property_name in enemy:
        return enemy.get(property_name)
    return default_value

func set_enemy_property(property_name: String, value) -> bool:
    # Set enemy property safely
    var enemy = get_enemy()
    if enemy and property_name in enemy:
        enemy.set(property_name, value)
        return true
    return false

func call_enemy_method(method_name: String, args: Array = []):
    # Call enemy method safely
    var enemy = get_enemy()
    if enemy and enemy.has_method(method_name):
        return enemy.callv(method_name, args)
    return null