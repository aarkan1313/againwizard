# StatSystemTester.gd
# Purpose: Test and demonstrate the Phase 3 reactive stat system
# Press F3 to run stat system tests and display current status

extends Node

func _ready():
	print("🧪 StatSystemTester ready - Press F3 to test stat system")

func _input(event):
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_F3:
				test_stat_system()
			KEY_F4:
				test_wave_system()
			KEY_F5:
				test_integration()

func test_stat_system():
	print("\n=== 📊 STAT SYSTEM TEST ===")
	
	# Get player reference
	var player = get_player_reference()
	if not player:
		print("❌ No player found")
		return
	
	if not player.stat_sheet:
		print("❌ Player has no stat sheet")
		return
	
	print("✅ Player stat sheet found")
	
	# Display current stats
	print("\n🧙 CURRENT PLAYER STATS:")
	var stat_sheet = player.stat_sheet
	print("Level: ", stat_sheet.get_stat_value("level"))
	print("Intelligence: ", stat_sheet.get_stat_value("intelligence"))
	print("Wisdom: ", stat_sheet.get_stat_value("wisdom"))
	print("Vitality: ", stat_sheet.get_stat_value("vitality"))
	print("Dexterity: ", stat_sheet.get_stat_value("dexterity"))
	
	print("\n⚡ COMPUTED STATS:")
	print("Max Health: ", stat_sheet.get_stat_value("max_health"))
	print("Max Mana: ", stat_sheet.get_stat_value("max_mana"))
	print("Spell Damage Multiplier: ", stat_sheet.get_stat_value("spell_damage_multiplier"))
	print("Critical Chance: ", stat_sheet.get_stat_value("critical_chance"))
	print("Movement Speed: ", stat_sheet.get_stat_value("movement_speed"))
	
	print("\n🏆 PROGRESSION:")
	print("Total XP: ", stat_sheet.total_xp)
	print("XP to Next Level: ", stat_sheet.xp_to_next_level)
	print("Available Stat Points: ", stat_sheet.available_stat_points)
	
	# Test XP gain
	print("\n🎯 TESTING XP GAIN (+100 XP)...")
	player.gain_xp(100)
	
	print("New Level: ", stat_sheet.get_stat_value("level"))
	print("New Available Points: ", stat_sheet.available_stat_points)

func test_wave_system():
	print("\n=== 🌊 WAVE SYSTEM TEST ===")
	
	if not WaveManager:
		print("❌ WaveManager not found")
		return
	
	print("✅ WaveManager found")
	
	# Display wave info
	var wave_info = WaveManager.get_wave_info()
	print("\n📊 CURRENT WAVE STATUS:")
	print("Current Wave: ", wave_info.current_wave)
	print("Total Kills: ", wave_info.total_kills)
	print("Kills This Wave: ", wave_info.kills_this_wave)
	print("Kills to Next Wave: ", wave_info.kills_to_next)
	print("Progress: ", wave_info.progress_percentage, "%")
	print("Available Enemy Types: ", wave_info.available_enemies)
	print("Awarded Milestones: ", wave_info.awarded_milestones)
	
	# Display multipliers
	var multipliers = WaveManager.get_current_enemy_multipliers()
	print("\n💪 ENEMY SCALING:")
	print("Health Multiplier: ", multipliers.health, "x")
	print("Damage Multiplier: ", multipliers.damage, "x")
	print("Speed Multiplier: ", multipliers.speed, "x")
	
	# Test debug kill addition
	print("\n🎯 TESTING DEBUG KILLS (+5 kills)...")
	WaveManager.debug_add_kills(5)

func test_integration():
	print("\n=== 🔗 INTEGRATION TEST ===")
	
	var player = get_player_reference()
	if not player:
		print("❌ No player found")
		return
	
	# Test spell damage integration
	print("🪄 SPELL SYSTEM INTEGRATION:")
	print("Base Spell Damage Multiplier: ", player.get_spell_damage_multiplier())
	print("Critical Chance: ", player.get_critical_chance())
	print("Cast Speed Multiplier: ", player.get_cast_speed_multiplier())
	
	# Test adding a stat modifier (only if not already testing)
	if player.stat_sheet and not player.stat_sheet.has_modifiers_from_source("tester"):
		print("\n🎭 TESTING STAT MODIFIER (+5 Intelligence)...")
		var modifier = StatModifier.new(5.0, StatModifier.ModifierType.FLAT_ADD, "tester")
		player.stat_sheet.add_modifier_to_stat("intelligence", modifier)
		
		print("New Intelligence: ", player.stat_sheet.get_stat_value("intelligence"))
		print("New Spell Damage: ", player.get_spell_damage_multiplier())
		
		# Schedule removal after 3 seconds
		await get_tree().create_timer(3.0).timeout
		print("Removing test modifier...")
		player.stat_sheet.remove_modifiers_by_source("tester")
		print("Intelligence restored: ", player.stat_sheet.get_stat_value("intelligence"))
	else:
		print("⏭️ Integration test already running, skipping to avoid spam")

func get_player_reference() -> Node:
	# Try GameManager first
	if GameManager and GameManager.player_reference:
		return GameManager.player_reference
	
	# Try scene tree search
	var players = get_tree().get_nodes_in_group("players")
	if players.size() > 0:
		return players[0]
	
	return null

func _notification(what):
	if what == NOTIFICATION_READY:
		print("📋 StatSystemTester Controls:")
		print("   F3 - Test Stat System")
		print("   F4 - Test Wave System") 
		print("   F5 - Test Integration")
