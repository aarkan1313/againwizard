extends Node
# GameManager_WithSaveSystem.gd - Enhanced with Phase 3.6 Save System Integration
# Purpose: Centralized game state management with save/load functionality
# Godot Version: 4.4.1 compatible
# INCLUDES: All existing functionality PLUS save system integration

enum GameState { PLAYING, PAUSED, GAME_OVER }

# Game state
var current_state: GameState = GameState.PLAYING
var previous_state: GameState = GameState.PLAYING

# Player stats - FIXED: Remove hardcoded values, get from stat system
var player_health: float = 0.0
var player_max_health: float = 0.0
var player_mana: float = 0.0
var player_max_mana: float = 0.0

# Player reference
var player_reference = null
var player_stat_sheet: PlayerStatSheet = null

# Game progression
var current_wave: int = 1
var enemies_killed_this_wave: int = 0
var total_enemies_killed: int = 0
var total_xp_earned: int = 0

# Performance tracking
var frame_time_accumulator: float = 0.0
var frame_count: int = 0
var average_fps: float = 60.0

# === SAVE SYSTEM INTEGRATION ===
var save_manager  # SaveManager singleton reference

func _ready() -> void:
	# CRITICAL: Allow GameManager to process input even when paused (for unpause functionality)
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	print("✅ GameManager_WithSaveSystem singleton initialized")
	print("🎮 Initial state: PLAYING")
	
	# FIXED: Don't initialize with hardcoded values, wait for player
	_connect_to_systems()
	
	# Find player and setup stat integration
	call_deferred("_initialize_player_integration")
	
	# Initialize save system
	call_deferred("_initialize_save_system")

func _connect_to_systems() -> void:
	# Connect to GameEvents signals
	if GameEvents:
		GameEvents.enemy_died.connect(_on_enemy_died)
		GameEvents.player_health_changed.connect(_on_player_health_changed)
		GameEvents.player_mana_changed.connect(_on_player_mana_changed)
		print("📡 Connected to GameEvents signals")

# === NEW: SAVE SYSTEM INITIALIZATION ===
func _initialize_save_system():
	# Initialize the save manager singleton reference
	# SaveManager is an autoload singleton
	if has_node("/root/SaveManager"):
		save_manager = SaveManager
		
		# Connect signals for monitoring
		save_manager.save_completed.connect(_on_save_completed)
		save_manager.load_completed.connect(_on_load_completed)
		print("💾 Save system integrated with GameManager")
	else:
		push_error("SaveManager singleton not available")

func _on_save_completed(success: bool, message: String):
	# Handle save completion events
	if success:
		print("✅ Game saved successfully")
	else:
		push_error("Save failed: " + message)

func _on_load_completed(success: bool, message: String, save_data: SaveData):
	# Handle load completion events
	if success:
		print("✅ Game loaded successfully")
		# The SaveManager already restored game state
	else:
		push_error("Load failed: " + message)

# === NEW: PUBLIC SAVE SYSTEM API ===
func start_new_game(character_name: String) -> bool:
	# Start a new game with the given character name
	if not save_manager:
		push_error("Save manager not initialized")
		return false
	
	if save_manager.create_new_save(character_name):
		save_manager.enable_auto_save()
		return true
	return false

func save_game() -> bool:
	# Save the current game
	if not save_manager:
		push_error("Save manager not initialized")
		return false
	
	return save_manager.save_current_game()

func load_game() -> bool:
	# Load the saved game
	if not save_manager:
		push_error("Save manager not initialized")
		return false
	
	return await save_manager.load_saved_game()

func has_saved_game() -> bool:
	# Check if a save file exists
	if not save_manager:
		return false
	
	return save_manager.has_save_file()

func get_save_summary() -> Dictionary:
	# Get summary of current save for UI display
	if not save_manager:
		return {}
	
	return save_manager.get_save_summary()

func get_save_manager():
	# Get reference to save manager
	# Always return the global SaveManager if available
	if has_node("/root/SaveManager"):
		return SaveManager
	return null

func emergency_save() -> bool:
	# Perform emergency save (used when quitting)
	if save_manager and save_manager.current_save:
		print("🚨 Performing emergency save...")
		return save_manager.save_current_game()
	return false

# === EXISTING METHODS CONTINUE BELOW ===

func _initialize_player_integration() -> void:
	# FIXED: Initialize with actual player stat values
	player_reference = get_tree().get_first_node_in_group("players")
	if not player_reference:
		print("⚠️ GameManager: Player not found for stat integration")
		# Use fallback values
		player_health = 100.0
		player_max_health = 100.0
		player_mana = 50.0
		player_max_mana = 50.0
		return
	
	# Get player stat sheet
	if player_reference.has_method("get_stat_sheet"):
		player_stat_sheet = player_reference.get_stat_sheet()
		if player_stat_sheet:
			# Get actual max values from stats
			player_max_health = player_stat_sheet.get_stat_value("max_health")
			player_max_mana = player_stat_sheet.get_stat_value("max_mana")
			
			# Get current values from HealthComponent
			var health_component = player_reference.get_node_or_null("HealthComponent")
			if health_component:
				player_health = health_component.current_health
				player_mana = health_component.current_mana
			else:
				# Start at full health/mana
				player_health = player_max_health
				player_mana = player_max_mana
			
			print("📊 GameManager using stat-based values:")
			print("❤️ Player health: ", player_health, "/", player_max_health)
			print("🔮 Player mana: ", player_mana, "/", player_max_mana)
			
			# Connect to stat changes
			if not player_stat_sheet.stat_value_changed.is_connected(_on_stat_changed):
				player_stat_sheet.stat_value_changed.connect(_on_stat_changed)
				print("🔗 GameManager connected to stat changes")
		else:
			print("⚠️ GameManager: PlayerStatSheet not available")
	else:
		print("⚠️ GameManager: Player doesn't have get_stat_sheet method")

func _on_stat_changed(stat_name: String, old_value: float, new_value: float) -> void:
	# Handle stat changes to keep GameManager values synchronized
	if stat_name == "max_health":
		player_max_health = new_value
		print("📊 GameManager max_health updated: ", old_value, " → ", new_value)
	elif stat_name == "max_mana":
		player_max_mana = new_value
		print("📊 GameManager max_mana updated: ", old_value, " → ", new_value)

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_game"):
		toggle_pause()

func _process(delta: float) -> void:
	# Track performance
	frame_time_accumulator += delta
	frame_count += 1
	
	if frame_count >= 60:  # Update every second
		average_fps = frame_count / frame_time_accumulator
		frame_time_accumulator = 0.0
		frame_count = 0

# Game State Management
func set_game_state(new_state: GameState) -> void:
	if new_state == current_state:
		return
	
	var _old_state = current_state
	previous_state = current_state
	current_state = new_state
	
	match current_state:
		GameState.PLAYING:
			get_tree().paused = false
			# Ensure input is enabled when playing
			if InputHandler and InputHandler.has_method("enable_input"):
				InputHandler.enable_input()
			print("🎮 Game resumed")
		GameState.PAUSED:
			get_tree().paused = true
			print("⏸️ Game paused")
		GameState.GAME_OVER:
			get_tree().paused = true
			print("💀 Game over! Wave: " + str(current_wave) + ", Kills: " + str(total_enemies_killed))

func toggle_pause() -> void:
	if current_state == GameState.GAME_OVER:
		return  # Can't unpause from game over
		
	if current_state == GameState.PLAYING:
		set_game_state(GameState.PAUSED)
	elif current_state == GameState.PAUSED:
		set_game_state(GameState.PLAYING)

func restart_game() -> void:
	# FIXED: Reset to stat-based values, not hardcoded
	if player_stat_sheet:
		player_max_health = player_stat_sheet.get_stat_value("max_health")
		player_max_mana = player_stat_sheet.get_stat_value("max_mana")
	
	player_health = player_max_health
	player_mana = player_max_mana
	current_wave = 1
	enemies_killed_this_wave = 0
	total_enemies_killed = 0
	total_xp_earned = 0
	
	set_game_state(GameState.PLAYING)
	print("🔄 Game restarted with stat-based values")

# Player Health Management - FIXED: Don't override HealthComponent
func damage_player(damage: float) -> void:
	# DEPRECATED: Use HealthComponent.take_damage() instead
	push_warning("GameManager.damage_player() is deprecated. Use HealthComponent.take_damage() instead.")
	
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			health_component.take_damage(damage)

func heal_player(amount: float) -> void:
	# DEPRECATED: Use HealthComponent.heal() instead
	push_warning("GameManager.heal_player() is deprecated. Use HealthComponent.heal() instead.")
	
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			health_component.heal(amount)

# Player Mana Management - FIXED: Don't override HealthComponent
func consume_mana(amount: float) -> bool:
	# DEPRECATED: Use HealthComponent.consume_mana() instead
	push_warning("GameManager.consume_mana() is deprecated. Use HealthComponent.consume_mana() instead.")
	
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			return health_component.consume_mana(amount)
	return false

func restore_mana(amount: float) -> void:
	# DEPRECATED: Use HealthComponent.restore_mana() instead
	push_warning("GameManager.restore_mana() is deprecated. Use HealthComponent.restore_mana() instead.")
	
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			health_component.restore_mana(amount)

func get_player_mana_ratio() -> float:
	if player_max_mana <= 0:
		return 0.0
	return player_mana / player_max_mana

func has_mana(required_amount: float) -> bool:
	return player_mana >= required_amount

# Wave Management  
func complete_wave() -> void:
	current_wave += 1
	enemies_killed_this_wave = 0
	
	if GameEvents:
		GameEvents.emit_wave_completed(current_wave - 1)
	
	print("🌊 Wave " + str(current_wave - 1) + " completed! Starting wave " + str(current_wave))

# === MODIFIED: Add wave setters for save system ===
func set_current_wave(wave: int) -> void:
	# Set current wave (used by save system)
	current_wave = max(1, wave)

func set_total_kills(kills: int) -> void:
	# Set total kills (used by save system)
	total_enemies_killed = max(0, kills)

func get_current_wave() -> int:
	# Get current wave number
	return current_wave

func get_total_kills() -> int:
	# Get total enemies killed
	return total_enemies_killed

func get_waves_completed() -> int:
	# Get number of waves completed
	return max(0, current_wave - 1)

func _on_enemy_died(enemy_name: String, xp_awarded: int) -> void:
	enemies_killed_this_wave += 1
	total_enemies_killed += 1
	
	# Apply experience multiplier if player has stat sheet
	var final_xp = xp_awarded
	if player_reference and player_reference.has_method("get_stat_sheet"):
		var stat_sheet = player_reference.get_stat_sheet()
		if stat_sheet:
			var xp_multiplier = stat_sheet.get_stat_value("experience_multiplier")
			final_xp = int(xp_awarded * xp_multiplier)
			if xp_multiplier > 1.0:
				print("🧠 Intelligence XP bonus: ", xp_awarded, " → ", final_xp, " (", xp_multiplier, "x)")
	
	total_xp_earned += final_xp
	
	# Give XP to player via stat sheet
	if player_reference and player_reference.has_method("get_stat_sheet"):
		var stat_sheet = player_reference.get_stat_sheet()
		if stat_sheet and stat_sheet.has_method("gain_experience"):
			stat_sheet.gain_experience(final_xp)
	
	print("⚔️ Enemy killed: " + enemy_name + " (+" + str(final_xp) + " XP)")
	print("📊 Wave progress: " + str(enemies_killed_this_wave) + " killed")

func _on_player_health_changed(current: float, maximum: float) -> void:
	# FIXED: Trust the HealthComponent values
	player_health = current
	# Only update max if it changed significantly (stat update)
	if abs(maximum - player_max_health) > 1.0:
		player_max_health = maximum
		print("📊 GameManager max_health synchronized: ", player_max_health)

func _on_player_mana_changed(current: float, maximum: float) -> void:
	# FIXED: Trust the HealthComponent values
	player_mana = current
	# Only update max if it changed significantly (stat update)
	if abs(maximum - player_max_mana) > 1.0:
		player_max_mana = maximum
		print("📊 GameManager max_mana synchronized: ", player_max_mana)

# Getters for UI and other systems
func get_current_state() -> GameState:
	return current_state

func get_state_string() -> String:
	match current_state:
		GameState.PLAYING:
			return "Playing"
		GameState.PAUSED:
			return "Paused"
		GameState.GAME_OVER:
			return "Game Over"
		_:
			return "Unknown"

func get_player_health_ratio() -> float:
	if player_max_health <= 0:
		return 0.0
	return player_health / player_max_health

func get_performance_info() -> Dictionary:
	return {
		"fps": average_fps,
		"state": get_state_string(),
		"wave": current_wave,
		"enemies_killed": total_enemies_killed
	}

# Debug functions
func get_status_report() -> String:
	var save_status = "No save data"
	if save_manager and save_manager.current_save:
		save_status = "Save: " + save_manager.get_character_name()
	
	return """
GameManager_WithSaveSystem Status Report:
State: %s
Wave: %d
Player Health: %.1f/%.1f (%.1f%%)
Player Mana: %.1f/%.1f (%.1f%%)
Enemies Killed: %d (this wave: %d)
Total XP: %d
Average FPS: %.1f
Stat Integration: %s
Save System: %s
%s
""" % [
		get_state_string(),
		current_wave,
		player_health,
		player_max_health,
		get_player_health_ratio() * 100,
		player_mana,
		player_max_mana,
		get_player_mana_ratio() * 100,
		total_enemies_killed,
		enemies_killed_this_wave,
		total_xp_earned,
		average_fps,
		str(player_stat_sheet != null),
		str(save_manager != null),
		save_status
	]

# Player reference helpers
func get_player_position() -> Vector2:
	if player_reference:
		return player_reference.global_position
	return Vector2.ZERO

func get_player():
	return player_reference

func is_player_alive() -> bool:
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			return health_component.is_alive()
	return false

# Missing methods required by TestValidation.gd
func set_player_health(health: float) -> void:
	# FIXED: Set through HealthComponent instead of directly
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			health_component.current_health = clamp(health, 0.0, health_component._get_current_max_health())
			if GameEvents:
				GameEvents.emit_player_health_changed(health_component.current_health, health_component._get_current_max_health())

func validate_game_state() -> bool:
	return (player_health >= 0 and player_max_health > 0 and 
			current_wave > 0 and current_state in GameState.values())

func pause_game() -> void:
	toggle_pause()

func reset_game() -> void:
	restart_game()

func test_game_manager() -> bool:
	print("🧪 Testing GameManager_WithSaveSystem functionality...")
	
	# Test state changes
	toggle_pause()
	toggle_pause()
	
	# FIXED: Test through HealthComponent instead of direct calls
	if player_reference:
		var health_component = player_reference.get_node_or_null("HealthComponent")
		if health_component:
			health_component.take_damage(25.0)
			health_component.heal(15.0)
			health_component.consume_mana(10.0)
			health_component.restore_mana(5.0)
	
	# Test enemy death tracking
	_on_enemy_died("TestEnemy", 50)
	
	# Test save system
	if save_manager:
		print("🧪 Testing save system integration...")
		var test_save = start_new_game("TestSave")
		print("Create test save: ", test_save)
		var save_success = save_game()
		print("Save game: ", save_success)
		var has_save = has_saved_game()
		print("Has saved game: ", has_save)
	
	print("✅ GameManager_WithSaveSystem tests completed successfully")
	return true
