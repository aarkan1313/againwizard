extends CharacterBody2D

# Simple test golem for Area2D testing

var stomp_timer = 0.0
var stomp_cooldown = 3.0
var move_speed = 50.0

func _ready():
	print("🗿 Simple golem ready at ", global_position)
	add_to_group("enemies")

func _physics_process(delta):
	stomp_timer -= delta
	
	# Get player
	var player = GameManager.get_player() if GameManager else null
	if not player:
		return
	
	var distance = global_position.distance_to(player.global_position)
	
	# Move towards player slowly
	if distance > 50:
		var direction = (player.global_position - global_position).normalized()
		velocity = direction * move_speed
	else:
		velocity = Vector2.ZERO
		
		# Try stone stomp when close
		if stomp_timer <= 0 and distance <= 100:
			stone_stomp()
			stomp_timer = stomp_cooldown
	
	move_and_slide()

func stone_stomp():
	print("🗿 SIMPLE GOLEM STOMP!")
	
	# Create Area2D for damage detection
	var damage_area = Area2D.new()
	var collision_shape = CollisionShape2D.new()
	var circle_shape = CircleShape2D.new()
	
	circle_shape.radius = 150.0
	collision_shape.shape = circle_shape
	damage_area.collision_layer = 0
	damage_area.collision_mask = 1
	damage_area.monitoring = true
	
	damage_area.add_child(collision_shape)
	get_tree().current_scene.add_child(damage_area)
	damage_area.global_position = global_position
	
	print("🗿 STOMP: Area2D created at ", global_position, " with radius ", circle_shape.radius)
	
	# Wait for physics
	await get_tree().physics_frame
	await get_tree().physics_frame
	
	var bodies = damage_area.get_overlapping_bodies()
	print("🗿 STOMP: Found ", bodies.size(), " bodies")
	
	for body in bodies:
		print("🗿 STOMP: Checking body ", body.name, " groups: ", body.get_groups())
		if body.is_in_group("player") and body.has_method("take_damage"):
			body.take_damage(25)
			print("💥 STOMP HIT PLAYER!")
	
	# Clean up
	damage_area.queue_free()