extends Node
# Logger.gd - Centralized error tracking and logging system
# Purpose: Provides unified error tracking across all game systems
# Godot Version: 4.4.1 compatible

# Error tracking counters
var error_count: int = 0
var warning_count: int = 0
var info_count: int = 0

# Log storage for debugging
var error_log: Array = []
var warning_log: Array = []
var max_log_entries: int = 100

# Categories for organized logging
enum LogCategory {
	GENERAL,
	GAMEEVENTS,
	GAMEMANAGER,
	INPUT,
	COLLISION,
	PLAYER,
	UI,
	PERFORMANCE,
	TESTING
}

func _ready() -> void:
	print("✅ Logger singleton initialized")
	print("📝 Error tracking system ready")
	
	# Set up the logger to process errors even when paused
	process_mode = Node.PROCESS_MODE_ALWAYS

# Main logging functions
func log_error(message: String, source: String = "Unknown", category: LogCategory = LogCategory.GENERAL) -> void:
	error_count += 1
	
	var log_entry = {
		"timestamp": Time.get_datetime_string_from_system(),
		"message": message,
		"source": source,
		"category": LogCategory.keys()[category],
		"type": "ERROR"
	}
	
	error_log.append(log_entry)
	_trim_log_if_needed(error_log)
	
	# Print to console with formatting
	print("❌ ERROR [" + source + "]: " + message)
	
	# Critical error handling
	if error_count > 50:
		push_warning("Logger: High error count detected (" + str(error_count) + "). System stability may be compromised.")

func log_warning(message: String, source: String = "Unknown", category: LogCategory = LogCategory.GENERAL) -> void:
	warning_count += 1
	
	var log_entry = {
		"timestamp": Time.get_datetime_string_from_system(),
		"message": message,
		"source": source,
		"category": LogCategory.keys()[category],
		"type": "WARNING"
	}
	
	warning_log.append(log_entry)
	_trim_log_if_needed(warning_log)
	
	# Print to console with formatting
	print("⚠️ WARNING [" + source + "]: " + message)

func log_info(message: String, source: String = "Unknown", _category: LogCategory = LogCategory.GENERAL) -> void:
	info_count += 1
	
	# Info messages don't need storage, just console output
	print("ℹ️ INFO [" + source + "]: " + message)

# System health and reporting functions
func get_error_summary() -> String:
	var summary = "Logger Error Summary:\n"
	summary += "- Total Errors: " + str(error_count) + "\n"
	summary += "- Total Warnings: " + str(warning_count) + "\n"
	summary += "- Total Info Messages: " + str(info_count) + "\n"
	summary += "- Recent Errors: " + str(error_log.size()) + "\n"
	summary += "- Recent Warnings: " + str(warning_log.size()) + "\n"
	summary += "- System Health: " + _get_system_health_status() + "\n"
	return summary

func get_system_health_status() -> String:
	return _get_system_health_status()

func _get_system_health_status() -> String:
	if error_count == 0 and warning_count <= 5:
		return "EXCELLENT"
	elif error_count <= 5 and warning_count <= 15:
		return "GOOD"
	elif error_count <= 15 and warning_count <= 30:
		return "FAIR"
	else:
		return "POOR"

# Advanced logging functions
func get_errors_by_category(category: LogCategory) -> Array:
	var category_name = LogCategory.keys()[category]
	var filtered_errors = []
	
	for error in error_log:
		if error.category == category_name:
			filtered_errors.append(error)
	
	return filtered_errors

func get_recent_errors(count: int = 10) -> Array:
	var recent_count = min(count, error_log.size())
	return error_log.slice(-recent_count)

func get_recent_warnings(count: int = 10) -> Array:
	var recent_count = min(count, warning_log.size())
	return warning_log.slice(-recent_count)

# Testing and validation functions
func clear_logs() -> void:
	error_count = 0
	warning_count = 0
	info_count = 0
	error_log.clear()
	warning_log.clear()
	log_info("Logs cleared", "Logger", LogCategory.TESTING)

func is_system_healthy() -> bool:
	# System is healthy if error count is low and no critical errors in last 10 entries
	if error_count > 20:
		return false
	
	var recent_errors = get_recent_errors(10)
	for error in recent_errors:
		if "critical" in error.message.to_lower() or "crash" in error.message.to_lower():
			return false
	
	return true

# Quality gate integration
func validate_error_threshold() -> bool:
	# For quality gates - system should have minimal errors
	return error_count <= 5 and warning_count <= 15

# Performance monitoring integration
func log_performance_warning(fps: float, source: String = "Performance Monitor") -> void:
	if fps < 30:
		log_error("Critical FPS drop detected: " + str(fps) + " FPS", source, LogCategory.PERFORMANCE)
	elif fps < 45:
		log_warning("Low FPS detected: " + str(fps) + " FPS", source, LogCategory.PERFORMANCE)

# Helper functions
func _trim_log_if_needed(log_array: Array) -> void:
	while log_array.size() > max_log_entries:
		log_array.pop_front()

# Debug functions for testing the logger itself
func test_logger_functionality() -> bool:
	print("🧪 Testing Logger functionality...")
	
	var initial_error_count = error_count
	var initial_warning_count = warning_count
	
	# Test basic logging
	log_error("Test error message", "Logger Test", LogCategory.TESTING)
	log_warning("Test warning message", "Logger Test", LogCategory.TESTING)
	log_info("Test info message", "Logger Test", LogCategory.TESTING)
	
	# Verify counts increased
	var errors_increased = (error_count == initial_error_count + 1)
	var warnings_increased = (warning_count == initial_warning_count + 1)
	
	if errors_increased and warnings_increased:
		log_info("Logger functionality test PASSED", "Logger Test", LogCategory.TESTING)
		return true
	else:
		print("❌ Logger functionality test FAILED")
		return false

# System integration helpers
func get_error_count_for_system(source: String) -> int:
	var count = 0
	for error in error_log:
		if error.source == source:
			count += 1
	return count

func get_warning_count_for_system(source: String) -> int:
	var count = 0
	for warning in warning_log:
		if warning.source == source:
			count += 1
	return count
