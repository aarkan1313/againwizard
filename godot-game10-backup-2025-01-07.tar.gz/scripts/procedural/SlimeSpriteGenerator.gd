# SlimeSpriteGenerator.gd
# Procedural sprite generation for slime enemy
extends RefCounted
class_name SlimeSpriteGenerator

static func generate_slime_texture() -> ImageTexture:
	# Generate a procedural green slime texture
	var size = 64
	var image = Image.create(size, size, false, Image.FORMAT_RGBA8)
	
	var center = Vector2(size / 2, size / 2)
	var main_radius = 28.0
	var highlight_radius = 15.0
	
	# Base slime color (bright green)
	var slime_color = Color(0.2, 0.8, 0.3, 1.0)  # Bright green
	var slime_dark = Color(0.1, 0.6, 0.2, 1.0)   # Darker green for shading
	var highlight_color = Color(0.6, 1.0, 0.7, 0.8)  # Light green highlight
	var shine_color = Color(1.0, 1.0, 1.0, 0.6)  # White shine
	
	# Fill the slime body
	for x in range(size):
		for y in range(size):
			var pos = Vector2(x, y)
			var distance_from_center = pos.distance_to(center)
			
			# Main slime body (circular with slight squash)
			var squash_factor = 1.0 + 0.2 * sin((pos.y / float(size)) * PI)
			var adjusted_radius = main_radius * squash_factor
			
			if distance_from_center <= adjusted_radius:
				# Create gradient from center to edge
				var gradient = 1.0 - (distance_from_center / adjusted_radius)
				var final_color = slime_color.lerp(slime_dark, 1.0 - gradient * 0.7)
				
				# Add some noise for texture
				var noise_factor = sin(x * 0.3) * cos(y * 0.4) * 0.1
				final_color = final_color.lerp(slime_dark, noise_factor)
				
				# Bottom shadow
				if y > center.y + 10:
					var shadow_strength = (y - center.y - 10) / 15.0
					final_color = final_color.lerp(slime_dark, shadow_strength * 0.5)
				
				image.set_pixel(x, y, final_color)
			
			# Highlight blob (upper left)
			var highlight_center = center + Vector2(-8, -12)
			var highlight_distance = pos.distance_to(highlight_center)
			if highlight_distance <= highlight_radius:
				var highlight_strength = 1.0 - (highlight_distance / highlight_radius)
				var current_color = image.get_pixel(x, y)
				if current_color.a > 0:  # Only add highlight to existing slime
					var highlighted = current_color.lerp(highlight_color, highlight_strength * 0.6)
					image.set_pixel(x, y, highlighted)
			
			# Small shine spot (upper right)
			var shine_center = center + Vector2(6, -8)
			var shine_distance = pos.distance_to(shine_center)
			if shine_distance <= 4:
				var shine_strength = 1.0 - (shine_distance / 4.0)
				var current_color = image.get_pixel(x, y)
				if current_color.a > 0:  # Only add shine to existing slime
					var shined = current_color.lerp(shine_color, shine_strength * 0.8)
					image.set_pixel(x, y, shined)
	
	# Create texture from image
	var texture = ImageTexture.new()
	texture.set_image(image)
	return texture

static func generate_animated_slime_frames() -> Array[ImageTexture]:
	# Generate multiple frames for slime animation
	var frames: Array[ImageTexture] = []
	
	# Generate 4 frames with slight variations for bouncy animation
	for frame in range(4):
		var size = 64
		var image = Image.create(size, size, false, Image.FORMAT_RGBA8)
		var center = Vector2(size / 2, size / 2)
		
		# Animate the squash factor
		var bounce_phase = (frame / 4.0) * PI * 2
		var squash_multiplier = 1.0 + 0.3 * sin(bounce_phase)
		var stretch_multiplier = 1.0 + 0.2 * cos(bounce_phase)
		
		var main_radius = 28.0
		var slime_color = Color(0.2, 0.8, 0.3, 1.0)
		var slime_dark = Color(0.1, 0.6, 0.2, 1.0)
		
		for x in range(size):
			for y in range(size):
				var pos = Vector2(x, y)
				var distance_from_center = pos.distance_to(center)
				
				# Apply squash and stretch
				var local_pos = pos - center
				local_pos.x *= stretch_multiplier
				local_pos.y *= squash_multiplier
				var adjusted_distance = local_pos.length()
				
				if adjusted_distance <= main_radius:
					var gradient = 1.0 - (adjusted_distance / main_radius)
					var final_color = slime_color.lerp(slime_dark, 1.0 - gradient * 0.7)
					image.set_pixel(x, y, final_color)
		
		var texture = ImageTexture.new()
		texture.set_image(image)
		frames.append(texture)
	
	return frames

static func save_slime_texture_to_file(file_path: String) -> bool:
	# Save the generated slime texture to a PNG file
	var texture = generate_slime_texture()
	var image = texture.get_image()
	
	# Ensure directory exists
	var dir = DirAccess.open("res://")
	var path_parts = file_path.split("/")
	var current_path = "res://"
	
	for i in range(path_parts.size() - 1):  # Skip the filename
		current_path += path_parts[i] + "/"
		if not dir.dir_exists(current_path):
			dir.make_dir(current_path)
	
	# Save the image
	var error = image.save_png(file_path)
	if error == OK:
		print("✅ Slime texture saved to: %s" % file_path)
		return true
	else:
		print("❌ Failed to save slime texture: Error %d" % error)
		return false