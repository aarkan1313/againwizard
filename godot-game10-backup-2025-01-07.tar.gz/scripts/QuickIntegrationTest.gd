# QuickIntegrationTest.gd
# Purpose: Quick test to verify Phase 3 integration is working end-to-end

extends Node

func _ready():
	print("🚀 Running Quick Integration Test...")
	await get_tree().process_frame
	run_integration_test()

func run_integration_test():
	print("\n" + "=".repeat(50))
	print("    QUICK INTEGRATION TEST")
	print("=".repeat(50))
	
	var success = true
	
	# Test 1: Create PlayerStatSheet manually
	print("\n🧪 Test 1: PlayerStatSheet Creation")
	var dummy_player = Node.new()
	dummy_player.name = "DummyPlayer"
	var stat_sheet = PlayerStatSheet.new(dummy_player)
	
	if stat_sheet:
		print("  ✅ PlayerStatSheet created successfully")
		print("  📊 Intelligence: ", stat_sheet.get_stat_value("intelligence"))
		print("  📊 Spell Damage Multiplier: ", stat_sheet.get_stat_value("spell_damage_multiplier"))
	else:
		print("  ❌ Failed to create PlayerStatSheet")
		success = false
	
	# Test 2: WaveManager functionality
	print("\n🧪 Test 2: WaveManager Integration")
	if WaveManager:
		var wave_info = WaveManager.get_wave_info()
		print("  ✅ WaveManager accessible")
		print("  🌊 Current Wave: ", wave_info.current_wave)
		print("  💀 Total Kills: ", wave_info.total_kills)
		print("  🎯 Kills to Next: ", wave_info.kills_to_next)
		
		# Test enemy types
		var enemy_types = WaveManager.get_available_enemy_types()
		print("  👹 Available Enemies: ", enemy_types)
	else:
		print("  ❌ WaveManager not accessible")
		success = false
	
	# Test 3: Signal connections
	print("\n🧪 Test 3: Signal System")
	if GameEvents:
		print("  ✅ GameEvents accessible")
		print("  📡 enemy_died signal: ", GameEvents.has_signal("enemy_died"))
		print("  📡 spell_cast signal: ", GameEvents.has_signal("spell_cast"))
	else:
		print("  ❌ GameEvents not accessible")
		success = false
	
	# Test 4: Scene loading
	print("\n🧪 Test 4: Critical Scene Loading")
	var scenes_to_test = [
		"res://scenes/GameplayMain.tscn",
		"res://scenes/Enemy.tscn"
	]
	
	for scene_path in scenes_to_test:
		if ResourceLoader.exists(scene_path):
			var scene = load(scene_path)
			if scene:
				print("  ✅ ", scene_path, " loads successfully")
			else:
				print("  ❌ ", scene_path, " failed to load")
				success = false
		else:
			print("  ❌ ", scene_path, " not found")
			success = false
	
	# Test 5: Stat calculation performance
	print("\n🧪 Test 5: Performance Test")
	if stat_sheet:
		var start_time = Time.get_unix_time_from_system()
		
		# Run 1000 stat calculations
		for i in range(1000):
			var damage_mult = stat_sheet.get_stat_value("spell_damage_multiplier")
			var crit_chance = stat_sheet.get_stat_value("critical_chance")
		
		var end_time = Time.get_unix_time_from_system()
		var duration = end_time - start_time
		
		print("  ⚡ 1000 stat calculations in ", duration, " seconds")
		if duration < 0.1:  # Should be very fast with caching
			print("  ✅ Performance excellent (< 0.1s)")
		else:
			print("  ⚠️ Performance slower than expected")
	
	# Final Results
	print("\n" + "=".repeat(50))
	if success:
		print("✅ INTEGRATION TEST PASSED!")
		print("🎮 Phase 3 is ready for gameplay!")
		print("\n🚀 To play:")
		print("   • Run scenes/GameplayMain.tscn for full experience")
		print("   • Run scenes/TestMain.tscn for enhanced test scene")
		print("   • Run scenes/Phase3VerificationTest.tscn for validation")
	else:
		print("❌ INTEGRATION TEST FAILED!")
		print("⚠️ Some components are not working correctly")
	print("=".repeat(50))
	
	# Cleanup
	dummy_player.queue_free()