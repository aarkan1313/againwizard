# PlayerStatSheet.gd - FIXED VERSION WITH IMMEDIATE STAT UPDATES
# Purpose: Fixed player stat sheet with proper stat propagation and update mechanisms
# Godot Version: 4.4.1 (verified via official docs)
# FIXES: 
# - Force immediate recalculation when stats change
# - Prevent recursion by using base values in formulas
# - Ensure all dependent stats update immediately
# - Add helper to get base stat values

extends StatSheet
class_name PlayerStatSheet

# Player-specific signals - RETAINED from current system
signal level_up(new_level: int, stat_points_gained: int)
signal attribute_increased(attribute_name: String, new_value: float)
signal milestone_reached(milestone_name: String, bonus_description: String)
signal xp_gained(current_xp: float, total_xp: float, xp_to_next: float, current_level: int)

# Player progression - RETAINED all current features
var available_stat_points: int = 0
var total_xp: float = 0.0
var current_xp: float = 0.0  # RETAINED: Current XP towards next level (for UI)
var xp_to_next_level: float = 100.0

# Track when we're updating stats to prevent loops
var _updating_stats: bool = false

func _init(player_entity: Node = null):
	super._init(player_entity, "Player")
	setup_player_stats()

# Setup all player stats according to Phase 3 design - RETAINED with enhancements
func setup_player_stats():
	setup_base_attributes()
	setup_enhanced_computed_stats()  # ENHANCED: Now supports direct modifiers
	setup_combat_stats()
	setup_utility_stats()
	
	# Force initial calculation of all computed stats
	_force_update_all_computed_stats()
	
	# Validate everything is working
	validate_stat_sheet()
	print("🧙 PlayerStatSheet initialized with ", get_all_stat_names().size(), " stats")

# === CORE ATTRIBUTES (Base Stats) === - RETAINED EXACTLY
func setup_base_attributes():
	# Core attributes - these are what players level up
	register_stat("intelligence", 10.0)
	register_stat("wisdom", 10.0)
	register_stat("vitality", 10.0)
	register_stat("dexterity", 10.0)
	register_stat("level", 1.0)
	
	print("✅ Base attributes setup complete")

# === ENHANCED COMPUTED STATS === - FIXED implementation
var enhanced_computed_stats: Dictionary = {}

func setup_enhanced_computed_stats():
	# Register as regular computed stats first
	register_computed_stat("max_health", 
		"100 + vitality * 5 + level * 3", 
		["vitality", "level"],
		"Maximum health points")
	
	register_computed_stat("health_regen_rate", 
		"2.0 + vitality * 0.5", 
		["vitality"],
		"Health regeneration per second")
	
	register_computed_stat("max_mana", 
		"50 + intelligence * 3 + wisdom * 2 + level * 2", 
		["intelligence", "wisdom", "level"],
		"Maximum mana points")
	
	register_computed_stat("mana_regen_rate", 
		"3.0 + wisdom * 0.8 + intelligence * 0.2", 
		["wisdom", "intelligence"],
		"Mana regeneration per second")
	
	register_computed_stat("spell_damage_multiplier", 
		"1.0 + intelligence * 0.02", 
		["intelligence"],
		"Multiplier for spell damage")
	
	register_computed_stat("critical_chance", 
		"0.05 + intelligence * 0.001", 
		["intelligence"],
		"Chance for critical spell hits")
	
	register_computed_stat("cooldown_reduction", 
		"wisdom * 0.005", 
		["wisdom"],
		"Spell cooldown reduction")
	
	register_computed_stat("movement_speed", 
		"120 + dexterity * 2", 
		["dexterity"],
		"Player movement speed")
	
	# DISABLED: cast_speed_multiplier - only needed when spells have cast times
	# register_computed_stat("cast_speed_multiplier", 
	#	"1.0 + dexterity * 0.015", 
	#	["dexterity"],
	#	"Spell casting speed multiplier")
	
	# Create enhanced computed stat overlays for those that need direct modifiers
	_setup_enhanced_computed_overlays()
	
	print("✅ Enhanced computed stats setup complete")

# Setup enhanced computed stat overlays for direct modifier support
func _setup_enhanced_computed_overlays():
	var stats_needing_direct_modifiers = [
		"max_health", "health_regen_rate", "max_mana", "mana_regen_rate",
		"spell_damage_multiplier", "critical_chance", "movement_speed", "experience_multiplier", "free_cast_chance", "spell_projectile_speed", "spell_range_multiplier", "dodge_chance"
	]
	
	for stat_name in stats_needing_direct_modifiers:
		var computed_stat = _get_base_computed_stat(stat_name)
		if computed_stat:
			var enhanced_stat = EnhancedComputedStat.new(
				computed_stat.formula, 
				computed_stat.dependencies, 
				self, 
				stat_name
			)
			enhanced_computed_stats[stat_name] = enhanced_stat
			
			# Connect value changed signal for immediate propagation
			enhanced_stat.value_changed.connect(_on_enhanced_stat_changed.bind(stat_name))
			
			# Connect to base stat changes to ensure updates propagate
			for dependency in computed_stat.dependencies:
				if has_stat(dependency):
					var base_stat = _get_base_reactive_stat(dependency)
					if base_stat and not base_stat.value_changed.is_connected(_on_dependency_changed):
						base_stat.value_changed.connect(_on_dependency_changed.bind(stat_name))

# FIXED: Propagate enhanced stat changes immediately
func _on_enhanced_stat_changed(old_value: float, new_value: float, stat_name: String):
	if not _updating_stats:
		_updating_stats = true
		# Emit stat value changed for UI and other systems
		stat_value_changed.emit(stat_name, old_value, new_value)
		_updating_stats = false

# FIXED: Helper to get base computed stat from parent class
func _get_base_computed_stat(stat_name: String) -> ComputedStat:
	if computed_stats.has(stat_name):
		return computed_stats[stat_name]
	return null

# FIXED: Helper to get base reactive stat from parent class
func _get_base_reactive_stat(stat_name: String) -> ReactiveStat:
	if stats.has(stat_name):
		return stats[stat_name]
	return null

# FIXED: Handle dependency changes to force immediate recalculation
func _on_dependency_changed(old_value: float, new_value: float, dependent_stat: String):
	if enhanced_computed_stats.has(dependent_stat):
		# Force immediate recalculation
		enhanced_computed_stats[dependent_stat].recalculate()

# Force update all computed stats
func _force_update_all_computed_stats():
	for stat_name in enhanced_computed_stats:
		enhanced_computed_stats[stat_name].recalculate()

# === COMBAT STATS === - RETAINED EXACTLY
func setup_combat_stats():
	# These could be computed or direct stats depending on design
	# Spell projectile speed now scales with intelligence (50% base + 0.5% per point)
	register_computed_stat("spell_projectile_speed",
		"300.0 * (1.0 + intelligence * 0.005)",
		["intelligence"],
		"Projectile speed multiplier")
	# Spell range multiplier now scales with intelligence (0.5% per point)
	register_computed_stat("spell_range_multiplier",
		"1.0 + intelligence * 0.005",
		["intelligence"],
		"Spell projectile range multiplier")
	# Free cast chance now scales with wisdom (0.1% per point)
	register_computed_stat("free_cast_chance",
		"wisdom * 0.001",
		["wisdom"],
		"Chance to cast spells without mana cost")
	register_stat("spell_penetration", 0.0)
	
	# Add critical hit multiplier stat
	register_stat("critical_hit_multiplier", 2.0)  # 2x damage on crit
	
	print("✅ Combat stats setup complete")

# === UTILITY STATS === - RETAINED EXACTLY
func setup_utility_stats():
	# Dodge chance now scales with vitality (5% base + 0.1% per point)
	register_computed_stat("dodge_chance",
		"0.05 + vitality * 0.001",
		["vitality"],
		"Chance to automatically avoid damage")
	# Experience multiplier now scales with intelligence (0.5% per point - balanced)
	register_computed_stat("experience_multiplier",
		"1.0 + intelligence * 0.005",
		["intelligence"],
		"Experience gain multiplier")
	register_stat("item_find_bonus", 0.0)
	
	# Movement and dodge stats for MovementComponent integration
	register_stat("dodge_speed", 600.0)
	register_stat("dodge_duration", 0.4)
	register_stat("dodge_cooldown", 1.2)
	register_stat("acceleration", 10.0)
	register_stat("friction", 8.0)
	
	print("✅ Utility stats setup complete")

# === ENHANCED MODIFIER SUPPORT ===

# Override add_modifier_to_stat to support enhanced computed stats
func add_modifier_to_stat(stat_name: String, modifier: StatModifier):
	# Check if this is an enhanced computed stat that needs direct modifier support
	if enhanced_computed_stats.has(stat_name):
		enhanced_computed_stats[stat_name].add_modifier(modifier)
		print("➕ Added enhanced modifier to ", stat_name, ": ", modifier.get_debug_info())
		return
	
	# Fall back to regular stat sheet behavior
	super.add_modifier_to_stat(stat_name, modifier)

# Override get_stat_value to use enhanced computed stats when available
func get_stat_value(stat_name: String) -> float:
	if enhanced_computed_stats.has(stat_name):
		return enhanced_computed_stats[stat_name].get_final_value()
	
	# Fall back to regular stat sheet behavior
	return super.get_stat_value(stat_name)

# NEW: Get base stat value without modifiers (for formula evaluation)
func get_stat_base_value(stat_name: String) -> float:
	if stats.has(stat_name):
		return stats[stat_name].base_value
	return 0.0

# Override set_stat_base_value to force immediate updates
func set_stat_base_value(stat_name: String, value: float):
	super.set_stat_base_value(stat_name, value)
	# Force recalculation of dependent enhanced stats
	_update_dependent_enhanced_stats(stat_name)

# Update all enhanced stats that depend on a changed stat
func _update_dependent_enhanced_stats(changed_stat: String):
	for stat_name in enhanced_computed_stats:
		var enhanced_stat = enhanced_computed_stats[stat_name]
		if changed_stat in enhanced_stat.dependencies:
			enhanced_stat.recalculate()

# Override get_computed_stat to maintain parent signature
func get_computed_stat(stat_name: String) -> ComputedStat:
	# Return the base computed stat for API compatibility
	return super.get_computed_stat(stat_name)

# Helper method to get enhanced computed stats (for internal use)
func get_enhanced_computed_stat(stat_name: String) -> EnhancedComputedStat:
	if enhanced_computed_stats.has(stat_name):
		return enhanced_computed_stats[stat_name]
	return null

# Override remove_modifiers_by_source to handle enhanced computed stats
func remove_modifiers_by_source(source: String):
	# Remove from enhanced computed stats
	for stat_name in enhanced_computed_stats:
		enhanced_computed_stats[stat_name].remove_modifiers_by_source(source)
	
	# Fall back to regular stat sheet behavior
	super.remove_modifiers_by_source(source)

# Get modifier summary for enhanced computed stats
func get_modifier_summary(stat_name: String) -> Dictionary:
	if enhanced_computed_stats.has(stat_name):
		return enhanced_computed_stats[stat_name].get_modifier_summary()
	else:
		return {"type": "regular_stat", "modifiers": 0}

# === PLAYER PROGRESSION === - RETAINED ALL FEATURES

# RETAINED: Gain experience points with proper current_xp tracking
func gain_experience(xp_amount: float):
	total_xp += xp_amount
	current_xp += xp_amount
	print("💎 Gained ", xp_amount, " XP (Total: ", total_xp, ", Current: ", current_xp, "/", xp_to_next_level, ")")
	
	# Emit XP gained signal for UI updates
	var current_level = get_stat_value("level")
	xp_gained.emit(current_xp, total_xp, xp_to_next_level, int(current_level))
	
	# Check for level up
	while current_xp >= xp_to_next_level:
		level_up_player()

# RETAINED: Level up the player with proper XP tracking
func level_up_player():
	var current_level = get_stat_value("level")
	var new_level = current_level + 1
	
	# Store old threshold for correct XP calculation
	var old_threshold = xp_to_next_level
	
	# Calculate XP needed for next level (increases each level)
	xp_to_next_level = 100.0 + (new_level * 50.0)
	
	# RETAINED: Keep overflow XP for next level - subtract old threshold from current_xp
	current_xp -= old_threshold
	
	# Increase level
	set_stat_base_value("level", new_level)
	
	# Award stat points
	var stat_points_gained = 2  # 2 stat points per level
	available_stat_points += stat_points_gained
	
	# Emit level up signal
	level_up.emit(new_level, stat_points_gained)
	
	# Emit XP gained signal with updated values for UI
	xp_gained.emit(current_xp, total_xp, xp_to_next_level, int(new_level))
	
	print("🎉 Level Up! Level ", new_level, " (", stat_points_gained, " stat points gained)")
	print("📊 Current XP: ", current_xp, "/", xp_to_next_level, " for next level")

# === STAT ALLOCATION === - RETAINED ALL FEATURES

# RETAINED: Allocate stat points to attributes
func allocate_stat_points(allocations: Dictionary) -> bool:
	var total_points_needed = 0
	
	# Calculate total points needed
	for stat_name in allocations:
		total_points_needed += allocations[stat_name]
	
	# Check if we have enough points
	if total_points_needed > available_stat_points:
		push_error("Not enough stat points! Need: " + str(total_points_needed) + ", Have: " + str(available_stat_points))
		return false
	
	# Apply allocations
	for stat_name in allocations:
		var points_to_add = allocations[stat_name]
		if points_to_add > 0:
			var current_value = get_stat_value(stat_name)
			set_stat_base_value(stat_name, current_value + points_to_add)
			available_stat_points -= points_to_add
			
			print("📈 Increased ", stat_name, " by ", points_to_add, " (new value: ", get_stat_value(stat_name), ")")
			attribute_increased.emit(stat_name, get_stat_value(stat_name))
	
	print("✅ Stat allocation complete. Remaining points: ", available_stat_points)
	return true

# RETAINED: Increase a single attribute by a specified amount (used by StatAllocationPanel)
func increase_attribute(attribute_name: String, points: int) -> bool:
	# Validate attribute name
	if not has_stat(attribute_name):
		push_error("PlayerStatSheet: Unknown attribute '" + attribute_name + "'")
		return false
	
	# Check if we have enough stat points
	if points > available_stat_points:
		push_error("PlayerStatSheet: Not enough stat points! Need: " + str(points) + ", Have: " + str(available_stat_points))
		return false
	
	# Increase the attribute
	var current_value = get_stat_value(attribute_name)
	set_stat_base_value(attribute_name, current_value + points)
	available_stat_points -= points
	
	# Emit signal and check milestones
	attribute_increased.emit(attribute_name, get_stat_value(attribute_name))
	check_milestones()
	
	print("📈 Increased ", attribute_name, " by ", points, " (new value: ", get_stat_value(attribute_name), ")")
	return true

# === ENHANCED MILESTONE BONUS SYSTEM === - FIXED to target computed stats directly

# ENHANCED: Apply milestone bonuses directly to computed stats (FIXES the error!)
func apply_milestone_bonus(milestone_name: String):
	var modifier_source = "milestone_" + milestone_name
	
	match milestone_name:
		"first_blood":  # 10 kills - FIXED: Direct +25 flat health bonus
			var health_modifier = StatModifier.new(25.0, StatModifier.ModifierType.FLAT_ADD, modifier_source)
			add_modifier_to_stat("max_health", health_modifier)  # Direct to computed stat!
			print("🏆 Applied milestone bonus: +25 flat health (separate from vitality scaling)")
			
		"apprentice_slayer":  # 50 kills - FIXED: Direct +1.0 flat mana regen bonus
			var mana_regen_modifier = StatModifier.new(1.0, StatModifier.ModifierType.FLAT_ADD, modifier_source)
			add_modifier_to_stat("mana_regen_rate", mana_regen_modifier)  # Direct to computed stat!
			print("🏆 Applied milestone bonus: +1.0 flat mana regen (separate from wisdom scaling)")
			
		"monster_hunter":  # 100 kills - FIXED: Direct +2% flat critical chance bonus
			var crit_modifier = StatModifier.new(0.02, StatModifier.ModifierType.FLAT_ADD, modifier_source)
			add_modifier_to_stat("critical_chance", crit_modifier)  # Direct to computed stat!
			print("🏆 Applied milestone bonus: +2% flat critical chance (separate from intelligence scaling)")
			
		"death_dealer":  # 250 kills - ENHANCED: +15% spell damage as percentage bonus
			var damage_modifier = StatModifier.new(0.15, StatModifier.ModifierType.PERCENT_ADD, modifier_source)
			add_modifier_to_stat("spell_damage_multiplier", damage_modifier)  # Percentage stacking!
			print("🏆 Applied milestone bonus: +15% spell damage multiplier (stacks with intelligence)")
			
		"destroyer":  # 500 kills - ENHANCED: Mixed bonuses with proper stacking
			# Direct flat health bonus
			var health_modifier = StatModifier.new(50.0, StatModifier.ModifierType.FLAT_ADD, modifier_source)
			add_modifier_to_stat("max_health", health_modifier)
			
			# Percentage spell damage bonus
			var damage_modifier = StatModifier.new(0.25, StatModifier.ModifierType.PERCENT_ADD, modifier_source)
			add_modifier_to_stat("spell_damage_multiplier", damage_modifier)
			print("🏆 Applied milestone bonus: +50 flat health, +25% spell damage multiplier")
			
		"legend":  # 1000 kills - ENHANCED: Ultimate mixed bonuses with perfect stacking
			# Massive flat health bonus
			var ultimate_health_modifier = StatModifier.new(100.0, StatModifier.ModifierType.FLAT_ADD, modifier_source)
			add_modifier_to_stat("max_health", ultimate_health_modifier)
			
			# Huge percentage spell damage bonus
			var ultimate_damage_modifier = StatModifier.new(0.50, StatModifier.ModifierType.PERCENT_ADD, modifier_source)
			add_modifier_to_stat("spell_damage_multiplier", ultimate_damage_modifier)
			
			# Flat critical chance bonus
			var ultimate_crit_modifier = StatModifier.new(0.05, StatModifier.ModifierType.FLAT_ADD, modifier_source)
			add_modifier_to_stat("critical_chance", ultimate_crit_modifier)
			print("🏆 Applied milestone bonus: +100 flat health, +50% spell damage, +5% flat crit")
			
		_:
			push_warning("PlayerStatSheet: Unknown milestone '" + milestone_name + "'")

# Force refresh all systems after stat allocation
func refresh_all_systems():
	print("🔄 Refreshing all systems after stat allocation...")
	
	# Force recalculation of all enhanced stats
	_force_update_all_computed_stats()
	
	# Emit signals for UI updates
	var vital_stats = get_vital_stats()
	for stat_name in vital_stats:
		stat_value_changed.emit(stat_name, vital_stats[stat_name], vital_stats[stat_name])
	
	# Update GameEvents for proper synchronization
	if GameEvents:
		# Force health/mana update
		var health_comp = owner_entity.get_node_or_null("HealthComponent") if owner_entity else null
		if health_comp:
			health_comp.on_stats_changed()
		
		# Ensure UI gets updated
		var player_ui = owner_entity.get_tree().get_first_node_in_group("player_ui") if owner_entity else null
		if player_ui and player_ui.has_method("force_refresh"):
			player_ui.force_refresh()
		
		GameEvents.emit_signal("stats_refreshed")
	
	print("✅ All systems refreshed after stat allocation")

# RETAINED: Reset all allocated stat points (for testing/respec)
func reset_stat_allocations():
	# Reset to base level 1 values
	set_stat_base_value("intelligence", 10.0)
	set_stat_base_value("wisdom", 10.0) 
	set_stat_base_value("vitality", 10.0)
	set_stat_base_value("dexterity", 10.0)
	
	# Recalculate available points based on level
	var current_level = get_stat_value("level")
	available_stat_points = int(current_level - 1) * 2  # 2 points per level after 1
	
	print("🔄 Stats reset to base values. Available points: ", available_stat_points)

# === MILESTONE SYSTEM === - RETAINED attribute-based milestones

# RETAINED: Check for milestone achievements
func check_milestones():
	var intelligence = get_stat_value("intelligence")
	var wisdom = get_stat_value("wisdom")
	var vitality = get_stat_value("vitality")
	var dexterity = get_stat_value("dexterity")
	var level = get_stat_value("level")
	
	# Intelligence milestones
	if intelligence == 25:
		milestone_reached.emit("Arcane Adept", "Critical spell chance increased")
	elif intelligence == 50:
		milestone_reached.emit("Master Wizard", "Spell damage significantly increased")
	
	# Wisdom milestones
	if wisdom == 25:
		milestone_reached.emit("Sage", "Mana regeneration greatly increased")
	elif wisdom == 50:
		milestone_reached.emit("Archmage", "Spell cooldowns significantly reduced")
	
	# Vitality milestones
	if vitality == 25:
		milestone_reached.emit("Hardy Survivor", "Health and regeneration greatly increased")
	elif vitality == 50:
		milestone_reached.emit("Indomitable", "Maximum survivability achieved")
	
	# Dexterity milestones
	if dexterity == 25:
		milestone_reached.emit("Swift Caster", "Movement and casting speed increased")
	elif dexterity == 50:
		milestone_reached.emit("Lightning Reflexes", "Maximum agility achieved")
	
	# Level milestones
	if level == 10:
		milestone_reached.emit("Experienced Adventurer", "Significant power increase")
	elif level == 25:
		milestone_reached.emit("Veteran Wizard", "Mastery of magical arts")
	elif level == 50:
		milestone_reached.emit("Legendary Mage", "Ultimate magical power")

# === VITAL STATS GETTER === - RETAINED

# RETAINED: Get vital stats (used by UI and other systems)
func get_vital_stats() -> Dictionary:
	return {
		"max_health": get_stat_value("max_health"),
		"health_regen_rate": get_stat_value("health_regen_rate"),
		"max_mana": get_stat_value("max_mana"),
		"mana_regen_rate": get_stat_value("mana_regen_rate"),
		"movement_speed": get_stat_value("movement_speed")
	}

# Get all allocatable stats for UI
func get_allocatable_stats() -> Array[String]:
	return ["intelligence", "wisdom", "vitality", "dexterity"]

# Get all display stats for UI
func get_display_stats() -> Dictionary:
	return {
		# Base stats
		"Intelligence": int(get_stat_value("intelligence")),
		"Wisdom": int(get_stat_value("wisdom")),
		"Vitality": int(get_stat_value("vitality")),
		"Dexterity": int(get_stat_value("dexterity")),
		"Level": int(get_stat_value("level")),
		
		# Computed stats
		"Max Health": int(get_stat_value("max_health")),
		"Health Regen": "%.1f/s" % get_stat_value("health_regen_rate"),
		"Max Mana": int(get_stat_value("max_mana")),
		"Mana Regen": "%.1f/s" % get_stat_value("mana_regen_rate"),
		
		# Combat stats
		"Spell Damage": "%.1fx" % get_stat_value("spell_damage_multiplier"),
		"Critical Chance": "%.1f%%" % (get_stat_value("critical_chance") * 100),
		"Critical Damage": "%.1fx" % get_stat_value("critical_hit_multiplier"),
		# "Cast Speed": "%.1fx" % get_stat_value("cast_speed_multiplier"),  # Disabled - no cast times yet
		"Cooldown Reduction": "%.0f%%" % (get_stat_value("cooldown_reduction") * 100),
		
		# Movement
		"Movement Speed": int(get_stat_value("movement_speed")),
		"Dodge Chance": "%.0f%%" % (get_stat_value("dodge_chance") * 100),
		
		# Available points
		"Stat Points": available_stat_points
	}

# === GETTERS FOR UI === - RETAINED ALL

# RETAINED: Get current XP for UI display
func get_current_xp() -> float:
	return current_xp

func get_total_xp() -> float:
	return total_xp

func get_xp_to_next_level() -> float:
	return xp_to_next_level

func get_level() -> int:
	return int(get_stat_value("level"))

func get_available_stat_points() -> int:
	return available_stat_points

# === CORE ATTRIBUTES GETTERS === - RETAINED

func get_intelligence() -> float:
	return get_stat_value("intelligence")

func get_wisdom() -> float:
	return get_stat_value("wisdom")

func get_vitality() -> float:
	return get_stat_value("vitality")

func get_dexterity() -> float:
	return get_stat_value("dexterity")

# === COMPUTED STATS GETTERS === - RETAINED

func get_max_health() -> float:
	return get_stat_value("max_health")

func get_max_mana() -> float:
	return get_stat_value("max_mana")

func get_spell_damage_multiplier() -> float:
	return get_stat_value("spell_damage_multiplier")

func get_movement_speed() -> float:
	return get_stat_value("movement_speed")

func get_critical_chance() -> float:
	return get_stat_value("critical_chance")

func get_cooldown_reduction() -> float:
	return get_stat_value("cooldown_reduction")

# === DEBUG AND VALIDATION === - ENHANCED

func get_debug_info() -> String:
	var debug_str = """
PlayerStatSheet Debug Info:
Level: %d (Available Points: %d)
XP: %.1f / %.1f (Total: %.1f)
Intelligence: %.1f | Wisdom: %.1f | Vitality: %.1f | Dexterity: %.1f
Max Health: %.1f | Max Mana: %.1f
Spell Damage: %.2fx | Movement Speed: %.1f
Critical Chance: %.1f%% | Cooldown Reduction: %.1f%%
""" % [
		get_level(), available_stat_points,
		current_xp, xp_to_next_level, total_xp,
		get_intelligence(), get_wisdom(), get_vitality(), get_dexterity(),
		get_max_health(), get_max_mana(),
		get_spell_damage_multiplier(), get_movement_speed(),
		get_critical_chance() * 100, get_cooldown_reduction() * 100
	]
	
	# Add enhanced stat info
	debug_str += "\nEnhanced Computed Stats:\n"
	for stat_name in enhanced_computed_stats:
		var summary = get_modifier_summary(stat_name)
		debug_str += "  %s: %.2f (modifiers: %d)\n" % [stat_name, get_stat_value(stat_name), summary.flat_modifiers + summary.percent_modifiers + summary.multiplier_modifiers]
	
	return debug_str

# RETAINED: Validate XP system is working correctly
func validate_xp_system() -> bool:
	# Validate XP system is working correctly
	var valid = true
	
	if current_xp < 0:
		push_error("current_xp is negative: " + str(current_xp))
		valid = false
	
	if xp_to_next_level <= 0:
		push_error("xp_to_next_level is invalid: " + str(xp_to_next_level))
		valid = false
	
	if total_xp < 0:
		push_error("total_xp is negative: " + str(total_xp))
		valid = false
	
	if valid:
		print("✅ XP system validation passed")
	
	return valid

# === ENHANCED FEATURES DEMONSTRATION ===

# NEW: Debug function to show enhanced modifier stacking
func debug_stat_breakdown(stat_name: String):
	print("=== ", stat_name.to_upper(), " BREAKDOWN ===")
	if enhanced_computed_stats.has(stat_name):
		var enhanced_stat = enhanced_computed_stats[stat_name]
		print(enhanced_stat.get_calculation_breakdown())
	else:
		print("Not an enhanced computed stat")
		print("Current Value: ", get_stat_value(stat_name))
	print("=============================")

# NEW: Example gear system for future use
func equip_gear(gear_item: Dictionary):
	var gear_source = "gear_" + gear_item.get("name", "unknown")
	
	# Example gear bonuses with different modifier types
	if gear_item.has("flat_health"):
		var modifier = StatModifier.new(gear_item.flat_health, StatModifier.ModifierType.FLAT_ADD, gear_source)
		add_modifier_to_stat("max_health", modifier)
	
	if gear_item.has("percent_damage"):
		var modifier = StatModifier.new(gear_item.percent_damage, StatModifier.ModifierType.PERCENT_ADD, gear_source)
		add_modifier_to_stat("spell_damage_multiplier", modifier)
	
	if gear_item.has("intelligence_bonus"):
		var modifier = StatModifier.new(gear_item.intelligence_bonus, StatModifier.ModifierType.FLAT_ADD, gear_source)
		add_modifier_to_stat("intelligence", modifier)

func unequip_gear(gear_name: String):
	var gear_source = "gear_" + gear_name
	remove_modifiers_by_source(gear_source)
