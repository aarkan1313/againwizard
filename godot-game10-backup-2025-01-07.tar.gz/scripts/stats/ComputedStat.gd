# ComputedStat.gd
# Purpose: Formula-based stats that auto-update when dependencies change
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: StatSheet, Expression class
# API References: Official Godot Expression documentation

extends RefCounted
class_name ComputedStat

signal value_changed(old_value: float, new_value: float)
signal recalculated(new_value: float)

# Core computed stat data
var formula: String = ""
var dependencies: Array[String] = []
var stat_sheet: StatSheet
var cached_value: float = 0.0
var is_dirty: bool = true
var is_evaluating: bool = false  # Recursion prevention flag

# Metadata
var stat_name: String = ""
var stat_description: String = ""

# Expression parsing
var expression: Expression
var parsed_formula: String = ""

# Performance optimization: Cache compiled RegEx patterns
var regex_cache: Dictionary = {}

func _init(name: String = "", formula_str: String = "", deps: Array[String] = [], description: String = ""):
	stat_name = name
	formula = formula_str
	dependencies = deps
	stat_description = description
	expression = Expression.new()
	mark_dirty()

# Setup after creation (when StatSheet is available)
func setup(formula_str: String, deps: Array[String], sheet: StatSheet):
	formula = formula_str
	dependencies = deps
	stat_sheet = sheet
	
	# Parse the formula for validation
	parse_formula()
	
	print("🧮 ComputedStat setup: ", stat_name, " = ", formula)

# Get the final calculated value (with caching and recursion prevention)
func get_final_value() -> float:
	# Prevent infinite recursion
	if is_evaluating:
		push_warning("ComputedStat: Recursion detected for " + stat_name + " - returning cached value: " + str(cached_value))
		return cached_value
	
	if is_dirty:
		is_evaluating = true  # Set recursion flag
		var old_value = cached_value
		var evaluation_successful = false
		
		# Try to evaluate with error handling
		var new_value = evaluate_formula()
		if new_value == 0.0 and not formula.is_empty():
			push_warning("ComputedStat: Formula evaluation returned 0 for " + stat_name + " - this might indicate an error")
		else:
			evaluation_successful = true
		
		cached_value = new_value
		is_dirty = false
		is_evaluating = false  # Always clear recursion flag
		
		# Only emit signals if evaluation was successful
		if evaluation_successful:
			recalculated.emit(cached_value)
			if abs(old_value - cached_value) > 0.001:
				value_changed.emit(old_value, cached_value)
				# Only log significant changes to prevent spam
				if abs(old_value - cached_value) > 1.0:
					print("📈 ", stat_name, " computed: ", old_value, " → ", cached_value)
	
	return cached_value

# Force recalculation
func recalculate() -> float:
	mark_dirty()
	return get_final_value()

# Evaluate the mathematical formula
func evaluate_formula() -> float:
	if not stat_sheet:
		push_error("ComputedStat: Cannot evaluate " + stat_name + " - no StatSheet reference")
		return 0.0
	
	if formula.is_empty():
		return 0.0
	
	var formula_copy = formula
	
	# Replace stat names with actual values using cached RegEx
	for dep_name in dependencies:
		var stat_value = stat_sheet.get_stat_value(dep_name)
		# Use cached RegEx pattern for performance
		var regex = _get_cached_regex(dep_name)
		formula_copy = regex.sub(formula_copy, str(stat_value), true)
	
	# Evaluate the mathematical expression
	var error = expression.parse(formula_copy)
	if error != OK:
		push_error("ComputedStat: Failed to parse formula for " + stat_name + ": " + formula_copy)
		return 0.0
	
	var result = expression.execute()
	if expression.has_execute_failed():
		push_error("ComputedStat: Failed to execute formula for " + stat_name + ": " + formula_copy)
		return 0.0
	
	# Ensure result is a number
	if typeof(result) != TYPE_FLOAT and typeof(result) != TYPE_INT:
		push_error("ComputedStat: Formula result is not a number for " + stat_name + ": " + str(result))
		return 0.0
	
	return float(result)

# Parse and validate formula
func parse_formula() -> bool:
	if formula.is_empty():
		return true
	
	# Create a test formula with dummy values
	var test_formula = formula
	for dep_name in dependencies:
		var pattern = "\\b" + dep_name + "\\b"
		var regex = RegEx.new()
		regex.compile(pattern)
		test_formula = regex.sub(test_formula, "1.0", true)
	
	# Test parsing
	var test_expression = Expression.new()
	var error = test_expression.parse(test_formula)
	if error != OK:
		push_error("ComputedStat: Invalid formula syntax for " + stat_name + ": " + formula)
		return false
	
	# Test execution
	var _result = test_expression.execute()
	if test_expression.has_execute_failed():
		push_error("ComputedStat: Formula execution failed for " + stat_name + ": " + test_formula)
		return false
	
	parsed_formula = test_formula
	print("✅ Formula validated for ", stat_name, ": ", formula)
	return true

# Dirty flagging
func mark_dirty():
	is_dirty = true

func is_stat_dirty() -> bool:
	return is_dirty

# Dependency management
func add_dependency(dep_name: String):
	if not dep_name in dependencies:
		dependencies.append(dep_name)
		mark_dirty()
		print("🔗 Added dependency to ", stat_name, ": ", dep_name)

func remove_dependency(dep_name: String):
	if dep_name in dependencies:
		dependencies.erase(dep_name)
		mark_dirty()
		print("🔗 Removed dependency from ", stat_name, ": ", dep_name)

func has_dependency(dep_name: String) -> bool:
	return dep_name in dependencies

func get_dependencies() -> Array[String]:
	return dependencies.duplicate()

# Connect to dependency changes (called by StatSheet)
func connect_to_dependencies():
	if not stat_sheet:
		return
	
	for dep_name in dependencies:
		var dep_stat = stat_sheet.get_stat(dep_name)
		if dep_stat:
			# Connect to ReactiveStat
			if not dep_stat.value_changed.is_connected(_on_dependency_changed):
				dep_stat.value_changed.connect(_on_dependency_changed)
		else:
			var comp_stat = stat_sheet.get_computed_stat(dep_name)
			if comp_stat:
				# Connect to ComputedStat
				if not comp_stat.value_changed.is_connected(_on_dependency_changed):
					comp_stat.value_changed.connect(_on_dependency_changed)

func _on_dependency_changed(_old_val: float, _new_val: float):
	mark_dirty()
	print("🔄 ", stat_name, " dependency changed, marking dirty")

# Disconnect from all dependencies to prevent memory leaks
func disconnect_from_dependencies():
	if not stat_sheet:
		return
	
	for dep_name in dependencies:
		var dep_stat = stat_sheet.get_stat(dep_name)
		if dep_stat and dep_stat.value_changed.is_connected(_on_dependency_changed):
			dep_stat.value_changed.disconnect(_on_dependency_changed)
		
		var comp_stat = stat_sheet.get_computed_stat(dep_name)
		if comp_stat and comp_stat.value_changed.is_connected(_on_dependency_changed):
			comp_stat.value_changed.disconnect(_on_dependency_changed)

# Get cached RegEx pattern for performance optimization
func _get_cached_regex(dep_name: String) -> RegEx:
	if not regex_cache.has(dep_name):
		var regex = RegEx.new()
		var pattern = "\\b" + dep_name + "\\b"
		regex.compile(pattern)
		regex_cache[dep_name] = regex
	return regex_cache[dep_name]

# Cleanup when ComputedStat is destroyed
func cleanup():
	disconnect_from_dependencies()
	stat_sheet = null
	expression = null
	regex_cache.clear()

# Debug information
func get_debug_info() -> String:
	var info = "ComputedStat: " + stat_name + "\n"
	info += "  Formula: " + formula + "\n"
	info += "  Dependencies: " + str(dependencies) + "\n"
	info += "  Current Value: " + str(get_final_value()) + "\n"
	info += "  Dirty: " + str(is_dirty)
	return info

func get_formula_with_values() -> String:
	if not stat_sheet:
		return formula
	
	var formula_copy = formula
	for dep_name in dependencies:
		var stat_value = stat_sheet.get_stat_value(dep_name)
		formula_copy = formula_copy.replace(dep_name, str(stat_value))
	
	return formula_copy + " = " + str(get_final_value())

# Validation
func validate() -> bool:
	if stat_name.is_empty():
		push_error("ComputedStat validation failed: stat_name cannot be empty")
		return false
	
	if formula.is_empty():
		push_error("ComputedStat validation failed: formula cannot be empty for " + stat_name)
		return false
	
	if dependencies.is_empty():
		push_warning("ComputedStat warning: no dependencies specified for " + stat_name)
	
	return parse_formula()
