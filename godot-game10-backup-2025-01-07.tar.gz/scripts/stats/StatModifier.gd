# StatModifier.gd
# Purpose: Individual stat modifications for reactive stat system
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: Godot Resource system
# API References: Official Godot Resource documentation

extends Resource
class_name StatModifier

enum ModifierType {
	FLAT_ADD,     # +10 damage
	PERCENT_ADD,  # +25% damage (stacks additively)
	PERCENT_MULT, # ×1.25 damage (multiplicative)
	OVERRIDE      # Force to specific value
}

@export var value: float = 0.0
@export var type: ModifierType = ModifierType.FLAT_ADD
@export var priority: int = 0
@export var source: String = ""

func _init(modifier_value: float = 0.0, modifier_type: ModifierType = ModifierType.FLAT_ADD, modifier_source: String = ""):
	value = modifier_value
	type = modifier_type
	source = modifier_source

# Get modifier priority for calculation order
func get_calculation_priority() -> int:
	match type:
		ModifierType.OVERRIDE:
			return 0  # Applied first
		ModifierType.FLAT_ADD:
			return 1  # Applied second
		ModifierType.PERCENT_ADD:
			return 2  # Applied third
		ModifierType.PERCENT_MULT:
			return 3  # Applied last
		_:
			return priority

# Apply this modifier to a base value
func apply_to_value(base_value: float) -> float:
	match type:
		ModifierType.FLAT_ADD:
			return base_value + value
		ModifierType.PERCENT_ADD:
			return base_value + (base_value * value)
		ModifierType.PERCENT_MULT:
			return base_value * value
		ModifierType.OVERRIDE:
			return value
		_:
			return base_value

# Get debug information
func get_debug_info() -> String:
	var type_str = ""
	match type:
		ModifierType.FLAT_ADD:
			type_str = "+" + str(value)
		ModifierType.PERCENT_ADD:
			type_str = "+" + str(value * 100) + "%"
		ModifierType.PERCENT_MULT:
			type_str = "×" + str(value)
		ModifierType.OVERRIDE:
			type_str = "=" + str(value)
	
	return type_str + " (" + source + ")"

# Validation
func is_valid() -> bool:
	if source.is_empty():
		push_error("StatModifier validation failed: source cannot be empty")
		return false
	
	match type:
		ModifierType.PERCENT_MULT:
			if value <= 0:
				push_error("StatModifier validation failed: PERCENT_MULT value must be > 0")
				return false
		ModifierType.OVERRIDE:
			if value < 0:
				push_error("StatModifier validation failed: OVERRIDE value cannot be negative")
				return false
	
	return true