# StatSheet.gd
# Purpose: Collection of all stats for an entity in reactive stat system
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: ReactiveStat, ComputedStat, StatModifier
# API References: Official Godot Dictionary and signal documentation

extends RefCounted
class_name StatSheet

signal stat_added(stat_name: String)
signal _stat_removed(stat_name: String)  # Future API for stat removal
signal stat_value_changed(stat_name: String, old_value: float, new_value: float)

# Core stat collections
var stats: Dictionary = {}          # String -> ReactiveStat
var computed_stats: Dictionary = {} # String -> ComputedStat

# Entity reference
var owner_entity: Node
var entity_name: String = ""

func _init(entity: Node = null, name: String = ""):
	owner_entity = entity
	entity_name = name
	print("📊 StatSheet created for: ", entity_name)

# Initialize base stats for player
func initialize_base_stats():
	# Base stats
	register_stat("level", 1, "Character level")
	register_stat("vitality", 10, "Increases health and health regeneration")
	register_stat("strength", 10, "Increases physical damage")
	register_stat("intelligence", 10, "Increases spell damage and mana")
	register_stat("wisdom", 10, "Increases mana regeneration")
	register_stat("agility", 10, "Increases movement speed and dodge chance")
	
	# Resource stats
	register_stat("max_health", 100, "Maximum health points")
	register_stat("max_mana", 50, "Maximum mana points")
	register_stat("health_regen_rate", 2.0, "Health regeneration per second")
	register_stat("mana_regen_rate", 3.0, "Mana regeneration per second")
	
	# Combat stats
	register_stat("spell_power", 1.0, "Spell damage multiplier")
	register_stat("dodge_chance", 0.0, "Chance to dodge attacks")
	
	print("✅ Base stats initialized for: ", entity_name)

# === STAT REGISTRATION ===

# Register a basic reactive stat
func register_stat(name: String, base_value: float, description: String = "") -> ReactiveStat:
	if stats.has(name):
		push_warning("StatSheet: Stat already exists: " + name + " - returning existing")
		return stats[name]
	
	var stat = ReactiveStat.new(name, base_value, description)
	stats[name] = stat
	
	# Connect to value changes for propagation using wrapper function
	stat.value_changed.connect(_create_reactive_stat_wrapper(name))
	
	stat_added.emit(name)
	print("📈 Registered stat: ", name, " = ", base_value)
	return stat

# Register a computed stat with formula
func register_computed_stat(name: String, formula: String, dependencies: Array[String], description: String = "") -> ComputedStat:
	if computed_stats.has(name):
		push_warning("StatSheet: Computed stat already exists: " + name + " - returning existing")
		return computed_stats[name]
	
	var computed_stat = ComputedStat.new(name, formula, dependencies, description)
	computed_stat.setup(formula, dependencies, self)
	computed_stats[name] = computed_stat
	
	# Connect to value changes for propagation using wrapper function
	computed_stat.value_changed.connect(_create_computed_stat_wrapper(name))
	
	# Connect to dependencies
	computed_stat.connect_to_dependencies()
	
	stat_added.emit(name)
	print("🧮 Registered computed stat: ", name, " = ", formula)
	return computed_stat

# === STAT ACCESS ===

# Get stat value (works for both reactive and computed stats)
func get_stat_value(name: String) -> float:
	if stats.has(name):
		return stats[name].get_final_value()
	elif computed_stats.has(name):
		return computed_stats[name].get_final_value()
	else:
		push_warning("StatSheet: Stat not found: " + name + " - returning 0")
		return 0.0

# Get reactive stat reference
func get_stat(name: String) -> ReactiveStat:
	if stats.has(name):
		return stats[name]
	return null

# Get computed stat reference
func get_computed_stat(name: String) -> ComputedStat:
	if computed_stats.has(name):
		return computed_stats[name]
	return null

# Check if stat exists
func has_stat(name: String) -> bool:
	return stats.has(name) or computed_stats.has(name)

# === MODIFIER MANAGEMENT ===

# Add modifier to a specific stat
func add_modifier_to_stat(stat_name: String, modifier: StatModifier):
	if not modifier or not modifier.is_valid():
		push_error("StatSheet: Cannot add invalid modifier to " + stat_name)
		return
	
	if stats.has(stat_name):
		stats[stat_name].add_modifier(modifier)
		print("➕ Added modifier to ", stat_name, ": ", modifier.get_debug_info())
	else:
		push_error("StatSheet: Cannot add modifier - stat not found: " + stat_name)

# Remove specific modifier from a stat
func remove_modifier_from_stat(stat_name: String, modifier: StatModifier):
	if stats.has(stat_name):
		stats[stat_name].remove_modifier(modifier)
		print("➖ Removed modifier from ", stat_name, ": ", modifier.get_debug_info())
	else:
		push_warning("StatSheet: Cannot remove modifier - stat not found: " + stat_name)

# Remove all modifiers from a source across all stats
func remove_modifiers_by_source(source: String):
	var removed_count = 0
	
	for stat_name in stats.keys():
		var stat = stats[stat_name]
		var initial_count = stat.get_modifier_count()
		stat.remove_modifiers_by_source(source)
		removed_count += initial_count - stat.get_modifier_count()
	
	if removed_count > 0:
		print("🧹 Removed ", removed_count, " modifiers from all stats (source: ", source, ")")

# Check if any stat has modifiers from source
func has_modifiers_from_source(source: String) -> bool:
	for stat in stats.values():
		if stat.has_modifier_from_source(source):
			return true
	return false

# === BULK OPERATIONS ===

# Set base value for a stat
func set_stat_base_value(stat_name: String, new_value: float):
	if stats.has(stat_name):
		stats[stat_name].set_base_value(new_value)
	else:
		push_warning("StatSheet: Cannot set base value - stat not found: " + stat_name)

# Get all stat names
func get_all_stat_names() -> Array[String]:
	var all_names: Array[String] = []
	
	# Manually add each key to avoid type conversion issues
	for key in stats.keys():
		all_names.append(key)
	for key in computed_stats.keys():
		all_names.append(key)
	
	return all_names

# Get all stat values as dictionary
func get_all_stat_values() -> Dictionary:
	var values = {}
	
	for name in stats.keys():
		values[name] = stats[name].get_final_value()
	
	for name in computed_stats.keys():
		values[name] = computed_stats[name].get_final_value()
	
	return values

# Force recalculation of all stats
func recalculate_all_stats():
	print("🔄 Recalculating all stats for: ", entity_name)
	
	# Recalculate reactive stats first
	for stat in stats.values():
		stat.recalculate()
	
	# Then computed stats (they depend on reactive stats)
	for computed_stat in computed_stats.values():
		computed_stat.recalculate()

# === STAT VALIDATION ===

# Validate all stats and their dependencies
func validate_stat_sheet() -> bool:
	var is_valid = true
	
	# Validate reactive stats
	for stat_name in stats.keys():
		var stat = stats[stat_name]
		if not stat.validate():
			push_error("StatSheet: Invalid reactive stat: " + stat_name)
			is_valid = false
	
	# Validate computed stats
	for stat_name in computed_stats.keys():
		var computed_stat = computed_stats[stat_name]
		if not computed_stat.validate():
			push_error("StatSheet: Invalid computed stat: " + stat_name)
			is_valid = false
		
		# Check dependencies exist
		for dep_name in computed_stat.dependencies:
			if not has_stat(dep_name):
				push_error("StatSheet: Missing dependency '" + dep_name + "' for computed stat: " + stat_name)
				is_valid = false
	
	if is_valid:
		print("✅ StatSheet validation passed for: ", entity_name)
	else:
		print("❌ StatSheet validation failed for: ", entity_name)
	
	return is_valid

# === DEBUG AND INFORMATION ===

# Get comprehensive debug information
func get_debug_info() -> String:
	var info = "=== StatSheet Debug Info: " + entity_name + " ===\n"
	
	info += "\nReactive Stats (" + str(stats.size()) + "):\n"
	for stat_name in stats.keys():
		var stat = stats[stat_name]
		info += "  " + stat_name + ": " + str(stat.get_final_value())
		if stat.get_modifier_count() > 0:
			info += " (" + stat.get_modifier_summary() + ")"
		info += "\n"
	
	info += "\nComputed Stats (" + str(computed_stats.size()) + "):\n"
	for stat_name in computed_stats.keys():
		var computed_stat = computed_stats[stat_name]
		info += "  " + stat_name + ": " + str(computed_stat.get_final_value())
		info += " [" + computed_stat.formula + "]\n"
	
	return info

# Get stat summary for UI display
func get_stat_summary() -> Dictionary:
	var summary = {}
	
	for name in stats.keys():
		var stat = stats[name]
		summary[name] = {
			"value": stat.get_final_value(),
			"base": stat.get_base_value(),
			"modifiers": stat.get_modifier_count(),
			"type": "reactive"
		}
	
	for name in computed_stats.keys():
		var computed_stat = computed_stats[name]
		summary[name] = {
			"value": computed_stat.get_final_value(),
			"formula": computed_stat.formula,
			"dependencies": computed_stat.dependencies,
			"type": "computed"
		}
	
	return summary

# === SIGNAL HANDLERS ===

# Create wrapper functions to avoid signal parameter binding issues
func _create_reactive_stat_wrapper(stat_name: String) -> Callable:
	return func(old_value: float, new_value: float):
		_on_stat_value_changed(stat_name, old_value, new_value)

func _create_computed_stat_wrapper(stat_name: String) -> Callable:
	return func(old_value: float, new_value: float):
		_on_stat_value_changed(stat_name, old_value, new_value)

func _on_stat_value_changed(stat_name: String, old_value: float, new_value: float):
	stat_value_changed.emit(stat_name, old_value, new_value)
	
	# Optional: Log significant changes
	if abs(new_value - old_value) > 1.0:  # Only log changes > 1
		print("📊 ", entity_name, " ", stat_name, ": ", old_value, " → ", new_value)

# === UTILITY FUNCTIONS ===

# Create a standard modifier (helper function)
func create_modifier(value: float, type: StatModifier.ModifierType, source: String) -> StatModifier:
	return StatModifier.new(value, type, source)

# Apply multiple modifiers at once
func apply_modifier_set(modifier_set: Array[Dictionary]):
	for mod_data in modifier_set:
		if mod_data.has("stat") and mod_data.has("value") and mod_data.has("type") and mod_data.has("source"):
			var modifier = create_modifier(mod_data.value, mod_data.type, mod_data.source)
			add_modifier_to_stat(mod_data.stat, modifier)

# Get entity reference
func get_owner_entity() -> Node:
	return owner_entity

func get_entity_name() -> String:
	return entity_name
