# ReactiveStat.gd
# Purpose: Self-updating stat with dirty flagging for reactive stat system
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: StatModifier, Godot signal system
# API References: Official Godot signal documentation

extends RefCounted
class_name ReactiveStat

# Signals for reactive updates
signal value_changed(old_value: float, new_value: float)
signal modifier_added(modifier: StatModifier)
signal modifier_removed(modifier: StatModifier)

# Core stat data
var base_value: float = 0.0
var modifiers: Array[StatModifier] = []
var cached_value: float = 0.0
var is_dirty: bool = true

# Stat metadata
var stat_name: String = ""
var stat_description: String = ""

func _init(name: String = "", base_val: float = 0.0, description: String = ""):
	stat_name = name
	base_value = base_val
	stat_description = description
	cached_value = base_val
	mark_dirty()

# Get the final calculated value (with caching and recursion protection)
var _is_calculating: bool = false

func get_final_value() -> float:
	# Prevent infinite recursion
	if _is_calculating:
		push_warning("ReactiveStat: Recursion detected for " + stat_name + " - returning cached value: " + str(cached_value))
		return cached_value
	
	if is_dirty:
		_is_calculating = true  # Set recursion flag
		var old_value = cached_value
		cached_value = calculate_final_value()
		is_dirty = false
		_is_calculating = false  # Clear recursion flag
		
		# Emit change signal if value actually changed
		if abs(old_value - cached_value) > 0.001:  # Float comparison tolerance
			value_changed.emit(old_value, cached_value)
			print("📊 ", stat_name, " changed: ", old_value, " → ", cached_value)
	
	return cached_value

# Force recalculation and return new value
func recalculate() -> float:
	mark_dirty()
	return get_final_value()

# Calculate final value from base + all modifiers
func calculate_final_value() -> float:
	if modifiers.is_empty():
		return base_value
	
	# Sort modifiers by calculation priority
	var sorted_modifiers = modifiers.duplicate()
	sorted_modifiers.sort_custom(_compare_modifier_priority)
	
	var result = base_value
	var flat_adds: float = 0.0
	var percent_adds: float = 0.0
	var has_override: bool = false
	
	# Apply modifiers in order: Override → Flat Add → Percent Add → Percent Mult
	for modifier in sorted_modifiers:
		if not modifier.is_valid():
			continue
			
		match modifier.type:
			StatModifier.ModifierType.OVERRIDE:
				if not has_override:  # Only first override counts
					result = modifier.value
					has_override = true
			
			StatModifier.ModifierType.FLAT_ADD:
				flat_adds += modifier.value
			
			StatModifier.ModifierType.PERCENT_ADD:
				percent_adds += modifier.value
			
			StatModifier.ModifierType.PERCENT_MULT:
				# Apply immediately to current result
				result *= modifier.value
	
	# If no override, apply base value with additions
	if not has_override:
		result = base_value + flat_adds
		result += (result * percent_adds)  # Percent adds apply to base + flats
	else:
		# Override ignores base, but still gets flat and percent adds
		result += flat_adds
		result += (result * percent_adds)
	
	return max(0.0, result)  # Prevent negative stats

# Modifier management
func add_modifier(modifier: StatModifier):
	if not modifier or not modifier.is_valid():
		push_error("Cannot add invalid modifier to stat: " + stat_name)
		return
	
	modifiers.append(modifier)
	mark_dirty()
	modifier_added.emit(modifier)
	
	print("➕ Added modifier to ", stat_name, ": ", modifier.get_debug_info())

func remove_modifier(modifier: StatModifier):
	if modifier in modifiers:
		modifiers.erase(modifier)
		mark_dirty()
		modifier_removed.emit(modifier)
		
		print("➖ Removed modifier from ", stat_name, ": ", modifier.get_debug_info())

func remove_modifiers_by_source(source: String):
	var removed_count = 0
	var to_remove: Array[StatModifier] = []
	
	for modifier in modifiers:
		if modifier.source == source:
			to_remove.append(modifier)
	
	for modifier in to_remove:
		modifiers.erase(modifier)
		removed_count += 1
	
	if removed_count > 0:
		mark_dirty()
		print("🧹 Removed ", removed_count, " modifiers from ", stat_name, " (source: ", source, ")")

func has_modifier_from_source(source: String) -> bool:
	for modifier in modifiers:
		if modifier.source == source:
			return true
	return false

# Dirty flagging
func mark_dirty():
	if not is_dirty:
		is_dirty = true
		# Dependent stats will be notified via signals

func is_stat_dirty() -> bool:
	return is_dirty

# Utility functions
func set_base_value(new_base: float):
	if abs(base_value - new_base) > 0.001:
		base_value = new_base
		mark_dirty()
		print("🔄 ", stat_name, " base value changed to: ", new_base)

func get_base_value() -> float:
	return base_value

func get_modifier_count() -> int:
	return modifiers.size()

func get_modifiers_by_type(type: StatModifier.ModifierType) -> Array[StatModifier]:
	var result: Array[StatModifier] = []
	for modifier in modifiers:
		if modifier.type == type:
			result.append(modifier)
	return result

# Debug information
func get_debug_info() -> String:
	var info = "ReactiveStat: " + stat_name + "\n"
	info += "  Base: " + str(base_value) + "\n"
	info += "  Final: " + str(get_final_value()) + "\n"
	info += "  Modifiers (" + str(modifiers.size()) + "):\n"
	
	for modifier in modifiers:
		info += "    " + modifier.get_debug_info() + "\n"
	
	info += "  Dirty: " + str(is_dirty)
	return info

func get_modifier_summary() -> String:
	if modifiers.is_empty():
		return "No modifiers"
	
	var summary = ""
	for modifier in modifiers:
		if summary != "":
			summary += ", "
		summary += modifier.get_debug_info()
	
	return summary

# Internal helper for sorting modifiers (stable sorting)
func _compare_modifier_priority(a: StatModifier, b: StatModifier) -> bool:
	var priority_a = a.get_calculation_priority()
	var priority_b = b.get_calculation_priority()
	
	if priority_a == priority_b:
		# Same priority type, use custom priority value
		if a.priority == b.priority:
			# Ultimate tie-breaker: use source name for stable sorting
			return a.source < b.source
		return a.priority < b.priority
	
	return priority_a < priority_b

# Validation
func validate() -> bool:
	if stat_name.is_empty():
		push_error("ReactiveStat validation failed: stat_name cannot be empty")
		return false
	
	for modifier in modifiers:
		if not modifier.is_valid():
			push_error("ReactiveStat validation failed: invalid modifier in " + stat_name)
			return false
	
	return true
