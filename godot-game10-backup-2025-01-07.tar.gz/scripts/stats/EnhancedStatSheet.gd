# EnhancedStatSheet.gd
# Purpose: StatSheet with enhanced computed stat support for complex modifier stacking
# Handles: Base stats + computed stats + direct computed stat modifiers

extends RefCounted
class_name EnhancedStatSheet

signal stat_changed(stat_name: String, old_value: float, new_value: float)

# Core storage
var reactive_stats: Dictionary = {}
var enhanced_computed_stats: Dictionary = {}  # New: EnhancedComputedStat instances
var stat_dependencies: Dictionary = {}

# Metadata
var sheet_name: String = ""

func _init(name: String = ""):
	sheet_name = name
	print("📊 Enhanced StatSheet created for: ", sheet_name)

# === BASIC STAT OPERATIONS ===

func register_stat(stat_name: String, base_value: float = 0.0) -> bool:
	if reactive_stats.has(stat_name):
		push_warning("Enhanced StatSheet: Stat '" + stat_name + "' already exists")
		return false
	
	var reactive_stat = ReactiveStat.new(stat_name, base_value)
	reactive_stat.value_changed.connect(_on_stat_value_changed.bind(stat_name))
	reactive_stats[stat_name] = reactive_stat
	
	print("📈 Registered stat: ", stat_name, " = ", base_value)
	return true

# NEW: Register enhanced computed stat that can accept direct modifiers
func register_enhanced_computed_stat(stat_name: String, formula: String, dependencies: Array[String] = []) -> bool:
	if enhanced_computed_stats.has(stat_name) or reactive_stats.has(stat_name):
		push_warning("Enhanced StatSheet: Stat '" + stat_name + "' already exists")
		return false
	
	# Validate dependencies exist
	for dep in dependencies:
		if not has_stat(dep):
			push_error("Enhanced StatSheet: Dependency '" + dep + "' not found for computed stat '" + stat_name + "'")
			return false
	
	var computed_stat = EnhancedComputedStat.new(formula, dependencies, self, stat_name)
	computed_stat.value_changed.connect(_on_stat_value_changed.bind(stat_name))
	enhanced_computed_stats[stat_name] = computed_stat
	
	# Connect to dependency changes
	for dep_name in dependencies:
		if not stat_dependencies.has(dep_name):
			stat_dependencies[dep_name] = []
		stat_dependencies[dep_name].append(stat_name)
		
		# Connect to existing stat changes
		if reactive_stats.has(dep_name):
			reactive_stats[dep_name].value_changed.connect(_on_dependency_changed.bind(stat_name))
		elif enhanced_computed_stats.has(dep_name):
			enhanced_computed_stats[dep_name].value_changed.connect(_on_dependency_changed.bind(stat_name))
	
	print("🧮 Registered enhanced computed stat: ", stat_name, " = ", formula)
	return true

# Get stat value (works for both regular and enhanced computed stats)
func get_stat_value(stat_name: String) -> float:
	if reactive_stats.has(stat_name):
		return reactive_stats[stat_name].get_final_value()
	elif enhanced_computed_stats.has(stat_name):
		return enhanced_computed_stats[stat_name].get_final_value()
	else:
		push_error("Enhanced StatSheet: Stat '" + stat_name + "' not found")
		return 0.0

# Set base value (only works for regular stats)
func set_stat_base_value(stat_name: String, value: float) -> bool:
	if reactive_stats.has(stat_name):
		reactive_stats[stat_name].set_base_value(value)
		return true
	else:
		push_error("Enhanced StatSheet: Cannot set base value for computed stat '" + stat_name + "'")
		return false

# Check if stat exists
func has_stat(stat_name: String) -> bool:
	return reactive_stats.has(stat_name) or enhanced_computed_stats.has(stat_name)

# === MODIFIER OPERATIONS ===

# Add modifier to regular stat OR enhanced computed stat
func add_modifier_to_stat(stat_name: String, modifier: StatModifier) -> bool:
	if reactive_stats.has(stat_name):
		# Regular stat modifier
		reactive_stats[stat_name].add_modifier(modifier)
		return true
	elif enhanced_computed_stats.has(stat_name):
		# Enhanced computed stat modifier (direct application)
		enhanced_computed_stats[stat_name].add_modifier(modifier)
		return true
	else:
		push_error("Enhanced StatSheet: Cannot add modifier - stat not found: " + stat_name)
		return false

# Remove modifiers by source (works for both types)
func remove_modifiers_by_source(source: String):
	# Remove from regular stats
	for stat_name in reactive_stats:
		reactive_stats[stat_name].remove_modifiers_by_source(source)
	
	# Remove from enhanced computed stats  
	for stat_name in enhanced_computed_stats:
		enhanced_computed_stats[stat_name].remove_modifiers_by_source(source)
	
	print("🗑️ Removed all modifiers from source: ", source)

# === DEPENDENCY MANAGEMENT ===

func _on_dependency_changed(dependent_stat_name: String, old_value: float, new_value: float):
	# Mark enhanced computed stat as dirty when its dependency changes
	if enhanced_computed_stats.has(dependent_stat_name):
		enhanced_computed_stats[dependent_stat_name].mark_dirty()

func _on_stat_value_changed(stat_name: String, old_value: float, new_value: float):
	# Emit global stat change signal
	stat_changed.emit(stat_name, old_value, new_value)
	print("📊 ", sheet_name, " ", stat_name, ": ", old_value, " → ", new_value)
	
	# Update any dependent enhanced computed stats
	if stat_dependencies.has(stat_name):
		for dependent_stat in stat_dependencies[stat_name]:
			if enhanced_computed_stats.has(dependent_stat):
				enhanced_computed_stats[dependent_stat].mark_dirty()

# === DEBUG & UTILITY ===

func get_all_stats() -> Dictionary:
	var all_stats = {}
	
	# Add regular stats
	for stat_name in reactive_stats:
		all_stats[stat_name] = reactive_stats[stat_name].get_final_value()
	
	# Add enhanced computed stats
	for stat_name in enhanced_computed_stats:
		all_stats[stat_name] = enhanced_computed_stats[stat_name].get_final_value()
	
	return all_stats

func get_modifier_summary(stat_name: String) -> Dictionary:
	if enhanced_computed_stats.has(stat_name):
		return enhanced_computed_stats[stat_name].get_modifier_summary()
	elif reactive_stats.has(stat_name):
		return {"type": "regular_stat", "modifiers": reactive_stats[stat_name].modifiers.size()}
	else:
		return {"error": "stat_not_found"}

func validate() -> bool:
	var valid = true
	
	# Validate all enhanced computed stats
	for stat_name in enhanced_computed_stats:
		var computed_stat = enhanced_computed_stats[stat_name]
		for dep in computed_stat.dependencies:
			if not has_stat(dep):
				push_error("Enhanced StatSheet: Invalid dependency '" + dep + "' for computed stat '" + stat_name + "'")
				valid = false
	
	if valid:
		print("✅ Enhanced StatSheet validation passed for: ", sheet_name)
	
	return valid