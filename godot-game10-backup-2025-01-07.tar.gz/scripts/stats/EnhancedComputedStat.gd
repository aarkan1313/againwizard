# EnhancedComputedStat.gd - FIXED VERSION
# Purpose: Formula-based stats with direct modifier support and proper recursion handling
# Handles: Base formula + flat modifiers + percentage modifiers + multipliers
# FIXES:
# - Better recursion protection with immediate recalculation
# - Force recalculation when dependencies change
# - Proper dirty flag management

extends RefCounted
class_name EnhancedComputedStat

signal value_changed(old_value: float, new_value: float)
signal recalculated(new_value: float)

# Core computed stat data
var formula: String = ""
var dependencies: Array[String] = []
var stat_sheet
var cached_value: float = 0.0
var is_dirty: bool = true
var is_evaluating: bool = false
var _recursion_depth: int = 0  # Track recursion depth
const MAX_RECURSION_DEPTH: int = 3  # Maximum allowed recursion

# Metadata
var stat_name: String = ""
var stat_description: String = ""

# Expression parsing
var expression: Expression
var regex_cache: Dictionary = {}

# ENHANCED: Direct modifier support for complex stacking
var flat_modifiers: Array[StatModifier] = []
var percent_modifiers: Array[StatModifier] = []
var multiplier_modifiers: Array[StatModifier] = []

# Track if we need to force recalculation
var _force_recalculate: bool = false

func _init(stat_formula: String = "", stat_dependencies: Array[String] = [], sheet_reference = null, name: String = ""):
	formula = stat_formula
	dependencies = stat_dependencies.duplicate()
	stat_sheet = sheet_reference
	stat_name = name
	expression = Expression.new()
	_build_regex_cache()

# Add modifier directly to this computed stat
func add_modifier(modifier: StatModifier):
	match modifier.type:
		StatModifier.ModifierType.FLAT_ADD:
			flat_modifiers.append(modifier)
		StatModifier.ModifierType.PERCENT_ADD:
			percent_modifiers.append(modifier)
		StatModifier.ModifierType.PERCENT_MULT:
			multiplier_modifiers.append(modifier)
		StatModifier.ModifierType.OVERRIDE:
			# For override, we clear all other modifiers and use only this one
			flat_modifiers.clear()
			percent_modifiers.clear()
			multiplier_modifiers.clear()
			flat_modifiers.append(modifier)
	
	# Force immediate recalculation
	_force_recalculate = true
	mark_dirty()
	get_final_value()  # Recalculate immediately
	print("🔧 Added modifier to ", stat_name, ": ", modifier.value, " (", modifier.type, ") from ", modifier.source)

# Remove modifiers by source (for gear unequipping, temporary effects, etc.)
func remove_modifiers_by_source(source: String) -> int:
	var removed_count = 0
	var old_flat_size = flat_modifiers.size()
	var old_percent_size = percent_modifiers.size()
	var old_mult_size = multiplier_modifiers.size()
	
	flat_modifiers = flat_modifiers.filter(func(m): return m.source != source)
	percent_modifiers = percent_modifiers.filter(func(m): return m.source != source)
	multiplier_modifiers = multiplier_modifiers.filter(func(m): return m.source != source)
	
	removed_count = (old_flat_size - flat_modifiers.size()) + \
					(old_percent_size - percent_modifiers.size()) + \
					(old_mult_size - multiplier_modifiers.size())
	
	if removed_count > 0:
		_force_recalculate = true
		mark_dirty()
		get_final_value()  # Recalculate immediately
		print("🧹 Removed ", removed_count, " modifiers from ", stat_name, " (source: ", source, ")")
	
	return removed_count

# Get final calculated value with full modifier stacking
func get_final_value() -> float:
	# Check recursion depth
	if _recursion_depth >= MAX_RECURSION_DEPTH:
		push_warning("EnhancedComputedStat: Max recursion depth reached for " + stat_name)
		return cached_value
	
	# If already evaluating and not forcing, return cached
	if is_evaluating and not _force_recalculate:
		return cached_value
	
	if is_dirty or _force_recalculate:
		_recursion_depth += 1
		is_evaluating = true
		_force_recalculate = false
		var old_value = cached_value
		
		# Step 1: Calculate base value from formula
		var base_value = evaluate_base_formula()
		
		# Step 2: Apply flat modifiers (additive)
		var flat_bonus = 0.0
		for modifier in flat_modifiers:
			if modifier.type == StatModifier.ModifierType.OVERRIDE:
				# Override completely replaces the value
				cached_value = modifier.value
				is_dirty = false
				is_evaluating = false
				_recursion_depth -= 1
				_emit_change_signals(old_value, cached_value)
				return cached_value
			else:
				flat_bonus += modifier.value
		
		var value_after_flat = base_value + flat_bonus
		
		# Step 3: Apply percentage modifiers (multiplicative stacking)
		var percent_multiplier = 1.0
		for modifier in percent_modifiers:
			percent_multiplier += modifier.value  # 0.25 = +25%
		
		var value_after_percent = value_after_flat * percent_multiplier
		
		# Step 4: Apply direct multipliers (multiplicative)
		var final_multiplier = 1.0
		for modifier in multiplier_modifiers:
			final_multiplier *= modifier.value  # 1.5 = x1.5 multiplier
		
		cached_value = value_after_percent * final_multiplier
		is_dirty = false
		is_evaluating = false
		_recursion_depth -= 1
		
		_emit_change_signals(old_value, cached_value)
	
	return cached_value

# Evaluate just the base formula (without modifiers)
func evaluate_base_formula() -> float:
	if not stat_sheet or formula.is_empty():
		return 0.0
	
	var formula_copy = formula
	var values_dict = {}
	
	# First, collect all values to avoid recursion during replacement
	for stat_name_ref in dependencies:
		if stat_sheet.has_stat(stat_name_ref):
			# Use base value if available to avoid recursion
			if stat_sheet.has_method("get_stat_base_value"):
				values_dict[stat_name_ref] = stat_sheet.get_stat_base_value(stat_name_ref)
			else:
				values_dict[stat_name_ref] = stat_sheet.get_stat_value(stat_name_ref)
	
	# Then replace all at once
	for stat_name_ref in values_dict:
		formula_copy = _replace_stat_in_formula(formula_copy, stat_name_ref, values_dict[stat_name_ref])
	
	# Evaluate expression
	var parse_error = expression.parse(formula_copy)
	if parse_error != OK:
		push_error("EnhancedComputedStat: Failed to parse formula '" + formula_copy + "' for " + stat_name)
		return 0.0
	
	var result = expression.execute()
	if expression.has_execute_failed():
		push_error("EnhancedComputedStat: Failed to execute formula '" + formula_copy + "' for " + stat_name)
		return 0.0
	
	return float(result)

# Helper to emit change signals
func _emit_change_signals(old_value: float, new_value: float):
	recalculated.emit(new_value)
	if abs(old_value - new_value) > 0.001:
		value_changed.emit(old_value, new_value)
		print("📈 ", stat_name, " computed: ", old_value, " → ", new_value)

# Mark as needing recalculation
func mark_dirty():
	is_dirty = true

# Force immediate recalculation
func recalculate() -> float:
	_force_recalculate = true
	mark_dirty()
	return get_final_value()

# Build regex cache for stat name replacement
func _build_regex_cache():
	# Pre-compile common regex patterns for performance
	pass

# Replace stat names in formula with actual values
func _replace_stat_in_formula(formula_text: String, stat_name_ref: String, stat_value: float) -> String:
	# Use word boundaries to avoid partial replacements
	var regex = RegEx.new()
	regex.compile("\\b" + stat_name_ref + "\\b")
	return regex.sub(formula_text, str(stat_value), true)

# Get debug info about modifiers
func get_modifier_summary() -> Dictionary:
	return {
		"base_formula": formula,
		"base_value": evaluate_base_formula() if not is_evaluating else 0.0,
		"flat_modifiers": flat_modifiers.size(),
		"percent_modifiers": percent_modifiers.size(),
		"multiplier_modifiers": multiplier_modifiers.size(),
		"total_flat": flat_modifiers.reduce(func(sum, m): return sum + m.value, 0.0),
		"total_percent": percent_modifiers.reduce(func(sum, m): return sum + m.value, 0.0),
		"final_value": cached_value
	}

# Get breakdown of calculation for debugging
func get_calculation_breakdown() -> String:
	var base = evaluate_base_formula() if not is_evaluating else cached_value
	var flat_total = flat_modifiers.reduce(func(sum, m): return sum + m.value, 0.0)
	var percent_total = percent_modifiers.reduce(func(sum, m): return sum + m.value, 0.0)
	var mult_total = multiplier_modifiers.reduce(func(prod, m): return prod * m.value, 1.0)
	
	var breakdown = "%s Breakdown:\n" % stat_name
	breakdown += "  Base (formula): %.1f\n" % base
	breakdown += "  Flat modifiers: %+.1f\n" % flat_total
	breakdown += "  After flat: %.1f\n" % (base + flat_total)
	breakdown += "  Percent bonus: %+.1f%%\n" % (percent_total * 100)
	breakdown += "  After percent: %.1f\n" % ((base + flat_total) * (1 + percent_total))
	if mult_total != 1.0:
		breakdown += "  Multipliers: x%.2f\n" % mult_total
	breakdown += "  Final value: %.1f" % cached_value
	
	return breakdown
