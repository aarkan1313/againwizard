# EnemyAttackComponent.gd
# Purpose: Component for handling enemy-specific attack patterns and behaviors
# Godot Version: 4.4.1
# Dependencies: Node, GameEvents
# API References: Official Godot Node and Area2D documentation

extends Node
class_name EnemyAttackComponent

# Attack pattern types
enum AttackPattern {
	MELEE_SWIPE,      # Quick melee attack in front
	MELEE_SLAM,       # Heavy AoE slam attack
	DUAL_STRIKE,      # Two quick attacks
	RANGED_PROJECTILE, # Shoot projectile at target
	AOE_BURST,        # Damage in radius around enemy
	CONTINUOUS_AURA   # Ongoing damage in area
}

# Parent enemy reference
var enemy: CharacterBody2D
var enemy_node: Node

# Attack effect scenes
var attack_effect_scene: PackedScene
var projectile_scene: PackedScene

# Attack visual indicators
var telegraph_indicator: Node2D
var attack_indicator: Node2D

func _ready():
	# Get parent enemy
	enemy_node = get_parent()
	enemy = enemy_node as CharacterBody2D
	if not enemy:
		push_error("EnemyAttackComponent must be child of Enemy node")
		return
	
	# Preload effect scenes
	_load_effect_scenes()
	
	# Create visual indicators
	_create_visual_indicators()

func _load_effect_scenes():
	# Load attack effect scenes if they exist
	var effect_path = "res://effects/AttackEffect.tscn"
	if ResourceLoader.exists(effect_path):
		attack_effect_scene = load(effect_path)
	
	var projectile_path = "res://projectiles/EnemyProjectile.tscn"
	if ResourceLoader.exists(projectile_path):
		projectile_scene = load(projectile_path)

func _create_visual_indicators():
	# Create telegraph indicator (shows where attack will land)
	telegraph_indicator = Node2D.new()
	telegraph_indicator.name = "TelegraphIndicator"
	telegraph_indicator.visible = false
	add_child(telegraph_indicator)
	
	# Create attack indicator (shows during attack)
	attack_indicator = Node2D.new()
	attack_indicator.name = "AttackIndicator"
	attack_indicator.visible = false
	add_child(attack_indicator)

# Execute attack based on enemy type
func execute_attack(target: Node, damage: float, enemy_type: String):
	match enemy_type:
		"goblin":
			execute_goblin_attack(target, damage)
		"orc":
			execute_orc_attack(target, damage)
		"skeleton":
			execute_skeleton_attack(target, damage)
		"wizard":
			execute_wizard_attack(target, damage)
		"golem":
			execute_golem_attack(target, damage)
		"elemental":
			execute_elemental_attack(target, damage)
		_:
			execute_basic_melee_attack(target, damage)

# === GOBLIN ATTACKS ===
func execute_goblin_attack(target: Node, damage: float):
	# Goblin: Fast swipe attack
	var attack_direction = (target.global_position - enemy.global_position).normalized()
	var attack_range = 50.0
	
	# Create swipe effect
	create_melee_swipe_effect(attack_direction, attack_range, Color.GREEN)
	
	# Check for hit
	var hit_point = enemy.global_position + attack_direction * attack_range
	if target.global_position.distance_to(hit_point) <= 40.0:
		apply_damage_to_target(target, damage * 1.0)  # Normal damage
		
		# Knockback
		if target.has_method("apply_knockback"):
			target.apply_knockback(attack_direction * 300.0)

# === ORC ATTACKS ===
func execute_orc_attack(target: Node, damage: float):
	# Orc: Heavy slam with AoE damage
	var attack_range = 70.0
	
	# Create slam effect
	create_slam_effect(enemy.global_position, attack_range, Color.RED)
	
	# Screen shake for heavy attack
	if GameEvents:
		GameEvents.emit_screen_shake(0.3, 3.0)
	
	# AoE damage check
	var distance_to_target = target.global_position.distance_to(enemy.global_position)
	if distance_to_target <= attack_range:
		var damage_multiplier = 1.5 - (distance_to_target / attack_range) * 0.5  # 1.5x to 1.0x based on distance
		apply_damage_to_target(target, damage * damage_multiplier)
		
		# Heavy knockback
		if target.has_method("apply_knockback"):
			var knockback_direction = (target.global_position - enemy.global_position).normalized()
			target.apply_knockback(knockback_direction * 500.0)

# === SKELETON ATTACKS ===
func execute_skeleton_attack(target: Node, damage: float):
	# Skeleton: Dual strike or ranged bone
	var distance_to_target = target.global_position.distance_to(enemy.global_position)
	
	if distance_to_target <= 60.0:
		# Close range: Dual melee strikes
		execute_dual_melee_strike(target, damage)
	else:
		# Long range: Bone projectile
		execute_bone_projectile(target, damage)

func execute_dual_melee_strike(target: Node, damage: float):
	var attack_direction = (target.global_position - enemy.global_position).normalized()
	
	# First strike
	create_melee_swipe_effect(attack_direction, 55.0, Color.YELLOW)
	if target.global_position.distance_to(enemy.global_position) <= 55.0:
		apply_damage_to_target(target, damage * 0.6)  # 60% damage per strike
	
	# Second strike (delayed)
	await get_tree().create_timer(0.2).timeout
	create_melee_swipe_effect(attack_direction, 55.0, Color.ORANGE)
	if target.global_position.distance_to(enemy.global_position) <= 55.0:
		apply_damage_to_target(target, damage * 0.6)

func execute_bone_projectile(target: Node, damage: float):
	# Create bone projectile effect
	create_projectile_attack(target, damage, Color.WHITE, 400.0)

# === WIZARD ATTACKS ===
func execute_wizard_attack(target: Node, damage: float):
	# Wizard: Magic projectile barrage
	var projectile_count = 3
	var spread_angle = PI / 4  # 45 degrees
	
	for i in range(projectile_count):
		var angle_offset = (i - 1) * (spread_angle / 2)
		var base_direction = (target.global_position - enemy.global_position).normalized()
		var projectile_direction = base_direction.rotated(angle_offset)
		
		# Create magical projectile
		create_directional_projectile(projectile_direction, damage * 0.7, Color.PURPLE, 350.0)
		
		# Slight delay between projectiles
		if i < projectile_count - 1:
			await get_tree().create_timer(0.1).timeout

# === GOLEM ATTACKS ===
func execute_golem_attack(target: Node, damage: float):
	# Golem: Earthquake attack with expanding shockwave
	var max_range = 120.0
	
	# Screen shake for earthquake
	if GameEvents:
		GameEvents.emit_screen_shake(0.8, 4.0)
	
	# Create expanding shockwave effect
	create_earthquake_effect(enemy.global_position, max_range, Color.BROWN)
	
	# Damage calculation based on distance
	var distance_to_target = target.global_position.distance_to(enemy.global_position)
	if distance_to_target <= max_range:
		var damage_multiplier = 2.0 - (distance_to_target / max_range)  # 2.0x to 1.0x damage
		apply_damage_to_target(target, damage * damage_multiplier)
		
		# Massive knockback
		if target.has_method("apply_knockback"):
			var knockback_direction = (target.global_position - enemy.global_position).normalized()
			target.apply_knockback(knockback_direction * 800.0)

# === ELEMENTAL ATTACKS ===
func execute_elemental_attack(target: Node, damage: float):
	# Elemental: Fire burst with burn effect
	var burst_range = 80.0
	
	# Create fire burst effect
	create_burst_effect(enemy.global_position, burst_range, Color.ORANGE_RED)
	
	# Damage and burn effect
	var distance_to_target = target.global_position.distance_to(enemy.global_position)
	if distance_to_target <= burst_range:
		apply_damage_to_target(target, damage * 1.2)  # Fire damage bonus
		
		# Apply burn effect (placeholder - implement DoT system later)
		if target.has_method("apply_status_effect"):
			target.apply_status_effect("burn", 3.0, damage * 0.3)

# === BASIC ATTACKS ===
func execute_basic_melee_attack(target: Node, damage: float):
	# Generic melee attack for undefined enemy types
	var attack_direction = (target.global_position - enemy.global_position).normalized()
	var attack_range = 45.0
	
	create_melee_swipe_effect(attack_direction, attack_range, Color.WHITE)
	
	if target.global_position.distance_to(enemy.global_position) <= attack_range:
		apply_damage_to_target(target, damage)

# === VISUAL EFFECT CREATORS ===

func create_melee_swipe_effect(direction: Vector2, range: float, color: Color):
	# Create simple line effect for melee swipe
	if telegraph_indicator:
		telegraph_indicator.visible = true
		telegraph_indicator.modulate = color
		# Simple visual representation - in a full game you'd use particles or sprites
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
			"Melee swipe effect: %s direction, %.0f range" % [str(direction), range])

func create_slam_effect(position: Vector2, radius: float, color: Color):
	# Create area effect for slam attacks
	if attack_indicator:
		attack_indicator.global_position = position
		attack_indicator.visible = true
		attack_indicator.modulate = color
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
			"Slam effect at %s, radius %.0f" % [str(position), radius])

func create_burst_effect(position: Vector2, radius: float, color: Color):
	# Create burst effect for AoE attacks
	if attack_indicator:
		attack_indicator.global_position = position
		attack_indicator.visible = true
		attack_indicator.modulate = color
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
			"Burst effect at %s, radius %.0f" % [str(position), radius])

func create_earthquake_effect(position: Vector2, max_radius: float, color: Color):
	# Create expanding earthquake effect
	if attack_indicator:
		attack_indicator.global_position = position
		attack_indicator.visible = true
		attack_indicator.modulate = color
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
			"Earthquake effect at %s, max radius %.0f" % [str(position), max_radius])

func create_projectile_attack(target: Node, damage: float, color: Color, speed: float):
	# Create projectile moving toward target
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
		"Projectile attack toward %s, %.0f damage, %.0f speed" % [target.name, damage, speed])
	
	# Simple projectile simulation - in full game would create actual projectile scene
	await get_tree().create_timer(0.3).timeout  # Simulate travel time
	
	# Check if target is still in reasonable range (projectile could miss)
	var current_distance = target.global_position.distance_to(enemy.global_position)
	if current_distance <= 200.0:  # Projectile range
		apply_damage_to_target(target, damage)

func create_directional_projectile(direction: Vector2, damage: float, color: Color, speed: float):
	# Create projectile in specific direction
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
		"Directional projectile: %s direction, %.0f damage" % [str(direction), damage])
	
	# Simulate projectile travel
	await get_tree().create_timer(0.4).timeout
	
	# Check if player is in projectile path (simplified)
	if enemy_node and enemy_node.has_method("get_current_target"):
		var target = enemy_node.get_current_target()
		if target:
			var target_direction = (target.global_position - enemy.global_position).normalized()
			if direction.dot(target_direction) > 0.8:  # Close to aimed direction
				apply_damage_to_target(target, damage)

# === DAMAGE APPLICATION ===

func apply_damage_to_target(target: Node, damage: float):
	if not target or not is_instance_valid(target):
		return
	
	# Try different damage methods depending on target type
	if target.has_method("take_damage"):
		target.take_damage(damage, enemy_node)
	elif target.has_method("damage"):
		target.damage(damage)
	elif target.has_method("receive_damage"):
		target.receive_damage(damage, enemy_node)
	else:
		UnifiedDebugSystem.log_warning_internal(UnifiedDebugSystem.LogCategory.GENERAL,
			"Target %s has no damage method" % target.name, "EnemyAttackComponent")
		return
	
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL,
		"Applied %.1f damage to %s" % [damage, target.name])

# === TELEGRAPH SYSTEM ===

func show_telegraph(attack_type: String, target_position: Vector2, duration: float):
	# Show visual warning of incoming attack
	if telegraph_indicator:
		telegraph_indicator.global_position = target_position
		telegraph_indicator.visible = true
		telegraph_indicator.modulate = Color.YELLOW
		
		# Hide after duration
		await get_tree().create_timer(duration).timeout
		if telegraph_indicator:
			telegraph_indicator.visible = false

func hide_telegraph():
	if telegraph_indicator:
		telegraph_indicator.visible = false

func show_attack_indicator(duration: float):
	# Show attack execution visual
	if attack_indicator:
		attack_indicator.visible = true
		attack_indicator.modulate = Color.RED
		
		# Hide after duration
		await get_tree().create_timer(duration).timeout
		if attack_indicator:
			attack_indicator.visible = false

# === CLEANUP ===

func cleanup_effects():
	if telegraph_indicator:
		telegraph_indicator.visible = false
	if attack_indicator:
		attack_indicator.visible = false