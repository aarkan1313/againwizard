# EnemyAttackPattern_Animated.gd
# Enhanced base class for enemy attack patterns with integrated animations
extends Node
class_name EnemyAttackPattern

# Pattern states - each pattern implements these differently
enum PatternState {
    IDLE,
    PURSUING,
    POSITIONING,
    TELEGRAPHING,
    EXECUTING,
    RECOVERING,
    REPOSITIONING
}

# Core properties
var current_state: PatternState = PatternState.IDLE
var enemy: CharacterBody2D
var target: Node2D
var state_timer: float = 0.0

# Pattern configuration (override in subclasses)
var attack_range: float = 60.0
var telegraph_duration: float = 0.5
var attack_duration: float = 0.2
var recovery_duration: float = 0.3
var reposition_duration: float = 0.5

# Behavioral properties
var preferred_distance: float = 50.0  # Ideal attack distance
var comfort_zone: float = 80.0  # Don't get closer than this to allies
var pursuit_speed_multiplier: float = 1.2
var retreat_speed_multiplier: float = 0.8

# State tracking
var attack_committed: bool = false
var last_attack_time: float = 0.0
var pattern_variation: int = 0  # For pattern variety

# Visual feedback
var telegraph_color: Color = Color.YELLOW
var attack_color: Color = Color.RED

# Animation system
var animation_system: EnemyAnimationSystem

func _ready():
    enemy = get_parent()
    set_physics_process(true)
    
    # Create animation system
    animation_system = EnemyAnimationSystem.new()
    add_child(animation_system)
    animation_system.setup(enemy)

func _physics_process(delta):
    if not enemy or not is_instance_valid(enemy):
        return
    
    # Update state timer
    state_timer -= delta
    
    # Get current target (usually player)
    target = get_target()
    if not target:
        current_state = PatternState.IDLE
        return
    
    # Update pattern based on current state
    match current_state:
        PatternState.IDLE:
            handle_idle_state(delta)
        PatternState.PURSUING:
            handle_pursuing_state(delta)
        PatternState.POSITIONING:
            handle_positioning_state(delta)
        PatternState.TELEGRAPHING:
            handle_telegraphing_state(delta)
        PatternState.EXECUTING:
            handle_executing_state(delta)
        PatternState.RECOVERING:
            handle_recovering_state(delta)
        PatternState.REPOSITIONING:
            handle_repositioning_state(delta)

# State handlers - Override these in pattern subclasses
func handle_idle_state(delta):
    # Default: Check if we should start pursuing
    if can_see_target() and is_target_in_aggro_range():
        transition_to_state(PatternState.PURSUING)

func handle_pursuing_state(delta):
    # Default: Move toward target until in attack range
    var distance = enemy.global_position.distance_to(target.global_position)
    
    if distance <= attack_range:
        transition_to_state(PatternState.POSITIONING)
    else:
        move_toward_target(pursuit_speed_multiplier)

func handle_positioning_state(delta):
    # Default: Get into ideal position for attack
    if is_in_attack_position():
        transition_to_state(PatternState.TELEGRAPHING)
    else:
        adjust_position()

func handle_telegraphing_state(delta):
    # Show attack warning - CANNOT BE CANCELLED
    attack_committed = true
    show_telegraph_visual()
    
    if state_timer <= 0:
        transition_to_state(PatternState.EXECUTING)

func handle_executing_state(delta):
    # Execute the attack
    if state_timer <= 0:
        execute_attack()
        transition_to_state(PatternState.RECOVERING)

func handle_recovering_state(delta):
    # Recovery period - vulnerable
    attack_committed = false
    
    if state_timer <= 0:
        transition_to_state(PatternState.REPOSITIONING)

func handle_repositioning_state(delta):
    # Move to new position after attack
    reposition_after_attack()
    
    if state_timer <= 0:
        transition_to_state(PatternState.IDLE)

# Utility functions
func get_target() -> Node2D:
    # Get player or current target
    return GameManager.get_player() if GameManager else null

func can_see_target() -> bool:
    if not target:
        return false
    
    # Line of sight check
    var space_state = enemy.get_world_2d().direct_space_state
    var query = PhysicsRayQueryParameters2D.create(
        enemy.global_position,
        target.global_position,
        4  # Environment layer
    )
    var result = space_state.intersect_ray(query)
    return result.is_empty()  # No obstacles

func is_target_in_aggro_range() -> bool:
    if not target:
        return false
    return enemy.global_position.distance_to(target.global_position) < 400.0

func is_in_attack_position() -> bool:
    if not target:
        return false
    
    var distance = enemy.global_position.distance_to(target.global_position)
    var has_line_of_sight = can_see_target()
    var not_too_crowded = !is_position_crowded()
    
    return distance <= attack_range and has_line_of_sight and not_too_crowded

func is_position_crowded() -> bool:
    # Check if too many allies nearby
    var nearby_count = 0
    for other_enemy in get_tree().get_nodes_in_group("enemies"):
        if other_enemy != enemy:
            if enemy.global_position.distance_to(other_enemy.global_position) < comfort_zone:
                nearby_count += 1
    
    return nearby_count >= 2  # Too crowded if 2+ allies nearby

func move_toward_target(speed_mult: float = 1.0):
    if not target or not enemy:
        return
    
    var direction = (target.global_position - enemy.global_position).normalized()
    
    # Apply personal space repulsion from other enemies
    var repulsion = calculate_repulsion_force()
    direction += repulsion * 0.3  # 30% influence from repulsion
    direction = direction.normalized()
    
    enemy.velocity = direction * enemy.speed * speed_mult
    enemy.move_and_slide()

func calculate_repulsion_force() -> Vector2:
    var repulsion = Vector2.ZERO
    
    for other_enemy in get_tree().get_nodes_in_group("enemies"):
        if other_enemy != enemy:
            var distance = enemy.global_position.distance_to(other_enemy.global_position)
            if distance < comfort_zone and distance > 0:
                var push_direction = (enemy.global_position - other_enemy.global_position).normalized()
                var push_strength = 1.0 - (distance / comfort_zone)
                repulsion += push_direction * push_strength * 100.0
    
    return repulsion

func adjust_position():
    # Find better attack position
    var ideal_distance = preferred_distance
    var current_distance = enemy.global_position.distance_to(target.global_position)
    
    if abs(current_distance - ideal_distance) > 10:
        if current_distance > ideal_distance:
            move_toward_target(pursuit_speed_multiplier * 0.7)
        else:
            move_away_from_target(retreat_speed_multiplier)
    else:
        # Strafe around target
        strafe_around_target()

func move_away_from_target(speed_mult: float = 1.0):
    if not target or not enemy:
        return
    
    var direction = (enemy.global_position - target.global_position).normalized()
    enemy.velocity = direction * enemy.speed * speed_mult
    enemy.move_and_slide()

func strafe_around_target():
    if not target or not enemy:
        return
    
    # Circle strafe with some randomness
    var to_target = (target.global_position - enemy.global_position).normalized()
    var strafe_direction = to_target.rotated(PI/2 * (1 if randf() > 0.5 else -1))
    
    enemy.velocity = strafe_direction * enemy.speed * 0.8
    enemy.move_and_slide()

func show_telegraph_visual():
    # Enhanced telegraph with animation
    enemy.modulate = telegraph_color
    
    # Use TelegraphSystem if available
    if TelegraphSystem:
        var threat_level = get_threat_level()
        match get_attack_type():
            "melee_rush", "melee_lunge":
                TelegraphSystem.show_melee_telegraph(enemy, attack_range, threat_level)
            "ranged_projectile":
                TelegraphSystem.show_ranged_telegraph(enemy, target, threat_level)
            "heavy_slam":
                TelegraphSystem.show_area_telegraph(enemy, attack_range * 2, threat_level)
            _:
                TelegraphSystem.show_melee_telegraph(enemy, attack_range, threat_level)
    
    # Play charge animation
    if animation_system:
        animation_system.play_charge_animation(telegraph_duration)

func execute_attack():
    # Perform the actual attack with animation
    if not target:
        return
    
    # Play attack animation
    if animation_system:
        animation_system.play_attack_animation(get_attack_type())
    
    # Check if target still in range
    var distance = enemy.global_position.distance_to(target.global_position)
    if distance <= attack_range * 1.2:  # Small grace distance
        deal_damage_to_target()
        create_attack_effect()

func deal_damage_to_target():
    if target and target.has_method("take_damage"):
        var damage = calculate_damage()
        target.take_damage(damage, enemy, get_attack_type())
        
        # Emit attack event
        if GameEvents:
            GameEvents.emit_signal("enemy_attack_landed", enemy, damage)

func calculate_damage() -> float:
    return enemy.damage

func get_attack_type() -> String:
    return "physical"  # Override in subclasses

func get_threat_level() -> String:
    # Determine threat level based on enemy type and damage
    if enemy.damage >= 50:
        return "extreme"
    elif enemy.damage >= 30:
        return "high"
    elif enemy.damage >= 20:
        return "medium"
    else:
        return "low"

func reposition_after_attack():
    # Move to new position
    var reposition_direction = Vector2(randf() - 0.5, randf() - 0.5).normalized()
    enemy.velocity = reposition_direction * enemy.speed * retreat_speed_multiplier
    enemy.move_and_slide()

func transition_to_state(new_state: PatternState):
    # Handle state transitions
    current_state = new_state
    
    # Set state timer based on state
    match new_state:
        PatternState.TELEGRAPHING:
            state_timer = telegraph_duration
            enemy.velocity = Vector2.ZERO  # Stop moving during telegraph
            
            # Hide any existing telegraphs
            if TelegraphSystem:
                TelegraphSystem.hide_telegraph(enemy)
                
        PatternState.EXECUTING:
            state_timer = attack_duration
            
        PatternState.RECOVERING:
            state_timer = recovery_duration
            enemy.modulate = Color.WHITE
            
            # Clean up telegraph
            if TelegraphSystem:
                TelegraphSystem.hide_telegraph(enemy)
                
        PatternState.REPOSITIONING:
            state_timer = reposition_duration
            pick_new_pattern_variation()

func pick_new_pattern_variation():
    # Add variety to patterns
    pattern_variation = randi() % 3

# Visual effect creation (enhanced with animation system)
func create_telegraph_effect():
    # Handled by TelegraphSystem and animation_system
    pass

func create_attack_effect():
    # Additional effects beyond animation
    pass

# Helper functions
func get_all_nearby_enemies(radius: float) -> Array:
    var nearby = []
    for other in get_tree().get_nodes_in_group("enemies"):
        if other != enemy and enemy.global_position.distance_to(other.global_position) < radius:
            nearby.append(other)
    return nearby

func is_attack_on_cooldown() -> bool:
    var time_since_attack = Time.get_ticks_msec() / 1000.0 - last_attack_time
    return time_since_attack < get_attack_cooldown()

func get_attack_cooldown() -> float:
    return 1.5  # Override in subclasses

# Debug info
func get_pattern_info() -> Dictionary:
    return {
        "pattern_type": get_class(),
        "current_state": PatternState.keys()[current_state],
        "state_timer": state_timer,
        "attack_committed": attack_committed,
        "target_distance": enemy.global_position.distance_to(target.global_position) if target else -1,
        "can_see_target": can_see_target(),
        "position_crowded": is_position_crowded()
    }

# Cleanup
func _exit_tree():
    if animation_system:
        animation_system.cleanup()