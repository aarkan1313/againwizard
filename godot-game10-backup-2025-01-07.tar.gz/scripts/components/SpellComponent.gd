# SpellComponent.gd
# Purpose: Handles spell casting logic for player entities
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: SpellData, HealthComponent, SpellProjectile
# API References: Node class, Input system, Timer

extends Node
class_name SpellComponent

var owner_entity: Node
var health_component: HealthComponent
var equipped_spells: Array[SpellData] = []
var spell_cooldowns: Dictionary = {}

# Phase 3: Reactive stat integration (safe, non-breaking)
var player_stat_sheet: PlayerStatSheet

# Default spells
var fireball_spell: SpellData

# Projectile scene reference
var projectile_scene: PackedScene

func setup(entity: Node, health_comp: HealthComponent):
	owner_entity = entity
	health_component = health_comp
	
	# Phase 3: Get player stat sheet reference (safe integration)
	if entity.has_method("get_stat_sheet"):
		player_stat_sheet = entity.get_stat_sheet()
		if player_stat_sheet:
			UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "📊 SpellComponent connected to reactive stats", "SpellComponent")
	
	# Load projectile scene
	var projectile_path = "res://scenes/SpellProjectile.tscn"
	if ResourceLoader.exists(projectile_path):
		projectile_scene = load(projectile_path)
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "✅ SpellProjectile scene loaded successfully", "SpellComponent")
	else:
		push_error("SpellProjectile scene not found at " + projectile_path)
		push_warning("⚠️ SpellProjectile scene not found - spells may not work")
	
	# Load default spells
	_load_default_spells()
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "✅ SpellComponent setup complete for " + entity.name, "SpellComponent")

func _load_default_spells():
	# Create all 5 basic spells from salvaged assets (simplified versions)
	
	# 1. Fireball - Blazing projectile with area damage
	fireball_spell = SpellData.new()
	fireball_spell.spell_name = "Fireball"
	fireball_spell.base_damage = 25.0
	fireball_spell.mana_cost = 8
	fireball_spell.projectile_speed = 300.0
	fireball_spell.projectile_range = 500.0
	fireball_spell.cooldown_duration = 1.0
	_add_spell_if_valid(fireball_spell)
	
	# 2. Magic Missile - Fast, reliable arcane projectile
	var magic_missile = SpellData.new()
	magic_missile.spell_name = "Magic Missile"
	magic_missile.base_damage = 15.0
	magic_missile.mana_cost = 5
	magic_missile.projectile_speed = 400.0
	magic_missile.projectile_range = 500.0
	magic_missile.cooldown_duration = 0.5
	_add_spell_if_valid(magic_missile)
	
	# 3. Ice Shard - Fast projectile with bouncing
	var ice_shard = SpellData.new()
	ice_shard.spell_name = "Ice Shard"
	ice_shard.base_damage = 20.0
	ice_shard.mana_cost = 6
	ice_shard.projectile_speed = 350.0
	ice_shard.projectile_range = 500.0
	ice_shard.cooldown_duration = 0.8
	_add_spell_if_valid(ice_shard)
	
	# 4. Lightning Bolt - High damage, fast piercing projectile
	var lightning_bolt = SpellData.new()
	lightning_bolt.spell_name = "Lightning Bolt"
	lightning_bolt.base_damage = 30.0
	lightning_bolt.mana_cost = 10
	lightning_bolt.projectile_speed = 500.0
	lightning_bolt.projectile_range = 500.0
	lightning_bolt.cooldown_duration = 1.5
	_add_spell_if_valid(lightning_bolt)
	
	# 5. Heal - Self-healing spell (negative damage = healing)
	var heal = SpellData.new()
	heal.spell_name = "Heal"
	heal.base_damage = -25.0  # Negative damage = healing
	heal.mana_cost = 12
	heal.projectile_speed = 0.0  # Instant self-cast
	heal.projectile_range = 0.0  # No projectile
	heal.cooldown_duration = 2.0
	_add_spell_if_valid(heal)
	
	UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "✅ Loaded " + str(equipped_spells.size()) + " default spells", "SpellComponent")

func _add_spell_if_valid(spell: SpellData):
	if spell.validate():
		equipped_spells.append(spell)
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL, "✅ Spell loaded: " + spell.get_debug_info(), "SpellComponent")
	else:
		push_error("Failed to create valid spell: " + spell.spell_name)

func _process(delta):
	# Update cooldowns
	var expired_cooldowns = []
	for spell_name in spell_cooldowns.keys():
		spell_cooldowns[spell_name] -= delta
		if spell_cooldowns[spell_name] <= 0:
			expired_cooldowns.append(spell_name)
	
	# Remove expired cooldowns
	for spell_name in expired_cooldowns:
		spell_cooldowns.erase(spell_name)

func cast_spell(spell_index: int) -> bool:
	# Validate spell index
	if spell_index < 0 or spell_index >= equipped_spells.size():
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "❌ Invalid spell index: " + str(spell_index) + " (available: 0-" + str(equipped_spells.size() - 1) + ")", "SpellComponent")
		return false
	
	var spell = equipped_spells[spell_index]
	
	# Check cooldown (reduced logging)
	if spell.spell_name in spell_cooldowns:
		return false
	
	# Check mana through HealthComponent (reduced logging)
	if not health_component or health_component.current_mana < spell.mana_cost:
		return false
	
	# Check for free cast chance (wisdom bonus)
	var free_cast = false
	if player_stat_sheet:
		var free_cast_chance = player_stat_sheet.get_stat_value("free_cast_chance")
		if randf() < free_cast_chance:
			free_cast = true
			print("🎯 Free cast! (", free_cast_chance * 100, "% chance from wisdom)")
	
	# Consume mana (unless free cast)
	if not free_cast:
		if not health_component.consume_mana(spell.mana_cost):
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "💙 Failed to consume mana for " + spell.spell_name, "SpellComponent")
			return false
	
	# Declare cast_direction for use in print statement later
	var cast_direction = Vector2.ZERO
	
	# Handle healing spells (negative damage, no projectile)
	if spell.base_damage < 0:
		# This is a healing spell - apply healing directly
		var heal_amount = abs(spell.base_damage)
		if health_component.heal(heal_amount):
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "💚 " + spell.spell_name + " healed for " + str(heal_amount) + " health", "SpellComponent")
		else:
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "⚠️ " + spell.spell_name + " healing failed", "SpellComponent")
		cast_direction = Vector2.ZERO  # No direction for healing
	else:
		# Normal projectile spell
		cast_direction = _get_cast_direction()
		if cast_direction.length() == 0:
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "⚠️ Invalid cast direction, using default (right)", "SpellComponent")
			cast_direction = Vector2.RIGHT
		
		# Create projectile
		var projectile_created = _create_projectile(spell, cast_direction)
		if not projectile_created:
			# Refund mana if projectile creation failed
			if health_component:
				health_component.restore_mana(spell.mana_cost)
			return false
	
	# Set cooldown with diminishing returns reduction from wisdom
	var base_cooldown = spell.cooldown_duration
	var final_cooldown = base_cooldown
	
	if player_stat_sheet:
		var raw_reduction = player_stat_sheet.get_stat_value("cooldown_reduction")
		var effective_reduction = _calculate_cooldown_reduction_with_diminishing_returns(raw_reduction)
		final_cooldown = base_cooldown * (1.0 - effective_reduction)
		# Minimum cooldown of 0.1 seconds to prevent spam
		final_cooldown = max(0.1, final_cooldown)
	
	spell_cooldowns[spell.spell_name] = final_cooldown
	
	# Emit event
	if GameEvents:
		GameEvents.spell_cast.emit(spell.spell_name, spell.base_damage)
	
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "🪄 " + spell.spell_name + " cast successfully! Direction: " + str(cast_direction), "SpellComponent")
	return true

func _get_cast_direction() -> Vector2:
	if not owner_entity:
		return Vector2.RIGHT
	
	# Accurate mouse aiming for Godot 4.4.1 - Get viewport and transform mouse position
	var viewport = owner_entity.get_viewport()
	if not viewport:
		return Vector2.RIGHT
	
	# Get mouse position in viewport coordinates
	var mouse_pos = viewport.get_mouse_position()
	# Transform to global coordinates using the viewport's canvas transform
	var global_mouse_pos = viewport.get_canvas_transform().affine_inverse() * mouse_pos
	
	var player_pos = owner_entity.global_position
	var direction = (global_mouse_pos - player_pos).normalized()
	
	# Validation and fallback
	if direction.length() == 0 or is_nan(direction.x) or is_nan(direction.y):
		return Vector2.RIGHT
	
	return direction

func _create_projectile(spell: SpellData, direction: Vector2) -> bool:
	if not projectile_scene:
		push_error("Cannot create projectile: projectile_scene is null")
		return false
	
	if not owner_entity:
		push_error("Cannot create projectile: owner_entity is null")
		return false
	
	# Create projectile instance
	var projectile = projectile_scene.instantiate()
	if not projectile:
		push_error("Failed to instantiate projectile scene")
		return false
	
	# Add to scene tree
	get_tree().current_scene.add_child(projectile)
	
	# Set projectile position
	projectile.global_position = owner_entity.global_position
	
	# Phase 3: Calculate enhanced damage using reactive stats (safe fallback)
	var final_damage = _calculate_enhanced_damage(spell.base_damage)
	
	# Calculate enhanced projectile speed and range
	var enhanced_speed = spell.projectile_speed
	var enhanced_range = spell.projectile_range
	if player_stat_sheet:
		enhanced_speed = player_stat_sheet.get_stat_value("spell_projectile_speed")
		var range_multiplier = player_stat_sheet.get_stat_value("spell_range_multiplier")
		enhanced_range = spell.projectile_range * range_multiplier
	
	# Setup projectile with enhanced damage, speed, and range
	if projectile.has_method("setup"):
		projectile.setup(spell, final_damage, direction)
		# Override projectile speed with enhanced value
		if projectile.has_method("set_speed"):
			projectile.set_speed(enhanced_speed)
		elif "speed" in projectile:
			projectile.speed = enhanced_speed
		# Override projectile range with enhanced value
		if projectile.has_method("set_range"):
			projectile.set_range(enhanced_range)
		elif "max_range" in projectile:
			projectile.max_range = enhanced_range
	else:
		push_error("SpellProjectile missing setup method")
		projectile.queue_free()
		return false
	
	return true

# Public API for external systems
func get_equipped_spells() -> Array[SpellData]:
	return equipped_spells

func get_spell_cooldown(spell_index: int) -> float:
	if spell_index < 0 or spell_index >= equipped_spells.size():
		return 0.0
	
	var spell = equipped_spells[spell_index]
	return spell_cooldowns.get(spell.spell_name, 0.0)

func is_spell_ready(spell_index: int) -> bool:
	if spell_index < 0 or spell_index >= equipped_spells.size():
		return false
	
	var spell = equipped_spells[spell_index]
	var on_cooldown = spell.spell_name in spell_cooldowns
	var has_mana = health_component and health_component.current_mana >= spell.mana_cost
	
	return not on_cooldown and has_mana

func get_debug_info() -> String:
	var info = "SpellComponent Debug:\n"
	info += "Equipped spells: " + str(equipped_spells.size()) + "\n"
	for i in range(equipped_spells.size()):
		var spell = equipped_spells[i]
		var cooldown = get_spell_cooldown(i)
		var is_ready = is_spell_ready(i)
		info += "  [" + str(i) + "] " + spell.spell_name + " - Cooldown: " + str(cooldown).pad_decimals(1) + "s - Ready: " + str(is_ready) + "\n"
	return info

# Validation method for testing
func validate_setup() -> bool:
	var checks = [
		owner_entity != null,
		health_component != null,
		equipped_spells.size() > 0,
		projectile_scene != null
	]
	
	var passed = 0
	for check in checks:
		if check:
			passed += 1
	
	var success = passed == checks.size()
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.TESTING, "🔍 SpellComponent validation: " + str(passed) + "/" + str(checks.size()) + " " + ("PASSED" if success else "FAILED"), "SpellComponent")
	return success

# Phase 3: Enhanced damage calculation with reactive stats (safe fallback)
func _calculate_enhanced_damage(base_damage: float) -> float:
	if not player_stat_sheet:
		return base_damage  # Fallback to original behavior
	
	# Get spell damage multiplier from Intelligence - FORCE FRESH CALCULATION
	var damage_multiplier = player_stat_sheet.get_stat_value("spell_damage_multiplier")
	
	# DEBUG: Force recalculation if using enhanced computed stats
	if player_stat_sheet.has_method("get_computed_stat"):
		var computed_stat = player_stat_sheet.get_computed_stat("spell_damage_multiplier")
		if computed_stat and computed_stat.has_method("mark_dirty"):
			computed_stat.mark_dirty()
			damage_multiplier = computed_stat.get_final_value()
	
	var modified_damage = base_damage * damage_multiplier
	
	# Check for critical hit based on Intelligence - FORCE FRESH CALCULATION
	var critical_chance = player_stat_sheet.get_stat_value("critical_chance")
	
	# DEBUG: Force recalculation for critical chance too
	if player_stat_sheet.has_method("get_computed_stat"):
		var crit_stat = player_stat_sheet.get_computed_stat("critical_chance")
		if crit_stat and crit_stat.has_method("mark_dirty"):
			crit_stat.mark_dirty()
			critical_chance = crit_stat.get_final_value()
	if randf() < critical_chance:
		modified_damage *= 2.0
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.PLAYER, "💥 CRITICAL HIT! Damage: " + str(modified_damage) + " (was " + str(base_damage) + ")", "SpellComponent")
	else:
		# Only log damage calculations occasionally (every 10th spell)
		if randf() < 0.1:
			var intelligence = player_stat_sheet.get_stat_value("intelligence")
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, "🎯 Enhanced damage: " + str(modified_damage) + " (base: " + str(base_damage) + ", multiplier: " + str(damage_multiplier) + ", int: " + str(intelligence) + ")", "SpellComponent")
	
	return modified_damage

# Cooldown reduction with diminishing returns after 70%
func _calculate_cooldown_reduction_with_diminishing_returns(raw_reduction: float) -> float:
	# Below 70% reduction: normal scaling
	if raw_reduction <= 0.7:
		return raw_reduction
	
	# Above 70%: extreme diminishing returns
	# Formula: 0.7 + (raw - 0.7) * 0.1 = caps at ~73% for very high wisdom
	var excess = raw_reduction - 0.7
	var diminished_excess = excess * 0.1  # Only 10% of excess applies
	var final_reduction = 0.7 + diminished_excess
	
	# Hard cap at 75% to prevent infinite reduction
	return min(final_reduction, 0.75)
