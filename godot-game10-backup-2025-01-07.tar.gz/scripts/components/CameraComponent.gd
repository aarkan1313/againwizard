# CameraComponent.gd
# Purpose: Simple camera follow and zoom system for infinite movement
# Godot Version: 4.4.1 compatible

extends Camera2D
class_name CameraComponent

# Player reference
var player: CharacterBody2D

# Zoom settings
var min_zoom: float = 0.5
var max_zoom: float = 3.0
var zoom_speed: float = 0.1
var zoom_step: float = 0.1

# Following settings
var follow_speed: float = 10.0
var follow_enabled: bool = true

func _ready():
	print("🔧 CameraComponent _ready() called")
	
	# Get player reference
	player = get_parent() as CharacterBody2D
	if not player:
		push_error("❌ CameraComponent must be child of CharacterBody2D")
		return
	
	print("✅ Player reference found: ", player.name)
	
	# This script IS the Camera2D node
	print("✅ PlayerCamera (self): ", name)
	
	# Make this camera current and enabled
	enabled = true
	make_current()
	
	print("📹 Camera system initialized - Following enabled, zoom controls active")
	print("📹 Camera position: ", global_position)
	print("📹 Camera zoom: ", zoom)
	print("📹 Camera current: ", is_current())
	print("📹 Camera enabled: ", enabled)

func _input(event):
	
	# Handle mouse wheel zoom
	if event is InputEventMouseButton and event.pressed:
		var zoom_change = 0.0
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_change = zoom_step  # Zoom in
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_change = -zoom_step  # Zoom out
		
		if zoom_change != 0.0:
			_zoom_camera(zoom_change)
	
	# Handle keyboard zoom
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_EQUAL, KEY_PLUS:  # + key
				print("⌨️ Plus key pressed - zooming in")
				_zoom_camera(zoom_step)
			KEY_MINUS:  # - key
				print("⌨️ Minus key pressed - zooming out")
				_zoom_camera(-zoom_step)
			KEY_0:  # Reset zoom
				zoom = Vector2.ONE
				print("📹 Camera zoom reset to 1.0x")

func _zoom_camera(zoom_change: float):
	var old_zoom = zoom.x
	var new_zoom = old_zoom + zoom_change
	new_zoom = clamp(new_zoom, min_zoom, max_zoom)
	
	zoom = Vector2(new_zoom, new_zoom)
	# Only log significant zoom changes to reduce spam
	if abs(new_zoom - old_zoom) > 0.05:
		UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.GENERAL, 
			"Camera zoom: %.1fx" % new_zoom, "CameraComponent")

func set_zoom_level(zoom_level: float):
	zoom_level = clamp(zoom_level, min_zoom, max_zoom)
	zoom = Vector2(zoom_level, zoom_level)

func get_zoom_level() -> float:
	return zoom.x

func set_follow_enabled(follow_active: bool):
	follow_enabled = follow_active

func _physics_process(delta: float) -> void:
	# Only follow if player exists and following is enabled
	if not player or not follow_enabled:
		return
	
	# Smooth follow player position
	if follow_speed > 0:
		global_position = global_position.lerp(player.global_position, follow_speed * delta)
	else:
		global_position = player.global_position

func get_camera() -> Camera2D:
	return self
