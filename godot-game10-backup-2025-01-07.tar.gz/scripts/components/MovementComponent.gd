extends Node
# MovementComponent_DodgeFixed.gd - Fixed to remove duplicate dodge collision handling
# Purpose: Handles player movement physics without interfering with Player.gd dodge
# Godot Version: 4.4.1 compatible
# FIXES: Removed dodge collision handling to prevent conflicts with Player.gd
class_name MovementComponent

var player: CharacterBody2D

# Movement stats - FIXED: No hardcoded initialization, all from stat system
var base_speed: float = 0.0
var acceleration: float = 0.0
var friction: float = 0.0

# Dodge system - FIXED: All values from stats
var dodge_speed: float = 0.0
var dodge_duration: float = 0.0
var dodge_cooldown: float = 0.0
var is_dodging: bool = false
var dodge_timer: float = 0.0
var dodge_cooldown_timer: float = 0.0
var dodge_direction: Vector2 = Vector2.ZERO

# Screen boundary system
var screen_margin: float = 50.0
var screen_size: Vector2

# Visual feedback references
var player_visuals: Node

# Stat integration - FIXED: Required for stat-based movement
var player_stat_sheet: PlayerStatSheet = null
var is_stat_integrated: bool = false

func setup(player_node: CharacterBody2D) -> void:
	player = player_node
	if not player:
		push_error("MovementComponent: Invalid player node provided")
		return
	
	# FIXED: Setup stat integration FIRST
	if not _setup_stat_integration():
		push_error("MovementComponent: Cannot initialize without stat integration!")
		return
	
	# Get screen size for boundary detection
	screen_size = get_viewport().get_visible_rect().size
	
	# Find visual component for feedback
	player_visuals = player.get_node_or_null("PlayerVisuals")
	if not player_visuals:
		print("⚠️ PlayerVisuals component not found - visual effects disabled")
	
	print("✅ MovementComponent setup complete for " + player.name)
	print("📏 Screen size: " + str(screen_size) + ", margin: " + str(screen_margin))
	print("🏃 Movement stats from PlayerStatSheet:")
	print("   Base Speed: ", base_speed)
	print("   Dodge Speed: ", dodge_speed, " Duration: ", dodge_duration, "s Cooldown: ", dodge_cooldown, "s")

func _setup_stat_integration() -> bool:
	# FIXED: Setup integration with player stat sheet - REQUIRED
	if not player.has_method("get_stat_sheet"):
		push_error("MovementComponent: Player entity must have get_stat_sheet method!")
		return false
	
	player_stat_sheet = player.get_stat_sheet()
	if not player_stat_sheet:
		push_error("MovementComponent: Player stat sheet not available!")
		return false
	
	# Connect to stat changes for real-time updates
	if not player_stat_sheet.stat_value_changed.is_connected(_on_stat_changed):
		player_stat_sheet.stat_value_changed.connect(_on_stat_changed)
		print("🔗 MovementComponent connected to stat changes")
	
	is_stat_integrated = true
	
	# FIXED: Initialize ALL values from stats (no hardcoded fallbacks)
	_initialize_from_stats()
	
	print("✅ Movement stat integration enabled - all values from PlayerStatSheet")
	return true

func _initialize_from_stats() -> void:
	# FIXED: Initialize ALL movement values from stats
	if not is_stat_integrated or not player_stat_sheet:
		push_error("MovementComponent: Cannot initialize from stats - stat integration failed!")
		return
	
	# Get movement stats from stat sheet
	base_speed = player_stat_sheet.get_stat_value("movement_speed")
	
	# Get dodge stats (should exist in PlayerStatSheet now)
	if player_stat_sheet.has_stat("dodge_speed"):
		dodge_speed = player_stat_sheet.get_stat_value("dodge_speed")
	else:
		dodge_speed = 600.0  # Fallback
		print("⚠️ MovementComponent: dodge_speed stat not found, using fallback: ", dodge_speed)
	
	if player_stat_sheet.has_stat("dodge_duration"):
		dodge_duration = player_stat_sheet.get_stat_value("dodge_duration")
	else:
		dodge_duration = 0.4  # Fallback
		print("⚠️ MovementComponent: dodge_duration stat not found, using fallback: ", dodge_duration)
	
	if player_stat_sheet.has_stat("dodge_cooldown"):
		dodge_cooldown = player_stat_sheet.get_stat_value("dodge_cooldown")
	else:
		dodge_cooldown = 1.2  # Fallback
		print("⚠️ MovementComponent: dodge_cooldown stat not found, using fallback: ", dodge_cooldown)
	
	# Get physics stats (should exist in PlayerStatSheet now)
	if player_stat_sheet.has_stat("acceleration"):
		acceleration = player_stat_sheet.get_stat_value("acceleration")
	else:
		acceleration = 10.0  # Fallback
		print("⚠️ MovementComponent: acceleration stat not found, using fallback: ", acceleration)
	
	if player_stat_sheet.has_stat("friction"):
		friction = player_stat_sheet.get_stat_value("friction")
	else:
		friction = 8.0  # Fallback
		print("⚠️ MovementComponent: friction stat not found, using fallback: ", friction)
	
	# Validate stat values
	if base_speed <= 0:
		push_error("MovementComponent: Invalid movement_speed from PlayerStatSheet: " + str(base_speed))
		return
	
	print("📊 MovementComponent initialized from stats:")
	print("   Movement Speed: ", base_speed, " (from dexterity)")
	print("   Dodge Speed: ", dodge_speed)
	print("   Dodge Duration: ", dodge_duration, "s")
	print("   Dodge Cooldown: ", dodge_cooldown, "s")
	print("   Acceleration: ", acceleration)
	print("   Friction: ", friction)

func _on_stat_changed(stat_name: String, old_value: float, new_value: float) -> void:
	# Handle stat changes and update movement accordingly
	# Only log important movement-related changes
	if stat_name in ["movement_speed", "dexterity", "dodge_speed", "dodge_duration", "dodge_cooldown"]:
		print("📊 MovementComponent stat change: ", stat_name, " ", old_value, " → ", new_value)
	
	# Update values based on stat changes
	match stat_name:
		"movement_speed":
			base_speed = new_value
			print("🏃 Movement speed updated: ", new_value)
		"dexterity":
			# Dexterity affects movement_speed through computed stat
			if player_stat_sheet:
				var new_speed = player_stat_sheet.get_stat_value("movement_speed")
				if new_speed != base_speed:
					base_speed = new_speed
					print("🏃 Movement speed updated from dexterity: ", new_speed)
		"dodge_speed":
			dodge_speed = new_value
		"dodge_duration":
			dodge_duration = new_value
		"dodge_cooldown":
			dodge_cooldown = new_value
		"acceleration":
			acceleration = new_value
		"friction":
			friction = new_value

func physics_update(delta: float) -> void:
	if not player:
		return
	
	# REMOVED: Let Player.gd handle dodge completely
	# Only update timers for MovementComponent's internal tracking
	_update_dodge_timers(delta)
	_handle_movement(delta)
	_apply_movement()

func _handle_movement(delta: float) -> void:
	var input_vector = InputHandler.get_movement_vector()
	
	# REMOVED: Don't interfere with Player.gd's dodge movement
	# Check if player is dodging from Player.gd
	if player.has_method("get_is_dodging") and player.get_is_dodging():
		return
	
	if input_vector.length() > 0:
		# Normalize diagonal movement to prevent speed boost
		input_vector = input_vector.normalized()
		
		# FIXED: Use stat-based speed and acceleration
		var target_velocity = input_vector * base_speed
		player.velocity = player.velocity.move_toward(target_velocity, acceleration * delta * 100)
	else:
		# FIXED: Use stat-based friction
		player.velocity = player.velocity.move_toward(Vector2.ZERO, friction * delta * 100)

func _update_dodge_timers(delta: float) -> void:
	# Only update timers, don't handle dodge logic
	if dodge_timer > 0:
		dodge_timer -= delta
		if dodge_timer <= 0:
			is_dodging = false
			# REMOVED: Don't handle collision here - Player.gd handles it
			# Trigger dodge end visual effect
			if player_visuals and player_visuals.has_method("on_dodge_end"):
				player_visuals.on_dodge_end()
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER, 
				"Dodge completed", "MovementComponent")
	
	# Update cooldown timer
	if dodge_cooldown_timer > 0:
		dodge_cooldown_timer -= delta

# REMOVED: _start_dodge function - let Player.gd handle dodge

func _apply_movement() -> void:
	# Apply movement using Godot 4.4.1 physics
	player.move_and_slide()
	
	# Emit movement event for other systems (only if position actually changed)
	if player.velocity.length() > 1.0:
		GameEvents.emit_player_moved(player.global_position)

func _handle_screen_boundaries() -> void:
	# Get current screen size (in case window was resized)
	screen_size = get_viewport().get_visible_rect().size
	
	# Calculate boundaries
	var min_x = screen_margin
	var max_x = screen_size.x - screen_margin
	var min_y = screen_margin
	var max_y = screen_size.y - screen_margin
	
	# Check and correct position with smooth clamping
	var new_position = player.global_position
	var corrected = false
	
	if new_position.x < min_x:
		new_position.x = min_x
		player.velocity.x = max(0, player.velocity.x)  # Stop leftward movement
		corrected = true
	elif new_position.x > max_x:
		new_position.x = max_x
		player.velocity.x = min(0, player.velocity.x)  # Stop rightward movement
		corrected = true
	
	if new_position.y < min_y:
		new_position.y = min_y
		player.velocity.y = max(0, player.velocity.y)  # Stop upward movement
		corrected = true
	elif new_position.y > max_y:
		new_position.y = max_y
		player.velocity.y = min(0, player.velocity.y)  # Stop downward movement
		corrected = true
	
	if corrected:
		player.global_position = new_position

# Enhanced dodge system functions
func can_dodge() -> bool:
	return dodge_cooldown_timer <= 0 and not is_dodging

func get_dodge_cooldown_remaining() -> float:
	return max(0, dodge_cooldown_timer)

func is_dodge_ready() -> bool:
	return dodge_cooldown_timer <= 0

func get_dodge_distance() -> float:
	# Calculate total dodge distance using stat-based values
	return dodge_speed * dodge_duration

func get_is_dodging() -> bool:
	return is_dodging

func get_dodge_progress() -> float:
	# Get dodge progress (0.0 to 1.0)
	if not is_dodging:
		return 0.0
	return 1.0 - (dodge_timer / dodge_duration)

# REMOVED: _set_dodge_collision_mode function - Player.gd handles collision

# External API
func get_current_speed() -> float:
	if player:
		return player.velocity.length()
	return 0.0

func is_moving() -> bool:
	if player:
		return player.velocity.length() > 10.0
	return false

func get_movement_state() -> String:
	# Check Player.gd's dodge state
	if player.has_method("get_is_dodging") and player.get_is_dodging():
		return "dodging"
	elif is_moving():
		return "moving"
	else:
		return "idle"

# === STAT-BASED GETTERS ===

func get_base_speed() -> float:
	# Get current base speed from stats
	if is_stat_integrated and player_stat_sheet:
		return player_stat_sheet.get_stat_value("movement_speed")
	return base_speed

func get_dodge_stats() -> Dictionary:
	# Get all dodge-related stats
	return {
		"dodge_speed": dodge_speed,
		"dodge_duration": dodge_duration,
		"dodge_cooldown": dodge_cooldown,
		"dodge_distance": get_dodge_distance()
	}

# === MANUAL UPDATE FUNCTIONS ===

func force_update_from_stats() -> void:
	# Force update movement values from current stats
	if is_stat_integrated and player_stat_sheet:
		_initialize_from_stats()
		print("🔄 MovementComponent force updated from stats")

# Debug functions
func get_movement_debug_info() -> String:
	return """
Movement Debug Info:
- Position: %s
- Velocity: %s (%.1f units/sec)
- State: %s
- Base Speed: %.1f (stat-based)
- Dodge Ready: %s (cooldown: %.1f)
- Dodge Speed: %.1f Duration: %.1fs
- Screen Bounds: %.0f x %.0f (margin: %.0f)
- Stat Integration: %s
""" % [
	str(player.global_position) if player else "N/A",
	str(player.velocity) if player else "N/A",
	get_current_speed(),
	get_movement_state(),
	base_speed,
	str(is_dodge_ready()),
	get_dodge_cooldown_remaining(),
	dodge_speed,
	dodge_duration,
	screen_size.x,
	screen_size.y,
	screen_margin,
	str(is_stat_integrated)
]