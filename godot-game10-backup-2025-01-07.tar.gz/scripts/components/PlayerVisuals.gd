extends Node
# PlayerVisuals.gd - Visual feedback system for player actions
# Purpose: Handles visual effects for movement, dodge, and damage feedback
# Godot Version: 4.4.1 compatible
class_name PlayerVisuals

var player: CharacterBody2D
var sprite: Sprite2D
var collision_shape: CollisionShape2D

# Visual effect states
var is_dodge_effect_active: bool = false
var is_damage_effect_active: bool = false

# Tween references for smooth animations
var dodge_tween: Tween
var damage_tween: Tween

# Effect parameters
var dodge_transparency: float = 0.5
var damage_flash_color: Color = Color.RED
var effect_duration: float = 0.2

func setup(player_node: CharacterBody2D) -> void:
	player = player_node
	if not player:
		push_error("PlayerVisuals: Invalid player node provided")
		return
	
	# Find sprite and collision components
	sprite = player.get_node_or_null("PlayerSprite")
	collision_shape = player.get_node_or_null("PlayerCollision")
	
	if not sprite:
		push_error("PlayerVisuals: PlayerSprite not found")
		return
	
	if not collision_shape:
		print("⚠️ PlayerVisuals: PlayerCollision not found - some effects may not work")
	
	# Initialize tween references (create when needed to avoid empty tween warnings)
	dodge_tween = null
	damage_tween = null
	
	print("✅ PlayerVisuals setup complete for " + player.name)
	print("🎨 Visual effects ready: dodge transparency, damage flash")

# Dodge visual effects
func on_dodge_start() -> void:
	if not sprite or is_dodge_effect_active:
		return
	
	is_dodge_effect_active = true
	
	# Create dodge transparency effect
	dodge_tween = create_tween()
	dodge_tween.set_parallel(true)  # Allow multiple animations
	
	# Fade to transparent
	dodge_tween.tween_property(sprite, "modulate:a", dodge_transparency, 0.05)
	
	# Add slight scale effect for impact
	var original_scale = sprite.scale
	dodge_tween.tween_property(sprite, "scale", original_scale * 1.1, 0.05)
	dodge_tween.tween_property(sprite, "scale", original_scale, 0.15)
	
	# Dodge visual effect started

func on_dodge_end() -> void:
	if not sprite or not is_dodge_effect_active:
		return
	
	is_dodge_effect_active = false
	
	# Restore full opacity
	dodge_tween = create_tween()
	dodge_tween.tween_property(sprite, "modulate:a", 1.0, 0.1)
	
	# Dodge visual effect ended

# Damage visual effects
func on_damage_taken(damage_amount: float) -> void:
	if not sprite:
		return
	
	# Stop any existing damage effect
	if is_damage_effect_active and damage_tween:
		damage_tween.kill()
	
	is_damage_effect_active = true
	
	# Create damage flash effect
	damage_tween = create_tween()
	damage_tween.set_parallel(true)
	
	# Flash red
	var original_color = sprite.modulate
	damage_tween.tween_property(sprite, "modulate", damage_flash_color, 0.1)
	damage_tween.tween_property(sprite, "modulate", original_color, 0.1)
	
	# Slight shake effect
	var _original_position = sprite.position
	damage_tween.tween_method(_shake_sprite, 0.0, 0.0, effect_duration)
	
	# Reset effect state when complete
	damage_tween.tween_callback(_on_damage_effect_complete)
	
	print("🎨 Damage visual effect triggered (damage: " + str(damage_amount) + ")")

func _shake_sprite(_progress: float) -> void:
	if not sprite:
		return
	
	# Simple shake effect
	var shake_strength = 3.0
	var shake_offset = Vector2(
		randf_range(-shake_strength, shake_strength),
		randf_range(-shake_strength, shake_strength)
	)
	
	sprite.position = shake_offset

func _on_damage_effect_complete() -> void:
	is_damage_effect_active = false
	
	# Reset sprite position
	if sprite:
		sprite.position = Vector2.ZERO
	
	print("🎨 Damage visual effect completed")

# Healing visual effects
func on_healing_received(heal_amount: float) -> void:
	if not sprite:
		return
	
	# Create healing glow effect
	var healing_tween = create_tween()
	healing_tween.set_parallel(true)
	
	# Green glow
	var original_color = sprite.modulate
	var heal_color = Color.GREEN
	heal_color.a = 0.7
	
	healing_tween.tween_property(sprite, "modulate", heal_color, 0.15)
	healing_tween.tween_property(sprite, "modulate", original_color, 0.15)
	
	print("🎨 Healing visual effect triggered (heal: " + str(heal_amount) + ")")

# Movement visual feedback
func on_movement_state_changed(new_state: String) -> void:
	# This can be expanded for movement-based visual effects
	match new_state:
		"moving":
			_start_movement_effect()
		"idle":
			_stop_movement_effect()
		"dodging":
			# Dodge effects are handled by on_dodge_start/end
			pass

func _start_movement_effect() -> void:
	# Subtle movement visual feedback could be added here
	# For now, this is a placeholder for future enhancements
	pass

func _stop_movement_effect() -> void:
	# Reset any movement-based visual effects
	pass

# Utility functions
func reset_all_effects() -> void:
	# Reset all visual effects to default state
	if dodge_tween:
		dodge_tween.kill()
	if damage_tween:
		damage_tween.kill()
	
	is_dodge_effect_active = false
	is_damage_effect_active = false
	
	if sprite:
		sprite.modulate = Color.WHITE
		sprite.position = Vector2.ZERO
		sprite.scale = Vector2.ONE
	
	print("🎨 All visual effects reset")

func get_visual_status() -> String:
	return """
PlayerVisuals Status:
- Dodge Effect Active: %s
- Damage Effect Active: %s
- Sprite Available: %s
- Collision Shape Available: %s
""" % [
	str(is_dodge_effect_active),
	str(is_damage_effect_active),
	str(sprite != null),
	str(collision_shape != null)
]

# Cleanup
func _exit_tree() -> void:
	if dodge_tween:
		dodge_tween.kill()
	if damage_tween:
		damage_tween.kill()
