# HealthComponent.gd - FIXED VERSION WITH PROPER MAX VALUE HANDLING
# Purpose: Fixed health component that always uses live stat values
# FIXES:
# - Always get max values from stat sheet when needed
# - Prevent mana overflow by clamping properly
# - Update current values when max values change

extends Node
class_name HealthComponent

# Health and mana tracking
var current_health: float = 100.0
var current_mana: float = 50.0
var max_health: float = 100.0  # Cached for performance, but always verify
var max_mana: float = 50.0     # Cached for performance, but always verify

# Regeneration rates
var health_regen_rate: float = 2.0
var mana_regen_rate: float = 3.0

# Timers for regeneration
var health_regen_timer: Timer
var mana_regen_timer: Timer

# Reference to owner entity
var owner_entity: Node = null
var stat_sheet = null

# Invincibility and infinite mana (for debugging/power-ups)
var invincible: bool = false
var infinite_mana_enabled: bool = false

# Damage flash effect
var damage_flash_duration: float = 0.1
var is_flashing: bool = false

func _ready() -> void:
	owner_entity = get_parent()
	
	# Setup regeneration timers
	_setup_regeneration_timers()
	
	# Connect to stat sheet if available
	_connect_to_stats()
	
	# Initialize health/mana from stats
	on_stats_changed()

# Setup method called by Player.gd for re-initialization
func setup(entity: Node) -> void:
	owner_entity = entity
	_connect_to_stats()
	on_stats_changed()
	print("🔧 HealthComponent setup complete for: ", entity.name)

func _setup_regeneration_timers() -> void:
	# Health regeneration timer
	health_regen_timer = Timer.new()
	health_regen_timer.wait_time = 0.5  # Tick every 0.5 seconds
	health_regen_timer.timeout.connect(_regenerate_health)
	add_child(health_regen_timer)
	health_regen_timer.start()
	
	# Mana regeneration timer
	mana_regen_timer = Timer.new()
	mana_regen_timer.wait_time = 0.5  # Tick every 0.5 seconds
	mana_regen_timer.timeout.connect(_regenerate_mana)
	add_child(mana_regen_timer)
	mana_regen_timer.start()

func _connect_to_stats() -> void:
	# Get stat sheet from owner
	if owner_entity and owner_entity.has_method("get_stat_sheet"):
		stat_sheet = owner_entity.get_stat_sheet()
		if stat_sheet:
			# Connect to stat changes
			if stat_sheet.has_signal("stat_value_changed"):
				stat_sheet.stat_value_changed.connect(_on_stat_changed)
			print("🔗 HealthComponent connected to stat changes")

func _on_stat_changed(stat_name: String, old_value: float, new_value: float) -> void:
	# Update when relevant stats change
	if stat_name in ["max_health", "max_mana", "health_regen_rate", "mana_regen_rate", "vitality", "intelligence", "wisdom", "level"]:
		on_stats_changed()

# Update health/mana values from stat sheet
func on_stats_changed() -> void:
	if not stat_sheet:
		return
	
	# Get new max values
	var new_max_health = stat_sheet.get_stat_value("max_health")
	var new_max_mana = stat_sheet.get_stat_value("max_mana")
	
	# Calculate percentage of current values
	var health_percent = current_health / max_health if max_health > 0 else 1.0
	var mana_percent = current_mana / max_mana if max_mana > 0 else 1.0
	
	# Update max values
	max_health = new_max_health
	max_mana = new_max_mana
	
	# Update regen rates
	health_regen_rate = stat_sheet.get_stat_value("health_regen_rate")
	mana_regen_rate = stat_sheet.get_stat_value("mana_regen_rate")
	
	# Maintain percentage when max values change (common for RPGs)
	# Or you can choose to add the difference to current values
	# For now, let's maintain percentage
	current_health = health_percent * max_health
	current_mana = mana_percent * max_mana
	
	# Ensure values are clamped properly
	current_health = clamp(current_health, 0, max_health)
	current_mana = clamp(current_mana, 0, max_mana)
	
	print("📊 HealthComponent updated from stats")
	print("❤️ Health: %.0f/%.0f (%.0f%%)" % [current_health, max_health, health_percent * 100])
	print("💙 Mana: %.0f/%.0f (%.0f%%)" % [current_mana, max_mana, mana_percent * 100])
	
	# Update GameManager if this is the player
	if owner_entity.is_in_group("players"):
		_update_game_manager()
		_emit_player_events()

# Always get current max health from stat sheet
func _get_current_max_health() -> float:
	if stat_sheet:
		return stat_sheet.get_stat_value("max_health")
	return max_health

# Always get current max mana from stat sheet
func _get_current_max_mana() -> float:
	if stat_sheet:
		return stat_sheet.get_stat_value("max_mana")
	return max_mana

# Take damage
func take_damage(amount: float) -> bool:
	if invincible or amount <= 0:
		return false
	
	# Check for dodge chance (vitality bonus)
	if stat_sheet and owner_entity.is_in_group("players"):
		var dodge_chance = stat_sheet.get_stat_value("dodge_chance")
		if randf() < dodge_chance:
			print("🏃 Dodge! (", dodge_chance * 100, "% chance from vitality)")
			return false  # Damage completely avoided
	
	var old_health = current_health
	current_health = max(0, current_health - amount)
	var damage_taken = old_health - current_health
	
	if damage_taken > 0:
		# Trigger damage flash
		_trigger_damage_flash()
		
		# Update GameManager if this is the player
		if owner_entity.is_in_group("players"):
			_update_game_manager()
			_emit_player_events()
		
		# Check for death
		if current_health <= 0:
			_handle_death()
		
		UnifiedDebugSystem.log_info(UnifiedDebugSystem.LogCategory.GENERAL,
			"%s took %.0f damage. Health: %.0f/%.0f" % [owner_entity.name, damage_taken, current_health, max_health], "HealthComponent")
	
	return damage_taken > 0

# Heal
func heal(amount: float) -> bool:
	if amount <= 0:
		return false
	
	var old_health = current_health
	var actual_max_health = _get_current_max_health()
	current_health = min(actual_max_health, current_health + amount)
	var healing_done = current_health - old_health
	
	if healing_done > 0:
		# Update GameManager if this is the player
		if owner_entity.is_in_group("players"):
			_update_game_manager()
			_emit_player_events()
		
		# Only log significant healing
		if healing_done > 1.0:
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER,
				"%s healed %.0f. Health: %.0f/%.0f" % [owner_entity.name, healing_done, current_health, actual_max_health], "HealthComponent")
	
	return healing_done > 0

# Consume mana
func consume_mana(amount: float) -> bool:
	if infinite_mana_enabled or amount <= 0:
		return true
	
	if current_mana < amount:
		return false  # Not enough mana
	
	current_mana -= amount
	
	# Update GameManager if this is the player
	if owner_entity.is_in_group("players"):
		_update_game_manager()
		_emit_player_events()
	
	UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER,
		"Consumed %.0f mana. Mana: %.0f/%.0f" % [amount, current_mana, _get_current_max_mana()], "HealthComponent")
	
	return true

# Restore mana
func restore_mana(amount: float) -> bool:
	if amount <= 0:
		return false
	
	var old_mana = current_mana
	var live_max_mana = _get_current_max_mana()
	current_mana = min(live_max_mana, current_mana + amount)
	var mana_restored = current_mana - old_mana
	
	if mana_restored > 0:
		# Update GameManager if this is the player
		if owner_entity.is_in_group("players"):
			_update_game_manager()
			_emit_player_events()
		
		# Only log significant mana restoration
		if mana_restored > 1.0:
			UnifiedDebugSystem.log_debug(UnifiedDebugSystem.LogCategory.PLAYER,
				"%s restored %.0f mana. Mana: %.0f/%.0f" % [owner_entity.name, mana_restored, current_mana, live_max_mana], "HealthComponent")
	
	return mana_restored > 0

# Regenerate health
func _regenerate_health() -> void:
	var live_max_health = _get_current_max_health()
	if current_health < live_max_health:
		var regen_amount = health_regen_rate * health_regen_timer.wait_time
		heal(regen_amount)

# Regenerate mana
func _regenerate_mana() -> void:
	var live_max_mana = _get_current_max_mana()
	if current_mana < live_max_mana:
		var regen_amount = mana_regen_rate * mana_regen_timer.wait_time
		restore_mana(regen_amount)

# Update GameManager values
func _update_game_manager() -> void:
	if GameManager:
		GameManager.player_health = current_health
		GameManager.player_max_health = _get_current_max_health()
		GameManager.player_mana = current_mana
		GameManager.player_max_mana = _get_current_max_mana()

# Emit events for UI updates
func _emit_player_events() -> void:
	if GameEvents:
		var actual_max_health = _get_current_max_health()
		var actual_max_mana = _get_current_max_mana()
		
		# Ensure current values don't exceed max (fixes overflow error)
		current_health = min(current_health, actual_max_health)
		current_mana = min(current_mana, actual_max_mana)
		
		GameEvents.emit_player_health_changed(current_health, actual_max_health)
		GameEvents.emit_player_mana_changed(current_mana, actual_max_mana)

# Handle death
func _handle_death() -> void:
	print("💀 ", owner_entity.name, " has died!")
	
	# Emit death event
	if GameEvents:
		if owner_entity.is_in_group("enemies"):
			var xp_value = owner_entity.xp_value if "xp_value" in owner_entity else 10
			var enemy_type = owner_entity.enemy_type if "enemy_type" in owner_entity else "unknown"
			GameEvents.emit_enemy_died(enemy_type, xp_value)
			# Queue enemy for deletion
			owner_entity.queue_free()
		elif owner_entity.is_in_group("players"):
			GameEvents.emit_player_died()
			# Don't delete the player - just disable them
			_disable_dead_player()
	else:
		# Default: queue for deletion
		owner_entity.queue_free()

func _disable_dead_player() -> void:
	# Disable player instead of deleting when dead
	if owner_entity.has_method("set_physics_process"):
		owner_entity.set_physics_process(false)
	if owner_entity.has_method("set_process"):
		owner_entity.set_process(false)
	
	# Hide player or play death animation
	if owner_entity.has_node("Sprite2D"):
		var sprite = owner_entity.get_node("Sprite2D")
		sprite.modulate.a = 0.5  # Make semi-transparent
	
	# Disable collision
	if owner_entity.has_node("CollisionShape2D"):
		var collision = owner_entity.get_node("CollisionShape2D")
		collision.set_deferred("disabled", true)
	
	print("⚰️ Player disabled but not deleted - can be revived")

# Trigger damage flash effect
func _trigger_damage_flash() -> void:
	if is_flashing:
		return
	
	is_flashing = true
	
	# Flash the sprite red
	var sprite = owner_entity.get_node_or_null("AnimatedSprite2D")
	if not sprite:
		sprite = owner_entity.get_node_or_null("Sprite2D")
	
	if sprite:
		sprite.modulate = Color.RED
		
		# Create timer to reset color
		await get_tree().create_timer(damage_flash_duration).timeout
		sprite.modulate = Color.WHITE
	
	is_flashing = false

# Set health to full
func set_full_health() -> void:
	current_health = _get_current_max_health()
	if owner_entity.is_in_group("players"):
		_update_game_manager()
		_emit_player_events()

# Set mana to full
func set_full_mana() -> void:
	current_mana = _get_current_max_mana()
	if owner_entity.is_in_group("players"):
		_update_game_manager()
		_emit_player_events()

# Get health percentage
func get_health_percentage() -> float:
	var actual_max_health = _get_current_max_health()
	return current_health / actual_max_health if actual_max_health > 0 else 0.0

# Get mana percentage
func get_mana_percentage() -> float:
	var actual_max_mana = _get_current_max_mana()
	return current_mana / actual_max_mana if actual_max_mana > 0 else 0.0

# Debug info
func get_debug_info() -> String:
	return """HealthComponent Debug:
Health: %.0f/%.0f (%.1f%%)
Mana: %.0f/%.0f (%.1f%%)
Health Regen: %.1f/s
Mana Regen: %.1f/s
Invincible: %s
Infinite Mana: %s""" % [
		current_health, _get_current_max_health(), get_health_percentage() * 100,
		current_mana, _get_current_max_mana(), get_mana_percentage() * 100,
		health_regen_rate, mana_regen_rate,
		"Yes" if invincible else "No",
		"Yes" if infinite_mana_enabled else "No"
	]
