# TestSaveSystemValidation.gd
# Quick test to validate save system classes are available

extends Node

func _ready():
	print("🧪 Testing Save System Class Availability...")
	
	# Test SaveData class
	print("Testing SaveData class...")
	if ClassDB.class_exists("SaveData"):
		print("✅ SaveData class found")
		var save_data = SaveData.new()
		if save_data:
			print("✅ SaveData can be instantiated")
			save_data.character_name = "Test Wizard"
			print("✅ SaveData properties work: ", save_data.character_name)
		else:
			print("❌ SaveData instantiation failed")
	else:
		print("❌ SaveData class not found")
	
	# Test SaveDataValidator class  
	print("Testing SaveDataValidator class...")
	if ClassDB.class_exists("SaveDataValidator"):
		print("✅ SaveDataValidator class found")
		var validator = SaveDataValidator.new()
		if validator:
			print("✅ SaveDataValidator can be instantiated")
		else:
			print("❌ SaveDataValidator instantiation failed")
	else:
		print("❌ SaveDataValidator class not found")
	
	# Test SaveManager singleton
	print("Testing SaveManager singleton...")
	if SaveManager:
		print("✅ SaveManager singleton accessible")
		if SaveManager.has_method("create_new_save"):
			print("✅ SaveManager has create_new_save method")
		else:
			print("❌ SaveManager missing create_new_save method")
	else:
		print("❌ SaveManager singleton not accessible")
	
	print("🧪 Save System Class Test Complete")