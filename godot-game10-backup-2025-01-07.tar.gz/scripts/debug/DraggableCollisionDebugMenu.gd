# DraggableCollisionDebugMenu.gd
# Legacy file - no longer needed with UnifiedDebugSystem
# Kept for compatibility but functionality moved to UnifiedDebugSystem

extends Control
class_name DraggableCollisionDebugMenu

func _ready():
	print("DraggableCollisionDebugMenu - Legacy compatibility mode")
	queue_free()  # Remove self as no longer needed

func is_menu_open() -> bool:
	return false

func toggle_debug_menu():
	# Redirect to UnifiedDebugSystem
	if UnifiedDebugSystem:
		UnifiedDebugSystem.toggle_collision_debug()
	else:
		print("UnifiedDebugSystem not found - debug functionality unavailable")
