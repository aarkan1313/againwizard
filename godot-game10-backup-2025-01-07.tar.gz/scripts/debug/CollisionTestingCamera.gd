# CollisionTestingCamera.gd
# Movable camera for collision testing scene
extends Camera2D

@export var move_speed: float = 300.0
@export var zoom_speed: float = 0.1
@export var min_zoom: float = 0.3
@export var max_zoom: float = 3.0

func _ready():
	# Start with moderate zoom for good overview
	zoom = Vector2(0.8, 0.8)
	print("📹 Camera Controls:")
	print("  Arrow Keys/WASD: Move camera")
	print("  Mouse Wheel/+/-: Zoom in/out")
	print("  HOME: Reset camera position and zoom")

func _input(event):
	# Handle zoom
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_in()
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_out()
	
	# Handle zoom with keyboard
	elif event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_EQUAL:  # + key (regular and shift)
				zoom_in()
			KEY_MINUS:  # - key
				zoom_out()
			KEY_HOME:  # Reset camera
				reset_camera()

func _process(delta):
	var movement = Vector2.ZERO
	
	# Handle movement input
	if Input.is_action_pressed("ui_right") or Input.is_key_pressed(KEY_D):
		movement.x += 1
	if Input.is_action_pressed("ui_left") or Input.is_key_pressed(KEY_A):
		movement.x -= 1
	if Input.is_action_pressed("ui_down") or Input.is_key_pressed(KEY_S):
		movement.y += 1
	if Input.is_action_pressed("ui_up") or Input.is_key_pressed(KEY_W):
		movement.y -= 1
	
	# Apply movement (adjust for zoom level)
	if movement != Vector2.ZERO:
		position += movement.normalized() * move_speed * delta / zoom.x

func zoom_in():
	var new_zoom = zoom.x + zoom_speed
	if new_zoom <= max_zoom:
		zoom = Vector2(new_zoom, new_zoom)

func zoom_out():
	var new_zoom = zoom.x - zoom_speed
	if new_zoom >= min_zoom:
		zoom = Vector2(new_zoom, new_zoom)

func reset_camera():
	position = Vector2(512, 300)
	zoom = Vector2(0.8, 0.8)
	print("📹 Camera reset to center")
