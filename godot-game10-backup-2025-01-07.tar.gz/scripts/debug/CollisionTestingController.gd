# CollisionTestingController.gd
# Purpose: Controller for collision testing scene with stationary enemies
# Allows visual adjustment of collision shapes without movement interference
extends Node

@export var enemy_scene: PackedScene
@export var spawn_distance: float = 150.0
@export var grid_spacing: float = 400.0

var spawned_enemies: Array[Node] = []
var current_selected_enemy: Node
var collision_tuner: Node
var visualization_enabled: bool = false
var ui_panel: CanvasLayer

# Entity testing framework
var entity_framework: EntityTestingFramework

# Current entity types to test (easily extensible)
var entity_types: Array[String] = []

# Collision shape types
enum CollisionShapeType {
	CIRCLE,
	RECTANGLE,
	POLYGON
}

var current_shape_type: CollisionShapeType = CollisionShapeType.CIRCLE
var shape_type_names = ["Circle", "Rectangle", "Polygon"]

func _ready():
	print("🔧 Collision Testing Scene Initialized with UI Panel")
	print("📋 Press TAB to toggle UI controls panel")
	
	# Load enemy scene
	if not enemy_scene:
		enemy_scene = load("res://scenes/Enemy.tscn")
	
	# Initialize entity testing framework
	entity_framework = EntityTestingFramework.new()
	add_child(entity_framework)
	entity_types = entity_framework.get_all_entity_types()
	
	# Initialize collision tuner
	collision_tuner = Node.new()
	collision_tuner.set_script(load("res://scripts/debug/CollisionTuner.gd"))
	add_child(collision_tuner)
	
	# Initialize UI panel (defer to avoid setup conflicts)
	call_deferred("setup_ui_panel")
	
	print("📋 Available entity types: %s" % str(entity_types))
	print("📋 Controls now available in UI panel (TAB to toggle)")
	
	# Auto-spawn entities on start
	call_deferred("spawn_all_entities")

func _input(event):
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_SPACE:
				spawn_all_entities()
			KEY_R:
				reset_scene()
			KEY_V:
				toggle_collision_visualization()
			KEY_1:
				select_entity_by_index(0)
			KEY_2:
				select_entity_by_index(1)
			KEY_3:
				select_entity_by_index(2)
			KEY_4:
				select_entity_by_index(3)
			KEY_5:
				select_entity_by_index(4)
			KEY_6:
				select_entity_by_index(5)
			KEY_7:
				select_entity_by_index(6)
			KEY_8:
				select_entity_by_index(7)
			KEY_9:
				select_entity_by_index(8)
			KEY_0:
				select_entity_by_index(9)
			KEY_F:
				toggle_selected_enemy_freeze()
			KEY_P:
				print_selected_enemy_values()
			KEY_T:
				toggle_collision_shape_type()
			KEY_G:
				generate_polygon_from_sprite()

func spawn_all_entities():
	"""Spawn all registered entity types in a grid layout"""
	reset_scene()
	
	print("🎯 Spawning all entity types for collision testing...")
	
	var center_position = Vector2(512, 300)
	var max_entities = entity_types.size()
	
	# Dynamic grid positioning based on number of entities
	var grid_cols = ceil(sqrt(max_entities))
	var grid_rows = ceil(max_entities / grid_cols)
	
	for i in range(max_entities):
		var entity_type = entity_types[i]
		var col = i % int(grid_cols)
		var row = i / int(grid_cols)
		
		var spawn_pos = center_position + Vector2(
			(col - grid_cols/2 + 0.5) * grid_spacing,
			(row - grid_rows/2 + 0.5) * grid_spacing
		)
		
		spawn_entity_at_position(entity_type, spawn_pos)
	
	print("✅ Spawned %d entities for testing" % spawned_enemies.size())
	
	# Auto-enable visualization
	if not visualization_enabled:
		toggle_collision_visualization()

func spawn_entity_at_position(entity_type: String, position: Vector2) -> Node:
	"""Spawn specific entity type at position using extensible framework"""
	var entity_instance = entity_framework.spawn_entity(entity_type, position, get_tree().current_scene)
	
	if not entity_instance:
		print("❌ Failed to spawn entity: %s" % entity_type)
		return null
	
	# Freeze entity by default for collision testing
	freeze_enemy(entity_instance)
	
	# Add to tracking list
	spawned_enemies.append(entity_instance)
	
	# Add label above entity
	add_entity_label(entity_instance, entity_type)
	
	print("✅ Spawned %s at %s" % [entity_type, position])
	return entity_instance

func freeze_enemy(enemy: Node):
	"""Freeze enemy movement and AI without breaking the system"""
	if not enemy:
		return
	
	# Disable AI controller if it exists
	if "ai_controller" in enemy and enemy.ai_controller:
		enemy.ai_controller.set_process(false)
		enemy.ai_controller.set_physics_process(false)
	
	# Stop physics processing for movement
	if enemy.has_method("set_physics_process"):
		enemy.set_physics_process(false)
	
	# Clear velocity if entity has it
	if "velocity" in enemy:
		enemy.velocity = Vector2.ZERO
	
	# Mark as frozen (custom property)
	enemy.set_meta("collision_test_frozen", true)

func unfreeze_enemy(enemy: Node):
	"""Unfreeze enemy movement and AI"""
	if not enemy:
		return
	
	# Re-enable AI controller if it exists
	if "ai_controller" in enemy and enemy.ai_controller:
		enemy.ai_controller.set_process(true)
		enemy.ai_controller.set_physics_process(true)
	
	# Re-enable physics processing
	if enemy.has_method("set_physics_process"):
		enemy.set_physics_process(true)
	
	# Remove frozen marker
	enemy.remove_meta("collision_test_frozen")

func add_entity_label(entity: Node, entity_type: String):
	"""Add label above entity showing its type"""
	var config = entity_framework.get_entity_config(entity_type)
	var display_name = config.entity_name if config else entity_type.to_upper()
	
	var label = Label.new()
	label.text = display_name
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_color_override("font_shadow_color", Color.BLACK)
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 1)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.position = Vector2(-30, -80)
	entity.add_child(label)

func reset_scene():
	"""Clear all spawned enemies"""
	for enemy in spawned_enemies:
		if is_instance_valid(enemy):
			enemy.queue_free()
	
	spawned_enemies.clear()
	current_selected_enemy = null
	print("🔄 Scene reset - all enemies cleared")

func toggle_collision_visualization():
	"""Toggle collision visualization for all enemies"""
	visualization_enabled = !visualization_enabled
	
	for enemy in spawned_enemies:
		if is_instance_valid(enemy):
			toggle_enemy_visualization(enemy)
	
	print("🔍 Collision visualization: %s" % ("ON" if visualization_enabled else "OFF"))

func toggle_enemy_visualization(enemy: Enemy):
	"""Toggle visualization for specific enemy"""
	var existing_visualizer = enemy.get_node_or_null("CollisionVisualizer")
	
	if visualization_enabled and not existing_visualizer:
		# Create visualizer
		var visualizer = Node2D.new()
		visualizer.name = "CollisionVisualizer"
		visualizer.set_script(load("res://scripts/debug/CollisionVisualizer.gd"))
		enemy.add_child(visualizer)
		visualizer.setup(enemy)
	elif not visualization_enabled and existing_visualizer:
		# Remove visualizer
		existing_visualizer.queue_free()

func select_entity_by_index(index: int):
	"""Select entity by index for collision tuning"""
	if index >= entity_types.size():
		print("❌ Invalid entity index: %d. Available: 0-%d" % [index, entity_types.size() - 1])
		return
	
	var entity_type = entity_types[index]
	select_entity_by_type(entity_type)

func select_entity_by_type(entity_type: String):
	"""Select entity by type for collision tuning"""
	var target_entity = null
	
	for entity in spawned_enemies:
		if is_instance_valid(entity):
			# Check entity type - works for enemies and other entities
			var entity_type_prop = null
			
			# Try different property names that entities might use
			if "enemy_type" in entity:
				entity_type_prop = entity.enemy_type
			elif "entity_type" in entity:
				entity_type_prop = entity.entity_type
			elif "projectile_type" in entity:
				entity_type_prop = entity.projectile_type
			
			if entity_type_prop == entity_type:
				target_entity = entity
				break
	
	if target_entity:
		select_enemy_for_tuning(target_entity)
	else:
		print("❌ No %s entity found. Press SPACE to spawn entities first." % entity_type)

func select_enemy_for_tuning(enemy: Node):
	"""Select specific enemy for collision tuning"""
	current_selected_enemy = enemy
	
	if collision_tuner and collision_tuner.has_method("select_enemy"):
		collision_tuner.select_enemy(enemy)
	
	# Update UI panel
	if ui_panel and ui_panel.has_method("on_enemy_selected"):
		ui_panel.on_enemy_selected()
	
	print("🎯 Selected %s for collision tuning" % get_entity_type(enemy).to_upper())
	print("  Size: Q/E=Main, Z/C=Damage | Position: SHIFT+IJKL=Main, IJKL=Damage")

func toggle_selected_enemy_freeze():
	"""Toggle freeze state of selected enemy"""
	if not current_selected_enemy:
		print("❌ No enemy selected. Use 1-5 to select an enemy.")
		return
	
	var is_frozen = current_selected_enemy.has_meta("collision_test_frozen")
	
	if is_frozen:
		unfreeze_enemy(current_selected_enemy)
		print("🟢 %s unfrozen - AI and movement enabled" % get_entity_type(current_selected_enemy))
	else:
		freeze_enemy(current_selected_enemy)
		print("🔴 %s frozen - AI and movement disabled" % get_entity_type(current_selected_enemy))

func print_all_collision_values():
	"""Print collision values for all spawned enemies"""
	print("=== CURRENT COLLISION VALUES ===")
	
	for enemy in spawned_enemies:
		if is_instance_valid(enemy) and "enemy_data" in enemy and enemy.enemy_data:
			print("%s: collision=%s, damage_area=%s" % [
				get_entity_type(enemy).to_upper(),
				enemy.enemy_data.collision_radius,
				enemy.enemy_data.damage_area_radius
			])
	
	print("Copy these values to the corresponding .tres files in data/enemies/")

func toggle_collision_shape_type():
	"""Toggle between circle, rectangle, and polygon collision shapes"""
	current_shape_type = (current_shape_type + 1) % CollisionShapeType.size()
	var shape_name = shape_type_names[current_shape_type]
	
	print("🔧 Switched to %s collision shapes" % shape_name)
	
	# Update all enemies to use new shape type
	for enemy in spawned_enemies:
		if is_instance_valid(enemy):
			apply_collision_shape_type(enemy)
	
	# Update visualization
	if visualization_enabled:
		toggle_collision_visualization()
		toggle_collision_visualization()

func apply_collision_shape_type(enemy: Node):
	"""Apply current collision shape type to enemy"""
	if not enemy or not ("enemy_data" in enemy) or not enemy.enemy_data:
		return
	
	var main_collision = enemy.get_node_or_null("EnemyCollision")
	var damage_collision = enemy.get_node_or_null("DamageArea/DamageAreaCollision")
	
	match current_shape_type:
		CollisionShapeType.CIRCLE:
			apply_circle_shape(main_collision, enemy.enemy_data.collision_radius)
			apply_circle_shape(damage_collision, enemy.enemy_data.damage_area_radius)
		
		CollisionShapeType.RECTANGLE:
			apply_rectangle_shape(main_collision, enemy.enemy_data.collision_radius)
			apply_rectangle_shape(damage_collision, enemy.enemy_data.damage_area_radius)
		
		CollisionShapeType.POLYGON:
			apply_polygon_shape(main_collision, enemy)
			apply_polygon_shape(damage_collision, enemy, true)

func apply_circle_shape(collision_node: CollisionShape2D, radius: float):
	"""Apply circle collision shape"""
	if not collision_node:
		return
	
	var circle_shape = CircleShape2D.new()
	circle_shape.radius = radius
	collision_node.shape = circle_shape

func apply_rectangle_shape(collision_node: CollisionShape2D, size: float):
	"""Apply rectangle collision shape"""
	if not collision_node:
		return
	
	var rect_shape = RectangleShape2D.new()
	# Make rectangle proportional to the sprite
	rect_shape.size = Vector2(size * 1.4, size * 1.8)  # Typical humanoid proportions
	collision_node.shape = rect_shape

func apply_polygon_shape(collision_node: CollisionShape2D, enemy: Node, is_damage_area: bool = false):
	"""Apply polygon collision shape based on sprite contours"""
	if not collision_node or not enemy:
		return
	
	var sprite = enemy.get_node_or_null("EnemySprite")
	if not sprite or not sprite.texture:
		# Fallback to circle if no sprite
		var fallback_radius = enemy.enemy_data.collision_radius if not is_damage_area else enemy.enemy_data.damage_area_radius
		apply_circle_shape(collision_node, fallback_radius)
		return
	
	# Create a basic polygon approximating the sprite shape
	var polygon_shape = ConvexPolygonShape2D.new()
	var entity_type = get_entity_type(enemy)
	var points = entity_framework.get_enemy_polygon_points(entity_type, is_damage_area)
	polygon_shape.points = points
	collision_node.shape = polygon_shape


func generate_polygon_from_sprite():
	"""Generate polygon collision from selected enemy's sprite data"""
	if not current_selected_enemy:
		print("❌ No enemy selected. Use 1-5 to select an enemy first.")
		return
	
	var entity_type = get_entity_type(current_selected_enemy)
	print("🔧 Generating polygon collision from %s sprite..." % entity_type)
	
	# Force polygon shape type
	current_shape_type = CollisionShapeType.POLYGON
	apply_collision_shape_type(current_selected_enemy)
	
	# Update visualization
	if visualization_enabled:
		toggle_enemy_visualization(current_selected_enemy)
		toggle_enemy_visualization(current_selected_enemy)
	
	print("✅ Generated polygon collision for %s" % entity_type)

func get_entity_type(entity: Node) -> String:
	"""Get entity type from any entity safely"""
	if not entity:
		return "unknown"
	
	if "enemy_type" in entity:
		return entity.enemy_type
	elif "entity_type" in entity:
		return entity.entity_type
	elif "projectile_type" in entity:
		return entity.projectile_type
	else:
		return "unknown"

func setup_ui_panel():
	"""Initialize and setup the UI panel"""
	var ui_script = load("res://scripts/debug/CollisionTestingUI.gd")
	ui_panel = CanvasLayer.new()
	ui_panel.set_script(ui_script)
	ui_panel.name = "CollisionTestingUI"
	
	# Use call_deferred to avoid parent setup conflicts
	get_tree().current_scene.call_deferred("add_child", ui_panel)
	
	# Connect UI to controller (also defer to ensure UI is ready)
	call_deferred("_connect_ui_panel")

func _connect_ui_panel():
	"""Connect UI panel after it's properly added to scene"""
	if ui_panel and ui_panel.has_method("set_controller"):
		ui_panel.set_controller(self)
	
	# Connect collision tuner to UI
	if collision_tuner and collision_tuner.has_method("set_ui_panel"):
		collision_tuner.set_ui_panel(ui_panel)

func print_selected_enemy_values():
	"""Print collision values for currently selected enemy only"""
	if collision_tuner and collision_tuner.has_method("print_selected_enemy_values"):
		collision_tuner.print_selected_enemy_values()
	else:
		print("❌ No collision tuner available")

func get_current_shape_name() -> String:
	"""Get current shape type name for UI display"""
	return shape_type_names[current_shape_type]

func _on_scene_changed():
	"""Clean up when leaving the scene"""
	reset_scene()
