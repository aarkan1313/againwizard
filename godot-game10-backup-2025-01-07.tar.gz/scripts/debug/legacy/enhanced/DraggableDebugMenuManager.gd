# DraggableDebugMenuManager.gd
# Main debug menu manager (F1 key)

extends Node

var debug_menu_instance = null
var debug_enabled: bool = true

func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	print("🔧 DebugMenuManager initialized - Press F1 for debug menu")

func _input(event):
	if not event is InputEventKey or not event.pressed:
		return
	
	# F1 toggles main debug menu
	if event.keycode == KEY_F1 and not event.shift_pressed:
		print("🔧 DebugMenuManager: F1 pressed, toggling debug menu")
		toggle_debug_menu()
		get_viewport().set_input_as_handled()

func toggle_debug_menu():
	if not debug_enabled:
		return
	
	if not debug_menu_instance or not is_instance_valid(debug_menu_instance):
		_create_debug_menu()
	
	if debug_menu_instance:
		debug_menu_instance.visible = !debug_menu_instance.visible

func _create_debug_menu():
	var DebugMenuScene = load("res://scenes/debug/DebugMenu.tscn")
	if DebugMenuScene:
		debug_menu_instance = DebugMenuScene.instantiate()
		get_tree().root.add_child(debug_menu_instance)
		print("✅ Debug menu created")
	else:
		print("❌ Could not load DebugMenu.tscn")