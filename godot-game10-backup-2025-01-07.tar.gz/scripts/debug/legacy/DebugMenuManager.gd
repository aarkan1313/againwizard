# DebugMenuManager.gd
# Purpose: Singleton manager for collision debug menu system (Shift+F1)
# Godot Version: 4.4.1
# FIXED: Proper key handling, collision focus, visualizer cleanup

extends Node

# Debug menu instance
var debug_menu_instance: DraggableCollisionDebugMenu = null

# Debug flags
var debug_enabled: bool = true
var debug_commands_active: bool = false

func _ready():
	# Set process mode to work during pause
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	print("🔧 CollisionDebugManager initialized - Press Shift+F1 for collision debug menu")

func _input(event):
	if not event is InputEventKey or not event.pressed:
		return
	
	# Shift+F1 toggles collision debug menu (F1 alone is for main debug)
	if event.keycode == KEY_F1 and event.shift_pressed:
		print("🔧 CollisionDebugManager: Shift+F1 pressed, toggling collision debug menu")
		toggle_debug_menu()
		get_viewport().set_input_as_handled()

func toggle_debug_menu():
	if not debug_enabled:
		print("🔧 Collision debug menu disabled")
		return
	
	# Check if instance exists and is still valid
	if not debug_menu_instance or not is_instance_valid(debug_menu_instance):
		debug_menu_instance = null
		_create_debug_menu_instance()
	
	if debug_menu_instance:
		# Always sync with the actual menu state before toggling
		debug_commands_active = debug_menu_instance.is_menu_open()
		debug_menu_instance.toggle_debug_menu()
		# Update our state after the toggle
		debug_commands_active = debug_menu_instance.is_menu_open()
		print("🔧 CollisionDebugManager: Menu is now %s" % ("OPEN" if debug_commands_active else "CLOSED"))

func _create_debug_menu_instance():
	print("🔧 Creating DraggableCollisionDebugMenu...")
	
	# Create the draggable collision debug menu directly
	debug_menu_instance = DraggableCollisionDebugMenu.new()
	
	if debug_menu_instance:
		# Add to root for proper window management
		get_tree().root.add_child(debug_menu_instance)
		print("✅ DraggableCollisionDebugMenu instance created")
		
		# Clean up any existing collision visualizers to prevent duplicates
		_cleanup_existing_visualizers()
	else:
		print("❌ Failed to create DraggableCollisionDebugMenu")

func _cleanup_existing_visualizers():
	# Clean up any existing collision visualizers to prevent multiple hitboxes
	print("🔧 Cleaning up existing collision visualizers...")
	
	var visualizers = get_tree().get_nodes_in_group("collision_visualizers")
	var cleaned_count = 0
	
	for visualizer in visualizers:
		if is_instance_valid(visualizer):
			if visualizer.has_method("cleanup"):
				visualizer.cleanup()
			else:
				visualizer.queue_free()
			cleaned_count += 1
	
	if cleaned_count > 0:
		print("✅ Cleaned up %d existing visualizers" % cleaned_count)
		# Wait a frame for cleanup to complete
		await get_tree().process_frame

# Public API for other systems
func is_debug_menu_open() -> bool:
	return debug_menu_instance != null and is_instance_valid(debug_menu_instance) and debug_menu_instance.is_menu_open()

func are_debug_commands_active() -> bool:
	return debug_commands_active

func close_debug_menu():
	if debug_menu_instance and is_instance_valid(debug_menu_instance) and debug_menu_instance.is_menu_open():
		debug_menu_instance.toggle_debug_menu()

func enable_debug_menu(enabled: bool = true):
	debug_enabled = enabled
	print("🔧 Collision debug menu %s" % ("enabled" if enabled else "disabled"))

# Collision-specific helper functions
func get_collision_controller() -> Node:
	# Get the active collision testing controller
	var scene_name = get_tree().current_scene.name if get_tree().current_scene else ""
	if scene_name == "CollisionTestingScene":
		return get_tree().current_scene
	return null

func cleanup_all_collision_visualizers():
	# Force cleanup of all collision visualizers - fixes multiple hitboxes
	print("🔧 Force cleaning all collision visualizers...")
	
	var visualizers = get_tree().get_nodes_in_group("collision_visualizers")
	var controller = get_collision_controller()
	
	# First, clean up visualizers
	for visualizer in visualizers:
		if is_instance_valid(visualizer):
			if visualizer.has_method("cleanup"):
				visualizer.cleanup()
			visualizer.queue_free()
	
	# Clear tracking in controller if available
	if controller and "active_visualizers" in controller:
		controller.active_visualizers.clear()
		print("✅ Cleared controller visualizer tracking")
	
	print("✅ Force cleanup completed - multiple hitboxes should be resolved")

func refresh_collision_visualization():
	# Refresh collision visualization - proper way to fix multiple hitboxes
	var controller = get_collision_controller()
	if not controller:
		print("❌ No collision controller available for refresh")
		return
	
	print("🔧 Refreshing collision visualization...")
	
	# Use controller's built-in cleanup and refresh methods
	if controller.has_method("cleanup_all_visualizers"):
		controller.cleanup_all_visualizers()
	
	await get_tree().process_frame
	
	if controller.has_method("refresh_all_visualizations"):
		controller.refresh_all_visualizations()
	
	print("✅ Collision visualization refreshed")

# Utility functions for collision debugging
func log_collision_debug(message: String):
	print("🎯 [COLLISION DEBUG] %s" % message)

func get_collision_info() -> Dictionary:
	var info = {}
	var controller = get_collision_controller()
	
	if controller:
		info["controller_available"] = true
		info["scene_type"] = "CollisionTestingScene"
		
		if "spawned_enemies" in controller:
			info["spawned_enemies"] = controller.spawned_enemies.size()
		
		if "current_selected_enemy" in controller and controller.current_selected_enemy:
			var selected = controller.current_selected_enemy
			info["selected_enemy"] = selected.enemy_type if "enemy_type" in selected else "Unknown"
		
		if "visualization_enabled" in controller:
			info["visualization_enabled"] = controller.visualization_enabled
	else:
		info["controller_available"] = false
		info["scene_type"] = get_tree().current_scene.name if get_tree().current_scene else "Unknown"
	
	# Count active visualizers
	var visualizers = get_tree().get_nodes_in_group("collision_visualizers")
	info["active_visualizers"] = visualizers.size()
	
	return info
