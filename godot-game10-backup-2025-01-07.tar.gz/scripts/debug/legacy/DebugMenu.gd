# DebugMenu.gd
# Purpose: Comprehensive debug interface for development and testing
# Godot Version: 4.4.1 (verified via official docs)
# Dependencies: GameEvents, GameManager, InputHandler (when available)

extends Control
class_name DebugMenu

# UI References - will be created programmatically
var debug_panel: Panel
var title_label: Label
var close_button: Button
var tab_container: TabContainer

# Tab references
var system_tab: Control
var player_tab: Control
var spells_tab: Control
var testing_tab: Control

# Status displays
var fps_label: Label
var memory_label: Label
var player_status_label: Label
var spell_status_label: Label

# Testing buttons (will be created programmatically)
var run_tests_button: Button
var validate_button: Button
var infra_tests_button: Button
var results_label: Label

# Commands list with scrolling
var commands_scroll: ScrollContainer
var commands_container: VBoxContainer

# Debug state
var is_debug_menu_open: bool = false
var debug_commands: Dictionary = {}
var update_timer: Timer

func _ready():
	# Set process mode to work during pause
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	# Create UI programmatically
	_create_debug_ui()
	
	# Hide initially
	visible = false
	is_debug_menu_open = false
	
	# Setup UI
	_setup_debug_interface()
	_register_debug_commands()
	
	# Create update timer
	update_timer = Timer.new()
	add_child(update_timer)
	update_timer.wait_time = 0.1  # Update 10 times per second
	update_timer.timeout.connect(_update_debug_displays)
	update_timer.start()
	
	# Connect close button
	if close_button:
		close_button.pressed.connect(_close_debug_menu)
	
	# Connect testing buttons
	if run_tests_button:
		run_tests_button.pressed.connect(_debug_run_tests)
	if validate_button:
		validate_button.pressed.connect(_debug_validate_systems)
	if infra_tests_button:
		infra_tests_button.pressed.connect(_debug_run_infrastructure_only)

func _create_debug_ui():
	# Create main debug panel
	debug_panel = Panel.new()
	debug_panel.name = "DebugPanel"
	debug_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	debug_panel.size = Vector2(800, 600)
	debug_panel.modulate.a = 0.95
	add_child(debug_panel)
	
	# Create main VBox
	var main_vbox = VBoxContainer.new()
	main_vbox.name = "VBox"
	main_vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	debug_panel.add_child(main_vbox)
	
	# Create title bar
	var title_bar = HBoxContainer.new()
	title_bar.name = "TitleBar"
	main_vbox.add_child(title_bar)
	
	title_label = Label.new()
	title_label.name = "Title"
	title_label.text = "Debug Menu"
	title_label.add_theme_font_size_override("font_size", 18)
	title_bar.add_child(title_label)
	
	# Add spacer
	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_bar.add_child(spacer)
	
	close_button = Button.new()
	close_button.name = "CloseButton"
	close_button.text = "X"
	close_button.custom_minimum_size = Vector2(30, 30)
	title_bar.add_child(close_button)
	
	# Create content area
	var content = VBoxContainer.new()
	content.name = "Content"
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(content)
	
	# Create tab container
	tab_container = TabContainer.new()
	tab_container.name = "TabContainer"
	tab_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(tab_container)
	
	# Create tabs
	_create_system_tab()
	_create_player_tab()
	_create_spells_tab()
	_create_testing_tab()
	
	# Create commands scroll area
	var command_list = VBoxContainer.new()
	command_list.name = "CommandList"
	content.add_child(command_list)
	
	commands_scroll = ScrollContainer.new()
	commands_scroll.name = "ScrollContainer"
	commands_scroll.custom_minimum_size = Vector2(0, 100)
	command_list.add_child(commands_scroll)
	
	commands_container = VBoxContainer.new()
	commands_container.name = "CommandsContainer"
	commands_scroll.add_child(commands_container)

func _create_system_tab():
	system_tab = Control.new()
	system_tab.name = "System"
	tab_container.add_child(system_tab)
	
	var system_info = VBoxContainer.new()
	system_info.name = "SystemInfo"
	system_tab.add_child(system_info)
	
	fps_label = Label.new()
	fps_label.name = "FPSLabel"
	fps_label.text = "FPS: 60"
	system_info.add_child(fps_label)
	
	memory_label = Label.new()
	memory_label.name = "MemoryLabel"
	memory_label.text = "Memory: 0 MB"
	system_info.add_child(memory_label)

func _create_player_tab():
	player_tab = Control.new()
	player_tab.name = "Player"
	tab_container.add_child(player_tab)
	
	var player_info = VBoxContainer.new()
	player_info.name = "PlayerInfo"
	player_tab.add_child(player_info)
	
	player_status_label = Label.new()
	player_status_label.name = "StatusLabel"
	player_status_label.text = "Player Status: Loading..."
	player_info.add_child(player_status_label)

func _create_spells_tab():
	spells_tab = Control.new()
	spells_tab.name = "Spells"
	tab_container.add_child(spells_tab)
	
	var spell_info = VBoxContainer.new()
	spell_info.name = "SpellInfo"
	spells_tab.add_child(spell_info)
	
	spell_status_label = Label.new()
	spell_status_label.name = "StatusLabel"
	spell_status_label.text = "Spell Status: Loading..."
	spell_info.add_child(spell_status_label)

func _create_testing_tab():
	testing_tab = Control.new()
	testing_tab.name = "Testing"
	tab_container.add_child(testing_tab)
	
	var test_info = VBoxContainer.new()
	test_info.name = "TestInfo"
	testing_tab.add_child(test_info)
	
	# Create test buttons
	var test_buttons = HBoxContainer.new()
	test_buttons.name = "TestButtons"
	test_info.add_child(test_buttons)
	
	run_tests_button = Button.new()
	run_tests_button.name = "RunTestsButton"
	run_tests_button.text = "Run Tests"
	test_buttons.add_child(run_tests_button)
	
	validate_button = Button.new()
	validate_button.name = "ValidateButton"
	validate_button.text = "Validate"
	test_buttons.add_child(validate_button)
	
	infra_tests_button = Button.new()
	infra_tests_button.name = "InfraTestsButton"
	infra_tests_button.text = "Infra Tests"
	test_buttons.add_child(infra_tests_button)
	
	# Create results area
	var results_scroll = ScrollContainer.new()
	results_scroll.name = "ScrollContainer"
	results_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	test_info.add_child(results_scroll)
	
	results_label = Label.new()
	results_label.name = "ResultsLabel"
	results_label.text = "No tests run yet"
	results_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	results_scroll.add_child(results_label)
	
	print("🔧 Collision Debug Menu initialized - Press Shift+F1 to open")
	
	# Initialize collision tuning system
	_init_collision_tuning()

func _setup_debug_interface():
	# Set window properties - smaller size, top right position
	if debug_panel:
		debug_panel.size = Vector2(500, 400)
		# Position in top right corner with some margin
		var screen_size = get_viewport().get_visible_rect().size
		debug_panel.position = Vector2(screen_size.x - 520, 20)
	
	# Setup title
	if title_label:
		title_label.text = "Collision Debug Menu - Wizard RPG v0.2"
	
	# Setup tab labels
	if tab_container:
		tab_container.set_tab_title(0, "System")
		tab_container.set_tab_title(1, "Player") 
		tab_container.set_tab_title(2, "Spells")
		tab_container.set_tab_title(3, "Testing")
	
	# Populate commands list with correct IJKL text
	_populate_commands_list()

func _populate_commands_list():
	# Populate the scrollable commands list with correct control information
	if not commands_container:
		return
	
	# Clear existing commands
	for child in commands_container.get_children():
		child.queue_free()
	
	# Create sections
	_add_command_section("SYSTEM COMMANDS", [
		"F2 - Physics Debug",
		"F3 - Reset Game", 
		"F4 - Performance Test"
	])
	
	_add_command_section("PLAYER COMMANDS", [
		"F5 - Heal (+25 HP)",
		"F6 - Damage (-25 HP)",
		"F7 - Restore Mana",
		"F9 - God Mode"
	])
	
	_add_command_section("SPELL COMMANDS", [
		"F10 - Reset Cooldowns",
		"F12 - Test All Spells"
	])
	
	_add_command_section("COLLISION TUNING", [
		"F9 - Toggle Visualization",
		"F10 - Select Nearest Enemy",
		"Q/E - Adjust Main Size",
		"Z/C - Adjust Damage Size",
		"SHIFT+IJKL - Move Main",
		"IJKL - Move Damage Area",
		"P - Print Values",
		"V - Toggle for Selected"
	])
	
	_add_command_section("TESTING & VALIDATION", [
		"Use Testing tab buttons →",
		"F8/F11 reserved by Godot",
		"Infrastructure tests available",
		"System validation included"
	])

func _add_command_section(title: String, commands: Array[String]):
	# Add a section of commands to the scrollable list
	if not commands_container:
		return
	
	# Add section title
	var title_label = Label.new()
	title_label.text = title
	title_label.add_theme_color_override("font_color", Color.YELLOW)
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	commands_container.add_child(title_label)
	
	# Add commands
	for command in commands:
		var command_label = Label.new()
		command_label.text = "  " + command
		command_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		commands_container.add_child(command_label)
	
	# Add spacing
	var spacer = Control.new()
	spacer.custom_minimum_size = Vector2(0, 5)
	commands_container.add_child(spacer)

func _register_debug_commands():
	# System commands
	debug_commands["F2"] = {"name": "Toggle Physics Debug", "category": "System", "function": "_debug_toggle_physics"}
	debug_commands["F3"] = {"name": "Reset Game State", "category": "System", "function": "_debug_reset_game"}
	debug_commands["F4"] = {"name": "Performance Test", "category": "System", "function": "_debug_performance_test"}
	
	# Player commands (placeholders for future implementation)
	debug_commands["F5"] = {"name": "Heal Player", "category": "Player", "function": "_debug_heal_player"}
	debug_commands["F6"] = {"name": "Damage Player", "category": "Player", "function": "_debug_damage_player"}
	debug_commands["F7"] = {"name": "Restore Mana", "category": "Player", "function": "_debug_restore_mana"}
	debug_commands["F9"] = {"name": "Toggle God Mode", "category": "Player", "function": "_debug_toggle_god_mode"}
	
	# Spell commands (placeholders for future implementation)
	debug_commands["F10"] = {"name": "Reset Spell Cooldowns", "category": "Spells", "function": "_debug_reset_cooldowns"}
	debug_commands["F12"] = {"name": "Test All Spells", "category": "Spells", "function": "_debug_test_spells"}
	
	# Testing commands - Using mouse buttons/UI for testing since F8 and F11 are reserved by Godot
	# These will be triggered via UI buttons in the Testing tab instead of function keys

func _input(event):
	if not event is InputEventKey or not event.pressed:
		return
	
	# DebugMenuManager handles Shift+F1 - we only handle F2-F12 debug commands
	# Other debug commands only work when menu is open
	if not is_debug_menu_open:
		return
	
	# Handle debug commands F2-F12 (Shift+F1 is handled by DebugMenuManager)
	var key_name = _keycode_to_string(event.keycode)
	if key_name in debug_commands:
		_execute_debug_command(key_name)

func _toggle_debug_menu():
	var was_open = is_debug_menu_open
	is_debug_menu_open = !is_debug_menu_open
	visible = is_debug_menu_open
	
	print("🔧 DebugMenu._toggle_debug_menu(): " + str(was_open) + " → " + str(is_debug_menu_open))
	
	if is_debug_menu_open:
		print("🔧 Debug Menu OPENED - Commands active")
		_update_debug_displays()
	else:
		print("🔧 Debug Menu CLOSED - Commands inactive")

func _close_debug_menu():
	if is_debug_menu_open:
		is_debug_menu_open = false
		visible = false
		print("🔧 Debug Menu CLOSED via X button - Commands inactive")
		# Notify the manager that we're closed  
		if CollisionDebugManager:
			CollisionDebugManager.debug_commands_active = false
			print("🔧 CollisionDebugManager: Notified of close via X button")

func _execute_debug_command(key: String):
	var command = debug_commands[key]
	print("🔧 Executing debug command: " + command.name + " (" + key + ")")
	
	# Call the function if it exists
	if has_method(command.function):
		call(command.function)
	else:
		print("⚠️ Debug function not implemented: " + command.function)

func _update_debug_displays():
	if not is_debug_menu_open:
		return
	
	# Update system info
	_update_system_info()
	_update_player_info()
	_update_spell_info()
	_update_testing_info()

func _update_system_info():
	if not fps_label or not memory_label:
		return
	
	# FPS and performance
	var fps = Engine.get_frames_per_second()
	var frame_time = 1000.0 / max(fps, 1)
	fps_label.text = "FPS: " + str(fps) + " (" + str(frame_time).pad_decimals(1) + "ms)"
	
	# Memory usage - use available Godot 4.4.1 methods
	var memory_mb = OS.get_static_memory_peak_usage() / 1024.0 / 1024.0
	memory_label.text = "Memory: " + str(memory_mb).pad_decimals(1) + " MB"

func _update_player_info():
	if not player_status_label:
		return
	
	var status_text = "Player Status:\n"
	
	# Check if GameManager exists
	if GameManager:
		status_text += "Health: " + str(GameManager.player_health) + "/" + str(GameManager.player_max_health) + "\n"
		status_text += "State: " + GameManager.get_state_string() + "\n"
		status_text += "Wave: " + str(GameManager.current_wave) + "\n"
	else:
		status_text += "GameManager: Not Available\n"
	
	# Check player node
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_node_or_null("GameWorld/Player")
	
	if player:
		status_text += "Player Node: Found\n"
		status_text += "Position: " + str(player.global_position) + "\n"
		
		# Check for HealthComponent
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp:
			if "current_mana" in health_comp:
				status_text += "Mana: " + str(health_comp.current_mana) + "/" + str(health_comp.max_mana) + "\n"
	else:
		status_text += "Player Node: Not Found\n"
	
	player_status_label.text = status_text

func _update_spell_info():
	if not spell_status_label:
		return
	
	var status_text = "Spell System Status:\n"
	
	# Check player and spell component
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_node_or_null("GameWorld/Player")
	
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp:
			status_text += "SpellComponent: Found\n"
			
			if spell_comp.has_method("get_equipped_spells"):
				var spells = spell_comp.get_equipped_spells()
				status_text += "Equipped Spells: " + str(spells.size()) + "\n"
				
				for i in range(min(spells.size(), 3)):  # Show first 3 spells
					var spell = spells[i]
					var cooldown = spell_comp.get_spell_cooldown(i) if spell_comp.has_method("get_spell_cooldown") else 0.0
					var spell_ready = spell_comp.is_spell_ready(i) if spell_comp.has_method("is_spell_ready") else false
					status_text += "  " + spell.spell_name + ": " + ("Ready" if spell_ready else "Cooldown " + str(cooldown).pad_decimals(1) + "s") + "\n"
		else:
			status_text += "SpellComponent: Not Found\n"
	else:
		status_text += "Player: Not Found\n"
	
	# Check SpellData availability
	var test_spell = SpellData.new()
	if test_spell:
		status_text += "SpellData: Available\n"
		test_spell = null
	else:
		status_text += "SpellData: Not Available\n"
	
	spell_status_label.text = status_text

func _update_testing_info():
	if not results_label:
		return
	
	# Check for test runner and display last results - use correct scene path
	var test_runner = get_node_or_null("/root/TestMain")  # TestMain is the root scene
	if not test_runner:
		test_runner = get_tree().current_scene  # Current scene should be TestMain
	
	var status_text = "Infrastructure Test Status:\n"
	
	if test_runner:
		status_text += "TestRunner: Found\n"
		
		# Get test results if available
		if test_runner.has_method("get_last_test_results"):
			var results = test_runner.get_last_test_results()
			if results.size() > 0:
				status_text += "Last Test Results (Recent " + str(min(results.size(), 8)) + "):\n"
				# Show only the most recent 8 results to keep display manageable
				var start_idx = max(0, results.size() - 8)
				for i in range(start_idx, results.size()):
					var result = results[i]
					# Clean up the result text for better display
					var clean_result = result.replace("===", "").replace("=", "").strip_edges()
					if clean_result.length() > 50:
						clean_result = clean_result.substr(0, 47) + "..."
					status_text += "• " + clean_result + "\n"
			else:
				status_text += "No tests run yet\n"
		else:
			status_text += "Results: Use buttons to run tests\n"
		
		# Add quick status overview
		status_text += "\nQuick System Health:\n"
		status_text += "  Singletons: " + ("✅" if GameEvents and GameManager else "❌") + "\n"
		var player = get_node_or_null("/root/TestMain/GameWorld/Player")
		if not player:
			player = get_tree().get_first_node_in_group("players")
		status_text += "  Player: " + ("✅" if player else "❌") + "\n"
		status_text += "  Input: " + ("✅" if InputHandler else "❌") + "\n"
		status_text += "  FPS: " + str(Engine.get_frames_per_second()) + "\n"
	else:
		status_text += "TestRunner: Not Found\n"
		status_text += "Use SPACE in-game to run tests\n"
	
	results_label.text = status_text

# Debug command implementations
var physics_debug_enabled: bool = false

func _debug_toggle_physics():
	print("🔧 DEBUG: Toggle Physics Debug")
	physics_debug_enabled = !physics_debug_enabled
	
	# Enable/disable collision shape visibility
	get_tree().debug_collisions_hint = physics_debug_enabled
	
	# Also enable visible collision shapes if available
	if physics_debug_enabled:
		print("✅ Physics debug enabled - collision shapes visible")
		# Enable debug draw for all bodies
		_set_debug_draw_recursive(get_tree().current_scene, true)
	else:
		print("✅ Physics debug disabled - collision shapes hidden")
		# Disable debug draw for all bodies
		_set_debug_draw_recursive(get_tree().current_scene, false)

func _set_debug_draw_recursive(node: Node, enabled: bool):
	# Enable debug draw for physics bodies
	if node is RigidBody2D:
		node.set_gravity_scale(node.get_gravity_scale())  # Trigger physics update
	elif node is CharacterBody2D:
		pass  # CharacterBody2D doesn't have debug draw, but collision shapes will show
	elif node is StaticBody2D:
		pass  # StaticBody2D collision shapes will show with debug_collisions_hint
	
	# Recursively apply to children
	for child in node.get_children():
		_set_debug_draw_recursive(child, enabled)

func _debug_reset_game():
	print("🔧 DEBUG: Reset Game State")
	if GameManager and GameManager.has_method("reset_game"):
		GameManager.reset_game()
	else:
		print("⚠️ GameManager.reset_game() not available")

func _debug_performance_test():
	print("🔧 DEBUG: Performance Test")
	var start_time = Time.get_ticks_msec()
	
	# Simple performance test - create and destroy objects
	var test_objects = []
	for i in range(1000):
		var node = Node.new()
		test_objects.append(node)
	
	for obj in test_objects:
		obj.queue_free()
	
	var end_time = Time.get_ticks_msec()
	print("🔧 Performance test completed in " + str(end_time - start_time) + "ms")

func _debug_heal_player():
	print("🔧 DEBUG: Heal Player")
	if GameManager and GameManager.has_method("heal_player"):
		GameManager.heal_player(25.0)
		print("✅ Player healed for 25 HP")
	else:
		print("❌ GameManager.heal_player() not available")

func _debug_damage_player():
	print("🔧 DEBUG: Damage Player")
	if GameManager and GameManager.has_method("damage_player"):
		GameManager.damage_player(25.0)
		print("✅ Player damaged for 25 HP")
	else:
		print("❌ GameManager.damage_player() not available")

func _debug_restore_mana():
	print("🔧 DEBUG: Restore Mana")
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_tree().get_first_node_in_group("players")
	
	if player:
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp and health_comp.has_method("restore_mana"):
			health_comp.restore_mana(25.0)
			print("✅ Player mana restored by 25")
		elif health_comp and "current_mana" in health_comp and "max_mana" in health_comp:
			health_comp.current_mana = health_comp.max_mana
			print("✅ Player mana fully restored")
		else:
			print("❌ HealthComponent mana methods not available")
	else:
		print("❌ Player not found")

func _debug_toggle_god_mode():
	print("🔧 DEBUG: Toggle God Mode")
	# Simple god mode - set high health and mana
	if GameManager:
		GameManager.set_player_health(999.0)
		print("✅ God mode enabled - Health set to 999")
	else:
		print("❌ GameManager not available for god mode")

func _debug_reset_cooldowns():
	print("🔧 DEBUG: Reset Spell Cooldowns")
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_tree().get_first_node_in_group("players")
	
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp:
			# Reset cooldowns by clearing the cooldown dictionary
			if "spell_cooldowns" in spell_comp:
				spell_comp.spell_cooldowns.clear()
				print("✅ All spell cooldowns reset")
			else:
				print("❌ spell_cooldowns not found in SpellComponent")
		else:
			print("❌ SpellComponent not found")
	else:
		print("❌ Player not found")

func _debug_test_spells():
	print("🔧 DEBUG: Test All Spells")
	var player = get_node_or_null("/root/Main/GameWorld/Player")
	if not player:
		player = get_tree().get_first_node_in_group("players")
	
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp and spell_comp.has_method("cast_spell"):
			print("🔮 Testing fireball spell cast...")
			var success = spell_comp.cast_spell(0)
			if success:
				print("✅ Spell test successful")
			else:
				print("❌ Spell test failed (cooldown/mana?)")
		else:
			print("❌ SpellComponent.cast_spell() not available")
	else:
		print("❌ Player not found")

func _debug_run_tests():
	print("🔧 DEBUG: Run Full Test Suite")
	# Try multiple paths to find TestRunner - check the actual scene structure
	var test_runner = get_node_or_null("/root/TestMain")  # TestMain is the root scene
	if not test_runner:
		test_runner = get_tree().current_scene  # Current scene should be TestMain
	if not test_runner:
		# Find any TestRunner in the scene tree
		var all_nodes = get_tree().get_nodes_in_group("test_runner")
		if all_nodes.size() > 0:
			test_runner = all_nodes[0]
	
	if test_runner and test_runner.has_method("run_all_tests"):
		print("✅ Found TestRunner, running tests...")
		test_runner.run_all_tests()
		# Update the display after running tests
		_update_testing_info()
	else:
		print("⚠️ TestRunner not available at expected paths")
		print("   Checked: /root/TestMain, current_scene")
		print("   Current scene: " + str(get_tree().current_scene.name if get_tree().current_scene else "none"))
		# Update display to show current status
		_update_testing_info()

func _debug_validate_systems():
	print("🔧 DEBUG: Validate All Systems")
	# Try multiple paths to find TestValidation
	var validator = get_node_or_null("/root/Main/TestValidation")
	if not validator:
		validator = get_tree().current_scene.get_node_or_null("TestValidation")
	if not validator:
		# Find any TestValidation in the scene tree
		var all_nodes = get_tree().get_nodes_in_group("test_validation")
		if all_nodes.size() > 0:
			validator = all_nodes[0]
	
	if validator and validator.has_method("run_all_tests"):
		print("✅ Found TestValidation, running validation...")
		validator.run_all_tests()
	else:
		print("⚠️ TestValidation not available - Running basic validation instead")
		_run_basic_validation()
	
	# Update the testing display
	_update_testing_info()

func _debug_run_infrastructure_only():
	print("🔧 DEBUG: Run Infrastructure Tests Only")
	# Run a focused infrastructure test - use correct scene path
	var test_runner = get_node_or_null("/root/TestMain")  # TestMain is the root scene
	if not test_runner:
		test_runner = get_tree().current_scene  # Current scene should be TestMain
	
	if test_runner and test_runner.has_method("run_infrastructure_tests"):
		print("✅ Running infrastructure-only tests...")
		test_runner.run_infrastructure_tests()
	elif test_runner and test_runner.has_method("run_phase_0_tests"):
		print("✅ Running Phase 0 (infrastructure) tests...")
		test_runner.run_phase_0_tests()
	else:
		print("⚠️ TestRunner not found - running manual infrastructure check...")
		_run_basic_validation()
	
	# Update the testing display
	_update_testing_info()

func _run_basic_validation():
	print("🔧 Running basic system validation...")
	var systems_ok = 0
	var total_systems = 0
	
	# Check core singletons
	total_systems += 4
	if GameEvents: 
		systems_ok += 1
		print("✅ GameEvents: OK")
	else:
		print("❌ GameEvents: MISSING")
	
	if GameManager:
		systems_ok += 1
		print("✅ GameManager: OK")
	else:
		print("❌ GameManager: MISSING")
	
	if InputHandler:
		systems_ok += 1
		print("✅ InputHandler: OK")
	else:
		print("❌ InputHandler: MISSING")
	
	if Logger:
		systems_ok += 1
		print("✅ Logger: OK")
	else:
		print("❌ Logger: MISSING")
	
	# Check player - use correct scene path
	total_systems += 1
	var player = get_node_or_null("/root/TestMain/GameWorld/Player")  # TestMain is the root scene
	if not player:
		player = get_tree().get_first_node_in_group("players")
	
	if player:
		systems_ok += 1
		print("✅ Player: OK")
	else:
		print("❌ Player: MISSING (checked /root/TestMain/GameWorld/Player and 'player' group)")
	
	print("🔧 Basic validation complete: " + str(systems_ok) + "/" + str(total_systems) + " systems OK")

# Utility function to convert keycode to string
func _keycode_to_string(keycode: int) -> String:
	match keycode:
		KEY_F1: return "F1"
		KEY_F2: return "F2"
		KEY_F3: return "F3"
		KEY_F4: return "F4"
		KEY_F5: return "F5"
		KEY_F6: return "F6"
		KEY_F7: return "F7"
		KEY_F8: return "F8"
		KEY_F9: return "F9"
		KEY_F10: return "F10"
		KEY_F11: return "F11"
		KEY_F12: return "F12"
		_: return "UNKNOWN"

# Public API for external systems to add debug commands
func register_debug_command(key: String, command_name: String, category: String, function_name: String, target_object: Object = null):
	debug_commands[key] = {
		"name": command_name,
		"category": category,
		"function": function_name,
		"target": target_object if target_object else self
	}
	print("🔧 Registered debug command: " + command_name + " (" + key + ")")

func get_debug_commands() -> Dictionary:
	return debug_commands

func is_menu_open() -> bool:
	# Always check both internal state AND visibility for robustness
	var state_open = is_debug_menu_open and visible
	return state_open

# COLLISION TUNING SYSTEM - FIXED TO PREVENT OVERLAP WITH COLLISION TESTING SCENE
var collision_tuner: Node
var collision_visualization_enabled: bool = false

func _init_collision_tuning():
	# Initialize collision tuning system - ONLY for non-testing scenes
	# Skip collision system initialization if we're in the CollisionTestingScene
	# to prevent conflict with the dedicated testing scene
	var scene_name = get_tree().current_scene.name if get_tree().current_scene else ""
	if scene_name == "CollisionTestingScene":
		print("🔧 DebugMenu: Skipping collision tuning init - in dedicated CollisionTestingScene")
		return
	
	if not collision_tuner:
		collision_tuner = Node.new()
		collision_tuner.set_script(preload("res://edited/collision-system-fixes/CollisionTuner.gd"))
		add_child(collision_tuner)
		
		# Register collision tuning commands
		register_debug_command("F9", "Toggle Collision Visualization", "Collision", "_toggle_collision_visualization")
		register_debug_command("F10", "Select Nearest Enemy for Tuning", "Collision", "_select_nearest_enemy_for_tuning")

func _toggle_collision_visualization():
	# Toggle collision shape visualization for all enemies - ONLY in non-testing scenes
	var scene_name = get_tree().current_scene.name if get_tree().current_scene else ""
	if scene_name == "CollisionTestingScene":
		print("🔧 DebugMenu: Use CollisionTestingScene controls instead of debug menu for collision visualization")
		return
	
	collision_visualization_enabled = !collision_visualization_enabled
	
	# FIXED: Proper cleanup before creating new visualizers
	var enemies = get_tree().get_nodes_in_group("enemies")
	
	# First, clean up ALL existing visualizers to prevent overlaps
	for enemy in enemies:
		_cleanup_enemy_visualizers(enemy)
	
	# Wait one frame for cleanup to complete
	await get_tree().process_frame
	
	# Then create new visualizers if enabled
	if collision_visualization_enabled:
		for enemy in enemies:
			_add_collision_visualizer_to_enemy(enemy)
	
	print("🔧 Collision visualization: ", "ON" if collision_visualization_enabled else "OFF")

func _cleanup_enemy_visualizers(enemy: Node):
	# Clean up ALL visualizers from an enemy to prevent overlaps
	if not enemy:
		return
	
	# Find and remove ALL CollisionVisualizer nodes
	var visualizers_to_remove = []
	for child in enemy.get_children():
		if child.name == "CollisionVisualizer" or child.has_method("cleanup"):
			visualizers_to_remove.append(child)
	
	# Remove all visualizers
	for visualizer in visualizers_to_remove:
		if visualizer.has_method("cleanup"):
			visualizer.cleanup()
		else:
			visualizer.queue_free()

func _select_nearest_enemy_for_tuning():
	# Select nearest enemy for collision tuning - ONLY in non-testing scenes
	var scene_name = get_tree().current_scene.name if get_tree().current_scene else ""
	if scene_name == "CollisionTestingScene":
		print("🔧 DebugMenu: Use CollisionTestingScene controls (1-5 keys) instead of debug menu for enemy selection")
		return
	
	if not collision_tuner:
		_init_collision_tuning()
	
	if collision_tuner and collision_tuner.has_method("auto_select_nearest_enemy"):
		collision_tuner.auto_select_nearest_enemy()

func _add_collision_visualizer_to_enemy(enemy: Enemy):
	# Add collision visualizer to specific enemy - ONLY in non-testing scenes
	var scene_name = get_tree().current_scene.name if get_tree().current_scene else ""
	if scene_name == "CollisionTestingScene":
		return  # Let CollisionTestingScene handle its own visualizers
	
	if not collision_visualization_enabled:
		return
	
	# Ensure enemy has no existing visualizers first
	_cleanup_enemy_visualizers(enemy)
	
	# Wait one frame to ensure cleanup completed
	await get_tree().process_frame
	
	# Create fresh visualizer
	var visualizer = Node2D.new()
	visualizer.name = "CollisionVisualizer"
	visualizer.set_script(preload("res://edited/collision-system-fixes/CollisionVisualizer.gd"))
	enemy.add_child(visualizer)
	visualizer.setup(enemy)

func show_collision_tuning_help():
	# Display collision tuning help in console
	var scene_name = get_tree().current_scene.name if get_tree().current_scene else ""
	if scene_name == "CollisionTestingScene":
		print("=== COLLISION TESTING SCENE DETECTED ===")
		print("Use dedicated CollisionTestingScene controls:")
		print("1-5: Select enemy type")
		print("V: Toggle collision visualization")
		print("T: Toggle shape type")
		print("See COLLISION_TESTING_INSTRUCTIONS.md for complete guide")
		return
	
	print("=== COLLISION TUNING HELP ===")
	print("F9: Toggle collision visualization for all enemies")
	print("F10: Select nearest enemy for tuning")
	print("")
	print("When enemy is selected for tuning:")
	print("SIZING:")
	print("  Q/E: Adjust main collision radius (+/-)")
	print("  Z/C: Adjust damage area radius (+/-)")
	print("  X/B: Change adjustment step size")
	print("")
	print("POSITIONING:")
	print("  SHIFT+I/K: Move main collision up/down")
	print("  SHIFT+J/L: Move main collision left/right")
	print("  I/K: Move damage area up/down")
	print("  J/L: Move damage area left/right")
	print("")
	print("UTILITIES:")
	print("  P: Print current values (copy to .tres file)")
	print("  V: Toggle visualization for selected enemy")
	print("  Mouse: Drag yellow handles to position collision shapes")
	print("")
	print("TIP: For dedicated collision testing, use CollisionTestingScene.tscn")
	print("Current collision values can be found in:")
	print("data/enemies/[enemy_type]_data.tres")
	print("Look for collision_radius and damage_area_radius")
