# UnifiedDebugSystem_Enhanced.gd
# Comprehensive unified debug system combining all debug functionalities
# 
# COMBINES:
# - F1 Debug Menu (DraggableDebugMenuManager + DebugMenu)
# - Shift+F1 Collision Debug (basic visualization only)
# - F2-F12 Debug Hotkeys (all original functionality)
# - Centralized Logging (Logger.gd + LogManager.gd)
# - Testing Framework (TestRunner.gd)
# - Performance Monitoring
# - Quality Gates and Validation
# - Debug Commands (H, M, R, Q, I, O, 1-5 keys)
#
# TECHNICAL FEASIBILITY: ✅ CONFIRMED FEASIBLE
# READY FOR INSTALLATION: ✅ YES

extends Control

# =============================================================================
# CORE SYSTEM SIGNALS
# =============================================================================

signal debug_event_logged(category: String, message: String, level: String)
signal test_completed(test_name: String, passed: bool, details: String)
signal performance_threshold_exceeded(metric: String, value: float, threshold: float)
signal collision_debug_toggled(enabled: bool)

# =============================================================================
# LOGGING SUBSYSTEM (Combined Logger.gd + LogManager.gd)
# =============================================================================

enum LogLevel { DEBUG, INFO, WARNING, ERROR, CRITICAL }
enum LogCategory { 
	GENERAL, GAMEEVENTS, GAMEMANAGER, INPUT, COLLISION, 
	PLAYER, UI, PERFORMANCE, TESTING, VALIDATION 
}

class LogEntry:
	var timestamp: String
	var level: LogLevel
	var category: LogCategory
	var message: String
	var source_file: String
	
	func _init(lvl: LogLevel, cat: LogCategory, msg: String, src: String = ""):
		timestamp = Time.get_datetime_string_from_system()
		level = lvl
		category = cat
		message = msg
		source_file = src

# Logging storage and management
var log_entries: Array[LogEntry] = []
var max_log_entries: int = 1000
var error_count: int = 0
var warning_count: int = 0
var performance_issues: Array[String] = []

# =============================================================================
# UI SUBSYSTEM (Combined Debug Menus)
# =============================================================================

# Main Debug Menu (F1) Components
var main_debug_panel: Panel
var main_tab_container: TabContainer
var main_system_tab: Control
var main_player_tab: Control
var main_spells_tab: Control
var main_testing_tab: Control

# Collision Debug Menu (Shift+F1) Components
var collision_debug_panel: Panel
var collision_status_label: Label

# Shared UI Components
var fps_label: Label
var memory_label: Label
var error_label: Label
var player_status_label: Label
var spell_status_label: Label

# UI State
var main_debug_visible: bool = false
var collision_debug_visible: bool = false
var collision_debug_enabled: bool = false

# =============================================================================
# COLLISION DEBUGGING SUBSYSTEM (Basic visualization only)
# =============================================================================

class CollisionDebugData:
	var shape_type: String
	var position: Vector2
	var size: Vector2
	var color: Color
	var thickness: float
	
	func _init(type: String, pos: Vector2, sz: Vector2, col: Color = Color.RED, thick: float = 2.0):
		shape_type = type
		position = pos
		size = sz
		color = col
		thickness = thick

var collision_visualizations: Array[CollisionDebugData] = []

# =============================================================================
# TESTING SUBSYSTEM (TestRunner.gd)
# =============================================================================

class TestResult:
	var test_name: String
	var passed: bool
	var details: String
	var execution_time: float
	var category: String
	
	func _init(name: String, success: bool, info: String, time: float, cat: String):
		test_name = name
		passed = success
		details = info
		execution_time = time
		category = cat

var test_results: Array[TestResult] = []
var tests_running: bool = false
var test_categories: Array[String] = [
	"Infrastructure", "Systems", "Performance", "Player", "Spells", "Collision"
]

# =============================================================================
# PERFORMANCE MONITORING SUBSYSTEM
# =============================================================================

class PerformanceMetrics:
	var fps: float = 0.0
	var memory_usage: int = 0
	var frame_time: float = 0.0
	var node_count: int = 0
	
	func update():
		fps = Engine.get_frames_per_second()
		memory_usage = OS.get_static_memory_usage()
		frame_time = 1.0 / Engine.get_frames_per_second() if Engine.get_frames_per_second() > 0 else 0.016
		var tree = Engine.get_main_loop() as SceneTree
		node_count = tree.get_node_count() if tree else 0

var performance_metrics: PerformanceMetrics = PerformanceMetrics.new()
var performance_thresholds: Dictionary = {
	"min_fps": 30.0,
	"max_memory_mb": 512,
	"max_frame_time_ms": 33.33
}

# =============================================================================
# QUALITY GATE SUBSYSTEM
# =============================================================================

class QualityGateResult:
	var gate_name: String
	var passed: bool
	var issues: Array[String]
	var score: float
	
	func _init(name: String):
		gate_name = name
		passed = true
		issues = []
		score = 100.0

var quality_gates: Array[QualityGateResult] = []

# =============================================================================
# UPDATE TIMERS
# =============================================================================

var update_timer: Timer
var performance_timer: Timer

# =============================================================================
# CORE SYSTEM INITIALIZATION
# =============================================================================

func _ready():
	name = "UnifiedDebugSystem"
	process_mode = Node.PROCESS_MODE_ALWAYS  # Essential for pause compatibility
	add_to_group("debug_system")
	
	# Initialize all subsystems
	initialize_logging_system()
	initialize_ui_system()
	initialize_collision_debug()
	initialize_testing_framework()
	initialize_performance_monitoring()
	initialize_quality_gates()
	
	# Setup input handling for all debug keys
	set_process_input(true)
	
	# Setup update timers
	setup_update_timers()
	
	log_info(LogCategory.GENERAL, "Unified Debug System initialized successfully")
	print("🔧 Unified Debug System ready")
	print("🔧 F1: Main Debug | Shift+F1: Collision Debug")
	print("🔧 F2-F12: Debug hotkeys | H,M,R,Q,I,O,1-5: Debug commands")

func initialize_logging_system():
	log_entries.clear()
	error_count = 0
	warning_count = 0
	performance_issues.clear()

func initialize_ui_system():
	create_main_debug_ui()
	create_collision_debug_ui()

func create_main_debug_ui():
	# Main Debug Panel (F1)
	main_debug_panel = Panel.new()
	main_debug_panel.name = "MainDebugPanel"
	main_debug_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	main_debug_panel.size = Vector2(800, 600)
	main_debug_panel.modulate.a = 0.95
	main_debug_panel.visible = false
	add_child(main_debug_panel)
	
	# Add draggable functionality
	main_debug_panel.gui_input.connect(_on_main_panel_input)
	
	# Create main tab container
	main_tab_container = TabContainer.new()
	main_tab_container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_tab_container.set_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 10)
	main_debug_panel.add_child(main_tab_container)
	
	# Create main debug tabs
	create_main_system_tab()
	create_main_player_tab()
	create_main_spells_tab()
	create_main_testing_tab()

func create_main_system_tab():
	main_system_tab = Control.new()
	main_system_tab.name = "System"
	main_tab_container.add_child(main_system_tab)
	
	var system_info = VBoxContainer.new()
	system_info.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	system_info.set_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 10)
	main_system_tab.add_child(system_info)
	
	# Title
	var title = Label.new()
	title.text = "System Information"
	title.add_theme_font_size_override("font_size", 16)
	system_info.add_child(title)
	
	fps_label = Label.new()
	fps_label.text = "FPS: 60"
	fps_label.add_theme_font_size_override("font_size", 14)
	system_info.add_child(fps_label)
	
	memory_label = Label.new()
	memory_label.text = "Memory: 0 MB"
	memory_label.add_theme_font_size_override("font_size", 14)
	system_info.add_child(memory_label)
	
	error_label = Label.new()
	error_label.text = "Errors: 0 | Warnings: 0"
	error_label.add_theme_font_size_override("font_size", 14)
	system_info.add_child(error_label)
	
	# Add system health
	var health_label = Label.new()
	health_label.name = "HealthLabel"
	health_label.text = "System Health: EXCELLENT"
	health_label.add_theme_font_size_override("font_size", 14)
	system_info.add_child(health_label)

func create_main_player_tab():
	main_player_tab = Control.new()
	main_player_tab.name = "Player"
	main_tab_container.add_child(main_player_tab)
	
	var player_info = VBoxContainer.new()
	player_info.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	player_info.set_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 10)
	main_player_tab.add_child(player_info)
	
	# Title
	var title = Label.new()
	title.text = "Player Information"
	title.add_theme_font_size_override("font_size", 16)
	player_info.add_child(title)
	
	player_status_label = Label.new()
	player_status_label.text = "Player Status: Loading..."
	player_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	player_info.add_child(player_status_label)
	
	# Add player debug buttons
	var button_container = HBoxContainer.new()
	player_info.add_child(button_container)
	
	var heal_btn = Button.new()
	heal_btn.text = "Heal +25"
	heal_btn.pressed.connect(_debug_heal_player)
	button_container.add_child(heal_btn)
	
	var damage_btn = Button.new()
	damage_btn.text = "Damage -25"
	damage_btn.pressed.connect(_debug_damage_player)
	button_container.add_child(damage_btn)
	
	var god_mode_btn = Button.new()
	god_mode_btn.text = "God Mode"
	god_mode_btn.pressed.connect(_debug_toggle_god_mode)
	button_container.add_child(god_mode_btn)

func create_main_spells_tab():
	main_spells_tab = Control.new()
	main_spells_tab.name = "Spells"
	main_tab_container.add_child(main_spells_tab)
	
	var spell_info = VBoxContainer.new()
	spell_info.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	spell_info.set_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 10)
	main_spells_tab.add_child(spell_info)
	
	# Title
	var title = Label.new()
	title.text = "Spell System"
	title.add_theme_font_size_override("font_size", 16)
	spell_info.add_child(title)
	
	spell_status_label = Label.new()
	spell_status_label.text = "Spell Status: Loading..."
	spell_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	spell_info.add_child(spell_status_label)
	
	# Add spell debug buttons
	var spell_buttons = HBoxContainer.new()
	spell_info.add_child(spell_buttons)
	
	var restore_mana_btn = Button.new()
	restore_mana_btn.text = "Restore Mana"
	restore_mana_btn.pressed.connect(_debug_restore_mana)
	spell_buttons.add_child(restore_mana_btn)
	
	var reset_cooldowns_btn = Button.new()
	reset_cooldowns_btn.text = "Reset Cooldowns"
	reset_cooldowns_btn.pressed.connect(_debug_reset_cooldowns)
	spell_buttons.add_child(reset_cooldowns_btn)
	
	var test_spells_btn = Button.new()
	test_spells_btn.text = "Test All Spells"
	test_spells_btn.pressed.connect(_debug_test_spells)
	spell_buttons.add_child(test_spells_btn)

func create_main_testing_tab():
	main_testing_tab = Control.new()
	main_testing_tab.name = "Testing"
	main_tab_container.add_child(main_testing_tab)
	
	var test_info = VBoxContainer.new()
	test_info.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	test_info.set_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 10)
	main_testing_tab.add_child(test_info)
	
	# Title
	var title = Label.new()
	title.text = "Testing Framework"
	title.add_theme_font_size_override("font_size", 16)
	test_info.add_child(title)
	
	# Create test buttons
	var test_buttons = HBoxContainer.new()
	test_info.add_child(test_buttons)
	
	var run_tests_btn = Button.new()
	run_tests_btn.text = "Run All Tests"
	run_tests_btn.pressed.connect(run_all_tests)
	test_buttons.add_child(run_tests_btn)
	
	var validate_btn = Button.new()
	validate_btn.text = "Validate Systems"
	validate_btn.pressed.connect(run_quality_gates)
	test_buttons.add_child(validate_btn)
	
	var infra_btn = Button.new()
	infra_btn.text = "Infrastructure Tests"
	infra_btn.pressed.connect(run_infrastructure_tests)
	test_buttons.add_child(infra_btn)
	
	# Test results area
	var results_scroll = ScrollContainer.new()
	results_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	test_info.add_child(results_scroll)
	
	var results_label = Label.new()
	results_label.name = "TestResultsLabel"
	results_label.text = "No tests run yet"
	results_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	results_scroll.add_child(results_label)

func create_collision_debug_ui():
	# Collision Debug Panel (Shift+F1)
	collision_debug_panel = Panel.new()
	collision_debug_panel.name = "CollisionDebugPanel"
	collision_debug_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	collision_debug_panel.size = Vector2(300, 200)
	collision_debug_panel.position = Vector2(-310, 10)
	collision_debug_panel.modulate.a = 0.9
	collision_debug_panel.visible = false
	add_child(collision_debug_panel)
	
	var collision_info = VBoxContainer.new()
	collision_info.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	collision_info.set_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 10)
	collision_debug_panel.add_child(collision_info)
	
	# Title
	var title = Label.new()
	title.text = "Collision Debug"
	title.add_theme_font_size_override("font_size", 16)
	collision_info.add_child(title)
	
	collision_status_label = Label.new()
	collision_status_label.text = "Status: Disabled"
	collision_status_label.add_theme_font_size_override("font_size", 14)
	collision_info.add_child(collision_status_label)
	
	# Toggle buttons
	var toggle_physics_btn = Button.new()
	toggle_physics_btn.text = "Toggle Physics Debug (F2)"
	toggle_physics_btn.pressed.connect(_debug_toggle_physics)
	collision_info.add_child(toggle_physics_btn)
	
	var clear_viz_btn = Button.new()
	clear_viz_btn.text = "Clear Visualizations"
	clear_viz_btn.pressed.connect(clear_collision_visualizations)
	collision_info.add_child(clear_viz_btn)

var dragging = false
var drag_offset = Vector2.ZERO

func _on_main_panel_input(event: InputEvent):
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				dragging = true
				drag_offset = event.position
			else:
				dragging = false
	elif event is InputEventMouseMotion and dragging:
		main_debug_panel.position += event.relative

func initialize_collision_debug():
	collision_visualizations.clear()

func initialize_testing_framework():
	test_results.clear()
	tests_running = false

func initialize_performance_monitoring():
	performance_metrics = PerformanceMetrics.new()

func initialize_quality_gates():
	quality_gates.clear()

func setup_update_timers():
	# Main update timer
	update_timer = Timer.new()
	update_timer.wait_time = 0.1  # 10 FPS update
	update_timer.timeout.connect(update_debug_displays)
	update_timer.autostart = true
	add_child(update_timer)
	
	# Performance monitoring timer
	performance_timer = Timer.new()
	performance_timer.wait_time = 1.0  # 1 second intervals
	performance_timer.timeout.connect(check_performance_thresholds)
	performance_timer.autostart = true
	add_child(performance_timer)

# =============================================================================
# DEBUG COMMANDS & HOTKEYS
# =============================================================================

# External API compatibility for existing code
func log_error(message: String, source: String = "", category: LogCategory = LogCategory.GENERAL):
	_add_log_entry(LogLevel.ERROR, category, message, source)

func log_warning(message: String, source: String = "", category: LogCategory = LogCategory.GENERAL):
	_add_log_entry(LogLevel.WARNING, category, message, source)

func log_info_external(message: String, source: String = "", category: LogCategory = LogCategory.GENERAL):
	_add_log_entry(LogLevel.INFO, category, message, source)

func get_error_summary() -> String:
	return "Errors: %d | Warnings: %d" % [error_count, warning_count]

func get_system_health_status() -> String:
	var health_score = 100 - (error_count * 5) - (warning_count * 2)
	if health_score >= 90:
		return "EXCELLENT"
	elif health_score >= 75:
		return "GOOD"  
	elif health_score >= 50:
		return "FAIR"
	else:
		return "POOR"

func is_system_healthy() -> bool:
	return error_count < 5 and warning_count < 20

# Test framework compatibility
func get_last_test_results() -> Array[String]:
	var results: Array[String] = []
	for result in test_results:
		var status = "PASS" if result.passed else "FAIL"
		results.append("%s: %s (%s)" % [result.test_name, status, result.details])
	return results

func has_test_results() -> bool:
	return test_results.size() > 0

func add_test_result(text: String):
	var parts = text.split(": ")
	var name = parts[0] if parts.size() > 0 else "Unknown Test"
	var passed = text.contains("PASS") or text.contains("✅")
	var details = parts[1] if parts.size() > 1 else text
	add_test_result_detailed(name, passed, details, 0.0, "External")

func add_test_result_detailed(name: String, passed: bool, details: String, time: float, category: String):
	var result = TestResult.new(name, passed, details, time, category)
	test_results.append(result)
	test_completed.emit(name, passed, details)

# F-Key Debug Commands (F2-F12)
func _debug_toggle_physics():
	# F2 - Toggle physics debug visualization
	get_tree().debug_collisions_hint = !get_tree().debug_collisions_hint
	log_info(LogCategory.UI, "Physics debug toggled: " + str(get_tree().debug_collisions_hint))

func _debug_reset_game():
	# F3 - Reset game state
	if GameManager and GameManager.has_method("reset_game"):
		GameManager.reset_game()
		log_info(LogCategory.GAMEMANAGER, "Game state reset")
	else:
		log_warning_internal(LogCategory.GAMEMANAGER, "GameManager.reset_game() not available", "UnifiedDebugSystem")

func _debug_performance_test():
	# F4 - Performance stress test
	log_info(LogCategory.PERFORMANCE, "Starting performance test...")
	var start_time = Time.get_time_dict_from_system()
	
	# Create and destroy 100 nodes to test performance
	var test_nodes = []
	for i in range(100):
		var node = Node2D.new()
		get_tree().current_scene.add_child(node)
		test_nodes.append(node)
	
	# Clean up
	for node in test_nodes:
		node.queue_free()
	
	log_info(LogCategory.PERFORMANCE, "Performance test completed")

func _debug_heal_player():
	# F5 - Heal player (+25 HP)
	var player = _get_player()
	if player and player.has_method("heal"):
		player.heal(25)
		log_info(LogCategory.PLAYER, "Player healed +25 HP")
	elif player and player.get_node_or_null("HealthComponent"):
		var health_comp = player.get_node("HealthComponent")
		if health_comp.has_method("heal"):
			health_comp.heal(25)
			log_info(LogCategory.PLAYER, "Player healed +25 HP via HealthComponent")
	else:
		log_warning_internal(LogCategory.PLAYER, "Could not heal player - no heal method found", "UnifiedDebugSystem")

func _debug_damage_player():
	# F6 - Damage player (-25 HP)
	var player = _get_player()
	if player and player.has_method("take_damage"):
		player.take_damage(25)
		log_info(LogCategory.PLAYER, "Player damaged -25 HP")
	else:
		log_warning_internal(LogCategory.PLAYER, "Could not damage player - no take_damage method found", "UnifiedDebugSystem")

func _debug_restore_mana():
	# F7 - Restore mana
	var player = _get_player()
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp and spell_comp.has_method("restore_mana"):
			spell_comp.restore_mana(50)
			log_info(LogCategory.PLAYER, "Player mana restored +50")
		else:
			log_warning_internal(LogCategory.PLAYER, "Could not restore mana - SpellComponent not found", "UnifiedDebugSystem")

func _debug_toggle_god_mode():
	# F9 - Toggle god mode (999 HP)
	var player = _get_player()
	if player:
		var health_comp = player.get_node_or_null("HealthComponent")
		if health_comp:
			if health_comp.has_method("set_health"):
				health_comp.set_health(999)
			elif health_comp.has_method("heal"):
				health_comp.heal(999)  # Fallback
			log_info(LogCategory.PLAYER, "God mode activated - HP boosted")
		else:
			log_warning_internal(LogCategory.PLAYER, "Could not activate god mode - HealthComponent not accessible", "UnifiedDebugSystem")

func _debug_reset_cooldowns():
	# F10 - Reset spell cooldowns
	var player = _get_player()
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp and spell_comp.has_method("reset_all_cooldowns"):
			spell_comp.reset_all_cooldowns()
			log_info(LogCategory.PLAYER, "All spell cooldowns reset")
		else:
			log_warning_internal(LogCategory.PLAYER, "Could not reset cooldowns - SpellComponent method not found", "UnifiedDebugSystem")

func _debug_test_spells():
	# F12 - Test all spells
	var player = _get_player()
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp:
			for i in range(1, 6):  # Test spells 1-5
				if spell_comp.has_method("cast_spell"):
					spell_comp.cast_spell(i)
					log_info(LogCategory.PLAYER, "Testing spell slot " + str(i))
		else:
			log_warning_internal(LogCategory.PLAYER, "Could not test spells - SpellComponent not found", "UnifiedDebugSystem")

# Letter Key Debug Commands (H, M, R, Q, I, O, 1-5)
func _debug_damage_player_h():
	# H key - Damage player (20 HP)
	var player = _get_player()
	if player and player.has_method("take_damage"):
		player.take_damage(20)
		log_info(LogCategory.PLAYER, "Player damaged -20 HP (H key)")

func _debug_consume_mana():
	# M key - Consume mana (10 mana)
	var player = _get_player()
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp and spell_comp.has_method("consume_mana"):
			spell_comp.consume_mana(10)
			log_info(LogCategory.PLAYER, "Player mana consumed -10 (M key)")

func _debug_regen_status():
	# R key - Show regeneration status
	var player = _get_player()
	if player:
		var health_comp = player.get_node_or_null("HealthComponent")
		var spell_comp = player.get_node_or_null("SpellComponent")
		var status = "Health: %s | Mana: %s" % [
			str(health_comp.current_health) + "/" + str(health_comp.max_health) if health_comp else "N/A",
			str(spell_comp.current_mana) + "/" + str(spell_comp.max_mana) if spell_comp else "N/A"
		]
		log_info(LogCategory.PLAYER, "Regen Status: " + status)

func _debug_spell_casting():
	# Q key - Test spell casting system
	var player = _get_player()
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp:
			log_info(LogCategory.PLAYER, "Spell System Debug: Component found, testing cast...")
			if spell_comp.has_method("cast_spell"):
				spell_comp.cast_spell(1)  # Test spell slot 1
		else:
			log_warning_internal(LogCategory.PLAYER, "Spell System Debug: SpellComponent not found", "UnifiedDebugSystem")

func _debug_intelligence_scaling():
	# I key - Debug intelligence scaling
	var player = _get_player()
	if player and player.has_method("get_debug_info"):
		var debug_info = player.get_debug_info()
		log_info(LogCategory.PLAYER, "Intelligence Scaling Debug: " + str(debug_info))
	else:
		log_info(LogCategory.PLAYER, "Intelligence Scaling Debug: Player debug info not available")

func _debug_all_stats_caching():
	# O key - Debug all stats caching
	var player = _get_player()
	if player:
		var stat_sheet = player.get_node_or_null("PlayerStatSheet")
		if stat_sheet and stat_sheet.has_method("get_all_stats"):
			var stats = stat_sheet.get_all_stats()
			log_info(LogCategory.PLAYER, "All Stats Cache: " + str(stats))
		else:
			log_warning_internal(LogCategory.PLAYER, "All Stats Cache: PlayerStatSheet not accessible", "UnifiedDebugSystem")

func _test_spell_cast(spell_index: int):
	# 1-5 keys - Test specific spell slots
	var player = _get_player()
	if player:
		var spell_comp = player.get_node_or_null("SpellComponent")
		if spell_comp and spell_comp.has_method("cast_spell"):
			spell_comp.cast_spell(spell_index)
			log_info(LogCategory.PLAYER, "Testing spell slot " + str(spell_index))

func _get_player() -> Node:
	# Helper method to get player node
	if GameManager and GameManager.has_method("get_player"):
		return GameManager.get_player()
	
	# Fallback path search
	var player = get_tree().get_first_node_in_group("player")
	if not player:
		player = get_tree().get_first_node_in_group("players")
	
	return player

# =============================================================================
# INPUT HANDLING (F1/Shift+F1 + All Debug Keys)
# =============================================================================

func _input(event: InputEvent):
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_F1:
				if event.shift_pressed:
					toggle_collision_debug()
				else:
					toggle_main_debug()
				get_viewport().set_input_as_handled()
			KEY_F2:
				_debug_toggle_physics()
				get_viewport().set_input_as_handled()
			KEY_F3:
				_debug_reset_game()
				get_viewport().set_input_as_handled()
			KEY_F4:
				_debug_performance_test()
				get_viewport().set_input_as_handled()
			KEY_F5:
				_debug_heal_player()
				get_viewport().set_input_as_handled()
			KEY_F6:
				_debug_damage_player()
				get_viewport().set_input_as_handled()
			KEY_F7:
				_debug_restore_mana()
				get_viewport().set_input_as_handled()
			KEY_F9:
				_debug_toggle_god_mode()
				get_viewport().set_input_as_handled()
			KEY_F10:
				_debug_reset_cooldowns()
				get_viewport().set_input_as_handled()
			KEY_F12:
				_debug_test_spells()
				get_viewport().set_input_as_handled()
			KEY_H:
				_debug_damage_player_h()
				get_viewport().set_input_as_handled()
			KEY_M:
				_debug_consume_mana()
				get_viewport().set_input_as_handled()
			KEY_R:
				_debug_regen_status()
				get_viewport().set_input_as_handled()
			KEY_Q:
				_debug_spell_casting()
				get_viewport().set_input_as_handled()
			KEY_I:
				_debug_intelligence_scaling()
				get_viewport().set_input_as_handled()
			KEY_O:
				_debug_all_stats_caching()
				get_viewport().set_input_as_handled()
			KEY_1:
				_test_spell_cast(1)
				get_viewport().set_input_as_handled()
			KEY_2:
				_test_spell_cast(2)
				get_viewport().set_input_as_handled()
			KEY_3:
				_test_spell_cast(3)
				get_viewport().set_input_as_handled()
			KEY_4:
				_test_spell_cast(4)
				get_viewport().set_input_as_handled()
			KEY_5:
				_test_spell_cast(5)
				get_viewport().set_input_as_handled()

func toggle_main_debug():
	main_debug_visible = !main_debug_visible
	main_debug_panel.visible = main_debug_visible
	log_info(LogCategory.UI, "Main debug menu toggled: " + str(main_debug_visible))

func toggle_collision_debug():
	collision_debug_visible = !collision_debug_visible
	collision_debug_panel.visible = collision_debug_visible
	collision_debug_enabled = collision_debug_visible
	collision_debug_toggled.emit(collision_debug_enabled)
	log_info(LogCategory.COLLISION, "Collision debug toggled: " + str(collision_debug_enabled))

# =============================================================================
# LOGGING METHODS
# =============================================================================

func log_debug(category: LogCategory, message: String, source: String = ""):
	_add_log_entry(LogLevel.DEBUG, category, message, source)

func log_info(category: LogCategory, message: String, source: String = ""):
	_add_log_entry(LogLevel.INFO, category, message, source)

func log_warning_internal(category: LogCategory, message: String, source: String = ""):
	warning_count += 1
	_add_log_entry(LogLevel.WARNING, category, message, source)

func log_error_internal(category: LogCategory, message: String, source: String = ""):
	error_count += 1
	_add_log_entry(LogLevel.ERROR, category, message, source)

func _add_log_entry(level: LogLevel, category: LogCategory, message: String, source: String):
	var entry = LogEntry.new(level, category, message, source)
	log_entries.append(entry)
	
	# Trim logs if too many
	if log_entries.size() > max_log_entries:
		log_entries = log_entries.slice(log_entries.size() - max_log_entries)
	
	# Emit signal for external listeners
	debug_event_logged.emit(LogCategory.keys()[category], message, LogLevel.keys()[level])
	
	# Console output
	var level_str = LogLevel.keys()[level]
	var category_str = LogCategory.keys()[category]
	print("[%s][%s] %s" % [level_str, category_str, message])

func clear_logs():
	log_entries.clear()
	error_count = 0
	warning_count = 0
	log_info(LogCategory.GENERAL, "Logs cleared")

# =============================================================================
# COLLISION DEBUGGING METHODS
# =============================================================================

func add_collision_visualization(shape_type: String, position: Vector2, size: Vector2, color: Color = Color.RED):
	var debug_data = CollisionDebugData.new(shape_type, position, size, color, 2.0)
	collision_visualizations.append(debug_data)

func clear_collision_visualizations():
	collision_visualizations.clear()
	log_info(LogCategory.COLLISION, "Collision visualizations cleared")

func _draw():
	if collision_debug_enabled:
		for viz_data in collision_visualizations:
			match viz_data.shape_type:
				"circle":
					draw_arc(viz_data.position, viz_data.size.x, 0, TAU, 32, viz_data.color, viz_data.thickness)
				"rectangle":
					draw_rect(Rect2(viz_data.position - viz_data.size/2, viz_data.size), viz_data.color, false, viz_data.thickness)

# =============================================================================
# TESTING FRAMEWORK METHODS
# =============================================================================

func run_all_tests():
	if tests_running:
		log_warning_internal(LogCategory.TESTING, "Tests already running")
		return
	
	tests_running = true
	test_results.clear()
	
	log_info(LogCategory.TESTING, "Starting comprehensive test suite")
	
	# Run tests for each category
	for category in test_categories:
		await run_category_tests(category)
	
	tests_running = false
	update_test_results_display()
	log_info(LogCategory.TESTING, "Test suite completed")

func run_category_tests(category: String):
	match category:
		"Infrastructure":
			await run_infrastructure_tests()
		"Systems":
			await run_system_tests()
		"Performance":
			await run_performance_tests()
		"Player":
			await run_player_tests()
		"Spells":
			await run_spell_tests()
		"Collision":
			await run_collision_tests()

func run_infrastructure_tests():
	log_info(LogCategory.TESTING, "Running infrastructure tests...")
	
	# Test singleton availability
	var gamemanager_exists = GameManager != null
	add_test_result_detailed("GameManager Singleton", gamemanager_exists, "GameManager availability", 0.001, "Infrastructure")
	
	var gameevents_exists = GameEvents != null
	add_test_result_detailed("GameEvents Singleton", gameevents_exists, "GameEvents availability", 0.001, "Infrastructure")
	
	# Test scene tree
	var scene_tree_valid = get_tree() != null
	add_test_result_detailed("Scene Tree", scene_tree_valid, "Scene tree accessibility", 0.001, "Infrastructure")

func run_system_tests():
	log_info(LogCategory.TESTING, "Running system tests...")
	
	# Input system test
	var input_system_ok = Input != null
	add_test_result_detailed("Input System", input_system_ok, "Input system functional", 0.001, "Systems")
	
	# Scene management test
	var scene_manager_ok = get_tree().current_scene != null
	add_test_result_detailed("Scene Management", scene_manager_ok, "Scene management functional", 0.001, "Systems")

func run_performance_tests():
	log_info(LogCategory.TESTING, "Running performance tests...")
	
	performance_metrics.update()
	var fps_ok = performance_metrics.fps >= performance_thresholds.min_fps
	add_test_result_detailed("FPS Performance", fps_ok, "FPS: " + str(performance_metrics.fps), 0.002, "Performance")
	
	var memory_ok = performance_metrics.memory_usage < performance_thresholds.max_memory_mb * 1024 * 1024
	add_test_result_detailed("Memory Usage", memory_ok, "Memory: " + str(performance_metrics.memory_usage / (1024*1024)) + " MB", 0.002, "Performance")

func run_player_tests():
	log_info(LogCategory.TESTING, "Running player tests...")
	
	var player = _get_player()
	var player_exists = player != null
	add_test_result_detailed("Player Entity", player_exists, "Player entity exists", 0.003, "Player")
	
	if player_exists:
		var has_health = player.has_method("take_damage")
		add_test_result_detailed("Player Health System", has_health, "Player health system functional", 0.002, "Player")

func run_spell_tests():
	log_info(LogCategory.TESTING, "Running spell tests...")
	
	var player = _get_player()
	if player:
		var spell_component = player.get_node_or_null("SpellComponent")
		var spell_system_ok = spell_component != null
		add_test_result_detailed("Spell System", spell_system_ok, "Spell component exists", 0.002, "Spells")

func run_collision_tests():
	log_info(LogCategory.TESTING, "Running collision tests...")
	
	# Test collision layer setup
	var collision_ok = Engine.get_singleton("PhysicsServer2D") != null
	add_test_result_detailed("Physics System", collision_ok, "Physics server available", 0.001, "Collision")

func update_test_results_display():
	if main_testing_tab:
		var results_label = main_testing_tab.find_child("TestResultsLabel", true, false)
		if results_label:
			var text = "Test Results:\n"
			var passed_count = 0
			var total_count = test_results.size()
			
			for result in test_results:
				var status = "✅" if result.passed else "❌"
				text += "%s %s (%s): %s\n" % [status, result.test_name, result.category, result.details]
				if result.passed:
					passed_count += 1
			
			text += "\nSummary: %d/%d tests passed (%.1f%%)" % [passed_count, total_count, (float(passed_count)/total_count)*100 if total_count > 0 else 0]
			results_label.text = text

# =============================================================================
# PERFORMANCE MONITORING METHODS
# =============================================================================

func update_debug_displays():
	if main_debug_visible or collision_debug_visible:
		performance_metrics.update()
		
		# Update main debug displays
		if fps_label:
			fps_label.text = "FPS: %.1f" % performance_metrics.fps
		if memory_label:
			memory_label.text = "Memory: %.1f MB" % (performance_metrics.memory_usage / (1024.0 * 1024.0))
		if error_label:
			error_label.text = "Errors: %d | Warnings: %d" % [error_count, warning_count]
		
		# Update system health
		var health_label = main_system_tab.find_child("HealthLabel", true, false) if main_system_tab else null
		if health_label:
			health_label.text = "System Health: " + get_system_health_status()
		
		# Update player status
		if player_status_label:
			var player = _get_player()
			if player:
				var health_comp = player.get_node_or_null("HealthComponent")
				if health_comp:
					player_status_label.text = "Health: %.0f/%.0f\nPosition: (%.0f, %.0f)" % [
						health_comp.current_health, health_comp.max_health,
						player.global_position.x, player.global_position.y
					]
				else:
					player_status_label.text = "Player found but no health component"
			else:
				player_status_label.text = "Player not found"
		
		# Update spell status
		if spell_status_label:
			var player = _get_player()
			if player:
				var spell_comp = player.get_node_or_null("SpellComponent")
				if spell_comp:
					spell_status_label.text = "Spell Component: Active\nMana: %s/%s" % [
						str(spell_comp.current_mana) if "current_mana" in spell_comp else "N/A",
						str(spell_comp.max_mana) if "max_mana" in spell_comp else "N/A"
					]
				else:
					spell_status_label.text = "Spell Component: Not found"
			else:
				spell_status_label.text = "Player not found"
		
		# Update collision status
		if collision_status_label:
			collision_status_label.text = "Status: %s\nPhysics Debug: %s\nVisualizations: %d" % [
				"Enabled" if collision_debug_enabled else "Disabled",
				"On" if get_tree().debug_collisions_hint else "Off",
				collision_visualizations.size()
			]

func check_performance_thresholds():
	performance_metrics.update()
	
	if performance_metrics.fps < performance_thresholds.min_fps:
		performance_threshold_exceeded.emit("fps", performance_metrics.fps, performance_thresholds.min_fps)
		log_warning_internal(LogCategory.PERFORMANCE, "FPS below threshold: %.1f < %.1f" % [performance_metrics.fps, performance_thresholds.min_fps])

# =============================================================================
# QUALITY GATE METHODS
# =============================================================================

func run_quality_gates():
	quality_gates.clear()
	
	log_info(LogCategory.VALIDATION, "Running quality gates...")
	
	# Error threshold gate
	var error_gate = QualityGateResult.new("Error Threshold")
	if error_count > 10:
		error_gate.passed = false
		error_gate.issues.append("Too many errors: " + str(error_count))
		error_gate.score = max(0, 100 - (error_count * 5))
	quality_gates.append(error_gate)
	
	# Performance gate
	var perf_gate = QualityGateResult.new("Performance")
	if performance_metrics.fps < performance_thresholds.min_fps:
		perf_gate.passed = false
		perf_gate.issues.append("FPS below threshold: " + str(performance_metrics.fps))
		perf_gate.score = (performance_metrics.fps / performance_thresholds.min_fps) * 100
	quality_gates.append(perf_gate)
	
	log_info(LogCategory.VALIDATION, "Quality gates executed: %d gates checked" % quality_gates.size())

# =============================================================================
# PUBLIC API METHODS
# =============================================================================

func get_system_health() -> Dictionary:
	return {
		"error_count": error_count,
		"warning_count": warning_count,
		"fps": performance_metrics.fps,
		"memory_usage_mb": performance_metrics.memory_usage / (1024.0 * 1024.0),
		"tests_passed": test_results.filter(func(t): return t.passed).size(),
		"tests_total": test_results.size(),
		"collision_debug_active": collision_debug_enabled,
		"visualizations_count": collision_visualizations.size(),
		"system_health": get_system_health_status()
	}

func export_debug_data() -> Dictionary:
	return {
		"logs": log_entries.map(func(entry): return {
			"timestamp": entry.timestamp,
			"level": LogLevel.keys()[entry.level],
			"category": LogCategory.keys()[entry.category],
			"message": entry.message
		}),
		"test_results": test_results.map(func(test): return {
			"name": test.test_name,
			"passed": test.passed,
			"details": test.details,
			"time": test.execution_time,
			"category": test.category
		}),
		"performance_metrics": {
			"fps": performance_metrics.fps,
			"memory_usage_mb": performance_metrics.memory_usage / (1024.0 * 1024.0),
			"frame_time": performance_metrics.frame_time,
			"node_count": performance_metrics.node_count
		},
		"quality_gates": quality_gates.map(func(gate): return {
			"name": gate.gate_name,
			"passed": gate.passed,
			"issues": gate.issues,
			"score": gate.score
		}),
		"system_health": get_system_health()
	}

# External integration methods for compatibility
func emit_player_health_changed(current: float, maximum: float):
	log_debug(LogCategory.PLAYER, "Health changed: %.0f/%.0f" % [current, maximum])

func emit_enemy_died(enemy_type: String, xp_awarded: int):
	log_debug(LogCategory.GAMEEVENTS, "Enemy died: %s (XP: %d)" % [enemy_type, xp_awarded])
