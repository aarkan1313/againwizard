extends Node
# test_physics_integration.gd - Comprehensive physics system validation
# Purpose: Validate complete movement physics and visual feedback systems
# Usage: Run this script to validate all physics integration components

var test_results: Array[String] = []
var test_passed: int = 0
var test_failed: int = 0

func _ready():
	print("🧪 Starting Physics Integration Test Suite...")
	print("=" * 60)
	
	# Run all test categories
	test_singletons()
	test_input_system()
	test_movement_component()
	test_visual_system()
	test_player_integration()
	test_performance()
	
	# Generate final report
	print_test_results()

func test_singletons() -> void:
	print("\n🔧 Testing Singleton Systems...")
	
	# Test InputHandler
	if InputHandler:
		log_pass("InputHandler singleton exists")
		
		# Test movement input
		var test_vector = InputHandler.get_movement_vector()
		if typeof(test_vector) == TYPE_VECTOR2:
			log_pass("InputHandler.get_movement_vector() returns Vector2")
		else:
			log_fail("InputHandler.get_movement_vector() invalid return type")
		
		# Test dodge input
		var dodge_available = InputHandler.has_method("is_dodge_pressed")
		if dodge_available:
			log_pass("InputHandler.is_dodge_pressed() method exists")
		else:
			log_fail("InputHandler.is_dodge_pressed() method missing")
	else:
		log_fail("InputHandler singleton not found")
	
	# Test GameEvents
	if GameEvents:
		log_pass("GameEvents singleton exists")
		
		# Test player_moved signal
		if GameEvents.has_signal("player_moved"):
			log_pass("GameEvents.player_moved signal exists")
		else:
			log_fail("GameEvents.player_moved signal missing")
	else:
		log_fail("GameEvents singleton not found")

func test_input_system() -> void:
	print("\n🎮 Testing Input System...")
	
	# Test input actions exist
	var required_actions = ["move_left", "move_right", "move_up", "move_down", "dodge"]
	
	for action in required_actions:
		if InputMap.has_action(action):
			log_pass("Input action '" + action + "' exists")
		else:
			log_fail("Input action '" + action + "' missing")
	
	# Test input responsiveness
	if InputHandler:
		var input_status = InputHandler.get_input_status()
		if input_status.length() > 0:
			log_pass("InputHandler provides debug information")
		else:
			log_fail("InputHandler debug information unavailable")

func test_movement_component() -> void:
	print("\n🏃 Testing MovementComponent...")
	
	# Create test MovementComponent
	var movement_comp = preload("res://scripts/components/MovementComponent.gd").new()
	
	if movement_comp:
		log_pass("MovementComponent can be instantiated")
		
		# Test required methods
		var required_methods = [
			"setup", "physics_update", "can_dodge", "get_current_speed", 
			"is_moving", "get_movement_state", "get_movement_debug_info"
		]
		
		for method in required_methods:
			if movement_comp.has_method(method):
				log_pass("MovementComponent." + method + "() exists")
			else:
				log_fail("MovementComponent." + method + "() missing")
		
		# Test properties
		var expected_properties = [
			"base_speed", "acceleration", "friction", "dodge_speed", 
			"dodge_duration", "dodge_cooldown"
		]
		
		for prop in expected_properties:
			if prop in movement_comp:
				log_pass("MovementComponent." + prop + " property exists")
			else:
				log_fail("MovementComponent." + prop + " property missing")
		
		movement_comp.queue_free()
	else:
		log_fail("MovementComponent cannot be instantiated")

func test_visual_system() -> void:
	print("\n🎨 Testing PlayerVisuals System...")
	
	# Create test PlayerVisuals
	var visuals_comp = preload("res://scripts/components/PlayerVisuals.gd").new()
	
	if visuals_comp:
		log_pass("PlayerVisuals can be instantiated")
		
		# Test required methods
		var required_methods = [
			"setup", "on_dodge_start", "on_dodge_end", "on_damage_taken", 
			"on_healing_received", "reset_all_effects", "get_visual_status"
		]
		
		for method in required_methods:
			if visuals_comp.has_method(method):
				log_pass("PlayerVisuals." + method + "() exists")
			else:
				log_fail("PlayerVisuals." + method + "() missing")
		
		# Test effect properties
		var expected_properties = [
			"dodge_transparency", "damage_flash_color", "effect_duration"
		]
		
		for prop in expected_properties:
			if prop in visuals_comp:
				log_pass("PlayerVisuals." + prop + " property exists")
			else:
				log_fail("PlayerVisuals." + prop + " property missing")
		
		visuals_comp.queue_free()
	else:
		log_fail("PlayerVisuals cannot be instantiated")

func test_player_integration() -> void:
	print("\n🧙 Testing Player Integration...")
	
	# Test Player scene exists
	var player_scene_path = "res://scenes/gameplay/Player.tscn"
	if ResourceLoader.exists(player_scene_path):
		log_pass("Player.tscn scene exists")
		
		# Load and test Player scene
		var player_scene = load(player_scene_path)
		if player_scene:
			log_pass("Player.tscn loads successfully")
			
			# Test scene can be instantiated
			var player_instance = player_scene.instantiate()
			if player_instance:
				log_pass("Player scene can be instantiated")
				
				# Test required components
				var required_components = ["MovementComponent", "HealthComponent", "PlayerVisuals"]
				
				for comp in required_components:
					var component = player_instance.get_node_or_null(comp)
					if component:
						log_pass("Player has " + comp + " component")
					else:
						log_fail("Player missing " + comp + " component")
				
				# Test sprite and collision
				if player_instance.get_node_or_null("PlayerSprite"):
					log_pass("Player has PlayerSprite")
				else:
					log_fail("Player missing PlayerSprite")
				
				if player_instance.get_node_or_null("PlayerCollision"):
					log_pass("Player has PlayerCollision")
				else:
					log_fail("Player missing PlayerCollision")
				
				player_instance.queue_free()
			else:
				log_fail("Player scene cannot be instantiated")
		else:
			log_fail("Player.tscn cannot be loaded")
	else:
		log_fail("Player.tscn scene not found")

func test_performance() -> void:
	print("\n⚡ Testing Performance Characteristics...")
	
	# Test component memory usage
	var movement_comp = preload("res://scripts/components/MovementComponent.gd").new()
	var visuals_comp = preload("res://scripts/components/PlayerVisuals.gd").new()
	
	if movement_comp and visuals_comp:
		log_pass("Components instantiate without memory issues")
		
		# Test Tween creation (common performance bottleneck)
		var test_tween = visuals_comp.create_tween()
		if test_tween:
			log_pass("PlayerVisuals can create Tween objects")
			test_tween.kill()
		else:
			log_fail("PlayerVisuals cannot create Tween objects")
		
		movement_comp.queue_free()
		visuals_comp.queue_free()
	else:
		log_fail("Component instantiation failed - memory issues")
	
	# Test screen size handling
	var screen_size = get_viewport().get_visible_rect().size
	if screen_size.x > 0 and screen_size.y > 0:
		log_pass("Screen size detection works: " + str(screen_size))
	else:
		log_fail("Screen size detection failed")

func log_pass(message: String) -> void:
	test_results.append("✅ " + message)
	test_passed += 1
	print("✅ " + message)

func log_fail(message: String) -> void:
	test_results.append("❌ " + message)
	test_failed += 1
	print("❌ " + message)

func print_test_results() -> void:
	print("\n" + "=" * 60)
	print("🧪 PHYSICS INTEGRATION TEST RESULTS")
	print("=" * 60)
	
	print("\n📊 SUMMARY:")
	print("✅ Passed: " + str(test_passed))
	print("❌ Failed: " + str(test_failed))
	print("📋 Total:  " + str(test_passed + test_failed))
	
	var success_rate = float(test_passed) / float(test_passed + test_failed) * 100
	print("🎯 Success Rate: " + str(success_rate) + "%")
	
	if test_failed == 0:
		print("\n🎉 ALL TESTS PASSED! Physics integration is COMPLETE!")
		print("✨ System is ready for Phase 2: Spellcasting")
	else:
		print("\n⚠️  SOME TESTS FAILED - Review implementation")
		print("🔧 Failed tests need attention before proceeding")
	
	print("\n🎮 MANUAL TESTING INSTRUCTIONS:")
	print("1. Run the game (F5)")
	print("2. Test WASD movement - should be smooth and responsive")
	print("3. Test Space key dodge - should show transparency effect")
	print("4. Test screen boundaries - player should stay within bounds")
	print("5. Check console for debug messages during movement")
	
	print("\n📋 DETAILED RESULTS:")
	for result in test_results:
		print(result)
	
	print("\n" + "=" * 60)

# Automated test runner
func run_physics_tests() -> bool:
	_ready()
	return test_failed == 0